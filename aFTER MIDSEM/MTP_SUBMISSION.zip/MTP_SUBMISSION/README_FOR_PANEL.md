# Evidence checks for clinical trial screening

Open **MTP_Evaluation.pptx** for the evaluation deck and **MTP_Final_Report.pdf** for the technical report. **CLOSEOUT_ADDENDUM.md** and **CLOSEOUT_EVIDENCE_NO_NOTES.json** record the verified 9 November results used for this submission.

**MTP_TOOL_CANDIDATE.zip** contains the runnable source and synthetic demonstration. After extracting the source ZIP, run the following from its MTP_TOOL directory in the project Python environment:

    python mtp_week_delivery.py self-test

The synthetic test exercises evidence checking, deferral and rechecking a proposed repair without model calls. The paired development comparison and the separate checker coverage are documented in the report. The package contains aggregate evidence rather than raw notes or label sheets.
