#!/usr/bin/env python3
"""Freeze a shareable, notes-free snapshot of existing MTP outputs. Offline only."""
import argparse
import csv
from datetime import datetime
import hashlib
import io
import json
import os
from pathlib import Path
from zoneinfo import ZoneInfo

DATASETS = {"nsclc100": ("NSCLC-100", 50, 950, 25), "sigir204": ("SIGIR-204", 102, 990, 49)}
MODES = {"unknown": "Allow unknown", "forced": "Forced guess"}
MODEL = "qwen2.5:7b"
INDEX = "outputs/mtp_parallel/REPORT_INDEX.json"
PRED = "outputs/plain_ai_qwen_dev.jsonl"
CHECKS = "outputs/mtp_completion/nsclc100/dev/plain_ai_qwen_dev_checks_theta95_fallback_exploratory.jsonl"
PILOT = "outputs/mtp_next_jobs/nsclc_reask_pilot"
PAIR_SHA_KEYS = ("corpus_sha256", "criteria_sha256", "splits_sha256")
CHECKER_LABELS = {"HALLUCINATED_EVIDENCE", "CONTEXT_ERROR", "LOGIC_ERROR", "CONTRADICTED",
                  "UNSUPPORTED", "MISSED_EVIDENCE", "VERIFIED"}
COLS = ("dataset", "mode", "pairs", "reference_eligible", "reference_ineligible", "eligible_found",
        "hard_wrong_exclusions", "wrong_inclusions", "review")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def load_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def pair_data(root, entry, ds):
    _, pairs, criteria, eligible = DATASETS[ds]
    path = (root / entry["results"]).resolve()
    if not path.is_relative_to(root / "outputs"):
        raise ValueError("Report index points outside project outputs")
    rpt = load_json(path)
    if (rpt["dataset"], rpt["split"], rpt["subject_models"]) != (ds, "dev", [MODEL]):
        raise ValueError("Pair report is not the expected Qwen development run")
    sources = rpt["sources"]
    if any(not sources.get(k) for k in (*PAIR_SHA_KEYS, "pred_sha256")):
        raise ValueError("Pair report has incomplete input provenance")
    csv_path = path.with_name("pair_decisions.csv")
    raw = csv_path.read_bytes()
    rows = {}
    for row in csv.DictReader(io.StringIO(raw.decode("utf-8-sig"), newline="")):
        k = int(row["pair_idx"])
        ref = int(row["reference"])
        n = int(row["n_rules"])
        decision = row["decision"]
        if (k in rows or ref not in (0, 1) or n < 1 or decision not in
                ("ELIGIBLE", "NOT_ELIGIBLE", "REVIEW") or not row["trial_id"] or not row["cluster"]):
            raise ValueError("Invalid, duplicate or incomplete pair decision")
        rows[k] = ((row["trial_id"], row["cluster"], n, ref), decision)
    if (len(rows) != pairs or sum(x[0][2] for x in rows.values()) != criteria
            or sum(x[0][3] for x in rows.values()) != eligible):
        raise ValueError("Pair report does not cover the expected development cohort")
    return rows, sources, {"path": str(csv_path.relative_to(root)), "sha256": digest(raw)}


def matched(root):
    index = load_json(root / INDEX)
    out = []
    for ds, (name, pairs, _, eligible) in DATASETS.items():
        runs = {m: pair_data(root, index[f"{ds}_{m}"], ds) for m in MODES}
        u, a, _ = runs["unknown"]
        f, b, _ = runs["forced"]
        if any(a[k] != b[k] for k in PAIR_SHA_KEYS) or a["pred_sha256"] == b["pred_sha256"]:
            raise ValueError("The modes do not use matched inputs and distinct predictions")
        if {k: v[0] for k, v in u.items()} != {k: v[0] for k, v in f.items()}:
            raise ValueError("The two modes disagree on pair identities or reference labels")
        for mode, label in MODES.items():
            rows, _, artifact = runs[mode]
            tp = sum(ref == 1 and decision == "ELIGIBLE" for (_, _, _, ref), decision in rows.values())
            fp = sum(ref == 0 and decision == "ELIGIBLE" for (_, _, _, ref), decision in rows.values())
            out.append({
                "dataset": name, "mode": label, "pairs": pairs, "reference_eligible": eligible,
                "reference_ineligible": pairs - eligible, "eligible_found": tp, "wrong_inclusions": fp,
                "hard_wrong_exclusions": sum(ref == 1 and decision == "NOT_ELIGIBLE"
                                             for (_, _, _, ref), decision in rows.values()),
                "review": sum(d == "REVIEW" for _, d in rows.values()),
                "binary_accuracy": (tp + pairs - eligible - fp) / pairs,
                "eligible_recall": tp / eligible, "eligible_f1": 2 * tp / (tp + eligible + fp),
                "source": artifact,
            })
    return out


def unique_rows(raw):
    rows = {}
    for line in raw.splitlines():
        if not line.strip():
            continue
        r = json.loads(line)
        k = (int(r["pair_idx"]), int(r["crit_idx"]))
        if k in rows:
            raise ValueError("Duplicate prediction or checker case ID")
        rows[k] = r
    return rows


def checker(root):
    pred_raw = (root / PRED).read_bytes()
    pred = unique_rows(pred_raw)
    if len(pred) != 950 or len({p for p, _ in pred}) != 50:
        raise ValueError("Legacy baseline does not cover 950 criterion answers and 50 pairs")
    raw = (root / CHECKS).read_bytes()
    prefix = raw[:raw.rfind(b"\n") + 1]
    checks = unique_rows(prefix)
    if not checks:
        raise ValueError("No complete checker records found")
    for k, row in checks.items():
        if k not in pred or row.get("label") not in CHECKER_LABELS:
            raise ValueError("Checker contains an unexpected record")
        baseline_hash = digest(json.dumps(pred[k], sort_keys=True, ensure_ascii=False).encode())
        if row.get("provenance", {}).get("source_answer_hash") != baseline_hash:
            raise ValueError("Checker provenance does not match the saved legacy baseline")
    complete = {p for p, _ in pred} - {p for p, _ in pred.keys() - checks.keys()}
    return {
        "saved": len(checks), "expected": len(pred), "fully_checked_pairs": len(complete),
        "expected_pairs": 50, "pred_sha256": digest(pred_raw),
        "complete_checkpoint_prefix_sha256": digest(prefix), "ignored_final_bytes": len(raw) - len(prefix),
        "path": CHECKS, "scope": "Legacy NSCLC development checker coverage",
    }


def pilot(root):
    p = root / PILOT
    s = load_json(p / "STATUS_NO_NOTES.json")
    records = list(p.glob("case_*.json"))
    if int(s["saved"]) != len(records) or int(s["planned"]) < len(records):
        raise ValueError("Pilot status and saved record count disagree")
    keys = set()
    usable = 0
    for path in records:
        r = load_json(path)
        m = r["case"]
        k = (int(m["pair_idx"]), int(m["crit_idx"]))
        if (k in keys or r["accepted"] is not False or r["status"] not in
                ("DRAFT_AWAITING_RECHECK", "UNPARSEABLE")):
            raise ValueError("Pilot records are not unique unrechecked draft records")
        keys.add(k)
        usable += r["status"] == "DRAFT_AWAITING_RECHECK"
    if usable != int(s["usable_drafts"]):
        raise ValueError("Pilot usable-draft count is inconsistent")
    return {"saved": len(records), "planned": int(s["planned"]), "usable_drafts": usable,
            "scope": "Pilot records awaiting recheck", "path": PILOT + "/STATUS_NO_NOTES.json"}


def saved_strategy_report(root, check):
    if check is None:
        return None
    names = ("random", "least_confident", "flagged_first", "fewest_reasons", "combined")
    for path in sorted((root / "outputs/mtp_checker_work").glob("results_*/RESULTS_NO_NOTES.json"), reverse=True):
        try:
            data = load_json(path)
            if (data.get("dataset"), data.get("split")) != ("nsclc100", "dev"):
                continue
            if any(data.get("inputs", {}).get(k) != check[k]
                   for k in ("pred_sha256", "complete_checkpoint_prefix_sha256")):
                continue
            coverage = data["coverage"]
            if coverage["saved_checks"] != check["saved"] or coverage["fully_checked_pairs"] != check["fully_checked_pairs"]:
                continue
            sim = data["K1_review_strategies"]
            selected = []
            for name in names:
                r = next(r for r in sim["strategies"][name] if r["budget"] == 50)
                selected.append({"strategy": name, "actual_checks": int(r["actual_checks"]),
                                 "net_simulated_rescues": int(r["rescued"]),
                                 "unknown_effect_checks": int(r["unknown_effect_checks"])})
            return {"complete_pairs": check["fully_checked_pairs"], "k1_budget_50": selected,
                    "scope": "Development simulation on complete pairs; not an observed clinical repair",
                    "source": str(path.relative_to(root)), "source_sha256": digest(path.read_bytes())}
        except (OSError, KeyError, ValueError, TypeError, StopIteration):
            continue
    return None


def capture(fn, root, key, out):
    try:
        out[key] = fn(root)
    except FileNotFoundError as exc:
        out["unverified"][key] = "Saved input not found: " + Path(exc.filename).name
    except (OSError, KeyError, ValueError, TypeError) as exc:
        out["unverified"][key] = str(exc) if type(exc) is ValueError else type(exc).__name__


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    args = parser.parse_args()
    root = args.root.resolve()
    if not (root / "outputs").is_dir():
        parser.error("--root must point to the project containing outputs/")
    os.umask(0o077)
    now = datetime.now(ZoneInfo("Asia/Calcutta"))
    original = load_json(Path(__file__).with_name("RESULTS_SNAPSHOT.json"))
    out = {"captured_at_ist": now.isoformat(), "scope": "Verified saved development evidence; no model calls",
           "unverified": {}, "held_out": "Not checked in this closeout"}
    capture(matched, root, "paired_development", out)
    capture(checker, root, "checker", out)
    capture(pilot, root, "reask", out)
    if out.get("paired_development"):
        normalize = lambda rows: [[r[k] for k in COLS] for r in rows]
        out["paired_metrics_agree_with_deck"] = (
            normalize(out["paired_development"]) == normalize(original["paired_development"])
        )
    sim = saved_strategy_report(root, out.get("checker"))
    if sim:
        out["saved_strategy_simulation"] = sim
    path = root / "outputs/mtp_closeout" / now.strftime("closeout_%Y%m%d_%H%M%S_%f_IST")
    path.mkdir(parents=True, exist_ok=False)
    (path / "CLOSEOUT_EVIDENCE_NO_NOTES.json").write_text(json.dumps(out, indent=2, allow_nan=False) + "\n",
                                                       encoding="utf-8")
    text = ["# Closeout evidence addendum", "", f"Captured {now.strftime('%d %B %Y, %H:%M IST')}. Saved development outputs only.", ""]
    if out.get("paired_development"):
        text += ["## Matched Qwen development comparison", "",
                 "| Dataset | Mode | Pairs | Wrong exclusions / eligible | Review | Wrong inclusions | Binary accuracy |",
                 "|---|---|---:|---:|---:|---:|---:|"]
        for r in out["paired_development"]:
            text.append(f"| {r['dataset']} | {r['mode']} | {r['pairs']} | {r['hard_wrong_exclusions']}/{r['reference_eligible']} | "
                        f"{r['review']} | {r['wrong_inclusions']} | {r['binary_accuracy']:.1%} |")
        text += ["", "Binary accuracy counts REVIEW as negative.", ""]
        if not out["paired_metrics_agree_with_deck"]:
            text += ["**The on-disk paired metrics differ from the recorded deck snapshot. Review the provenance and use this table for the on-disk run.**", ""]
    if "checker" in out:
        c = out["checker"]
        text += [f"**Legacy NSCLC checker: {c['saved']} / {c['expected']} saved.** "
                 f"{c['fully_checked_pairs']} / {c['expected_pairs']} pairs have all criteria checked. Coverage does not establish correctness.", ""]
    if "reask" in out:
        r = out["reask"]
        text += [f"**Pilot: {r['saved']} / {r['planned']} records saved, {r['usable_drafts']} parseable drafts.** "
                 "Acceptance requires a verified recheck.", ""]
    if sim:
        text += ["## Saved prioritization simulation", "",
                 f"Eligible for this saved analysis: {sim['complete_pairs']} complete pairs. "
                 "Counts are net simulated rescues at a nominal budget of 50.", "",
                 "| Strategy | Checks used | Net simulated rescues | Unknown effects |",
                 "|---|---:|---:|---:|"]
        for r in sim["k1_budget_50"]:
            text.append(f"| {r['strategy']} | {r['actual_checks']} | {r['net_simulated_rescues']} | {r['unknown_effect_checks']} |")
        text.append("")
    if out["unverified"]:
        text += ["## Saved sources that could not be verified", ""]
        text += [f"- {name}: {reason}" for name, reason in out["unverified"].items()]
        text += ["", "Use the package's recorded snapshot for the corresponding historical numbers.", ""]
    text += ["This file contains aggregate results only. No patient notes, model calls, or held-out results.", ""]
    (path / "CLOSEOUT_ADDENDUM.md").write_text("\n".join(text), encoding="utf-8")
    print("SAVED CLOSEOUT:", path)
    if "checker" in out:
        print(f"Verified legacy NSCLC checker: {out['checker']['saved']} / {out['checker']['expected']}")
    if out["unverified"]:
        print("Review the unverified sources listed in CLOSEOUT_ADDENDUM.md.")
    print("Model calls: 0")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
