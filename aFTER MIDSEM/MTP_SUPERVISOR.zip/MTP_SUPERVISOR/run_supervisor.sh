#!/usr/bin/env bash
set -euo pipefail
cd "$HOME/MTP/Akash_Kit"
if [[ -z "${GROQ_API_KEY:-}" ]]; then
  read -r -s -p 'Paste your active Groq API key, then Enter: ' GROQ_API_KEY
  printf '\n'
fi
export GROQ_API_KEY
exec .venv/bin/python -u mtp_supervisor.py --root "$PWD" --hours 24 --max-attempts 2500 --max-restarts 30
