MTP SUPERVISOR — NSCLC DEVELOPMENT CHECKER

Install: copy mtp_supervisor.py and run_supervisor.sh into ~/MTP/Akash_Kit.
Run: bash run_supervisor.sh
Self-test: .venv/bin/python mtp_supervisor.py --self-test
Monitor: cat outputs/mtp_supervisor/STATUS.json
Logs: outputs/mtp_supervisor/<session>/console.log

Scope: resumes the existing 950-row exploratory NSCLC development checker,
using the same saved predictions, fallback statements, theta=95 and output path.
No original code, labels, input statements, cache entries, or held-out data is edited.
The checker itself appends results and updates its existing manifest as usual.

Defaults per launch: 24 wall-clock hours, at most 2,500 API attempts, at most
30 automatic restarts. No fixed token or monetary cap is imposed. Each API
completion remains capped by the existing client's 2,048 output-token setting.
Usage continues in outputs/mtp_completion/cache/groq/API_USAGE.jsonl.
The attempt counter reserves one attempt before every actual completion request,
including retries. A new manual launch starts a new session/budget; cached
responses and the existing row checkpoint remain reusable.

Only HTTP 429 and 500/502/503/504 trigger automatic delayed restart. Retry-After
is respected; long waits are bounded by the session deadline. Authentication,
invalid JSON/semantic responses, configuration errors and ambiguous network
failures stop with NEEDS_ATTENTION. It does not rotate accounts, rewrite labels,
change prompts, bypass validation, or silently skip rows. No report/held-out run
starts automatically. Missing inputs are reported rather than fabricated.

Keep the terminal open and prevent machine sleep. Ctrl+C stops and retains
checkpoints. Do not run a second completion job alongside the supervisor.
An additional supervisor is prevented by an OS lock; the existing project's
own lock protects against other completion processes.

Verification: standard-library self-tests cover classification, atomic status
and duplicate-safe coverage. Worker integration tests use a fake transport;
no real Groq calls or clinical data used during testing. Live API behaviour
and clinical checker accuracy still require verification in your environment.
