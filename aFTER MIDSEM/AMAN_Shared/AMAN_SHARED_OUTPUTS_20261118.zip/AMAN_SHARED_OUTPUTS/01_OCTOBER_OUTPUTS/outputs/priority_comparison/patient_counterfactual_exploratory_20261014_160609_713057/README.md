# Exploratory Patient-Level Counterfactuals

Each one-rule row replaces ONE baseline truth with an assistant-proposed truth, maps it to a criterion verdict by inclusion/exclusion kind, and recalculates NOT_ELIGIBLE / REVIEW / ELIGIBLE over ALL other baseline criteria for that same dataset and pair.

The simultaneous analysis applies all proposed disagreements in a pair together, avoiding duplicate counting of the same pair.

**Important limitations:** No independent ground-truth adjudications. The 44-case annotation cohort was assembled from top-ten ranking lists and is selection-biased. This is a diagnostic simulation, not a clinically verified rescue study. Do not interpret a removal of NOT_ELIGIBLE as confirmed eligibility or clinical benefit.

Inputs were read without modification. This command performed no Ollama inference.
