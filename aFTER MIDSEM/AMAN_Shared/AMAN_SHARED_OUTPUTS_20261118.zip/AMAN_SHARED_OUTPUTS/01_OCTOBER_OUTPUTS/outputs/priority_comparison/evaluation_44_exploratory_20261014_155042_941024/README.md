# MTP exploratory equal-budget evaluation (44 selected cases)

Created: 2026-10-14T15:50:42
Ranking universe: 1940 criterion records per strategy; 44 distinct annotated cases in the selected cohort.

## Inputs
- top10_blinded_annotation.csv: user's preserved manual selections plus assistant proposals.
- top10_baseline_comparison_key.csv: held-out baseline answers revealed only during evaluation.
- priority_rankings.csv: unchanged five-method ranking of the full criterion universe.

## Outputs
- case_level_comparison.csv: one record per annotated case, baseline and proposal labels, tier flags, and all 5 ranks. No patient notes copied.
- equal_budget_within_44_cohort.csv: for each strategy at review budgets 5/10/20/30/44, take that many cases **from the already selected union of 44 cases**. Same sample size across strategies, but this is a biased, strategy-selected cohort, not an external evaluation set. The same 44 cases are used for every strategy.
- equal_budget_global_top_b_coverage.csv: for budgets 10/25/50/100/200 in the full 1940-criterion universe, only the already annotated cases in each top-B set can be scored. **Unreviewed cases are missing labels, NOT assumed correct.** Do not compare raw discrepancy counts if coverage differs.
- cohort_ranking_order.csv: case IDs in each strategy's rank order restricted to 44 cases.
- evaluation_metadata.json: basic input counts and methodological warnings.

## Interpretation and caveats
**assistant_baseline_disagreements** counts discrepancies between baseline model truth label and assistant-proposed truth label. It does NOT mean confirmed AI errors, patient rescues, or independent correctness. A proposed `unknown` is compared as its own label, and `defer` is excluded from the scorable denominator.

**explicit_proposal_disagreements** counts only cases marked EXPLICIT_EVIDENCE_PRELIMINARY in the assistant annotations; a quotation existing in a patient note is not an independent adjudication, and some medical criteria need protocol/context review.

**manual_preliminary_disagreements** counts only manual records marked EVIDENCE_SUPPORTED_PRELIMINARY; these are not independent adjudications. USER_CONFIRMED alone does not establish clinical correctness. PENDING_EVIDENCE, DEFERRED, and UNREVIEWED manually remain unverified.

**Major design limitations:** Cases were preselected as the union of the top ten from the five ranked strategies, so rankings influence entry into the cohort (selection bias). Earlier cases/criteria were already examined in conversation (exposure). Assistant and baseline are both model-based; the assistant proposal is not blind independent human ground truth. Decision-impact-based retrieval of sole-rejection flags partly shares the defining logic of the candidate outcome (circularity). The five methods can be described descriptively within this cohort, not tested for independent real-world rescue superiority. Prioritize independent adjudication across a stratified or held-out random selection before inferential claims.

**Scope:** Criterion-level truth-label disagreement only. No counterfactual pair-decision recalculation, no audited repair, no patient-level recovery, no confusion-matrix model accuracy, and no new Ollama inference. `reference_pair_target` intentionally excluded as a criterion-level gold label.
