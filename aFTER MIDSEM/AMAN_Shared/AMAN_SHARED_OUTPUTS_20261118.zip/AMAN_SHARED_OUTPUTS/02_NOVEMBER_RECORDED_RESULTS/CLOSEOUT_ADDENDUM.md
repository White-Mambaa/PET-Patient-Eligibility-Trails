# Closeout evidence addendum

Captured 09 November 2026, 20:27 IST. Saved development outputs only.

## Matched Qwen development comparison

| Dataset | Mode | Pairs | Wrong exclusions / eligible | Review | Wrong inclusions | Binary accuracy |
|---|---|---:|---:|---:|---:|---:|
| NSCLC-100 | Allow unknown | 50 | 12/25 | 16 | 0 | 50.0% |
| NSCLC-100 | Forced guess | 50 | 22/25 | 0 | 0 | 56.0% |
| SIGIR-204 | Allow unknown | 102 | 15/49 | 72 | 0 | 53.9% |
| SIGIR-204 | Forced guess | 102 | 43/49 | 0 | 0 | 57.8% |

Binary accuracy counts REVIEW as negative.

**Legacy NSCLC checker: 706 / 950 saved.** 36 / 50 pairs have all criteria checked. Coverage does not establish correctness.

**Pilot: 20 / 20 records saved, 20 parseable drafts.** Acceptance requires a verified recheck.

This file contains aggregate results only. No patient notes, model calls, or held-out results.
