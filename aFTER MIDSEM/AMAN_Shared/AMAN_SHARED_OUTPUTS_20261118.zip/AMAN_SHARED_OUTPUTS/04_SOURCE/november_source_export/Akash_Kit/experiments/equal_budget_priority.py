import csv
import random
from pathlib import Path
from collections import defaultdict

ROOT = Path("outputs")
OUT = ROOT / "priority_comparison"
OUT.mkdir(parents=True, exist_ok=True)

def load_csv(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))

def key(row):
    return (
        row["dataset"],
        int(row["pair_idx"]),
        int(row["crit_idx"]),
    )

def flag(value):
    return str(value).strip().lower() == "true"

def confidence(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return 1.0

impact = load_csv(
    ROOT / "decision_impact/real_priority_analysis.csv"
)

citations = {
    key(r): r
    for r in load_csv(
        ROOT / "evidence_checks/real_citation_results.csv"
    )
}

candidates = {
    key(r): r
    for r in load_csv(
        ROOT / "decision_impact/rescue_review_queue_with_labels.csv"
    )
    if r["reference_target"] == "Eligible"
}

rows = []

for r in impact:
    k = key(r)
    citation = citations.get(k, {})

    status = citation.get("citation_status", "UNKNOWN")

    sole = flag(r["sole_rejection"])
    near = flag(r["near_sole_rejection"])
    changing = flag(r["decision_changing"])

    if sole:
        impact_rank = 3
    elif near:
        impact_rank = 2
    elif changing:
        impact_rank = 1
    else:
        impact_rank = 0

    citation_rank = {
        "FAIL": 2,
        "NO_EVIDENCE": 1,
        "PASS": 0,
    }.get(status, 0)

    conf = confidence(r["confidence"])

    combined_score = (
        impact_rank * 10
        + citation_rank * 3
        + (1 - conf)
    )

    rows.append({
        "dataset": k[0],
        "pair_idx": k[1],
        "crit_idx": k[2],
        "confidence": conf,
        "citation_status": status,
        "impact_rank": impact_rank,
        "citation_rank": citation_rank,
        "combined_score": combined_score,
        "eligible_rejection_candidate": int(k in candidates),
    })

rng = random.Random(42)
random_rows = rows.copy()
rng.shuffle(random_rows)

strategies = {
    "random": random_rows,
    "confidence": sorted(
        rows,
        key=lambda r: (
            r["confidence"],
            r["dataset"],
            r["pair_idx"],
            r["crit_idx"],
        ),
    ),
    "citation": sorted(
        rows,
        key=lambda r: (
            -r["citation_rank"],
            r["confidence"],
            r["dataset"],
            r["pair_idx"],
            r["crit_idx"],
        ),
    ),
    "decision_impact": sorted(
        rows,
        key=lambda r: (
            -r["impact_rank"],
            r["confidence"],
            r["dataset"],
            r["pair_idx"],
            r["crit_idx"],
        ),
    ),
    "combined": sorted(
        rows,
        key=lambda r: (
            -r["combined_score"],
            r["dataset"],
            r["pair_idx"],
            r["crit_idx"],
        ),
    ),
}

budgets = [25, 50, 100, 200]
summary = []

for name, ranked in strategies.items():
    for budget in budgets:
        selected = ranked[:budget]

        summary.append({
            "strategy": name,
            "budget": budget,
            "eligible_rejection_candidates_found": sum(
                r["eligible_rejection_candidate"]
                for r in selected
            ),
            "citation_fail_selected": sum(
                r["citation_status"] == "FAIL"
                for r in selected
            ),
            "sole_rejection_selected": sum(
                r["impact_rank"] == 3
                for r in selected
            ),
            "decision_impact_selected": sum(
                r["impact_rank"] > 0
                for r in selected
            ),
        })

summary_path = OUT / "equal_budget_summary.csv"

with open(summary_path, "w", newline="") as f:
    writer = csv.DictWriter(
        f,
        fieldnames=list(summary[0].keys()),
    )
    writer.writeheader()
    writer.writerows(summary)

ranking_path = OUT / "priority_rankings.csv"

with open(ranking_path, "w", newline="") as f:
    writer = csv.DictWriter(
        f,
        fieldnames=[
            "strategy",
            "rank",
            *list(rows[0].keys()),
        ],
    )
    writer.writeheader()

    for name, ranked in strategies.items():
        for rank, row in enumerate(ranked, start=1):
            writer.writerow({
                "strategy": name,
                "rank": rank,
                **row,
            })

print("\nEQUAL-BUDGET PRIORITY COMPARISON")
print("Total criterion predictions:", len(rows))
print("Reference-eligible rejection candidates:", len(candidates))
print("Strategies:", len(strategies))

print("\nRESULTS")
print(
    f"{'Strategy':<18}"
    f"{'Budget':>8}"
    f"{'Candidates':>13}"
    f"{'Citation FAIL':>16}"
    f"{'Sole reject':>14}"
)

for r in summary:
    print(
        f"{r['strategy']:<18}"
        f"{r['budget']:>8}"
        f"{r['eligible_rejection_candidates_found']:>13}"
        f"{r['citation_fail_selected']:>16}"
        f"{r['sole_rejection_selected']:>14}"
    )

print("\nSaved:", summary_path)
print("Saved:", ranking_path)
