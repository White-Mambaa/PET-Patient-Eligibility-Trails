"""Small Groq development pilot using the existing MTP screening pipeline."""
import datetime
import json
import os
from pathlib import Path
import sys
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "code"))

import plain_ai
from llm_client import LocalLLM, CallFailed

MODEL = "openai/gpt-oss-20b"
ENDPOINT = "https://api.groq.com/openai/v1/chat/completions"
KEY = os.environ.get("GROQ_API_KEY", "").strip()
REQUEST_LIMIT = 10
QUESTION_LIMIT = 5

if not KEY:
    raise SystemExit("GROQ_API_KEY is missing in this terminal.")

stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
RUN = ROOT / "outputs" / "groq_dev_pilot" / stamp
RUN.mkdir(parents=True, exist_ok=False)
USAGE = RUN / "api_usage.jsonl"
STATE = {"requests": 0, "prompt_tokens": 0, "completion_tokens": 0}

class GroqLLM(LocalLLM):
    def __init__(self, model, *args, **kwargs):
        kwargs.update(
            max_output=1024,
            timeout=90,
            call_retries=0,
            parse_retries=0,
        )
        super().__init__(model, *args, **kwargs)
        # Actual API settings also form part of the inherited cache key.
        self.options = {
            "provider": "groq",
            "endpoint": ENDPOINT,
            "temperature": 0,
            "reasoning_effort": "low",
            "max_completion_tokens": 1024,
            "response_format": {"type": "json_object"},
        }

    def check_model_available(self):
        # Connection and generation already verified by the smoke test.
        pass

    def _send(self, system, user):
        if STATE["requests"] >= REQUEST_LIMIT:
            raise CallFailed("Pilot request limit reached.")

        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "temperature": 0,
            "reasoning_effort": "low",
            "max_completion_tokens": 1024,
            "response_format": {"type": "json_object"},
            "stream": False,
        }
        request = urllib.request.Request(
            ENDPOINT,
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Authorization": "Bearer " + KEY,
                "Content-Type": "application/json",
                "User-Agent": "MTP-Groq-Dev-Pilot/1.0",
            },
            method="POST",
        )

        STATE["requests"] += 1
        number = STATE["requests"]
        log = {"request_number": number, "requested_model": self.model}

        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                result = json.load(response)
        except urllib.error.HTTPError as error:
            # Do not print response bodies containing submitted clinical text.
            log.update(status="http_error", http_status=error.code)
            with USAGE.open("a", encoding="utf-8") as f:
                f.write(json.dumps(log) + "\n")
            raise CallFailed(
                f"Groq HTTP {error.code}; request logged; no automatic retry."
            ) from None
        except (
            urllib.error.URLError, TimeoutError, OSError, ValueError
        ):
            log.update(status="transport_or_json_error")
            with USAGE.open("a", encoding="utf-8") as f:
                f.write(json.dumps(log) + "\n")
            raise CallFailed(
                "Groq connection/response failure; no automatic retry."
            ) from None

        usage = result.get("usage") or {}
        log.update(
            status="response_received",
            returned_model=result.get("model"),
            response_id=result.get("id"),
            usage=usage,
        )
        with USAGE.open("a", encoding="utf-8") as f:
            f.write(json.dumps(log) + "\n")

        STATE["prompt_tokens"] += usage.get("prompt_tokens", 0) or 0
        STATE["completion_tokens"] += usage.get("completion_tokens", 0) or 0

        try:
            choice = result["choices"][0]
            content = choice["message"].get("content") or ""
            finish = choice.get("finish_reason")
        except (KeyError, IndexError, TypeError):
            raise CallFailed("Groq returned an unexpected response structure.")

        if finish != "stop":
            raise CallFailed(
                f"Response finish reason {finish!r}; not accepted as a completed answer."
            )

        return {
            "raw": content,
            "prompt_tokens": usage.get("prompt_tokens"),
            "done_reason": finish,
        }

original_load_jobs = plain_ai.load_jobs

def limited_dev_jobs(
    corpus_path, criteria_path, splits_path, split, pairs, cases_path
):
    if split != "dev" or pairs or cases_path:
        raise SystemExit("This runner permits the development split only.")

    remaining = QUESTION_LIMIT
    for pair, trial, note, rules, extra in original_load_jobs(
        corpus_path, criteria_path, splits_path, split, pairs, cases_path
    ):
        selected = rules[:remaining]
        if selected:
            yield pair, trial, note, selected, extra
            remaining -= len(selected)
        if remaining == 0:
            return

plain_ai.LocalLLM = GroqLLM
plain_ai.load_jobs = limited_dev_jobs

manifest = {
    "purpose": "Engineering pilot, not a performance estimate",
    "dataset": "nsclc100",
    "split": "dev",
    "model": MODEL,
    "questions_per_policy": QUESTION_LIMIT,
    "maximum_generation_requests": REQUEST_LIMIT,
    "policies": ["explicit_unknown", "forced_guess"],
    "settings": {
        "temperature": 0,
        "reasoning_effort": "low",
        "max_completion_tokens": 1024,
        "automatic_retries": 0,
    },
}
(RUN / "manifest.json").write_text(
    json.dumps(manifest, indent=2), encoding="utf-8"
)

exit_codes = {}
try:
    for policy, flags in [
        ("explicit_unknown", []),
        ("forced_guess", ["--no-unknown"]),
    ]:
        sys.argv = [
            "plain_ai.py",
            "--model", MODEL,
            "--split", "dev",
            "--dataset", "nsclc100",
            "--corpus", str(ROOT / "datasets/nsclc100/nsclc100.csv"),
            "--criteria", str(plain_ai.DEFAULT_CRITERIA),
            "--splits", str(plain_ai.DEFAULT_SPLITS),
            "--num-ctx", "32768",
            "--cache-dir", str(ROOT / "outputs/groq_cache"),
            "--out", str(RUN / f"{policy}.jsonl"),
        ] + flags

        exit_codes[policy] = plain_ai.main()
        if exit_codes[policy] != 0:
            print("Stopping: this policy run is incomplete.")
            break
finally:
    summary = {
        **STATE,
        "total_tokens": STATE["prompt_tokens"] + STATE["completion_tokens"],
        "policy_exit_codes": exit_codes,
    }
    (RUN / "usage_summary.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )
    print("\nPILOT OUTPUT:", RUN)
    print("USAGE SUMMARY:", json.dumps(summary))
    print("No annotation files were modified.")
    print("No held-out evaluation was requested.")
