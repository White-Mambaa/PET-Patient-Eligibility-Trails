import csv
import json
from pathlib import Path
from collections import Counter

ROOT = Path("datasets")
OUT = Path("outputs/priority_comparison")

QUEUE = OUT / "top10_annotation_queue.csv"
BLIND = OUT / "top10_blinded_annotation.csv"
KEY = OUT / "top10_baseline_comparison_key.csv"

CONFIG = {
    "nsclc100": {
        "pairs": ROOT / "nsclc100/nsclc100.csv",
        "criteria": ROOT / "nsclc100/criteria.csv",
        "baseline": Path("outputs/plain_ai_qwen_dev.jsonl"),
    },
    "sigir204": {
        "pairs": ROOT / "sigir204/sigir204.csv",
        "criteria": ROOT / "sigir204/criteria.csv",
        "baseline": Path("outputs/plain_ai_qwen_sigir_dev.jsonl"),
    },
}

def read_csv(path):
    with path.open(newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))

def load_jsonl(path):
    records = []
    with path.open(encoding="utf-8") as f:
        for line in f:
            if line.strip():
                records.append(json.loads(line))
    return records

queue = read_csv(QUEUE)

patients = {}
criteria = {}
predictions = {}

for dataset, config in CONFIG.items():
    for row in read_csv(config["pairs"]):
        key = (dataset, int(row["pair_idx"]))
        assert key not in patients, f"Duplicate patient pair: {key}"
        patients[key] = row

    for row in read_csv(config["criteria"]):
        key = (
            dataset,
            row["trial_id"],
            int(row["crit_idx"])
        )
        assert key not in criteria, f"Duplicate criterion: {key}"
        criteria[key] = row

    for row in load_jsonl(config["baseline"]):
        key = (
            dataset,
            int(row["pair_idx"]),
            int(row["crit_idx"])
        )
        assert key not in predictions, f"Duplicate prediction: {key}"
        predictions[key] = row

blind_rows = []
key_rows = []
seen = set()

for index, selection in enumerate(queue, start=1):
    dataset = selection["dataset"]
    pair = int(selection["pair_idx"])
    crit = int(selection["crit_idx"])

    key = (dataset, pair, crit)
    assert key not in seen, f"Duplicate selected case: {key}"
    seen.add(key)

    patient = patients[(dataset, pair)]
    rule = criteria[(dataset, patient["trial_id"], crit)]
    baseline = predictions[key]

    assert rule["kind"] == baseline["kind"], (
        f"Criterion kind mismatch: {key}"
    )

    case_id = f"ANN-{index:03d}"

    blind_rows.append({
        "case_id": case_id,
        "dataset": dataset,
        "pair_idx": pair,
        "trial_id": patient["trial_id"],
        "patient_id": patient["patient_id"],
        "crit_idx": crit,
        "criterion_kind": rule["kind"],
        "criterion_text": rule["criterion_text"],
        "patient_note": patient["patient_orig"],
        "manual_truth": "",
        "manual_evidence_quote": "",
        "manual_reasoning": "",
        "ambiguity_flag": "",
        "review_status": "UNREVIEWED",
    })

    key_rows.append({
        "case_id": case_id,
        "dataset": dataset,
        "pair_idx": pair,
        "crit_idx": crit,
        "baseline_truth": baseline["truth"],
        "baseline_verdict": baseline["verdict"],
        "baseline_evidence": json.dumps(
            baseline.get("evidence", []),
            ensure_ascii=False
        ),
        "baseline_rationale": baseline.get("rationale", ""),
        "baseline_confidence": baseline.get("confidence", ""),
        "baseline_parse_ok": baseline.get("parse_ok", ""),
        "reference_pair_target": patient["target"],
        "criterion_review_source": rule.get("review", ""),
        "random_rank": selection["random_rank"],
        "confidence_rank": selection["confidence_rank"],
        "citation_rank": selection["citation_rank"],
        "decision_impact_rank": selection["decision_impact_rank"],
        "combined_rank": selection["combined_rank"],
    })

assert len(blind_rows) == len(queue)
assert len(key_rows) == len(queue)

def save_csv(path, rows):
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=list(rows[0].keys())
        )
        writer.writeheader()
        writer.writerows(rows)

save_csv(BLIND, blind_rows)
save_csv(KEY, key_rows)

print("=== UNIFIED ANNOTATION PILOT ===")
print("Selected cases:", len(queue))
print("Blinded cases:", len(blind_rows))
print("Matched baseline predictions:", len(key_rows))

print("\n=== DATASET COUNTS ===")
for name, count in sorted(
    Counter(r["dataset"] for r in blind_rows).items()
):
    print(f"{name}: {count}")

print("\n=== FIRST THREE ANNOTATION CASES ===")
for r in blind_rows[:3]:
    print(
        f'{r["case_id"]}: '
        f'{r["dataset"]} '
        f'pair={r["pair_idx"]} '
        f'criterion={r["crit_idx"]}'
    )
    print("Rule:", r["criterion_text"][:180])
    print("Review:", r["review_status"])

print("\n=== FILES CREATED ===")
print("Blinded annotation:", BLIND)
print("Baseline comparison key:", KEY)

print("\nManual labels populated: 0")
print("Ollama calls: 0")
print("STATUS: READY FOR MANUAL ANNOTATION")
