import json
import os
import sys
import time
import urllib.request
import urllib.error
from pathlib import Path
from collections import Counter

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs/overnight_audit"
OUT.mkdir(parents=True, exist_ok=True)

MODEL = os.environ.get("JUDGE_MODEL", "qwen2.5:7b")
URL = os.environ.get(
    "OLLAMA_URL",
    "http://127.0.0.1:11434"
)

HOURS = float(os.environ.get("MAX_HOURS", "8"))
MAX_RECORDS = int(os.environ.get("MAX_RECORDS", "0"))
DEADLINE = time.monotonic() + HOURS * 3600

SOURCES = {
    "nsclc100": ROOT / "outputs/plain_ai_qwen_dev.jsonl",
    "sigir204": ROOT / "outputs/plain_ai_qwen_sigir_dev.jsonl",
}

DATASETS = {
    "nsclc100": ROOT / "datasets/nsclc100/nsclc100.csv",
    "sigir204": ROOT / "datasets/sigir204/sigir204.csv",
}

OUTPUT = OUT / "evidence_audit.jsonl"
ERRORS = OUT / "errors.jsonl"

def request_json(path, payload=None, timeout=180):
    data = (
        json.dumps(payload).encode("utf-8")
        if payload is not None else None
    )
    req = urllib.request.Request(
        URL + path,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST" if data is not None else "GET",
    )
    with urllib.request.urlopen(req, timeout=timeout) as response:
        return json.load(response)

def key_of(r):
    return (
        str(r["dataset"]),
        int(r["pair_idx"]),
        int(r["crit_idx"]),
    )

def load_notes():
    import csv
    notes = {}
    for dataset, path in DATASETS.items():
        with path.open(newline="", encoding="utf-8-sig") as f:
            for r in csv.DictReader(f):
                key = (dataset, int(r["pair_idx"]))
                if key in notes:
                    raise ValueError(f"Duplicate pair: {key}")
                notes[key] = r["patient_orig"]
    return notes

def load_predictions():
    records = []
    seen = set()
    for dataset, path in SOURCES.items():
        with path.open(encoding="utf-8") as f:
            for line in f:
                if not line.strip():
                    continue
                r = json.loads(line)
                if r["dataset"] != dataset:
                    raise ValueError("Dataset mismatch")
                key = key_of(r)
                if key in seen:
                    raise ValueError(f"Duplicate prediction: {key}")
                seen.add(key)
                records.append(r)
    return records

def completed_keys():
    done = set()
    if OUTPUT.exists():
        with OUTPUT.open(encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    r = json.loads(line)
                    done.add(key_of(r))
    return done

def judge(record, note):
    prompt = {
        "patient_note": note,
        "criterion": record["criterion"],
        "criterion_kind": record["kind"],
        "screening_answer": record["truth"],
        "screening_verdict": record["verdict"],
        "claimed_evidence": record.get("evidence", []),
        "screening_rationale": record.get("rationale", ""),
    }

    system = """
You are auditing an AI-generated clinical-trial screening answer.

Use ONLY the provided patient note and criterion.
Do not assume missing facts are negative facts.
Do not use the patient's pair-level eligibility label.
Do not automatically treat a non-verbatim quotation as
a clinically unsupported claim.
Distinguish criterion satisfaction from presence of a
medical condition, especially for exclusion criteria.

Assess:
1. Whether the evidence supports the answer.
2. Whether context, negation or timing was misread.
3. Whether the answer-to-verdict logic is consistent.
4. Whether the answer contradicts the note.
5. Whether important evidence was overlooked.

Return a JSON object with these exact keys:
support: supported|unsupported|insufficient|uncertain
context_issue: yes|no|uncertain
logic_issue: yes|no|uncertain
contradiction_issue: yes|no|uncertain
missed_evidence_issue: yes|no|uncertain
suggested_truth: yes|no|unknown
suggested_verdict: met|not_met|not_stated
needs_human_review: true|false
explanation: concise explanation grounded in the note

Do not invent evidence. These are preliminary AI audit
judgments, not gold-standard labels.
"""

    result = request_json(
        "/api/chat",
        {
            "model": MODEL,
            "stream": False,
            "format": "json",
            "options": {
                "temperature": 0,
                "num_predict": 350,
            },
            "messages": [
                {"role": "system", "content": system},
                {
                    "role": "user",
                    "content": json.dumps(prompt, ensure_ascii=False),
                },
            ],
        },
        timeout=180,
    )

    content = result["message"]["content"]
    audit = json.loads(content)

    required = {
        "support", "context_issue", "logic_issue",
        "contradiction_issue", "missed_evidence_issue",
        "suggested_truth", "suggested_verdict",
        "needs_human_review", "explanation",
    }
    if not required.issubset(audit):
        raise ValueError("Incomplete judge response")

    allowed = {
        "support": {"supported", "unsupported", "insufficient", "uncertain"},
        "context_issue": {"yes", "no", "uncertain"},
        "logic_issue": {"yes", "no", "uncertain"},
        "contradiction_issue": {"yes", "no", "uncertain"},
        "missed_evidence_issue": {"yes", "no", "uncertain"},
        "suggested_truth": {"yes", "no", "unknown"},
        "suggested_verdict": {"met", "not_met", "not_stated"},
    }
    # Normalize an explicit model synonym while preserving
    # its original value for research reproducibility.
    if audit.get("support") == "no_evidence":
        audit["support_original_value"] = "no_evidence"
        audit["support"] = "insufficient"
        audit["support_normalization"] = (
            "no_evidence_to_insufficient"
        )

    for field, values in allowed.items():
        if audit[field] not in values:
            raise ValueError(f"Invalid {field}: {audit[field]}")

    value = audit["needs_human_review"]

    if isinstance(value, bool):
        pass
    elif isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in ("true", "yes", "1"):
            audit["needs_human_review"] = True
        elif normalized in ("false", "no", "0"):
            audit["needs_human_review"] = False
        else:
            raise ValueError(
                f"Invalid needs_human_review: {value!r}"
            )
    elif isinstance(value, int) and value in (0, 1):
        audit["needs_human_review"] = bool(value)
    else:
        raise ValueError(
            f"Invalid needs_human_review: {value!r}"
        )

    return audit

def main():
    models = request_json("/api/tags")
    installed = {m["name"] for m in models.get("models", [])}

    if MODEL not in installed:
        raise SystemExit(
            f"Model {MODEL!r} not installed. Available: {sorted(installed)}"
        )

    notes = load_notes()
    records = load_predictions()
    done = completed_keys()

    print("OVERNIGHT EVIDENCE AUDIT", flush=True)
    print("Judge model:", MODEL, flush=True)
    print("Predictions:", len(records), flush=True)
    print("Already completed:", len(done), flush=True)
    print("Time limit (hours):", HOURS, flush=True)
    print("Max new records (0=unlimited):", MAX_RECORDS, flush=True)
    print("Output:", OUTPUT, flush=True)

    new_count = 0
    failures = 0

    with OUTPUT.open("a", encoding="utf-8") as out, \
         ERRORS.open("a", encoding="utf-8") as err:

        for r in records:
            if time.monotonic() >= DEADLINE:
                print("Time limit reached.", flush=True)
                break

            if MAX_RECORDS and new_count >= MAX_RECORDS:
                print("Record limit reached.", flush=True)
                break

            key = key_of(r)
            if key in done:
                continue

            note_key = (r["dataset"], int(r["pair_idx"]))
            note = notes[note_key]
            started = time.monotonic()

            try:
                audit = judge(r, note)
                elapsed = round(time.monotonic() - started, 2)

                result = {
                    "dataset": r["dataset"],
                    "pair_idx": r["pair_idx"],
                    "crit_idx": r["crit_idx"],
                    "judge_model": MODEL,
                    "audit_type": "AI_PRELIMINARY",
                    "baseline_truth": r["truth"],
                    "baseline_verdict": r["verdict"],
                    "audit": audit,
                    "elapsed_seconds": elapsed,
                }

                out.write(json.dumps(result, ensure_ascii=False) + "\n")
                out.flush()
                done.add(key)
                new_count += 1

                if new_count <= 5 or new_count % 25 == 0:
                    print(
                        f"Completed {len(done)}/{len(records)} "
                        f"| latest {elapsed}s "
                        f"| errors {failures}",
                        flush=True,
                    )

            except Exception as exc:
                failures += 1
                err.write(json.dumps({
                    "dataset": r["dataset"],
                    "pair_idx": r["pair_idx"],
                    "crit_idx": r["crit_idx"],
                    "error": str(exc),
                }) + "\n")
                err.flush()
                print(f"Error on {key}: {exc}", flush=True)

                # Avoid repeatedly hammering an unavailable server.
                if isinstance(exc, urllib.error.URLError):
                    print("Ollama connection failed. Stopping.", flush=True)
                    break

    print("\nRUN SUMMARY", flush=True)
    print("New successful audits:", new_count, flush=True)
    print("Errors this run:", failures, flush=True)
    print("Total completed:", len(done), flush=True)
    print("Remaining:", len(records) - len(done), flush=True)
    print("Saved:", OUTPUT, flush=True)

if __name__ == "__main__":
    main()
