import csv
import json
import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "code"))

from criteria import decide, what_could_change

SOURCES = {
    "nsclc100": ROOT / "outputs/plain_ai_qwen_dev.jsonl",
    "sigir204": ROOT / "outputs/plain_ai_qwen_sigir_dev.jsonl",
}

rows = []
summary = {}

for dataset, path in SOURCES.items():
    groups = defaultdict(list)

    with path.open(encoding="utf-8") as f:
        for line in f:
            if line.strip():
                record = json.loads(line)
                groups[int(record["pair_idx"])].append(record)

    pair_count = 0
    sole_pairs = 0
    near_sole_pairs = 0
    decision_changing_count = 0

    for pair_idx, records in sorted(groups.items()):
        records.sort(key=lambda r: int(r["crit_idx"]))

        indices = [int(r["crit_idx"]) for r in records]
        if len(indices) != len(set(indices)):
            raise ValueError(f"Duplicate criterion index: {dataset}, pair {pair_idx}")

        verdicts = [r["verdict"] for r in records]
        impact = what_could_change(verdicts)

        failing_count = verdicts.count("not_met")
        decision = decide(verdicts)

        pair_count += 1
        sole_pairs += int(failing_count == 1)
        near_sole_pairs += int(failing_count == 2)

        for record, result in zip(records, impact):
            if result["changes"]:
                decision_changing_count += 1

            rows.append({
                "dataset": dataset,
                "pair_idx": pair_idx,
                "crit_idx": record["crit_idx"],
                "verdict": record["verdict"],
                "decision": decision,
                "failing_count": failing_count,
                "decision_changing": result["changes"],
                "sole_rejection": result["sole_reason"],
                "near_sole_rejection": (
                    failing_count == 2 and record["verdict"] == "not_met"
                ),
                "confidence": record.get("confidence"),
                "evidence": json.dumps(record.get("evidence", [])),
            })

    summary[dataset] = {
        "pairs": pair_count,
        "sole_rejection_pairs": sole_pairs,
        "near_sole_rejection_pairs": near_sole_pairs,
        "decision_changing_criteria": decision_changing_count,
    }

output = ROOT / "outputs/decision_impact/real_priority_analysis.csv"

with output.open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)

print("REAL DECISION-IMPACT ANALYSIS")
print("=" * 45)

for dataset, result in summary.items():
    print(f"\n{dataset}")
    for key, value in result.items():
        print(f"  {key}: {value}")

print(f"\nTotal criterion records: {len(rows)}")
print(f"Saved: {output}")
