import csv
import json
import sys
from pathlib import Path
from collections import Counter

sys.path.insert(0, str(Path("code").resolve()))
from criteria import map_truth

BASE = Path("datasets/nsclc100")
SOURCE = Path("outputs/overnight_audit/evidence_audit.jsonl")
DEST = Path("outputs/overnight_audit/consistency_snapshot.csv")

with (BASE / "nsclc100.csv").open(
    newline="", encoding="utf-8"
) as f:
    pair_trials = {
        int(r["pair_idx"]): r["trial_id"]
        for r in csv.DictReader(f)
    }

with (BASE / "criteria.csv").open(
    newline="", encoding="utf-8"
) as f:
    rule_kinds = {
        (r["trial_id"], int(r["crit_idx"])): r["kind"]
        for r in csv.DictReader(f)
    }

# Read a snapshot while the audit continues writing.
with SOURCE.open(encoding="utf-8") as f:
    lines = f.readlines()

results = []
seen = set()
stats = Counter()

for line in lines:
    try:
        r = json.loads(line)
    except json.JSONDecodeError:
        stats["incomplete_or_invalid_lines"] += 1
        continue

    if r["dataset"] != "nsclc100":
        stats["other_dataset_skipped"] += 1
        continue

    pair = int(r["pair_idx"])
    crit = int(r["crit_idx"])
    key = (r["dataset"], pair, crit)

    if key in seen:
        stats["duplicate_records"] += 1
        continue

    seen.add(key)

    trial = pair_trials[pair]
    kind = rule_kinds[(trial, crit)]
    a = r["audit"]

    proposed_truth = a["suggested_truth"]
    proposed_verdict = a["suggested_verdict"]

    derived_verdict = map_truth(proposed_truth, kind)

    inconsistent = proposed_verdict != derived_verdict

    if inconsistent:
        stats["mapping_inconsistent"] += 1
    else:
        stats["mapping_consistent"] += 1

    if proposed_truth != r["baseline_truth"]:
        stats["truth_change_suggested"] += 1

    if (
        a.get("missed_evidence_issue") == "yes"
        and proposed_truth == "unknown"
        and r["baseline_truth"] == "unknown"
    ):
        stats["missed_flag_unknown_unchanged"] += 1

    results.append({
        "dataset": r["dataset"],
        "pair_idx": pair,
        "crit_idx": crit,
        "trial_id": trial,
        "kind": kind,
        "baseline_truth": r["baseline_truth"],
        "baseline_verdict": r["baseline_verdict"],
        "suggested_truth": proposed_truth,
        "judge_suggested_verdict": proposed_verdict,
        "deterministically_derived_verdict": derived_verdict,
        "mapping_inconsistent": inconsistent,
        "support": a.get("support"),
        "missed_evidence_issue": a.get(
            "missed_evidence_issue"
        ),
        "needs_human_review": a.get(
            "needs_human_review"
        ),
        "audit_type": r["audit_type"],
    })

if results:
    with DEST.open(
        "w", newline="", encoding="utf-8"
    ) as f:
        writer = csv.DictWriter(
            f, fieldnames=list(results[0])
        )
        writer.writeheader()
        writer.writerows(results)

print("=== AUDIT CONSISTENCY SNAPSHOT ===")
print("Analyzed:", len(results))
print("Consistent:", stats["mapping_consistent"])
print("Inconsistent:", stats["mapping_inconsistent"])

if results:
    print(
        "Inconsistency rate:",
        f'{100 * stats["mapping_inconsistent"] / len(results):.2f}%'
    )

print(
    "Suggested truth changes:",
    stats["truth_change_suggested"]
)
print(
    "Missed-evidence flags with unchanged unknown:",
    stats["missed_flag_unknown_unchanged"]
)
print(
    "Duplicate records skipped:",
    stats["duplicate_records"]
)
print(
    "Invalid/incomplete lines skipped:",
    stats["incomplete_or_invalid_lines"]
)
print("Saved:", DEST)

print("\nIMPORTANT:")
print("Derived verdicts are logical mappings only.")
print("They are NOT verified clinical corrections.")
