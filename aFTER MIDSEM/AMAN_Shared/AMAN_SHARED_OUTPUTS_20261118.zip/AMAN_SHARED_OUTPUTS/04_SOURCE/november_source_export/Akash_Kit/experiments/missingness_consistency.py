import csv
import re
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

source = ROOT / "outputs/evidence_checks/eligible_rejection_verification.csv"
output = ROOT / "outputs/evidence_checks/missingness_consistency.csv"

patterns = [
    r"\bdoes not mention\b",
    r"\bnot mentioned\b",
    r"\bno mention of\b",
    r"\bnot documented\b",
    r"\bno information\b",
    r"\bnot specified\b",
    r"\bnot provided\b",
    r"\bunknown\b",
    r"\bcannot determine\b",
    r"\bunclear whether\b",
]

with source.open(newline="", encoding="utf-8") as f:
    rows = list(csv.DictReader(f))

results = []

for row in rows:
    rationale = row.get("rationale", "")
    matches = [
        p for p in patterns
        if re.search(p, rationale, flags=re.IGNORECASE)
    ]

    flagged = (
        row["verdict"] == "not_met"
        and bool(matches)
    )

    results.append({
        "dataset": row["dataset"],
        "pair_idx": row["pair_idx"],
        "crit_idx": row["crit_idx"],
        "reference_target": row["reference_target"],
        "verdict": row["verdict"],
        "citation_status": row["citation_status"],
        "missingness_flag": int(flagged),
        "matched_patterns": "; ".join(matches),
        "rationale": rationale,
        "verification_status": "UNVERIFIED_HEURISTIC",
    })

output.parent.mkdir(parents=True, exist_ok=True)

with output.open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=list(results[0]))
    writer.writeheader()
    writer.writerows(results)

print("MISSINGNESS-CONSISTENCY CHECK")
print("=" * 45)
print("Total candidates:", len(results))
print("Flagged:", sum(r["missingness_flag"] for r in results))
print("By dataset:", dict(Counter(
    r["dataset"] for r in results
    if r["missingness_flag"]
)))

print("\nFLAGGED CASES")
for row in results:
    if row["missingness_flag"]:
        print(
            row["dataset"],
            "pair", row["pair_idx"],
            "criterion", row["crit_idx"],
            "| citation:", row["citation_status"]
        )

print("\nAll flags require independent verification.")
print("Saved:", output)
