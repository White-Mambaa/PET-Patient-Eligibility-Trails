import csv
import json
import re
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

DATASETS = {
    "nsclc100": {
        "pred": ROOT / "outputs/plain_ai_qwen_dev.jsonl",
        "corpus": ROOT / "datasets/nsclc100/nsclc100.csv",
    },
    "sigir204": {
        "pred": ROOT / "outputs/plain_ai_qwen_sigir_dev.jsonl",
        "corpus": ROOT / "datasets/sigir204/sigir204.csv",
    },
}

def normalize(text):
    return re.sub(r"\s+", " ", str(text)).strip()

def load_notes(path):
    with path.open(encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        required = {"pair_idx", "patient_orig"}
        if not required.issubset(reader.fieldnames or []):
            raise ValueError(f"Missing columns in {path}: {required}")

        notes = {}
        for row in reader:
            pair = int(row["pair_idx"])
            if pair in notes:
                raise ValueError(f"Duplicate pair_idx {pair} in {path}")
            notes[pair] = row["patient_orig"]
        return notes

def check(note, evidence):
    if isinstance(evidence, str):
        evidence = [evidence]
    elif evidence is None:
        evidence = []
    elif not isinstance(evidence, list):
        return "INVALID_EVIDENCE", 0, 0, []

    quotes = [normalize(q) for q in evidence if normalize(q)]
    if not quotes:
        return "NO_EVIDENCE", 0, 0, []

    normalized_note = normalize(note)
    matched = [q for q in quotes if q in normalized_note]
    unmatched = [q for q in quotes if q not in normalized_note]

    return (
        "PASS" if not unmatched else "FAIL",
        len(quotes),
        len(matched),
        unmatched,
    )

results = []

for dataset, paths in DATASETS.items():
    print(f"Processing {dataset}...", flush=True)
    notes = load_notes(paths["corpus"])

    with paths["pred"].open(encoding="utf-8") as f:
        for line_number, line in enumerate(f, 1):
            if not line.strip():
                continue

            record = json.loads(line)
            pair = int(record["pair_idx"])

            if pair not in notes:
                raise ValueError(
                    f"Missing patient note: {dataset}, pair {pair}"
                )

            status, total, matched, unmatched = check(
                notes[pair], record.get("evidence")
            )

            results.append({
                "dataset": dataset,
                "pair_idx": pair,
                "crit_idx": record["crit_idx"],
                "verdict": record["verdict"],
                "truth": record["truth"],
                "confidence": record.get("confidence"),
                "citation_status": status,
                "total_quotes": total,
                "matched_quotes": matched,
                "unmatched_quotes": json.dumps(
                    unmatched, ensure_ascii=False
                ),
            })

    print(f"Completed {dataset}", flush=True)

output = ROOT / "outputs/evidence_checks/real_citation_results.csv"

with output.open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=list(results[0]))
    writer.writeheader()
    writer.writerows(results)

print("\n===== REAL CITATION CHECK RESULTS =====")

for dataset in DATASETS:
    subset = [r for r in results if r["dataset"] == dataset]
    counts = Counter(r["citation_status"] for r in subset)

    total_quotes = sum(r["total_quotes"] for r in subset)
    matched_quotes = sum(r["matched_quotes"] for r in subset)

    print(f"\n{dataset}")
    print("Criterion predictions:", len(subset))
    print("Citation statuses:", dict(counts))
    print("Total quoted spans:", total_quotes)
    print("Verbatim matches:", matched_quotes)
    print("Non-verbatim spans:", total_quotes - matched_quotes)
    print(
        "Verbatim match rate:",
        f"{100 * matched_quotes / total_quotes:.2f}%"
        if total_quotes else "N/A"
    )

print("\nTotal predictions processed:", len(results))
print("Results saved:", output)
