import csv
import json
from pathlib import Path
from collections import Counter

SOURCE = Path("outputs/plain_ai_qwen_dev.jsonl")
DATASET = Path("datasets/nsclc100/nsclc100.csv")
OUTPUT = Path("outputs/decision_impact/verified_counterfactual_pilot.csv")

# Criterion-level corrections supported by explicit note evidence.
# Not independently clinically adjudicated.
cases = {
    25: (3, "ECOG score is 1", "yes", "met"),
    26: (3, "ECOG score of 1", "yes", "met"),
    48: (13, "Post-op predicted FEV1 and DLCO of 47% and 46% respectively.", "yes", "met"),
}

def decision(verdicts):
    if "not_met" in verdicts:
        return "NOT_ELIGIBLE"
    if "not_stated" in verdicts:
        return "REVIEW"
    return "ELIGIBLE"

with DATASET.open(newline="", encoding="utf-8") as f:
    patients = {
        int(r["pair_idx"]): r
        for r in csv.DictReader(f)
    }

predictions = {pair: [] for pair in cases}

with SOURCE.open(encoding="utf-8") as f:
    for line in f:
        if not line.strip():
            continue

        r = json.loads(line)
        pair = int(r["pair_idx"])

        if r.get("dataset") == "nsclc100" and pair in cases:
            predictions[pair].append(r)

results = []

for pair, (crit, evidence, new_truth, new_verdict) in cases.items():
    rows = predictions[pair]
    assert rows, f"No baseline records for pair {pair}"

    patient = patients[pair]
    assert evidence in patient["patient_orig"], (
        f"Evidence not found for pair {pair}"
    )

    matches = [
        r for r in rows
        if int(r["crit_idx"]) == crit
    ]
    assert len(matches) == 1, (
        f"Expected one matching criterion for pair {pair}"
    )

    original_rule = matches[0]
    assert original_rule["verdict"] == "not_met"

    before = [r["verdict"] for r in rows]
    after = [
        new_verdict if int(r["crit_idx"]) == crit
        else r["verdict"]
        for r in rows
    ]

    before_decision = decision(before)
    after_decision = decision(after)

    result = {
        "dataset": "nsclc100",
        "trial_id": patient["trial_id"],
        "pair_idx": pair,
        "crit_idx": crit,
        "evidence": evidence,
        "baseline_truth": original_rule["truth"],
        "baseline_verdict": original_rule["verdict"],
        "corrected_truth": new_truth,
        "corrected_verdict": new_verdict,
        "criteria_total": len(rows),
        "remaining_not_met": Counter(after)["not_met"],
        "remaining_not_stated": Counter(after)["not_stated"],
        "decision_before": before_decision,
        "decision_after": after_decision,
        "decision_changed": before_decision != after_decision,
        "reference_target": patient["target"],
        "review_status": "EVIDENCE_SUPPORTED_PRELIMINARY",
        "independent_clinical_adjudication": False,
    }

    assert result["decision_changed"], (
        f"Decision did not change for pair {pair}"
    )

    results.append(result)

OUTPUT.parent.mkdir(parents=True, exist_ok=True)

with OUTPUT.open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=list(results[0]))
    writer.writeheader()
    writer.writerows(results)

print("=== DECISION CORRECTION PILOT ===")
for r in results:
    print(
        f'Pair {r["pair_idx"]}: '
        f'{r["decision_before"]} -> {r["decision_after"]} '
        f'| remaining unknown: {r["remaining_not_stated"]}'
    )

print("\nTotal cases:", len(results))
print("Decision changes:", sum(r["decision_changed"] for r in results))
print("Moved to ELIGIBLE:",
      sum(r["decision_after"] == "ELIGIBLE" for r in results))
print("Moved to REVIEW:",
      sum(r["decision_after"] == "REVIEW" for r in results))
print("Saved:", OUTPUT)
print("Status: Preliminary counterfactual, not clinical adjudication.")
