import csv
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "code"))

from criteria import decide

SOURCES = {
    "nsclc100": ROOT / "outputs/plain_ai_qwen_dev.jsonl",
    "sigir204": ROOT / "outputs/plain_ai_qwen_sigir_dev.jsonl",
}

citation_path = ROOT / "outputs/evidence_checks/real_citation_results.csv"

with citation_path.open(newline="", encoding="utf-8") as f:
    citation_rows = list(csv.DictReader(f))

citations = {
    (r["dataset"], int(r["pair_idx"]), int(r["crit_idx"])): r
    for r in citation_rows
}

if len(citations) != len(citation_rows):
    raise ValueError("Duplicate citation keys")

queue = []
summary = Counter()

for dataset, path in SOURCES.items():
    groups = defaultdict(list)

    with path.open(encoding="utf-8") as f:
        for line in f:
            if line.strip():
                record = json.loads(line)
                groups[int(record["pair_idx"])].append(record)

    for pair_idx, records in sorted(groups.items()):
        records.sort(key=lambda r: int(r["crit_idx"]))

        failing = [r for r in records if r["verdict"] == "not_met"]

        if len(failing) != 1:
            continue

        target = failing[0]
        current = decide([r["verdict"] for r in records])

        corrected = [
            "met" if r is target else r["verdict"]
            for r in records
        ]
        after = decide(corrected)

        key = (dataset, pair_idx, int(target["crit_idx"]))

        if key not in citations:
            raise ValueError(f"Missing citation result: {key}")

        citation = citations[key]
        status = citation["citation_status"]

        if after == "ELIGIBLE":
            outcome = "POTENTIAL_FULL_RESCUE"
        elif after == "REVIEW":
            outcome = "POTENTIAL_REVIEW_RECOVERY"
        else:
            outcome = "NO_DECISION_CHANGE"

        queue.append({
            "dataset": dataset,
            "pair_idx": pair_idx,
            "crit_idx": target["crit_idx"],
            "criterion": target["criterion"],
            "truth": target["truth"],
            "verdict": target["verdict"],
            "confidence": target.get("confidence"),
            "rationale": target.get("rationale", ""),
            "evidence": json.dumps(
                target.get("evidence", []), ensure_ascii=False
            ),
            "citation_status": status,
            "decision_before": current,
            "decision_if_corrected": after,
            "counterfactual_category": outcome,
            "verification_status": "UNVERIFIED",
        })

        summary[(dataset, outcome)] += 1

priority = {
    "FAIL": 0,
    "NO_EVIDENCE": 1,
    "PASS": 2,
}

queue.sort(key=lambda r: (
    priority.get(r["citation_status"], 3),
    r["dataset"],
    int(r["pair_idx"]),
))

out = ROOT / "outputs/decision_impact/rescue_review_queue.csv"

with out.open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=list(queue[0]))
    writer.writeheader()
    writer.writerows(queue)

print("REJECTION-REVIEW QUEUE")
print("=" * 45)

for dataset in SOURCES:
    print(f"\n{dataset}")
    for outcome in (
        "POTENTIAL_FULL_RESCUE",
        "POTENTIAL_REVIEW_RECOVERY",
        "NO_DECISION_CHANGE",
    ):
        print(f"  {outcome}: {summary[(dataset, outcome)]}")

print("\nTotal candidates:", len(queue))
print("Citation status:", dict(Counter(
    r["citation_status"] for r in queue
)))
print("Verification status: ALL UNVERIFIED")
print("Saved:", out)
