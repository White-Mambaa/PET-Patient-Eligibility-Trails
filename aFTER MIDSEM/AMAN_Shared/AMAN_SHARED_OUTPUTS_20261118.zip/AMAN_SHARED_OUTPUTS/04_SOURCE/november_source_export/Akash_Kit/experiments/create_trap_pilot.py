import csv
import json
from pathlib import Path
from jsonschema import Draft202012Validator

ROOT = Path("datasets/nsclc100")
OUT = Path("outputs/traps/trap_pilot_candidates.jsonl")

with open(ROOT / "nsclc100.csv", newline="", encoding="utf-8") as f:
    patients = {int(r["pair_idx"]): r for r in csv.DictReader(f)}

with open(ROOT / "criteria.csv", newline="", encoding="utf-8") as f:
    rules = {
        (r["trial_id"], int(r["crit_idx"])): r
        for r in csv.DictReader(f)
    }

with open("templates/trap_record.schema.json", encoding="utf-8") as f:
    schema = json.load(f)

specs = [
    {
        "pair": 40,
        "crit": 23,
        "trap_type": "NEGATION",
        "old": "a history of smoking and HIV infection",
        "new": "a history of smoking and no history of HIV infection",
        "truth_before": "yes",
        "expected_truth_after": "no",
    },
    {
        "pair": 11,
        "crit": 13,
        "trap_type": "FAMILY_HISTORY",
        "old": "Has a history of peptic ulcerative disease.",
        "new": "His father has a history of peptic ulcerative disease; the patient has no personal history of this condition.",
        "truth_before": "yes",
        "expected_truth_after": "no",
    },
    {
        "pair": 2,
        "crit": 6,
        "trap_type": "EVIDENCE_REMOVED",
        "old": "ECOG was 0.",
        "new": "",
        "truth_before": "yes",
        "expected_truth_after": "unknown",
    },
]

records = []

for i, spec in enumerate(specs):
    patient = patients[spec["pair"]]
    trial_id = patient["trial_id"]
    rule = rules[(trial_id, spec["crit"])]

    original = patient["patient_orig"]
    old = spec["old"]

    if original.count(old) != 1:
        raise ValueError(
            f"Expected exactly one occurrence of {old!r} "
            f"in pair {spec['pair']}"
        )

    altered = original.replace(old, spec["new"], 1)

    record = {
        "case_idx": i,
        "trap_id": f"PILOT-{i+1:03d}",
        "base_pair_idx": spec["pair"],
        "trial_id": trial_id,
        "crit_idx": spec["crit"],
        "kind": rule["kind"],
        "criterion": rule["criterion_text"],
        "trap_type": spec["trap_type"],
        "operation": "remove" if not spec["new"] else "replace",
        "position": "in_place",
        "text": spec["new"] if spec["new"] else old,
        "replaced_text": old if spec["new"] else None,
        "truth_before": spec["truth_before"],
        "expected_truth_after": spec["expected_truth_after"],
        "expected_trap": "Model may misinterpret the altered clinical evidence.",
        "note": altered,
        "checked_by_hand": False,
    }

    Draft202012Validator(schema).validate(record)
    records.append(record)

with OUT.open("w", encoding="utf-8") as f:
    for record in records:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")

print("SCHEMA VALIDATION: PASSED")
print("CREATED:", OUT)
print("CANDIDATE TRAPS:", len(records))

for r in records:
    print(
        f"\n{r['trap_id']} | {r['trap_type']} | "
        f"{r['trial_id']} criterion {r['crit_idx']}"
    )
    print("Criterion:", r["criterion"])
    print("Expected truth:", r["expected_truth_after"])
    print("Altered note:", r["note"])
    print("Checked by hand:", r["checked_by_hand"])
