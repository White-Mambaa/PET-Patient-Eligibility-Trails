#!/usr/bin/env python3
"""Three non-checker review-strategy baselines on saved Qwen development outputs."""
import argparse, csv, datetime as dt, hashlib, json, os, random, sys
from collections import defaultdict
from pathlib import Path
BUDGETS=(5,10,20,50,100)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write_json(p,data):Path(p).write_text(json.dumps(data,indent=2,ensure_ascii=False,allow_nan=False),encoding='utf-8')
def write_csv(p,rows,fields):
    with Path(p).open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)

def orders(pred,map_truth):
    keys=sorted(pred);tie_order=list(keys);random.Random(7).shuffle(tie_order);tie={k:i for i,k in enumerate(tie_order)}
    group=defaultdict(list)
    for k in keys:group[k[0]].append(k)
    features={}
    for groupkeys in group.values():
        verdicts={k:map_truth(pred[k]['truth'],pred[k]['kind']) for k in groupkeys};n_failing=sum(v=='not_met' for v in verdicts.values())
        for k in groupkeys:
            confidence=pred[k].get('confidence');confidence=confidence if isinstance(confidence,(int,float)) and 0<=confidence<=1 else .5
            features[k]={'failing':verdicts[k]=='not_met','n_failing':n_failing,'confidence':confidence}
    # No patient reference labels or checker labels are arguments to this function.
    return {'random':tie_order,
       'least_confident':sorted(keys,key=lambda k:(features[k]['confidence'],tie[k])),
       'fewest_reasons':sorted(keys,key=lambda k:(not features[k]['failing'],features[k]['n_failing'] if features[k]['failing'] else 0,tie[k]))}

def simulation(corpus,rules,pred,ordering,budget,cluster,pair_rows,pair_metrics,map_truth,target):
    before_rows=pair_rows(corpus,rules,pred,cluster,'target');before=pair_metrics(before_rows,0)
    refs={int(p['pair_idx']):target(p['target']) for p in corpus}
    changed={k:dict(r) for k,r in pred.items()};assumption_changes=unknown_effect=0
    for k in ordering[:budget]:
        if refs[k[0]] and map_truth(changed[k]['truth'],changed[k]['kind'])=='not_met':
            changed[k]['truth']='unknown';changed[k]['verdict']='not_stated';assumption_changes+=1
        else:unknown_effect+=1
    after=pair_metrics(pair_rows(corpus,rules,changed,cluster,'target'),0)
    actual=min(budget,len(ordering));rescued=before['false_exclusions']-after['false_exclusions']
    return {'budget':budget,'actual_checks':actual,'label_implied_rescues':rescued,
      'label_implied_rescues_per_10_checks':10*rescued/actual if actual else None,
      'eligible_pair_label_assumption_changes':assumption_changes,'checks_with_unknown_effect':unknown_effect,
      'after':{k:after[k] for k in ('false_exclusions','false_inclusions','review_count','per_cluster')}}

def svg(path,result):
    maximum=max(1,result['before']['false_exclusions']);colors=['#64748b','#2563eb','#059669']
    s=['<svg xmlns="http://www.w3.org/2000/svg" width="800" height="460" viewBox="0 0 800 460">',
       '<rect width="800" height="460" fill="white"/>','<g font-family="sans-serif" fill="#111827">',
       '<text x="60" y="26" font-size="17">Wrong exclusions remaining: pair-label simulation</text>',
       '<text x="60" y="48" font-size="12">Three baseline orders; not observed human correction</text>',
       '<path d="M70 65V365H650" stroke="#111827" fill="none"/>']
    for x in BUDGETS:
        pos=70+5.8*x;s.append(f'<text x="{pos}" y="385" font-size="11">{x}</text>')
    s.append('<text x="280" y="415">Review budget (rule answers)</text>')
    for i,(name,rows) in enumerate(result['strategies'].items()):
        points=[(0,result['before']['false_exclusions'])]+[(r['actual_checks'],r['after']['false_exclusions']) for r in rows]
        joined=' '.join(f'{70+5.8*x},{365-290*y/maximum}' for x,y in points)
        s.append(f'<polyline points="{joined}" fill="none" stroke="{colors[i]}" stroke-width="2"/>')
        s.append(f'<text x="{75+i*235}" y="443" font-size="13" fill="{colors[i]}">{name}</text>')
    for y in range(maximum+1):s.append(f'<text x="43" y="{369-290*y/maximum}" font-size="11">{y}</text>')
    s.append('</g></svg>');path.write_text('\n'.join(s))

def run(root):
    sys.path[:0]=[str(root/'code'),str(root)]
    from criteria import map_truth
    from mtp_completion.common import select,load_predictions
    from mtp_completion.analysis import pair_rows,pair_metrics,target
    stamp=dt.datetime.now(dt.timezone.utc).strftime('%Y%m%d_%H%M%S_%f');out=root/'outputs/mtp_parallel/priority_baselines'/stamp;out.mkdir(parents=True,exist_ok=False)
    summary={}
    for ds,name,cluster in (('nsclc100','plain_ai_qwen_dev.jsonl','trial_id'),('sigir204','plain_ai_qwen_sigir_dev.jsonl','patient_id')):
        path=root/'outputs'/name
        if Path(str(path)+'.INCOMPLETE').exists():raise ValueError('Cannot score an incomplete prediction file: '+str(path))
        corpus,rules=select(root,ds,'dev');pred=load_predictions(path,corpus,rules,ds)
        if len({r.get('system','unrecorded') for r in pred.values()})>1:raise ValueError('Mixed systems in one prediction file.')
        order=orders(pred,map_truth);before=pair_metrics(pair_rows(corpus,rules,pred,cluster,'target'),0)
        data={'dataset':ds,'split':'dev','rows':len(pred),'pair_count':len(corpus),'cluster_by':cluster,
          'scope':'Three non-checker strategy baselines only. No reference criterion labels used.',
          'correction_basis':'Guide 9.3 eligible-pair-label assumption: a checked not_met on a dataset-Eligible pair becomes unknown; otherwise its effect is unknown.',
          'interpretation':'A label-implied rescue means NOT_ELIGIBLE became REVIEW/ELIGIBLE. It is not a verified clinical correction or automatic eligibility approval.',
          'before':{k:before[k] for k in ('false_exclusions','false_inclusions','review_count','sole_reason_false_exclusions','eligible_pairs','ineligible_pairs','per_cluster')},
          'source_prediction_sha256':sha(path),'source_criteria_sha256':sha(root/'datasets'/ds/'criteria.csv'),'seed':7,
          'implementation_sha256':sha(__file__),
          'strategies':{name:[simulation(corpus,rules,pred,keys,b,cluster,pair_rows,pair_metrics,map_truth,target) for b in BUDGETS] for name,keys in order.items()},
          'remaining':['flagged_first and combined require completed checker outputs','Independent criterion/checker accuracy needs usable reference annotations','Frozen held-out evaluation and repair/trap results remain separate']}
        folder=out/ds;folder.mkdir()
        for name,keys in order.items():write_csv(folder/('order_'+name+'.csv'),[dict(pair_idx=k[0],crit_idx=k[1]) for k in keys],['pair_idx','crit_idx'])
        table=[]
        for name,rows in data['strategies'].items():
            row={'strategy':name}
            for r in rows:row['label_implied_rescues_at_'+str(r['budget'])]=r['label_implied_rescues']
            fifty=next(r for r in rows if r['budget']==50);row.update(rescues_per_10_at_50=fifty['label_implied_rescues_per_10_checks'],unknown_effect_checks_at_50=fifty['checks_with_unknown_effect']);table.append(row)
        write_csv(folder/'TABLE2_THREE_BASELINES_SIMULATION.csv',table,list(table[0]));write_json(folder/'RESULTS_NO_NOTES.json',data);svg(folder/'review_curve.svg',data);summary[ds]=data
        print(ds,'| pairs:',len(corpus),'| scored rows:',len(pred),'| before: wrong exclusions',before['false_exclusions'],flush=True)
        for r in table:print(r,flush=True)
    write_json(out/'SUMMARY_NO_NOTES.json',summary)
    (out/'README.txt').write_text('Three baseline review orders, scored using the explicit guide pair-label correction assumption. Not observed human rescues. No criterion reference accuracy, full five-strategy result, or clinical correctness is established. No model calls; no inputs changed.\n')
    print('OUTPUT:',out);print('No Qwen generation or external API calls. Existing workers and files unchanged.')

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=Path.home()/'MTP/Akash_Kit');a=p.parse_args();os.umask(0o077);run(a.root.expanduser().resolve())
if __name__=='__main__':main()
