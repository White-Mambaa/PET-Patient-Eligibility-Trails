#!/usr/bin/env python3
"""Independent MTP development workspaces, bounded workers and blinded annotation."""
import argparse, csv, datetime as dt, email.utils, fcntl, hashlib, json, os
from pathlib import Path
import shutil, signal, subprocess, sys, time, urllib.error, urllib.request
VERSION='parallel-dev-1'
PRIMARY='outputs/mtp_completion/nsclc100/dev/plain_ai_qwen_dev_checks_theta95_fallback_exploratory.jsonl'
STATEMENTS='outputs/mtp_completion/nsclc100/dev/rule_statements_dev95_with_source_fallback.csv'

def now():return dt.datetime.now(dt.timezone.utc).isoformat()
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p,default=None):
    p=Path(p)
    return json.loads(p.read_text()) if p.exists() else default

def save(p,data):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(data,indent=2));tmp.replace(p)

def load_csv(p):
    with Path(p).open(encoding='utf-8-sig',newline='') as f:
        r=csv.DictReader(f);return r.fieldnames,list(r)

def complete(p):
    try:
        p=Path(p)
        if not p.is_file():return False
        m=read(str(p)+'.manifest.json',{})
        if m.get('status')!='COMPLETE' or Path(str(p)+'.INCOMPLETE').exists():return False
        if p.suffix=='.csv':rows=load_csv(p)[1]
        else:
            with p.open() as f:rows=[json.loads(line) for line in f if line.strip()]
        keys={(r.get('pair_idx',r.get('trial_id')),r['crit_idx']) for r in rows}
        return len(rows)==len(keys)==m.get('written')==m.get('expected')
    except (OSError,ValueError,KeyError,TypeError):return False

def progress(p):
    p=Path(p)
    if not p.exists():return 0
    if p.suffix=='.csv':return len(load_csv(p)[1])
    with p.open() as f:return sum(bool(line.strip()) for line in f)

def copy_checked(src,dst):
    src=Path(src);dst=Path(dst);dst.parent.mkdir(parents=True,exist_ok=True)
    if dst.exists():
        if digest(src)!=digest(dst):raise ValueError('Input/code changed since workspace creation: '+str(src))
    else:shutil.copy2(src,dst)

def workspace(root,name):
    ws=root/'outputs/mtp_parallel/workspaces'/name;ws.mkdir(parents=True,exist_ok=True)
    for sub in ('code','mtp_completion'):
        for src in sorted((root/sub).glob('*.py')):copy_checked(src,ws/sub/src.name)
    copy_checked(root/'completion.py',ws/'completion.py')
    for sub in ('datasets','labelling'):
        target=ws/sub
        if not target.exists():target.symlink_to(root/sub,target_is_directory=True)
        if not target.is_symlink() or target.resolve()!=(root/sub).resolve():raise ValueError('Unexpected workspace input path: '+str(target))
    for name in ('plain_ai_qwen_dev.jsonl','plain_ai_qwen_sigir_dev.jsonl'):
        p=root/'outputs'/name
        if p.exists():copy_checked(p,ws/'outputs'/name)
    return ws

def key_list():
    p=Path.home()/'.config/mtp/groq_keys.json';keys=[]
    if p.exists():
        if p.is_symlink() or p.stat().st_mode & 0o077:raise ValueError('Saved key file must be private (chmod 600) and not a symlink.')
        keys=read(p,{}).get('keys',[])
    active=os.environ.get('GROQ_API_KEY','').strip()
    if active:keys=[active]+keys
    if not isinstance(keys,list) or any(not isinstance(k,str) or not k.strip() for k in keys):raise ValueError('Invalid saved keys.')
    return list(dict.fromkeys(keys))

def schema_ok(data,prompt):
    if not isinstance(data,dict):return False
    if prompt=='RULE_STATEMENT_v1':
        terms=data.get('key_terms')
        return isinstance(data.get('statement'),str) and bool(data['statement'].strip()) and isinstance(terms,list) and 1<=len(terms)<=3 and all(isinstance(t,str) and t.strip() for t in terms)
    if prompt=='SUPPORT_v1':return data.get('label') in ('entailment','contradiction','neutral')
    if prompt=='INFERENCE_LOGIC_v1':return type(data.get('valid')) is bool and isinstance(data.get('reason'),str)
    return True

def worker(config_path,index):
    config=read(config_path);stage=config['stages'][index];ws=Path(config['workspace']);state=Path(config['state'])
    os.chdir(ws);sys.path[:0]=[str(ws/'code'),str(ws)]
    from llm_client import CallFailed
    from mtp_completion import client,workflow
    actual=urllib.request.urlopen
    def guarded(req,*a,**kw):
        url=getattr(req,'full_url',str(req))
        counted=url=='https://api.groq.com/openai/v1/chat/completions' or (url.startswith('http://localhost:11434/') and url.endswith('/api/chat'))
        if counted:
            b=read(state/'BUDGET.json')
            if b['attempts']>=b['limit']:raise CallFailed('PARALLEL_BUDGET_EXHAUSTED')
            b['attempts']+=1;save(state/'BUDGET.json',b)
        try:return actual(req,*a,**kw)
        except urllib.error.HTTPError as e:
            save(state/'failure.json',{'type':'http','code':e.code,'retry_after':e.headers.get('Retry-After',''),'time':now()});raise
    urllib.request.urlopen=guarded
    original=client.ask
    def bounded_schema(client_obj,system,payload,prompt_id):
        last=None
        for attempt in range(2):
            sys_prompt=system if attempt==0 else system+'\nFORMAT REPAIR: Return exactly the requested JSON object and field types. key_terms, when requested, must have 1 to 3 nonempty strings. Preserve all conditions and exceptions. No extra text.'
            try:
                result=original(client_obj,sys_prompt,payload,prompt_id if attempt==0 else prompt_id+'_FORMAT_RETRY')
                if schema_ok(result.get('data'),prompt_id):return result
                last=CallFailed('Invalid structured response: '+prompt_id)
            except CallFailed as e:
                # Never use a schema retry for transport, quota or request budgets.
                if 'JSON object' not in str(e):raise
                last=e
            with (state/'schema_retries.jsonl').open('a') as f:
                f.write(json.dumps({'time':now(),'prompt_id':prompt_id,'attempt':attempt+1})+'\n')
        raise last
    client.ask=workflow.ask=bounded_schema
    def trace(frame,event,arg):
        if event=='exception' and frame.f_code.co_name in ('run_check','run_statements','run_baseline','run_repair','run'):
            typ,err,_=arg
            if isinstance(err,CallFailed):
                msg=str(err);key=os.environ.get('GROQ_API_KEY','')
                if key:msg=msg.replace(key,'[REDACTED]')
                old=read(state/'failure.json',{});old.update(message=msg[:800],time=now());save(state/'failure.json',old)
                print('WORKER FAILURE:',msg[:800],flush=True)
        return trace
    sys.settrace(trace)
    sys.argv=['completion.py']+stage['args']
    import runpy
    runpy.run_path(str(ws/'completion.py'),run_name='__main__')

def plan(ws,job,pause):
    stages=[]
    def add(name,cmd,dataset,out,extra,backend='groq',model='openai/gpt-oss-20b'):
        args=[cmd,'--root',str(ws),'--dataset',dataset,'--split','dev','--backend',backend,'--model',model,'--out',str(out),'--max-calls','6000','--pause',str(pause),'--retries','0']+extra
        stages.append({'name':name,'out':str(out),'args':args})
    if job=='sigir':
        folder=ws/'outputs/mtp_completion/sigir204/dev';stm=folder/'statements.csv';checks=folder/'qwen_checks_exploratory.jsonl'
        add('SIGIR rule statements','statements','sigir204',stm,['--limit','0'])
        add('SIGIR six-check audit','check','sigir204',checks,['--pred',str(ws/'outputs/plain_ai_qwen_sigir_dev.jsonl'),'--statements',str(stm),'--theta','95','--limit','0','--allow-unreviewed-statements'])
    else:
        for ds in ('nsclc100','sigir204'):
            for mode in ('unknown','forced'):
                out=ws/'outputs/mtp_completion'/ds/'dev'/('qwen_'+mode+'.jsonl')
                add(ds+' '+mode,'baseline',ds,out,['--policy',mode,'--limit','0','--num-ctx','8192','--max-output','400'],'ollama','qwen2.5:7b')
    return stages

def stop_child(child):
    if child is None or child.poll() is not None:return
    os.killpg(child.pid,signal.SIGINT)
    try:child.wait(timeout=20)
    except subprocess.TimeoutExpired:
        os.killpg(child.pid,signal.SIGTERM)
        try:child.wait(timeout=5)
        except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()

def run_job(a):
    root=a.root.resolve();base=root/'outputs/mtp_parallel';base.mkdir(parents=True,exist_ok=True)
    lock=(base/(a.job+'.lock')).open('a')
    try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:raise SystemExit('This parallel job is already running.')
    for rel in ('code/llm_client.py','code/stats_tools.py','completion.py'):
        if not (root/rel).is_file():raise ValueError('Missing project file: '+rel)
    ws=workspace(root,a.job);state=base/'state'/a.job;state.mkdir(parents=True,exist_ok=True)
    if a.job=='qwen':
        # Only seed a new local cache. Never write back to the existing cache.
        cache=ws/'outputs/mtp_completion/cache/ollama/cache_qwen2.5-7b.jsonl';old=root/'outputs/cache/cache_qwen2.5-7b.jsonl'
        if not cache.exists() and old.exists():cache.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(old,cache)
    budget=state/'BUDGET.json'
    if budget.exists():
        if read(budget)['limit']!=a.max_attempts:raise ValueError('Budget belongs to an existing run; reuse the same --max-attempts value.')
    else:save(budget,{'attempts':0,'limit':a.max_attempts,'kind':'external API attempts' if a.job=='sigir' else 'local Ollama generation attempts'})
    config={'version':VERSION,'workspace':str(ws),'state':str(state),'stages':plan(ws,a.job,a.pause),'runner_sha256':digest(__file__),
      'scope':'DEVELOPMENT ONLY; exploratory; format retries recorded; no reference labels inferred'}
    cp=state/'JOB.json'
    if cp.exists() and read(cp)!=config:raise ValueError('Job runner/settings changed; preserve this run and choose a new workspace rather than mixing results.')
    save(cp,config)
    keys=key_list() if a.job=='sigir' else [''];ki=0
    if a.job=='sigir' and not keys:raise ValueError('Configure authorised keys using the existing V3 setup first.')
    started=time.monotonic();deadline=started+a.hours*3600;child=None;restarts=0;no_progress=0
    def status(label,stage=None):
        data={'time_utc':now(),'job':a.job,'status':label,'stage':stage['name'] if stage else None,
         'saved_rows':progress(stage['out']) if stage else None,'requests':read(budget),'workspace':str(ws),'restarts':restarts}
        save(state/'STATUS.json',data)
        return data
    print('JOB STATUS:',state/'STATUS.json',flush=True)
    try:
        for i,stage in enumerate(config['stages']):
            if complete(stage['out']):print('Already complete:',stage['name'],flush=True);continue
            while True:
                if time.monotonic()>=deadline:status('TIME_LIMIT',stage);return
                if read(budget)['attempts']>=a.max_attempts:status('BUDGET_LIMIT',stage);return
                (state/'failure.json').unlink(missing_ok=True)
                before=progress(stage['out']);env=os.environ.copy();env['LOGURU_LEVEL']='WARNING'
                if a.job=='sigir':env['GROQ_API_KEY']=keys[ki]
                with (state/'console.log').open('a') as log:
                    child=subprocess.Popen([sys.executable,'-u',str(Path(__file__).resolve()),'worker','--config',str(cp),'--index',str(i)],stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True)
                    while child.poll() is None:
                        d=status('RUNNING',stage);print(stage['name'],'| saved',d['saved_rows'],'| attempts',d['requests']['attempts'],flush=True)
                        if time.monotonic()>=deadline:stop_child(child);status('TIME_LIMIT',stage);return
                        time.sleep(10)
                exit_code=child.returncode;child=None
                if complete(stage['out']):status('STAGE_COMPLETE',stage);break
                fail=read(state/'failure.json',{});msg=fail.get('message','Worker exited '+str(exit_code)+'; inspect console.log');print('STOP DETAIL:',msg,flush=True)
                after=progress(stage['out']);no_progress=no_progress+1 if after==before else 0
                if 'BUDGET' in msg:status('BUDGET_LIMIT',stage);return
                if fail.get('code') in (401,403) and ki+1<len(keys):ki+=1;restarts+=1;continue
                http=fail.get('code');transport='Transport' in msg or 'model call failed' in msg
                retry=http in (429,500,502,503,504) or transport and no_progress<3
                if not retry or restarts>=a.max_restarts:
                    status('NEEDS_ATTENTION',stage);return
                wait=min(1800,60*2**min(no_progress,5));raw=fail.get('retry_after','')
                if raw:
                    try:wait=max(wait,float(raw))
                    except ValueError:
                        try:wait=max(wait,email.utils.parsedate_to_datetime(raw).timestamp()-time.time())
                        except (ValueError,TypeError):pass
                if transport:print('Network retry may incur a duplicate charge; limited to 3 stalls.',flush=True)
                if time.monotonic()+wait>=deadline:status('PAUSED_FOR_RESET',stage);return
                until=time.monotonic()+wait
                while time.monotonic()<until:status('WAITING_TO_RETRY',stage);time.sleep(min(10,max(0,until-time.monotonic())))
                restarts+=1
        status('COMPLETE');print('Completed:',a.job,'development stages. Reports are generated by the reports job.',flush=True)
    except KeyboardInterrupt:stop_child(child);status('INTERRUPTED');print('Saved work retained.')
    except Exception:stop_child(child);status('SUPERVISOR_ERROR');raise


def report_watch(a):
    root=a.root.resolve();base=root/'outputs/mtp_parallel';base.mkdir(parents=True,exist_ok=True)
    lock=(base/'reports.lock').open('a')
    try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:raise SystemExit('Report watcher already running.')
    done=read(base/'REPORT_INDEX.json',{});deadline=time.monotonic()+a.hours*3600
    while True:
        specs=[('primary_nsclc',root,'nsclc100',root/'outputs/plain_ai_qwen_dev.jsonl',root/PRIMARY)]
        sw=base/'workspaces/sigir';specs.append(('sigir_checked',sw,'sigir204',sw/'outputs/plain_ai_qwen_sigir_dev.jsonl',sw/'outputs/mtp_completion/sigir204/dev/qwen_checks_exploratory.jsonl'))
        qw=base/'workspaces/qwen'
        for ds in ('nsclc100','sigir204'):
            for mode in ('unknown','forced'):specs.append((ds+'_'+mode,qw,ds,qw/'outputs/mtp_completion'/ds/'dev'/('qwen_'+mode+'.jsonl'),None))
        available=0
        for name,ws,ds,pred,checks in specs:
            if not pred.exists() or (checks is not None and not complete(checks)) or (checks is None and not complete(pred)):continue
            label=root/'labelling'/('my_label_sheet.csv' if ds=='nsclc100' else 'sigir_label_sheet.csv')
            fingerprint=hashlib.sha256((digest(pred)+(digest(checks) if checks else '')+(digest(label) if label.exists() else '')).encode()).hexdigest()
            available+=1
            if done.get(name,{}).get('input_hash')==fingerprint:continue
            out=base/'reports'/name/dt.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
            cmd=[sys.executable,str(ws/'completion.py'),'report','--root',str(ws),'--dataset',ds,'--split','dev','--pred',str(pred),'--bootstrap','1000','--out',str(out)]
            if checks:cmd+=['--checks',str(checks)]
            if label.exists():cmd+=['--labels',str(label),'--label-provenance','student_ai_assisted']
            completed=subprocess.run(cmd,cwd=ws)
            if completed.returncode==0:
                done[name]={'input_hash':fingerprint,'report':str(out/'REPORT.md'),'results':str(out/'RESULTS.json'),'time':now()};save(base/'REPORT_INDEX.json',done)
        save(base/'REPORT_STATUS.json',{'time':now(),'available_complete_inputs':available,'reported':list(done),'pending':[x[0] for x in specs if x[0] not in done],
             'note':'Empty references mean criterion/checker accuracy is unavailable; complete automated reports do not complete the whole study.'})
        print(now(),'| reports ready:',len(done),'| watcher active',flush=True)
        if time.monotonic()>=deadline or a.once:return
        time.sleep(60)


def review(a):
    root=a.root.resolve();path=root/'labelling'/('my_label_sheet.csv' if a.dataset=='nsclc100' else 'sigir_label_sheet.csv')
    fields,rows=load_csv(path);expected=digest(path)
    private=root/'outputs/mtp_parallel/private_review';private.mkdir(parents=True,exist_ok=True);os.chmod(private,0o700)
    backup=private/(path.stem+'_'+dt.datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.csv');shutil.copy2(path,backup);os.chmod(backup,0o600)
    print('Blinded manual labels: no model suggestions or pair eligibility labels displayed.')
    print('Follow original guide 6.3. unknown = absent information; UNSURE: = uncertainty about interpretation.')
    for r in rows:
        if r.get('split')!=a.split or r.get('truth','').strip():continue
        print('\nCASE',r.get('pair_idx'),r.get('crit_idx'),'KIND',r.get('kind'))
        print('CRITERION:',r.get('criterion_text'));print('GUIDANCE:',r.get('criterion_note',''));print('PRIVATE NOTE:',r.get('patient_note'))
        truth=input('truth yes/no/unknown; s=skip, q=quit > ').strip().lower()
        if truth=='q':break
        if truth=='s':continue
        if truth not in ('yes','no','unknown'):print('Invalid choice; row unchanged.');continue
        ev=input('Exact evidence (multiple spans separated by ||; blank for absent information) > ').strip()
        if (truth!='unknown' and not ev) or any(s.strip() not in r['patient_note'] for s in ev.split('||') if s.strip()):print('Evidence missing or not exact; row unchanged.');continue
        basis=input('basis stated/inferred/absent > ').strip().lower()
        if basis not in ('stated','inferred','absent'):print('Invalid basis; row unchanged.');continue
        na=input('not_applicable Y or Enter > ').strip().upper();compound=input('compound Y or Enter > ').strip().upper()
        comment=input('Comment (start UNSURE: when unsure of interpretation) > ').strip()
        if na not in ('','Y') or compound not in ('','Y'):print('Invalid flags; row unchanged.');continue
        if na=='Y' and truth!=('yes' if r['kind']=='inclusion' else 'no'):print('Not-applicable truth conflicts with guide; row unchanged.');continue
        if input('Save this human judgment? y/Enter > ').strip().lower()!='y':continue
        if digest(path)!=expected:raise ValueError('Sheet changed in another editor; stopping to preserve both versions.')
        r.update(truth=truth,evidence_span=ev,basis=basis,not_applicable=na,compound=compound,comment=comment)
        tmp=path.with_suffix('.review.tmp')
        with tmp.open('w',encoding='utf-8-sig',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows(rows)
        tmp.replace(path);os.chmod(path,0o600);expected=digest(path);print('Saved human judgment.')
    print('Review finished. Backup:',backup)


def main():
    os.umask(0o077)
    p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='job',required=True)
    for job in ('sigir','qwen','reports','review'):
        q=sub.add_parser(job);q.add_argument('--root',type=Path,default=Path.home()/'MTP/Akash_Kit')
        q.add_argument('--hours',type=float,default=24);q.add_argument('--max-attempts',type=int,default=6000 if job=='sigir' else 4500)
        q.add_argument('--max-restarts',type=int,default=30);q.add_argument('--pause',type=float,default=20)
        q.add_argument('--once',action='store_true');q.add_argument('--dataset',choices=('nsclc100','sigir204'),default='nsclc100');q.add_argument('--split',choices=('dev','test'),default='dev')
    q=sub.add_parser('worker');q.add_argument('--config',type=Path,required=True);q.add_argument('--index',type=int,required=True)
    a=p.parse_args()
    if a.job=='worker':return worker(a.config,a.index)
    if a.hours<=0 or a.max_attempts<1 or a.pause<0:raise SystemExit('Invalid job limits.')
    if a.job in ('sigir','qwen'):return run_job(a)
    if a.job=='reports':return report_watch(a)
    return review(a)
if __name__=='__main__':
    try:main()
    except KeyboardInterrupt:print('Interrupted; completed records retained.')
    except (ValueError,FileNotFoundError,ImportError) as e:raise SystemExit(str(e))
