# Main MTP completion package

Scope: **Check What Can Change the Outcome**, using the supplied Akash project guide and SIGIR pack. No AAPEMS, SQL-agent extension or MIMIC/eICU work is included.

## First run: useful outputs with no new API calls

Extract this folder into Downloads. Install into the existing kit:

```bash
python3 ~/Downloads/MTP_MAIN_COMPLETION/INSTALL.py --root ~/MTP/Akash_Kit --install
cd ~/MTP/Akash_Kit
bash run_main_mtp_offline.sh
```

This tests the new modules, inventories the main project, and scores the **existing complete Qwen development predictions against the dataset's pair-level Eligible/Not Eligible labels**. It creates separate NSCLC and SIGIR reports under a new `outputs/mtp_completion/offline_...` directory. It does not require completed student labels to calculate pair-level results. Blank student-label metrics are explicitly unavailable, not estimated from model predictions.

**The previously reported 92.73% model-field agreement is not clinical accuracy.** This package reports three-way exact accuracy (REVIEW not a correct decision), binary REVIEW-as-negative accuracy, and binary REVIEW-as-positive accuracy separately. That resolves an important source of earlier conflicting numbers. Report counts and policy definitions beside every accuracy.

No original kit code, datasets or labels are replaced. Existing completion-package files are backed up before an upgrade. Private output directories are created with a restrictive process umask.

## What the actual guide says

- Your annotations are **student labels**, not clinician-confirmed gold. Student labelling is an assigned task, not an API task.
- `criterion_note` overrides ambiguity. Standard clinical implications are allowed, marked `inferred`. Do not infer undocumented patient events, measurements or dates.
- `UNSURE:` comments represent uncertainty in applying a rule; `unknown` represents insufficient patient information. These are different.
- Student labels must not be copied from model outputs. Annotating after seeing AI suggestions is AI-assisted; report that exposure and use independent overlap review where applicable.
- The original guide is local-only. The later reported instruction from Neha providing API access is treated as a supervisor-authorised backend change; disclose external Groq use in the methods. Groq is the provider, not xAI Grok. The hosted model ID is part of provenance.

## Dependencies and tests

```bash
cd ~/MTP/Akash_Kit
.venv/bin/python -m pip install -r requirements_mtp_completion.txt
.venv/bin/python completion_selftest.py --root "$PWD"
```

The base offline report needs the kit's existing pandas. Citation fuzzy matching uses rapidfuzz. Guide check 3 uses medspaCy; its five extension names are verified on startup. There is no silent fallback if it is unavailable. `--context-backend judge` is an explicitly experimental API alternative, not a claim of implementing medspaCy.

Optional support option A:

```bash
.venv/bin/python -m pip install sentence-transformers
```

This downloads local NLI model weights when first selected. The model's three-way label mapping is checked. Option B is a separately prompted AI judge. Compare both on development labels, as the guide requires, before selecting the final method. The package author did not make live API calls or download medspaCy/NLI models during development; see TEST_RESULTS.md in the downloaded package.

## Groq keys and spending limits

Keep the key only in your environment:

```bash
read -r -s -p 'API key: ' GROQ_API_KEY
printf '\n'
export GROQ_API_KEY
```

API commands default to 10 maximum HTTP generation attempts and a 10-second minimum interval. Retries count toward the cap; an optional retry obeys Retry-After when at most 60 seconds, otherwise stops for explicit later resumption. Authentication failures are not retried. Network failures with uncertain billing are not automatically retried. There is no automatic key rotation to bypass account limits. Multiple subject/judge clients share one request budget within a command.

All prompts use the kit's LocalLLM interface: the Groq client subclasses it, keeping full-prompt caching and parse-failure handling. Raw returned reasoning is not saved by the transport. Usage logs omit credentials and prompts. The response cache and decision files can contain clinical text, so keep them private. These are request caps, not guaranteed monetary ceilings. A timeout may have unknown usage.

## A. Two baseline policies

The existing Qwen predictions remain valid inputs if complete and structurally verified. A Groq subject is a new comparison or explicitly agreed replacement, not automatically the same experiment.

Small Groq engineering pilot (five questions per separate policy; at most ten new attempts total):

```bash
.venv/bin/python completion.py baseline --root "$PWD" --dataset nsclc100 \
  --backend groq --model openai/gpt-oss-20b --policy both --limit 5 --max-calls 10
```

Full development run: use `--limit 0`, enough `--max-calls`, and adequate pacing. Both policies must use the same reported main model. Pilot outputs cannot be used as full-pair results. A failed API call stops safely with `.INCOMPLETE`; successful responses/rows are reused on an identical rerun. An unparseable response is retained with `parse_ok=false` and counted, not silently dropped.

The original `code/plain_ai.py` and its local behaviour are preserved.

## B. Generate rule statements, then review them

Start with five rules, or `--limit 0` for the whole development rule set:

```bash
.venv/bin/python completion.py statements --root "$PWD" --dataset nsclc100 \
  --model openai/gpt-oss-20b --backend groq --limit 5 --max-calls 5
```

The output CSV contains the original condition and guidance, generated `statement`, `key_terms` as a JSON array, `reviewed`, `reviewer` and `comment`. Hand-check the statement/terms and mark reviewed=true. Never edit original condition/guidance. For an engineering pilot only, checking can explicitly allow unreviewed statements. This status is recorded and must not be reported as a frozen validated method.

Generate SIGIR statements using `--dataset sigir204`. The original guide specifies 95 unique NSCLC development rules and 128 test rules, not 1,940 unique statements; patient-rule answers repeat the same trial rules.

## C. Run all six checks

For the first five existing Qwen answers:

```bash
.venv/bin/python completion.py check --root "$PWD" --dataset nsclc100 \
  --pred outputs/plain_ai_qwen_dev.jsonl \
  --statements outputs/mtp_completion/nsclc100/dev/rule_statements_pilot5.csv \
  --allow-unreviewed-statements --limit 5 --max-calls 20
```

Default methods follow the guide: rapidfuzz citation, support AI judge, medspaCy assertion context, deterministic truth/verdict and interval numeric checks, unquoted-sentence contradiction search, and deciding-sentence search for unknown answers. Precedence exactly follows section 8.8. Quote mismatches are not automatically clinical fabrications: nonexact spans above the chosen threshold are PARAPHRASED with the matched text stored. No-quote unknown answers are recorded as citation not applicable.

Numerical checks cover compatible named measures/units, point values, comparison bounds and simple ranges. Mixed units, multiple conflicting values and unsupported compound numeric logic abstain from a deterministic conclusion instead of guessing. Additional complex units/ULN conversions require extension and validation; they are not claimed as supported.

A judge support request is cached per full statement/evidence pair. Contradiction and missed-evidence scan sentences independently, following the guide. If an unknown answer's note has both support and contradiction, the package records a conflict instead of asserting that one sentence decides the answer. This conflict guard is an explicit implementation detail requiring development evaluation.

For a complete checker run: review the complete statement file, use it without `--allow-unreviewed-statements`, and use `--limit 0`. Successful cases are checkpointed. Budget exhaustion pauses with INCOMPLETE; rerun the same command with a fresh per-run cap. Do not evaluate the incomplete file as a complete checker.

## D. Threshold calibration on development data

Export up to 60 non-verbatim quotes for human classification:

```bash
.venv/bin/python completion.py calibrate-citation --root "$PWD" --dataset nsclc100 \
  --pred outputs/plain_ai_qwen_dev.jsonl --out outputs/mtp_completion/citation_calibration.csv
```

Fill `human_label` with `real_paraphrase` or `invented`, then:

```bash
.venv/bin/python completion.py calibrate-citation --root "$PWD" --dataset nsclc100 \
  --pred outputs/plain_ai_qwen_dev.jsonl \
  --calibration-labels outputs/mtp_completion/citation_calibration.csv \
  --out outputs/mtp_completion/citation_calibration.csv
```

The result evaluates theta {70,75,80,85,90,95}; the tie-break chooses the higher threshold. Inspect the sample and label distribution; thresholds are not calibrated by default. For local NLI option A, repeat complete development checks with `--support-backend nli --tau 0.5` through 0.9, score each against student labels, compare flag quality to option B, and freeze the selected method/tau. No test-set tuning.

## E. Report, prioritisation and ablations

```bash
.venv/bin/python completion.py report --root "$PWD" --dataset nsclc100 \
  --pred outputs/plain_ai_qwen_dev.jsonl \
  --checks PATH_TO_COMPLETE_CHECKER.jsonl \
  --labels labelling/my_labels_final.csv --label-provenance student_unassisted
```

Use `student_ai_assisted` when appropriate. Reports include rule accuracy/macro-F1/class metrics; checker precision/recall/F1; all/without-UNSURE comparisons; six ablations; five guide orders (random seed 7); 5/10/20/50/100-budget simulations; rescued pairs per 10 checks; unknown-effect checks; trial/patient comparisons with sign tests/Holm adjustment; rejection-risk P/R@3/5/10; keep-versus-flag changes; per-cluster results; bootstrap interval; rarity reweighting. SIGIR is reported separately, with its development-median count-the-rules baseline.

Guide section 9.3 uses dataset Eligible labels in the **scoring simulation** to remove unsupported rejection reasons when no student label exists. This is reported as an assumption, never as actual blinded coordinator rescue. Rankings never use the answer key.

`VERIFIED` means no implemented check flagged the answer; it is not proof of correctness. Self-reported model confidence is not calibrated probability. No Brier/ECE claim is made.

The package emits `student_pair_label_conflicts.csv`. Also run the kit's mandatory `code/evaluate.py labelcheck` on final student labels and send conflicts to the supervisor; record dispositions rather than changing labels to match pair outcomes. Peer overlap agreement remains a required human workflow; use the existing `evaluate.py kappa --overlap-only` when both independently prepared sheets are available.

## F. Repair versus deferral

```bash
.venv/bin/python completion.py repair --root "$PWD" --dataset nsclc100 \
  --pred outputs/plain_ai_qwen_dev.jsonl --checks PATH_TO_COMPLETE_CHECKER.jsonl \
  --statements PATH_TO_REVIEWED_STATEMENTS.csv \
  --subject-backend ollama --subject-model qwen2.5:7b \
  --backend groq --model openai/gpt-oss-20b --repair-budget 5 --max-calls 20
```

Top flagged answers in combined order are re-asked exactly once with the original subject model/policy and feedback; every new answer is checked again. Only VERIFIED revisions are accepted; other revisions become unknown with recorded deferral provenance. Recheck/API failure keeps the run incomplete. `--repair-budget 0` processes all flagged answers. Report with `--after PATH_TO_COMPLETE_REPAIR.jsonl` to count fixed, broken, unchanged, pair-level changes and review load. All/without-UNSURE counts are separate.

## G. Seven controlled trap types

```bash
.venv/bin/python completion.py prepare-traps --root "$PWD" --dataset nsclc100 \
  --labels labelling/my_labels_final.csv --statements PATH_TO_REVIEWED_STATEMENTS.csv
```

This proposes development-only NEGATION, FAMILY_HISTORY, HYPOTHETICAL, OLD_VALUE, CONTRADICTION, EVIDENCE_REMOVED and THRESHOLD_SHIFT drafts, up to 20 suitable cases/type. Unsupported source cases yield fewer cases, not fabricated coverage. Every draft starts `checked_by_hand=false`; verify the altered note, other evidence, grammar and expected answer before marking true. This is unavoidable assigned work in the guide.

```bash
.venv/bin/python completion.py run-traps --root "$PWD" --dataset nsclc100 \
  --traps PATH_TO_HAND_CHECKED_TRAPS.jsonl --statements PATH_TO_REVIEWED_STATEMENTS.csv \
  --subject-backend ollama --subject-model qwen2.5:7b --policy unknown --limit 5 --max-calls 20
.venv/bin/python completion.py trap-report --root "$PWD" --results PATH_TO_COMPLETE_TRAP_RESULTS.jsonl
```

Use `--limit 0` for the full checked trap set, and separately run the forced policy. The runner uses the altered note, verifies source development membership and operation consistency, and refuses unreviewed cases. The report uses hand-checked expected truths, counts failures/unparseable answers, and reports trap/detection/expected-label rates per type.

## H. Freeze before test runs

First finish assigned student labels, run mandatory labelchecks and peer comparisons, review development statements, calibrate thresholds, select support/context methods and complete development experiments. Then register hashes:

```bash
.venv/bin/python completion.py freeze --root "$PWD" \
  --labels-file labelling/my_labels_final.csv \
  --labels-file labelling/my_sigir_labels_final.csv \
  --artifacts PATH_TO_REVIEWED_DEV_STATEMENTS.csv PATH_TO_CALIBRATION_SELECTION.json \
  --subject-backend ollama --subject-model qwen2.5:7b \
  --backend groq --model openai/gpt-oss-20b \
  --label-provenance student_unassisted --theta SELECTED_THETA \
  --out outputs/mtp_completion/METHOD_FREEZE.json
```

Replace placeholders with real paths/values. Include both datasets' reviewed statements as artifacts if they are part of the agreed protocol. The freeze checks complete assigned development/test label coverage, hashes the implementation and listed artifacts, and refuses overwriting an existing freeze. Hashes cannot prove independent labelling, supervisor decisions, or peer agreement: record these separately.

API-bearing `--split test` commands require `--freeze`, unchanged code/artifacts and matching subject/judge settings. Generate test statements after freezing; their initial generated bytes are hashed separately and must remain unedited. Save all failed/difficult/unparseable rows; do not tune or rerun to seek better test results. Cache-based recovery of interrupted execution is distinct from methodological retuning.

## What this package does not establish

It delivers executable implementation and offline/mocked tests, **not completion of the research**. Full real-data execution, medspaCy/NLI integration in your environment, threshold calibration, student annotation completion, peer agreement, supervised conflict decisions and held-out evaluation remain required. Dataset files were excluded from the uploaded source ZIP, so live corpus metrics were not fabricated. Originals and raw AI proposals are retained; the earlier annotation-assistant experiments do not become student reference labels.

## I. Dataset comparison (Table 8)

After both complete reports exist:

```bash
.venv/bin/python completion.py compare-datasets --root "$PWD" \
  --nsclc-results PATH_TO_NSCLC_RESULTS.json --sigir-results PATH_TO_SIGIR_RESULTS.json \
  --strategy combined --out outputs/mtp_completion/TABLE8.json
```

Use the strategy selected on development data. The command checks dataset identities, split equality and recorded subject-model equality. Its error-type distribution is explicitly checker-assigned, not independently confirmed human error-type ground truth.

Freeze records the subject completion cap separately (`--subject-max-output`, default 400, matching the original Qwen setup) from the judge cap (`--max-output`, default 2048). Supply `--max-output` matching the frozen subject cap on test baseline commands. Repair supports `--subject-max-output`; use the subject's actual registered setting.
