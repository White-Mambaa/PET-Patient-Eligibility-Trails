#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
ROOT="$PWD"
PYTHON="$ROOT/.venv/bin/python"
if [ ! -x "$PYTHON" ]; then PYTHON=python3; fi
RUN_ID="$(date +%Y%m%d_%H%M%S)_$$"
REPORT_ROOT="$ROOT/outputs/mtp_completion/offline_$RUN_ID"
mkdir -p "$REPORT_ROOT"
"$PYTHON" completion_selftest.py --root "$ROOT" 2>&1 | tee "$REPORT_ROOT/software_tests.txt"
"$PYTHON" completion.py status --root "$ROOT" --out "$REPORT_ROOT/PROJECT_STATUS.json" | tee "$REPORT_ROOT/status_console.txt"
for DATASET in nsclc100 sigir204; do
 if [ "$DATASET" = nsclc100 ]; then
  PRED="$ROOT/outputs/plain_ai_qwen_dev.jsonl"
  LABELS="$ROOT/labelling/my_labels_final.csv"
  if [ ! -f "$LABELS" ]; then LABELS="$ROOT/labelling/my_label_sheet.csv"; fi
 else
  PRED="$ROOT/outputs/plain_ai_qwen_sigir_dev.jsonl"
  LABELS="$ROOT/labelling/my_sigir_labels_final.csv"
  if [ ! -f "$LABELS" ]; then LABELS="$ROOT/labelling/sigir_label_sheet.csv"; fi
 fi
 if [ ! -f "$PRED" ]; then
  echo "Missing known baseline: $PRED. Use completion.py report --pred with the correct full-development file."
  continue
 fi
 LABEL_ARGS=()
 if [ -f "$LABELS" ]; then LABEL_ARGS=(--labels "$LABELS" --label-provenance student_ai_assisted); fi
 "$PYTHON" completion.py report --root "$ROOT" --dataset "$DATASET" --split dev \
   --pred "$PRED" "${LABEL_ARGS[@]}" --out "$REPORT_ROOT/$DATASET" \
   2>&1 | tee "$REPORT_ROOT/${DATASET}_console.txt"
done
printf '\nOFFLINE OUTPUTS: %s\n' "$REPORT_ROOT"
printf 'No API generation calls were made by this script. Reported student-label metrics may be unavailable.\n'
