# Software verification
Synthetic fixtures and mocked model responses only. No live API requests.
```text
test_blank_student_labels_unavailable (__main__.Tests.test_blank_student_labels_unavailable) ... ok
test_broken_not_fixed (__main__.Tests.test_broken_not_fixed) ... ok
test_budget_shared_across_models (__main__.Tests.test_budget_shared_across_models) ... ok
test_checker_integration_mock_semantics (__main__.Tests.test_checker_integration_mock_semantics) ... ok
test_fuzzy_if_installed (__main__.Tests.test_fuzzy_if_installed) ... skipped 'rapidfuzz not installed in this environment'
test_invalid_not_unknown_success (__main__.Tests.test_invalid_not_unknown_success) ... ok
test_label_precedence (__main__.Tests.test_label_precedence) ... ok
test_mapping_and_sole_reason (__main__.Tests.test_mapping_and_sole_reason) ... ok
test_medspacy_if_installed (__main__.Tests.test_medspacy_if_installed) ... skipped 'medspaCy not installed; actual integration remains unverified here'
test_mock_groq_cache_and_cap (__main__.Tests.test_mock_groq_cache_and_cap) ... ok
test_no_missing_pair_scoring (__main__.Tests.test_no_missing_pair_scoring) ... ok
test_numeric_age_and_multiple_values (__main__.Tests.test_numeric_age_and_multiple_values) ... ok
test_numeric_bounds (__main__.Tests.test_numeric_bounds) ... ok
test_numeric_ecog (__main__.Tests.test_numeric_ecog) ... ok
test_quotes (__main__.Tests.test_quotes) ... ok
test_ranking_never_reads_reference (__main__.Tests.test_ranking_never_reads_reference) ... ok
test_review_definitions_separate (__main__.Tests.test_review_definitions_separate) ... ok
test_transport_failure_not_unknown (__main__.Tests.test_transport_failure_not_unknown) ... ok

----------------------------------------------------------------------
Ran 18 tests in 0.009s

OK (skipped=2)
PASS complete offline report, labels, strategies, ablations, risk, deferral: nsclc100
PASS complete offline report, labels, strategies, ablations, risk, deferral: sigir204
PASS freeze gate and post-freeze mutation refusal
PASS development trap drafting and unreviewed execution refusal
FIXTURE INTEGRATION PASS. No real API calls. Synthetic test metrics are not project results.
unknown saved 1 / 1
OUTPUT: /tmp/tmpr32n_m4d/pred.jsonl | records: 1 / 1 | status: COMPLETE
OUTPUT: /tmp/tmpr32n_m4d/pred.jsonl | records: 1 / 1 | status: COMPLETE
Statement saved: 1 / 1
OUTPUT: /tmp/tmpr32n_m4d/statements.csv | records: 1 / 1 | status: COMPLETE
Checked: 1 / 1 label: LOGIC_ERROR
OUTPUT: /tmp/tmpr32n_m4d/checks.jsonl | records: 1 / 1 | status: COMPLETE
OUTPUT: /tmp/tmpr32n_m4d/repair.jsonl | records: 1 / 1 | status: COMPLETE
MODEL WORKFLOW MOCK PASS: baseline checkpoint reuse, statement review, checker precedence, same-subject re-ask and recheck. No real API calls.
```
Live dataset evaluation and local NLI integration remain unverified.
