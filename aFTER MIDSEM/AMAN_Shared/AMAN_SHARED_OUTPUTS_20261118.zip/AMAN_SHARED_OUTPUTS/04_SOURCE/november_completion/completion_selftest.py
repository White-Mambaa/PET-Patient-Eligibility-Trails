#!/usr/bin/env python3
"""Deterministic and mocked integration checks. No real API calls or clinical labels."""
import argparse
import csv
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,default=Path.cwd());args,extra=ap.parse_known_args()
sys.path.insert(0,str(args.root.resolve()/'code'));sys.path.insert(0,str(Path(__file__).resolve().parent))
from criteria import map_truth,what_could_change
from llm_client import CallFailed
from mtp_completion.common import final_label,atomic_json,read_jsonl
from mtp_completion.numeric import numeric_expected
from mtp_completion.analysis import binary_metrics,classification,fixed_broken,orders,pair_rows,pair_metrics,student_labels
from mtp_completion.checker import citation,Checker
from mtp_completion.client import GroqLLM,BudgetExceeded

class Tests(unittest.TestCase):
    def test_numeric_ecog(self):
        self.assertEqual(numeric_expected('ECOG 0 or 1','ECOG 2')['expected_truth'],'no')
        self.assertEqual(numeric_expected('ECOG 0-1','ECOG=1')['expected_truth'],'yes')
    def test_numeric_bounds(self):
        self.assertEqual(numeric_expected('FEV1 >= 50%','FEV1 >= 50%')['expected_truth'],'yes')
        self.assertIsNone(numeric_expected('FEV1 >= 60%','FEV1 >= 50%')['expected_truth'])
        self.assertEqual(numeric_expected('FEV1 > 50%','FEV1 50%')['expected_truth'],'no')
        self.assertIsNone(numeric_expected('FEV1 >= 50%','FEV1 1300 cc')['expected_truth'])
    def test_numeric_age_and_multiple_values(self):
        self.assertEqual(numeric_expected('Greater than 18 years old','A 21-year-old man')['expected_truth'],'yes')
        self.assertIsNone(numeric_expected('ECOG 0 or 1','ECOG 0. ECOG 2.')['expected_truth'])
    def test_quotes(self):
        self.assertEqual(citation('ECOG=1',['ECOG=1'],'yes')['status'],'FOUND')
        self.assertEqual(citation('ECOG was  1',['ECOG was 1'],'yes')['status'],'FOUND')
        self.assertEqual(citation('ECOG=1',[],'yes')['status'],'NO_EVIDENCE_CITED')
        self.assertFalse(citation('ECOG=1',[],'unknown')['applicable'])
    def test_fuzzy_if_installed(self):
        if not importlib.util.find_spec('rapidfuzz'):self.skipTest('rapidfuzz not installed in this environment')
        self.assertNotEqual(citation('ECOG=1',['ECOG equals one'],'yes')['status'],'FOUND')
        self.assertEqual(citation('ECOG=1',['stage IV adenocarcinoma'],'yes')['status'],'NOT_FOUND')
    def test_label_precedence(self):
        c={'citation':{'status':'NOT_FOUND'},'context':{'misread':True},'logic':{'valid':False},'contradiction':{'found':True},'entailment':{'consistent_with_truth':False},'missed_evidence':{'found':True}}
        self.assertEqual(final_label(c),'HALLUCINATED_EVIDENCE')
        self.assertEqual(final_label(c,'citation'),'CONTEXT_ERROR')
        c['citation']['status']='FOUND';c['context']['misread']=False
        self.assertEqual(final_label(c),'LOGIC_ERROR')
    def test_mapping_and_sole_reason(self):
        self.assertEqual(map_truth('yes','exclusion'),'not_met')
        self.assertTrue(what_could_change(['met','not_met','met'])[1]['sole_reason'])
        self.assertFalse(any(r['sole_reason'] for r in what_could_change(['not_met','not_met','met'])))
    def test_broken_not_fixed(self):
        g={(1,0):{'truth':'yes'}};b={(1,0):{'truth':'yes'}};a={(1,0):{'truth':'no'}}
        r=fixed_broken(g,b,a);self.assertEqual(r['broken'],1);self.assertEqual(r['fixed'],0)
    def test_invalid_not_unknown_success(self):
        r=classification(['unknown'],['INVALID'],('yes','no','unknown'));self.assertEqual(r['accuracy'],0)
    def test_review_definitions_separate(self):
        rows=[{'reference':1,'decision':'REVIEW','cluster':'T1','n_failing':0},{'reference':0,'decision':'REVIEW','cluster':'T2','n_failing':0}]
        r=pair_metrics(rows,50);self.assertEqual(r['three_way_exact_accuracy_review_incorrect'],0);self.assertEqual(r['binary_review_as_not_eligible']['accuracy'],.5);self.assertEqual(r['false_exclusions'],0)
    def test_ranking_never_reads_reference(self):
        p={(1,0):{'truth':'no','kind':'inclusion','confidence':.9},(2,0):{'truth':'unknown','kind':'inclusion','confidence':.1}}
        c={k:{'label':'UNSUPPORTED'} for k in p};a,_=orders(p,c)
        for r in p.values():r['target']='Eligible'
        b,_=orders(p,c);self.assertEqual(a,b)
    def test_no_missing_pair_scoring(self):
        with self.assertRaises(ValueError):pair_rows([{'pair_idx':'1','trial_id':'T1','target':'Eligible'}],{'T1':[{'crit_idx':0,'kind':'inclusion'}]}, {})
    def test_blank_student_labels_unavailable(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'labels.csv'
            with p.open('w',newline='') as f:
                w=csv.DictWriter(f,fieldnames=['split','pair_idx','crit_idx','kind','truth']);w.writeheader();w.writerow({'split':'dev','pair_idx':1,'crit_idx':0,'kind':'inclusion','truth':''})
            g,s=student_labels(p,'dev',[{'pair_idx':'1','trial_id':'T1'}],{'T1':[{'crit_idx':0,'kind':'inclusion'}]})
            self.assertEqual(g,{});self.assertEqual(s['blank_rows'],1)
    def test_mock_groq_cache_and_cap(self):
        with tempfile.TemporaryDirectory() as td,patch.dict(os.environ,{'GROQ_API_KEY':'FAKE_ONLY'}):
            result={'choices':[{'finish_reason':'stop','message':{'content':'{"label":"neutral"}'}}],'usage':{'total_tokens':12},'model':'mock'}
            with patch('urllib.request.urlopen',return_value=io.BytesIO(json.dumps(result).encode())) as send:
                llm=GroqLLM('openai/gpt-oss-20b',td,max_calls=1,pause=0,retries=0)
                self.assertTrue(llm.chat_json('system','user')['ok']);self.assertTrue(llm.chat_json('system','user')['cache_hit']);self.assertEqual(send.call_count,1)
                with self.assertRaises(BudgetExceeded):llm.chat_json('system','different')
                self.assertEqual(read_jsonl(Path(td)/'API_USAGE.jsonl')[0]['usage']['total_tokens'],12)
    def test_transport_failure_not_unknown(self):
        with tempfile.TemporaryDirectory() as td,patch.dict(os.environ,{'GROQ_API_KEY':'FAKE_ONLY'}):
            with patch('urllib.request.urlopen',side_effect=TimeoutError):
                llm=GroqLLM('openai/gpt-oss-20b',td,max_calls=1,pause=0,retries=0)
                with self.assertRaises(CallFailed):llm.chat_json('sys','user')
                self.assertFalse(llm.cache)
    def test_budget_shared_across_models(self):
        with tempfile.TemporaryDirectory() as td,patch.dict(os.environ,{'GROQ_API_KEY':'FAKE_ONLY'}):
            budget={'attempts':1,'last':0,'max':1}
            llm=GroqLLM('other',td,max_calls=1,pause=0,controller=budget)
            with self.assertRaises(BudgetExceeded):llm.chat_json('s','u')
    def test_checker_integration_mock_semantics(self):
        class FakeSupport:
            method='mock'
            def score(self,statement,evidence):return {'label':'entailment','probabilities':{},'method':'mock'}
        class FakeContext:
            method='mock'
            def run(self,*args):return {'misread':False,'method':'mock'}
        checker=object.__new__(Checker);checker.theta=90;checker.support=FakeSupport();checker.context=FakeContext();checker.client=None
        r={'system':'test','dataset':'nsclc100','pair_idx':1,'crit_idx':0,'truth':'yes','kind':'inclusion','verdict':'met','evidence':['ECOG=1'],'basis':'stated'}
        rule={'criterion_text':'ECOG 0 or 1','kind':'inclusion','note':''};statement={'statement':'ECOG is 0 or 1','key_terms':['ECOG']}
        self.assertEqual(checker.check(r,'ECOG=1',rule,statement)['label'],'VERIFIED')
        r['truth']='unknown';r['verdict']='not_stated';r['evidence']=[]
        self.assertEqual(checker.check(r,'ECOG=1',rule,statement)['label'],'MISSED_EVIDENCE')
    def test_medspacy_if_installed(self):
        if not importlib.util.find_spec('medspacy'):self.skipTest('medspaCy not installed; actual integration remains unverified here')
        from mtp_completion.checker import Context
        ctx=Context('medspacy',None)
        self.assertTrue(ctx.run('No evidence of brain metastases.',['brain metastases'],'brain metastases','yes')['misread'])
        self.assertTrue(ctx.run('Her mother had lung cancer.',['lung cancer'],'lung cancer','yes')['misread'])

if __name__=='__main__':unittest.main(argv=[sys.argv[0]]+extra,verbosity=2)
