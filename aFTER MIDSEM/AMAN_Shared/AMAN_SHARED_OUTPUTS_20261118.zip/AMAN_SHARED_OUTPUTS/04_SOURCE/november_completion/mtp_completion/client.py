"""Groq transport subclasses the kit's LocalLLM; full-prompt caching is retained."""
import datetime as dt
import email.utils
import json
import os
import time
import urllib.error
import urllib.request
from pathlib import Path
from llm_client import LocalLLM,CallFailed
from .common import append,hashed

class BudgetExceeded(CallFailed): pass

class GroqLLM(LocalLLM):
    def __init__(self,model,cache_dir,max_calls=10,pause=10,retries=1,max_output=2048,timeout=120,controller=None,num_ctx=32768):
        if max_calls<0 or pause<0 or retries<0: raise ValueError('Invalid API limits')
        self.api_key=os.environ.get('GROQ_API_KEY','').strip()
        if not self.api_key: raise ValueError('GROQ_API_KEY is missing')
        super().__init__(model,cache_dir=cache_dir,num_ctx=num_ctx,max_output=max_output,
                         timeout=timeout,call_retries=0,parse_retries=0)
        self.options={'provider':'groq','endpoint':'https://api.groq.com/openai/v1/chat/completions',
                      'temperature':0,'seed':0,'max_completion_tokens':max_output,'response_format':{'type':'json_object'}}
        if 'gpt-oss' in model:
            self.options.update(reasoning_effort='low',include_reasoning=False)
        self.max_calls=max_calls;self.pause=pause;self.retries=retries;self.api_attempts=0
        self.controller=controller if controller is not None else {'attempts':0,'last':0,'max':max_calls}
        self.last=0;self.tokens=0;self.usage_file=Path(cache_dir)/'API_USAGE.jsonl'
    def check_model_available(self): pass
    def _send(self,system,user):
        payload={k:v for k,v in self.options.items() if k not in ('provider','endpoint')}
        payload.update(model=self.model,stream=False,messages=[{'role':'system','content':system},{'role':'user','content':user}])
        for attempt in range(self.retries+1):
            if self.controller['attempts']>=self.controller['max']: raise BudgetExceeded('API attempt budget reached; resume from cache')
            delay=max(0,self.pause-(time.monotonic()-self.controller['last']));time.sleep(delay)
            self.api_attempts+=1;self.last=time.monotonic();self.controller['attempts']+=1;self.controller['last']=self.last
            event={'time_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'model':self.model,'prompt_hash':hashed([self.model,system,user,self.options])}
            req=urllib.request.Request(self.options['endpoint'],data=json.dumps(payload).encode(),method='POST',headers={
                'Authorization':'Bearer '+self.api_key,'Content-Type':'application/json','User-Agent':'Main-MTP/1.0'})
            try:
                with urllib.request.urlopen(req,timeout=self.timeout) as response: result=json.load(response)
                usage=result.get('usage') or {};self.tokens+=usage.get('total_tokens',0) or 0
                event.update(status='response',usage=usage,response_id=result.get('id'),returned_model=result.get('model'))
                append(self.usage_file,event)
                choice=result['choices'][0]
                if choice.get('finish_reason')!='stop': raise CallFailed('Non-stop completion rejected; raise output budget if length-limited')
                return {'raw':choice['message'].get('content') or '', 'prompt_tokens':usage.get('prompt_tokens'),'done_reason':'stop'}
            except urllib.error.HTTPError as e:
                event.update(status='http_error',http_status=e.code,retry_after=e.headers.get('Retry-After'));append(self.usage_file,event)
                if e.code not in (429,500,502,503,504) or attempt>=self.retries: raise CallFailed('Groq HTTP '+str(e.code)) from None
                retry=e.headers.get('Retry-After','')
                try: wait=float(retry)
                except ValueError:
                    try: wait=email.utils.parsedate_to_datetime(retry).timestamp()-time.time()
                    except (ValueError,TypeError): wait=30
                if wait>60: raise CallFailed('Server requests a long wait; resume later. Retry-After='+retry) from None
                time.sleep(max(wait,self.pause,1))
            except (urllib.error.URLError,TimeoutError,OSError) as e:
                event.update(status='transport_error',type=type(e).__name__);append(self.usage_file,event)
                # Ambiguous network failures are not retried automatically (possible duplicate charge).
                raise CallFailed('Transport failed; outcome may be unknown. Resume explicitly.') from None
            except (ValueError,KeyError,IndexError,TypeError):
                raise CallFailed('Unexpected Groq response structure') from None

def make_client(args,root):
    base=Path(root)/'outputs/mtp_completion/cache'/args.backend
    if args.backend=='groq':
        if not hasattr(args,'_api_controller'):args._api_controller={'attempts':0,'last':0,'max':args.max_calls}
        return GroqLLM(args.model,base,max_calls=args.max_calls,pause=args.pause,retries=args.retries,max_output=args.max_output,controller=args._api_controller,num_ctx=args.num_ctx)
    return LocalLLM(args.model,cache_dir=base,num_ctx=args.num_ctx,max_output=args.max_output,parse_retries=0,call_retries=1)

def ask(client,system,payload,prompt_id):
    result=client.chat_json(system,json.dumps(payload,ensure_ascii=False),prompt_id=prompt_id)
    if not result['ok']: raise CallFailed('Model response is not a JSON object')
    return result
