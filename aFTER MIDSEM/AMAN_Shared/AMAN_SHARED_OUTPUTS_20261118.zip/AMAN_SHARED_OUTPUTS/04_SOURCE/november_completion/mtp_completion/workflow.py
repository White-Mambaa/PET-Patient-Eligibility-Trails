import argparse
import copy
import datetime as dt
import importlib.util
import json
import math
import os
import statistics
import random
import fcntl
from pathlib import Path
import sys
from collections import Counter
from llm_client import CallFailed
from . import VERSION
from .common import *
from .client import make_client,ask,BudgetExceeded
from .analysis import *

STATEMENT_SYSTEM='''Rewrite CONDITION as one short patient-level statement preserving every medical detail, threshold, temporal qualifier, conjunction, alternative, exception and conditional applicability. Follow GUIDANCE. Do not decide eligibility and do not infer patient facts. Return JSON only: {"statement":"...","key_terms":["1 to 3 key terms"]}.'''


def settings(a):
    return {'model':a.model,'backend':a.backend,'theta':a.theta,'tau':a.tau,'support_backend':a.support_backend,'context_backend':a.context_backend}

def freeze_guard(a,role='judge'):
    if a.split!='test':return
    if not a.freeze:raise ValueError('Test execution requires --freeze METHOD_FREEZE.json')
    manifest=json.loads(Path(a.freeze).read_text(encoding='utf-8'))
    for rel,h in manifest['sha256'].items():
        path=Path(a.root)/rel
        if not path.is_file() or sha(path)!=h:raise ValueError('Frozen artifact changed/missing: '+rel)
    method=manifest['method']
    if a.model!=method[role+'_model'] or a.backend!=method[role+'_backend']:raise ValueError('Model/backend differs from method freeze')
    if a.command not in ('report',) and a.max_output!=method['max_output' if role=='judge' else 'subject_max_output']:
        raise ValueError('Completion-token setting differs from method freeze')
    if a.command!='report' and a.num_ctx!=method['judge_num_ctx' if role=='judge' else 'subject_num_ctx']:
        raise ValueError('Context guard/size differs from method freeze')
    if role=='judge':
        for k in ('theta','tau','support_backend','context_backend'):
            if getattr(a,k)!=method[k]:raise ValueError('Checker setting differs from method freeze: '+k)

def output_path(a,name):
    return Path(a.out) if getattr(a,'out',None) else Path(a.root)/'outputs/mtp_completion'/a.dataset/a.split/name

def bind_run(out,config):
    config['implementation_sha256']={p.name:sha(p) for p in sorted(Path(__file__).parent.glob('*.py'))}
    out=Path(out);out.parent.mkdir(parents=True,exist_ok=True)
    mp=Path(str(out)+'.manifest.json')
    if mp.exists() and json.loads(mp.read_text())['config']!=config:raise ValueError('Output belongs to another configuration/input. Choose a new --out.')
    atomic_json(mp,{'version':VERSION,'config':config,'status':'running'})
    marker(out).write_text('INCOMPLETE until expected coverage is verified.\n')
    return mp

def finish(out,mp,config,expected,actual,errors):
    done=expected==actual and not errors
    atomic_json(mp,{'version':VERSION,'config':config,'expected':expected,'written':actual,'errors':errors,'status':'COMPLETE' if done else 'INCOMPLETE'})
    if done:marker(out).unlink(missing_ok=True)
    print('OUTPUT:',out,'| records:',actual,'/',expected,'| status:','COMPLETE' if done else 'INCOMPLETE')
    return 0 if done else 2

def selected_records(a):
    corpus,rules=select(a.root,a.dataset,a.split)
    pred=load_predictions(a.pred,corpus,rules,a.dataset,a.allow_partial)
    chosen=sorted(pred)
    if a.limit:chosen=chosen[:a.limit]
    return corpus,rules,pred,chosen

def statement_map(path,rules,corpus,allow_unreviewed=False,test=False):
    rows=read_csv(path);out={};trials={r['trial_id'] for r in corpus}
    if test:
        meta=Path(str(path)+'.generated.json')
        if not meta.exists() or json.loads(meta.read_text())['sha256']!=sha(path):raise ValueError('Test statements changed after generation')
    for r in rows:
        if r['trial_id'] not in trials:continue
        idx=int(r['crit_idx']);rule=rules[r['trial_id']][idx]
        if r['criterion']!=rule['criterion_text'] or r.get('guidance','')!=rule.get('note',''):raise ValueError('Statement source/guidance mismatch')
        terms=json.loads(r['key_terms'])
        if not r['statement'].strip() or not isinstance(terms,list) or not terms or any(not isinstance(t,str) or not t.strip() for t in terms):raise ValueError('Invalid statement/key terms')
        if not test and not allow_unreviewed and r.get('reviewed','').strip().lower() not in ('true','yes','1'):raise ValueError('Hand-review development rule statements, or explicitly use exploratory --allow-unreviewed-statements')
        k=(r['trial_id'],idx)
        if k in out:raise ValueError('Duplicate rule statement')
        out[k]={**r,'key_terms':terms}
    return out

def run_baseline(a):
    import plain_ai
    from criteria import map_truth
    freeze_guard(a,'subject')
    corpus,rules=select(a.root,a.dataset,a.split)
    jobs=[(p,c) for p in corpus for c in rules[p['trial_id']]]
    if a.limit:jobs=jobs[:a.limit]
    client=make_client(a,a.root);client.check_model_available();errors=[]
    policies=['unknown','forced'] if a.policy=='both' else [a.policy]
    for policy in policies:
        system=plain_ai.SYSTEM_PROMPT_FORCED if policy=='forced' else plain_ai.SYSTEM_PROMPT
        prompt_id=plain_ai.PROMPT_ID_FORCED if policy=='forced' else plain_ai.PROMPT_ID
        out=output_path(a,f'baseline_{a.backend}_{plain_ai.model_tag(a.model)}_{policy}'+('_pilot'+str(a.limit) if a.limit else '')+'.jsonl')
        if a.out and len(policies)>1:raise ValueError('Use --policy unknown or forced with explicit --out')
        config={'command':'baseline','dataset':a.dataset,'split':a.split,'limit':a.limit,'settings':settings(a),'client_options':client.options,
                'prompt_hash':hashed(system),'source_sha256':{n:sha(Path(a.root)/'datasets'/a.dataset/n) for n in (a.dataset+'.csv','criteria.csv','splits.csv')}}
        mp=bind_run(out,config);done=unique(read_jsonl(out)) if out.exists() else {}
        allowed=('yes','no') if policy=='forced' else ('yes','no','unknown')
        try:
            for p,c in jobs:
                k=(int(p['pair_idx']),c['crit_idx'])
                if k in done:continue
                user=plain_ai.build_user(c['criterion_text'],p['patient_orig'],c['note'])
                res=client.chat_json(system,user,prompt_id=prompt_id)
                ans=plain_ai.clean_answer(res['data'],allowed) if res['ok'] else None
                parse_ok=ans is not None
                if ans is None:ans={'truth':'unknown','evidence':[],'basis':None,'rationale':'','confidence':None}
                r={'system':f'plain_ai_{a.backend}_{plain_ai.model_tag(a.model)}_{policy}','dataset':a.dataset,
                   'pair_idx':k[0],'crit_idx':k[1],'kind':c['kind'],'criterion':c['criterion_text'],**ans,
                   'verdict':map_truth(ans['truth'],c['kind']),'parse_ok':parse_ok,'route':'llm',
                   'trace':{'model':a.model,'backend':a.backend,'trial_id':p['trial_id'],'prompt_id':prompt_id,'prompt_sha256':res['prompt_sha256'],'cache_hit':res['cache_hit'],'attempts':res['attempts']}}
                append(out,r);done[k]=r;print(policy,'saved',len(done),'/',len(jobs),flush=True)
        except (CallFailed,KeyboardInterrupt) as e:errors.append(type(e).__name__);print('Stopped safely:',type(e).__name__)
        code=finish(out,mp,config,len(jobs),len(done),errors)
        if code:return code
    return 0

def run_statements(a):
    freeze_guard(a)
    corpus,rules=select(a.root,a.dataset,a.split);trials=sorted({p['trial_id'] for p in corpus})
    jobs=[(t,c) for t in trials for c in rules[t]]
    if a.limit:jobs=jobs[:a.limit]
    out=output_path(a,'rule_statements'+('_pilot'+str(a.limit) if a.limit else '')+'.csv')
    if a.split=='test' and out.exists():
        meta=Path(str(out)+'.generated.json')
        if meta.exists() and json.loads(meta.read_text())['sha256']==sha(out):print('Frozen test statements already generated; not changed.');return 0
        raise ValueError('Existing test statements cannot be overwritten/edited')
    client=make_client(a,a.root);client.check_model_available()
    existing={(r['trial_id'],int(r['crit_idx'])):r for r in read_csv(out)} if out.exists() else {}
    config={'command':'statements','dataset':a.dataset,'split':a.split,'limit':a.limit,'settings':settings(a),'client_options':client.options,'prompt':hashed(STATEMENT_SYSTEM),'criteria_sha256':sha(Path(a.root)/'datasets'/a.dataset/'criteria.csv')}
    mp=bind_run(out,config);errors=[]
    try:
        for t,c in jobs:
            k=(t,c['crit_idx'])
            if k in existing:continue
            data=ask(client,STATEMENT_SYSTEM,{'CONDITION':c['criterion_text'],'GUIDANCE':c['note']},'RULE_STATEMENT_v1')['data']
            if not isinstance(data.get('statement'),str) or not data['statement'].strip() or not isinstance(data.get('key_terms'),list) or not 1<=len(data['key_terms'])<=3 or any(not isinstance(x,str) or not x.strip() for x in data['key_terms']):raise CallFailed('Invalid rule statement response')
            existing[k]={'trial_id':t,'crit_idx':c['crit_idx'],'kind':c['kind'],'criterion':c['criterion_text'],'guidance':c['note'],
                         'statement':data['statement'],'key_terms':json.dumps(data['key_terms'],ensure_ascii=False),'reviewed':'false','reviewer':'','comment':''}
            write_csv(out,list(existing.values()));print('Statement saved:',len(existing),'/',len(jobs),flush=True)
    except (CallFailed,KeyboardInterrupt) as e:errors.append(type(e).__name__)
    code=finish(out,mp,config,len(jobs),len(existing),errors)
    if code==0 and a.split=='test':atomic_json(Path(str(out)+'.generated.json'),{'sha256':sha(out),'method':'one-pass unedited test statements'})
    return code

def run_check(a):
    from .checker import Checker
    freeze_guard(a)
    corpus,rules,pred,chosen=selected_records(a);pairs={int(r['pair_idx']):r for r in corpus}
    stm=statement_map(a.statements,rules,corpus,a.allow_unreviewed_statements,a.split=='test')
    for k in chosen:
        if (pairs[k[0]]['trial_id'],k[1]) not in stm:raise ValueError('Missing rule statement for a selected prediction')
    client=make_client(a,a.root);checker=Checker(client,a.theta,a.tau,a.support_backend,a.context_backend)
    out=output_path(a,Path(a.pred).stem+'_checks'+('_pilot'+str(a.limit) if a.limit else '')+'.jsonl')
    config={'command':'check','dataset':a.dataset,'split':a.split,'settings':settings(a),'limit':a.limit,
            'allow_unreviewed_statements':a.allow_unreviewed_statements,'client_options':client.options,'pred_sha256':sha(a.pred),'statements_sha256':sha(a.statements)}
    mp=bind_run(out,config);done=unique(read_jsonl(out)) if out.exists() else {};errors=[]
    try:
        for k in chosen:
            if k in done:continue
            p=pairs[k[0]];rule=rules[p['trial_id']][k[1]]
            r=checker.check(pred[k],p['patient_orig'],rule,stm[(p['trial_id'],k[1])]);append(out,r);done[k]=r
            print('Checked:',len(done),'/',len(chosen),'label:',r['label'],flush=True)
    except (CallFailed,KeyboardInterrupt) as e:errors.append(type(e).__name__);print('Stopped safely:',type(e).__name__)
    return finish(out,mp,config,len(chosen),len(done),errors)

def run_report(a):
    freeze_guard(a,'subject')
    corpus,rules=select(a.root,a.dataset,a.split);pred=load_predictions(a.pred,corpus,rules,a.dataset)
    if len({r.get('system','unrecorded') for r in pred.values()})>1:raise ValueError('Do not mix different baseline systems in one report')
    cluster='patient_id' if a.dataset=='sigir204' else 'trial_id'
    rows=pair_rows(corpus,rules,pred,cluster,a.target_column)
    gold,labelstatus=student_labels(a.labels,a.split,corpus,rules)
    checks=None
    if a.checks:
        require_complete(a.checks);checks=unique(read_jsonl(a.checks));ensure_checks(checks.values())
        if set(checks)!=set(pred):raise ValueError('Checker and prediction coverage differ')
        for k,c in checks.items():
            source=c.get('provenance',{}).get('source_answer_hash')
            if source and source!=hashed(pred[k]):raise ValueError('Checker output refers to another prediction version')
    out=output_path(a,'report_'+Path(a.pred).stem);out.mkdir(parents=True,exist_ok=True)
    summary={'version':VERSION,'dataset':a.dataset,'split':a.split,'cluster_by':cluster,'status':'EXPLORATORY_STUDENT_PROJECT',
             'pair_metrics':pair_metrics(rows,a.bootstrap),'student_label_status':labelstatus,'label_provenance':a.label_provenance if a.labels else 'none',
             'student_metrics':student_metrics(gold,pred,checks),
             'unparseable_predictions':sum(not r.get('parse_ok',True) for r in pred.values()),
             'baseline_mapping_mismatches':0,'subject_models':sorted({r.get('trace',{}).get('model','unrecorded') for r in pred.values()}),'sources':{'pred_sha256':sha(a.pred)}}
    import re
    normalise=lambda s:re.sub(r'\s+',' ',s).strip()
    notes={int(p['pair_idx']):p['patient_orig'] for p in corpus}
    spans=[(q,notes[k[0]]) for k,r in pred.items() for q in r.get('evidence',[]) if isinstance(q,str) and q.strip()]
    summary['quotation_metrics']={'quoted_spans':len(spans),'raw_exact_spans':sum(q in n for q,n in spans),
        'whitespace_normalised_exact_spans':sum(normalise(q) in normalise(n) for q,n in spans),
        'whitespace_normalised_verbatim_rate':div(sum(normalise(q) in normalise(n) for q,n in spans),len(spans)),
        'definite_answers_without_quote':sum(r['truth']!='unknown' and not r.get('evidence') for r in pred.values())}
    summary['unknown_rate']=div(sum(r['truth']=='unknown' for r in pred.values()),len(pred))
    summary['sources'].update(corpus_sha256=sha(Path(a.root)/'datasets'/a.dataset/(a.dataset+'.csv')),criteria_sha256=sha(Path(a.root)/'datasets'/a.dataset/'criteria.csv'),splits_sha256=sha(Path(a.root)/'datasets'/a.dataset/'splits.csv'))
    if a.labels:summary['sources']['student_labels_sha256']=sha(a.labels)
    if a.checks:summary['sources']['checks_sha256']=sha(a.checks)
    from criteria import map_truth
    summary['baseline_mapping_mismatches']=sum(r.get('verdict')!=map_truth(r['truth'],r['kind']) for r in pred.values())
    write_csv(out/'pair_decisions.csv',rows)
    conflicts=[]
    for p in corpus:
        for c in rules[p['trial_id']]:
            k=(int(p['pair_idx']),c['crit_idx'])
            if k in gold and target(p[a.target_column]) and map_truth(gold[k]['truth'],c['kind'])=='not_met':
                conflicts.append({'pair_idx':k[0],'crit_idx':k[1],'conflict':'Student violation on dataset-Eligible pair','supervisor_decision':''})
    from criteria import decide
    for p in corpus:
        ids=[(int(p['pair_idx']),c['crit_idx']) for c in rules[p['trial_id']]]
        if not target(p[a.target_column]) and all(k in gold for k in ids):
            verdicts=[map_truth(gold[k]['truth'],pred[k]['kind']) for k in ids]
            if decide(verdicts)=='ELIGIBLE':conflicts.append({'pair_idx':int(p['pair_idx']),'crit_idx':'ALL','conflict':'All student rules pass on dataset-Not-Eligible pair','supervisor_decision':''})
    write_csv(out/'student_pair_label_conflicts.csv',conflicts,['pair_idx','crit_idx','conflict','supervisor_decision'])
    summary['eligible_pair_student_label_conflicts']=len(conflicts)
    if checks:
        summary['checker_label_distribution']=dict(Counter(c['label'] for c in checks.values()))
        targeting,ordering,features=simulate(corpus,rules,pred,checks,gold,cluster,a.target_column)
        summary['review_simulation']=targeting
        risk,riskrows=rejection_risk(rows,features);summary['rejection_risk']=risk
        for name,order in ordering.items():write_csv(out/('order_'+name+'.csv'),[{'pair_idx':k[0],'crit_idx':k[1]} for k in order])
        write_csv(out/'rejected_pair_risk.csv',riskrows,list(riskrows[0]) if riskrows else ['pair_idx','risk'])
        write_csv(out/'decision_impact.csv',[{'pair_idx':k[0],'crit_idx':k[1],**{n:f[n] for n in ('verdict','n_failing','flagged','confidence','changes','sole_reason')}} for k,f in features.items()])
        from criteria import map_truth
        flagged={k for k,r in checks.items() if r['label']!='VERIFIED'}
        deferred={k:({**r,'truth':'unknown','verdict':'not_stated'} if k in flagged else dict(r)) for k,r in pred.items()}
        summary['keep_vs_flag']={'keep':summary['pair_metrics'],'flag':pair_metrics(pair_rows(corpus,rules,deferred,cluster,a.target_column),0),
                                 'student_fixed_broken_all':fixed_broken(gold,pred,deferred),
                                 'student_fixed_broken_without_UNSURE':fixed_broken({k:r for k,r in gold.items() if not r.get('comment','').strip().upper().startswith('UNSURE')},pred,deferred)}
        jsonl(out/'flag_policy.jsonl',deferred.values())
    if a.after:
        after=load_predictions(a.after,corpus,rules,a.dataset)
        summary['repair_policy']={'pair_metrics':pair_metrics(pair_rows(corpus,rules,after,cluster,a.target_column),0),
                                  'student_fixed_broken_all':fixed_broken(gold,pred,after),
                                  'student_fixed_broken_without_UNSURE':fixed_broken({k:r for k,r in gold.items() if not r.get('comment','').strip().upper().startswith('UNSURE')},pred,after)}
    if a.dataset=='sigir204':
        development,_=select(a.root,a.dataset,'dev');median=statistics.median(len(rules[p['trial_id']]) for p in development)
        countrows=[{**r,'decision':'NOT_ELIGIBLE' if r['n_rules']>median else 'ELIGIBLE'} for r in rows]
        summary['count_the_rules_baseline']={'development_median':median,'metrics':pair_metrics(countrows,0)}
    atomic_json(out/'RESULTS.json',summary)
    pm=summary['pair_metrics'];review=pm['review_count']
    text=f'''# Main MTP results: {a.dataset} / {a.split}\n\nExploratory student project; no claim of clinical deployment validity.\n\n## Pair-level results (dataset reference labels)\n- Pairs: {len(rows)}; clustering: {cluster}.\n- Wrongly excluded: {pm['false_exclusions']}/{pm['eligible_pairs']}.\n- Wrongly included: {pm['false_inclusions']}/{pm['ineligible_pairs']}.\n- Review: {review}/{len(rows)}.\n- Three-way exact accuracy (REVIEW incorrect): {pm['three_way_exact_accuracy_review_incorrect']}.\n- Binary REVIEW-as-negative accuracy: {pm['binary_review_as_not_eligible']['accuracy']}.\n\n## Student labels\nStatus: {labelstatus['status']}; usable: {len(gold)}. Provenance: {summary['label_provenance']}.\nThese labels are not clinician-confirmed gold. Blank labels are not filled by a model.\n\n## Outputs\nRESULTS.json includes confusion matrices, precision/recall/F1/MCC, trial/patient bootstrap, reweighting, all/without-UNSURE rule metrics, checker ablations, priority simulations and rejected-pair risk where inputs are available.\nOrdering uses system-visible features only. The guide simulation uses dataset eligibility labels only when scoring correction effects; it is not actual coordinator intervention evidence.\n\n## Limitations\nUnparseable model responses are counted and retained as parse_ok=false; HTTP failures keep a run INCOMPLETE. VERIFIED is not proof of correctness. Confidence is self-reported, not a calibrated probability. No calibration or held-out clinical result is implied.\n'''
    (out/'REPORT.md').write_text(text,encoding='utf-8')
    # Lightweight portable SVG rather than an extra plotting dependency.
    if checks:
        palette=['#64748b','#2563eb','#a855f7','#d97706','#059669'];svg=['<svg xmlns="http://www.w3.org/2000/svg" width="740" height="440"><rect width="100%" height="100%" fill="white"/>','<text x="55" y="25" font-size="17">Wrongly excluded eligible pairs remaining (simulation)</text>','<path d="M55 45 V350 H620" fill="none" stroke="black"/>']
        maximum=max([1,targeting['baseline']['false_exclusions']]+[r['after']['false_exclusions'] for group in targeting['strategies'].values() for r in group])
        for i,(name,rr) in enumerate(targeting['strategies'].items()):
            vals=[(0,targeting['baseline']['false_exclusions'])]+[(r['actual_checks'],r['after']['false_exclusions']) for r in rr]
            points=' '.join(f'{55+5.5*x},{350-290*y/maximum}' for x,y in vals)
            svg.append(f'<polyline points="{points}" fill="none" stroke="{palette[i]}" stroke-width="2"/><text x="{55+i*135}" y="390" font-size="12" fill="{palette[i]}">{name}</text>')
        svg+=['<text x="280" y="430">Checks (0-100)</text></svg>'];(out/'review_curve.svg').write_text(''.join(svg))
    print('REPORT:',out/'REPORT.md');print('PAIR RESULTS:',pm['false_exclusions'],'wrong exclusions;',pm['false_inclusions'],'wrong inclusions;',review,'review')
    print('STUDENT LABEL STATUS:',labelstatus['status']);return 0

def run_repair(a):
    import plain_ai
    from criteria import map_truth
    from .checker import Checker
    freeze_guard(a)
    corpus,rules=select(a.root,a.dataset,a.split);pred=load_predictions(a.pred,corpus,rules,a.dataset)
    require_complete(a.checks);checks=unique(read_jsonl(a.checks));ensure_checks(checks.values())
    if set(pred)!=set(checks):raise ValueError('Repair needs full matching prediction/check files')
    for k,r in pred.items():
        if r.get('trace',{}).get('model') not in (None,a.subject_model):raise ValueError('Repair model must match baseline model')
        if checks[k].get('provenance',{}).get('source_answer_hash') not in (None,hashed(r)):raise ValueError('Checker/prediction mismatch')
    if a.split=='test':
        manifest=json.loads(Path(a.freeze).read_text());method=manifest['method']
        if a.subject_model!=method['subject_model'] or a.subject_backend!=method['subject_backend'] or a.subject_max_output!=method['subject_max_output'] or a.subject_num_ctx!=method['subject_num_ctx']:raise ValueError('Repair subject model differs from freeze')
    stm=statement_map(a.statements,rules,corpus,a.allow_unreviewed_statements,a.split=='test')
    judge=make_client(a,a.root);subject_args=copy.copy(a);subject_args.model=a.subject_model;subject_args.backend=a.subject_backend;subject_args.max_output=a.subject_max_output;subject_args.num_ctx=a.subject_num_ctx
    subject=make_client(subject_args,a.root);checker=Checker(judge,a.theta,a.tau,a.support_backend,a.context_backend)
    ordering,_=orders(pred,checks);eligible=[k for k in ordering['combined'] if checks[k]['label']!='VERIFIED']
    if a.repair_budget:eligible=eligible[:a.repair_budget]
    eligible=set(eligible);pairs={int(r['pair_idx']):r for r in corpus}
    out=output_path(a,Path(a.pred).stem+'_repair.jsonl');config={'command':'repair','settings':settings(a),'subject_model':a.subject_model,'subject_backend':a.subject_backend,
        'pred_sha256':sha(a.pred),'checks_sha256':sha(a.checks),'statements_sha256':sha(a.statements),'repair_budget':a.repair_budget,'judge_options':judge.options,'subject_options':subject.options}
    mp=bind_run(out,config);done=unique(read_jsonl(out)) if out.exists() else {};errors=[]
    try:
        for k,r in sorted(pred.items()):
            if k in done:continue
            if k not in eligible:
                result=dict(r)
            else:
                pair=pairs[k[0]];rule=rules[pair['trial_id']][k[1]];check=checks[k]
                forced='FORCED' in r.get('trace',{}).get('prompt_id','') or 'forced' in r.get('system','').lower()
                system=plain_ai.SYSTEM_PROMPT_FORCED if forced else plain_ai.SYSTEM_PROMPT
                feedback=check['reason']
                if check['label']=='CONTRADICTED':feedback+=' Evidence: '+str(check['checks']['contradiction']['sentence'])
                if check['label']=='MISSED_EVIDENCE':feedback+=' Evidence: '+str(check['checks']['missed_evidence']['sentence'])
                user=plain_ai.build_user(rule['criterion_text'],pair['patient_orig'],rule['note'])+'\nFEEDBACK: '+feedback
                response=subject.chat_json(system,user,prompt_id='REPAIR_ONCE_FORCED_v1' if forced else 'REPAIR_ONCE_v1')
                answer=plain_ai.clean_answer(response['data'],('yes','no') if forced else TRUTHS) if response['ok'] else None
                result=dict(r)
                if answer is None:
                    result.update(truth='unknown',verdict='not_stated',parse_ok=False,route='repair_parse_failure_then_flag')
                    result['repair']={'attempted':True,'accepted':False,'reason':'model output unparseable','feedback':feedback}
                else:
                    proposal={**r,**answer,'verdict':map_truth(answer['truth'],r['kind']),'parse_ok':True}
                    reviewed=checker.check(proposal,pair['patient_orig'],rule,stm[(pair['trial_id'],k[1])])
                    accepted=reviewed['label']=='VERIFIED'
                    result={**proposal,'truth':answer['truth'] if accepted else 'unknown',
                            'verdict':map_truth(answer['truth'],r['kind']) if accepted else 'not_stated',
                            'route':'repair_once_verified' if accepted else 'repair_once_then_flag',
                            'repair':{'attempted':True,'accepted':accepted,'feedback':feedback,'recheck':reviewed,
                                      'raw_proposed_truth':answer['truth'],'prompt_sha256':response['prompt_sha256']}}
            append(out,result);done[k]=result
    except (CallFailed,KeyboardInterrupt) as e:errors.append(type(e).__name__);print('Repair paused safely:',type(e).__name__)
    return finish(out,mp,config,len(pred),len(done),errors)

def run_status(a):
    rows=[]
    for dataset,sheet in [('nsclc100','my_label_sheet.csv'),('sigir204','sigir_label_sheet.csv')]:
        corpus,rules=select(a.root,dataset,'dev');p=Path(a.root)/'labelling'/sheet
        labels=read_csv(p) if p.exists() else []
        labels_by_split={split:{'assigned':sum(r.get('split')==split for r in labels),
                               'filled':sum(r.get('split')==split and r.get('truth','').strip().lower() in TRUTHS for r in labels)} for split in ('dev','test')}
        records={'dataset':dataset,'dev_pairs':len(corpus),'dev_rule_questions':len(expected_keys(corpus,rules)),'student_labels':labels_by_split,
                 'actual_guide':str(Path(a.root)/'Akash_Project_Guide.md'),'baseline_files':[]}
        candidates=sorted((Path(a.root)/'outputs').glob('plain_ai*dev.jsonl'))
        for f in candidates:
            data=read_jsonl(f)
            if data and all(r.get('dataset',dataset)==dataset for r in data):records['baseline_files'].append({'file':str(f),'rows':len(data),'incomplete':marker(f).exists()})
        rows.append(records)
    out=output_path(a,'PROJECT_STATUS.json');atomic_json(out,{'scope':'Main MTP only; AAPEMS excluded','datasets':rows,'api_calls':0,
        'guide_corrections':['Guide accepts student labels; do not demand expert labels as a new requirement.','Standard clinical implications are allowed and must be marked inferred.','Original guide is local-only; Groq is a later supervisor-authorised methodological change and must be disclosed.','Original guide research experiments are K1-K6, plus Tables 1-8.']})
    print(json.dumps(rows,indent=2));print('STATUS:',out);return 0

def run_calibrate(a):
    from .checker import norm,citation
    corpus,rules=select(a.root,a.dataset,'dev');pred=load_predictions(a.pred,corpus,rules,a.dataset,a.allow_partial)
    notes={int(r['pair_idx']):r['patient_orig'] for r in corpus};out=output_path(a,'citation_calibration.csv')
    if a.calibration_labels:
        rows=read_csv(a.calibration_labels);valid=[r for r in rows if r.get('human_label') in ('real_paraphrase','invented')]
        if not valid:raise ValueError('No human-labelled paraphrase/invention examples')
        scores=[]
        for theta in (70,75,80,85,90,95):
            correct=0
            for r in valid:
                if r.get('split')!='dev':raise ValueError('Calibration must use development rows only')
                c=citation(r['patient_note'],[r['quote']],'yes',theta)
                correct+=(c['status']=='PARAPHRASED')==(r['human_label']=='real_paraphrase')
            scores.append({'theta':theta,'n':len(valid),'agreement':correct/len(valid)})
        best=max(scores,key=lambda r:(r['agreement'],r['theta']))
        atomic_json(str(out)+'.selection.json',{'grid':scores,'selected_theta':best['theta'],'tie_rule':'higher threshold','source_sha256':sha(a.calibration_labels),'status':'development-only calibration'})
        print('SELECTED THETA:',best['theta']);return 0
    rows=[]
    for k,r in sorted(pred.items()):
        for quote in r.get('evidence',[]):
            if norm(quote) not in norm(notes[k[0]]):rows.append({'split':'dev','pair_idx':k[0],'crit_idx':k[1],'quote':quote,'patient_note':notes[k[0]],'human_label':''})
    random.Random(7).shuffle(rows);rows=rows[:60]
    if out.exists():raise ValueError('Calibration review file already exists; do not overwrite human edits')
    write_csv(out,rows,['split','pair_idx','crit_idx','quote','patient_note','human_label']);print('CALIBRATION QUEUE:',out,'| cases:',len(rows));return 0

def run_freeze(a):
    root=Path(a.root).resolve();artifacts=list(a.artifacts or []);labels=list(a.labels_files or [])
    if not labels:raise ValueError('Freeze needs completed student-label files using --labels-file')
    for path in labels:
        rows=read_csv(path)
        if not rows or any(r.get('truth','').strip().lower() not in TRUTHS for r in rows):raise ValueError('Complete every assigned label before freezing')
        if not {'dev','test'}.issubset({r.get('split') for r in rows}):raise ValueError('Final label file must include assigned development and test rows')
        # Student reference sheets are distinct from model prediction JSONL files.
        if any('ai_suggested_truth' in r for r in rows):raise ValueError('AI proposal export is not a final student-label sheet')
        dataset='sigir204' if 'sigir' in Path(path).name.lower() else 'nsclc100'
        assignment=root/'labelling'/('sigir_label_sheet.csv' if dataset=='sigir204' else 'my_label_sheet.csv')
        assigned=read_csv(assignment)
        if {(r['split'],*key(r)) for r in rows}!={(r['split'],*key(r)) for r in assigned}:raise ValueError('Final labels do not cover the exact assigned sheet')
    required=[root/'code'/n for n in ('criteria.py','plain_ai.py','llm_client.py','stats_tools.py')]
    required += sorted((root/'mtp_completion').glob('*.py'))+[root/'completion.py']
    paths=[*required,*map(Path,artifacts),*map(Path,labels)]
    hashes={}
    for path in paths:
        path=path.resolve()
        try:relative=path.relative_to(root)
        except ValueError:raise ValueError('Freeze artifacts must be inside project root')
        hashes[str(relative)]=sha(path)
    method={'subject_model':a.subject_model,'subject_backend':a.subject_backend,'judge_model':a.model,'judge_backend':a.backend,
            'theta':a.theta,'tau':a.tau,'support_backend':a.support_backend,'context_backend':a.context_backend,
            'label_provenance':a.label_provenance,'max_output':a.max_output,'subject_max_output':a.subject_max_output,'subject_num_ctx':a.subject_num_ctx,'judge_num_ctx':a.num_ctx}
    out=output_path(a,'METHOD_FREEZE.json')
    if out.exists():raise ValueError('Freeze manifest already exists; do not overwrite a registered method')
    atomic_json(out,{'version':VERSION,'method':method,'sha256':hashes,'created_utc':dt.datetime.now(dt.timezone.utc).isoformat(),
                     'caveat':'User must verify human independence, peer agreement, labelcheck dispositions, and supervisor approval; hashes cannot establish those facts.'})
    print('METHOD FREEZE:',out);return 0

def parser():
    ap=argparse.ArgumentParser(description='Main MTP completion workflow; follows the supplied project guide.')
    sub=ap.add_subparsers(dest='command',required=True)
    def common(name):
        p=sub.add_parser(name);p.add_argument('--root',type=Path,default=Path.cwd());p.add_argument('--dataset',choices=['nsclc100','sigir204'],default='nsclc100');p.add_argument('--split',choices=['dev','test'],default='dev')
        p.add_argument('--out',type=Path);p.add_argument('--freeze',type=Path)
        p.add_argument('--backend',choices=['ollama','groq'],default='groq');p.add_argument('--model',default='openai/gpt-oss-20b')
        p.add_argument('--max-calls',type=int,default=10);p.add_argument('--pause',type=float,default=10);p.add_argument('--retries',type=int,default=1)
        p.add_argument('--max-output',type=int,default=2048);p.add_argument('--num-ctx',type=int,default=32768)
        p.add_argument('--theta',type=int,default=90);p.add_argument('--tau',type=float,default=.7)
        p.add_argument('--support-backend',choices=['judge','nli'],default='judge');p.add_argument('--context-backend',choices=['medspacy','judge'],default='medspacy')
        return p
    common('status')
    p=common('baseline');p.add_argument('--policy',choices=['unknown','forced','both'],default='both');p.add_argument('--limit',type=int,default=5,help='0 means all questions; default is a 5-question engineering pilot')
    p=common('statements');p.add_argument('--limit',type=int,default=5)
    def predargs(p):
        p.add_argument('--pred',type=Path,required=True);p.add_argument('--allow-partial',action='store_true')
    def checkargs(p):
        p.add_argument('--statements',type=Path,required=True);p.add_argument('--allow-unreviewed-statements',action='store_true')
    p=common('check');predargs(p);checkargs(p);p.add_argument('--limit',type=int,default=5)
    p=common('report');predargs(p);p.add_argument('--checks',type=Path);p.add_argument('--labels',type=Path);p.add_argument('--after',type=Path);p.add_argument('--target-column',default='target');p.add_argument('--bootstrap',type=int,default=1000);p.add_argument('--label-provenance',choices=['student_unassisted','student_ai_assisted'],default='student_unassisted')
    p=common('repair');predargs(p);checkargs(p);p.add_argument('--checks',type=Path,required=True);p.add_argument('--subject-model',required=True);p.add_argument('--subject-backend',choices=['ollama','groq'],required=True);p.add_argument('--subject-max-output',type=int,default=400);p.add_argument('--subject-num-ctx',type=int,default=8192);p.add_argument('--repair-budget',type=int,default=5,help='0 repairs all flagged rows; otherwise top combined-order flagged rows only')
    p=common('calibrate-citation');predargs(p);p.add_argument('--calibration-labels',type=Path)
    p=common('freeze');p.add_argument('--subject-max-output',type=int,default=400);p.add_argument('--subject-num-ctx',type=int,default=8192);p.add_argument('--labels-file',dest='labels_files',type=Path,action='append',required=True);p.add_argument('--artifacts',type=Path,nargs='+',required=True);p.add_argument('--subject-model',required=True);p.add_argument('--subject-backend',choices=['ollama','groq'],required=True);p.add_argument('--label-provenance',choices=['student_unassisted','student_ai_assisted'],required=True)
    p=common('compare-datasets');p.add_argument('--nsclc-results',type=Path,required=True);p.add_argument('--sigir-results',type=Path,required=True);p.add_argument('--strategy',choices=['random','least_confident','flagged_first','fewest_reasons','combined'],default='combined')
    from .traps import add_commands
    add_commands(common)
    return ap

def main():
    a=parser().parse_args();a.root=a.root.resolve();os.umask(0o077)
    if a.max_calls<0 or a.pause<0 or a.retries<0 or getattr(a,'limit',0)<0:raise ValueError('Negative limits are not allowed')
    if a.command=='compare-datasets':
        return run_compare(a)
    funcs={'baseline':run_baseline,'statements':run_statements,'check':run_check,'report':run_report,'repair':run_repair,'status':run_status,'calibrate-citation':run_calibrate,'freeze':run_freeze}
    lock=None
    try:
        if a.command in ('baseline','statements','check','repair','run-traps'):
            lock=(a.root/'.mtp_completion.lock').open('a')
            try:fcntl.flock(lock,fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:raise ValueError('Another completion API/model process is running in this project')
        if a.command in funcs:return funcs[a.command](a)
        from .traps import dispatch
        return dispatch(a)
    finally:
        if lock:lock.close()


def run_compare(a):
    ns=json.loads(a.nsclc_results.read_text());sg=json.loads(a.sigir_results.read_text())
    if ns['dataset']!='nsclc100' or sg['dataset']!='sigir204':raise ValueError('Dataset comparison files are reversed or misidentified')
    if ns['split']!=sg['split']:raise ValueError('Compare the same split, never dev with test')
    if ns.get('subject_models')!=sg.get('subject_models'):raise ValueError('Reported main model differs between datasets')
    rows=[]
    for r in (ns,sg):
        strategy=r.get('review_simulation',{}).get('strategies',{}).get(a.strategy)
        if not strategy:raise ValueError('Need complete checker reports for both datasets')
        at50=next(x for x in strategy if x['budget']==50)
        labels=r.get('checker_label_distribution',{})
        rows.append({'dataset':r['dataset'],'split':r['split'],'cluster_by':r['cluster_by'],
                     'answers_flagged':sum(n for lab,n in labels.items() if lab!='VERIFIED'),
                     'wrongly_excluded_before':r['pair_metrics']['false_exclusions'],
                     'selected_strategy':a.strategy,'rescued_per_10_checks_at_50':at50['rescued_per_10_checks'],
                     'checker_label_distribution_not_human_error_types':labels})
    out=output_path(a,'TABLE8_DATASET_COMPARISON.json')
    atomic_json(out,{'table8':rows,'limitations':['Strategy must be selected/prespecified on development data, not chosen to maximise test results.','Checker-assigned categories are not independently confirmed human error-type proportions.','Review rescue is the guide scoring simulation, not observed clinical intervention.']})
    print('DATASET COMPARISON:',out);return 0
