import csv
import hashlib
import json
import os
from pathlib import Path

TRUTHS = ('yes', 'no', 'unknown')
LABELS = ('HALLUCINATED_EVIDENCE','CONTEXT_ERROR','LOGIC_ERROR','CONTRADICTED','UNSUPPORTED','MISSED_EVIDENCE','VERIFIED')

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def hashed(obj):
    return hashlib.sha256(json.dumps(obj, sort_keys=True, ensure_ascii=False).encode()).hexdigest()

def read_csv(path):
    with Path(path).open(newline='', encoding='utf-8-sig') as f:
        rd = csv.DictReader(f)
        rows = list(rd)
    if any(None in r or any(v is None for v in r.values()) for r in rows):
        raise ValueError('Malformed CSV columns: ' + str(path))
    return rows

def read_jsonl(path):
    return [json.loads(s) for s in Path(path).read_text(encoding='utf-8').splitlines() if s.strip()]

def atomic_json(path, obj):
    path=Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(obj,indent=2,ensure_ascii=False,allow_nan=False),encoding='utf-8'); tmp.replace(path)

def jsonl(path, rows):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp')
    with tmp.open('w',encoding='utf-8') as f:
        for r in rows: f.write(json.dumps(r,ensure_ascii=False,allow_nan=False)+'\n')
    tmp.replace(path)

def append(path, row):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('a',encoding='utf-8') as f:
        f.write(json.dumps(row,ensure_ascii=False,allow_nan=False)+'\n');f.flush();os.fsync(f.fileno())

def write_csv(path, rows, fields=None):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    fields=fields or list(rows[0] if rows else [])
    tmp=path.with_suffix('.csv.tmp')
    with tmp.open('w',newline='',encoding='utf-8-sig') as f:
        wr=csv.DictWriter(f,fieldnames=fields);wr.writeheader();wr.writerows(rows)
    tmp.replace(path)

def key(r): return (int(r['pair_idx']),int(r['crit_idx']))

def unique(rows):
    out={}
    for r in rows:
        k=key(r)
        if k in out: raise ValueError('Duplicate case identity')
        out[k]=r
    return out

def marker(path): return Path(str(path)+'.INCOMPLETE')

def require_complete(path):
    if marker(path).exists(): raise ValueError('Run is INCOMPLETE: '+str(path))

def ensure_checks(rows):
    for r in rows:
        if r.get('label') not in LABELS: raise ValueError('Invalid checker label')

def final_label(checks, omitted=None):
    candidates=[('citation',checks['citation']['status']=='NOT_FOUND','HALLUCINATED_EVIDENCE'),
                ('context',checks['context']['misread'],'CONTEXT_ERROR'),
                ('logic',checks['logic']['valid'] is False,'LOGIC_ERROR'),
                ('contradiction',checks['contradiction']['found'],'CONTRADICTED'),
                ('entailment',checks['entailment']['consistent_with_truth'] is False or checks['citation']['status']=='NO_EVIDENCE_CITED','UNSUPPORTED'),
                ('missed_evidence',checks['missed_evidence']['found'],'MISSED_EVIDENCE')]
    if omitted=='citation':
        candidates=[(n,(checks['entailment']['consistent_with_truth'] is False if n=='entailment' else flag),lab) for n,flag,lab in candidates]
    return next((lab for n,flag,lab in candidates if n!=omitted and flag),'VERIFIED')

def select(root,dataset,split):
    from criteria import load_criteria,load_splits
    folder=Path(root)/'datasets'/dataset
    rules=load_criteria(folder/'criteria.csv'); splits=load_splits(folder/'splits.csv')
    allrows=read_csv(folder/(dataset+'.csv'))
    if len({int(r['pair_idx']) for r in allrows})!=len(allrows): raise ValueError('Duplicate corpus pair')
    if dataset=='sigir204':
        patients={}
        for r in allrows:
            patients.setdefault(r['patient_id'],set()).add(splits[r['trial_id']])
        if any(len(v)!=1 for v in patients.values()): raise ValueError('SIGIR patient leaks across split')
    rows=[r for r in allrows if splits[r['trial_id']]==split]
    if not rows: raise ValueError('No corpus rows in requested split')
    return rows,rules

def expected_keys(corpus,rules):
    return {(int(r['pair_idx']),c['crit_idx']) for r in corpus for c in rules[r['trial_id']]}

def load_predictions(path,corpus,rules,dataset,partial=False):
    require_complete(path)
    records=read_jsonl(path);pred=unique(records);expected=expected_keys(corpus,rules)
    if set(pred)-expected: raise ValueError('Predictions contain cases outside the selected split/dataset')
    if not partial and set(pred)!=expected: raise ValueError('Prediction coverage differs from complete split; use --allow-partial only for pilot')
    pairs={int(r['pair_idx']):r for r in corpus}
    for k,r in pred.items():
        source=pairs[k[0]]; rule=rules[source['trial_id']][k[1]]
        if r.get('dataset',dataset)!=dataset or r['kind']!=rule['kind']: raise ValueError('Prediction dataset/kind mismatch')
        if r.get('criterion') and r['criterion']!=rule['criterion_text']: raise ValueError('Criterion text mismatch')
        if r.get('truth') not in TRUTHS: raise ValueError('Invalid prediction truth')
    return pred
