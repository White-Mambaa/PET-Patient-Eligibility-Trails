"""Conservative interval checks: only compatible named measures and units are compared."""
import math
import re

MEASURES={
 'ecog':r'(?:ECOG|Zubrod|WHO(?:\s+performance\s+status)?)',
 'karnofsky':r'Karnofsky', 'fev1':r'FEV\s*1', 'dlco':r'DLCO',
 'age':r'age(?:d)?', 'creatinine':r'creatinine','hemoglobin':r'h(?:a)?emoglobin',
 'platelets':r'platelets?','bilirubin':r'bilirubin','alt':r'ALT','ast':r'AST','neutrophils':r'neutrophils?'}
N=r'(\d+(?:\.\d+)?)'

def interval(text):
    text=text.replace('≥','>=').replace('≤','<=').replace('–','-').replace('−','-')
    text=re.sub(r'\b(?:greater than or equal to|at least)\b','>=',text,flags=re.I)
    text=re.sub(r'\b(?:less than or equal to|at most)\b','<=',text,flags=re.I)
    text=re.sub(r'\b(?:greater than|older than|more than)\b','>',text,flags=re.I)
    text=re.sub(r'\b(?:less than|younger than|under)\b','<',text,flags=re.I)
    m=re.search(r'between\s+'+N+r'\s+and\s+'+N,text,re.I)
    if not m:m=re.search(N+r'\s*(?:-|\bor\b|\bto\b)\s*'+N,text,re.I)
    if m:
        lo,hi=map(float,m.groups())
        return (lo,hi,True,True),m.end() if lo<=hi else None
    m=re.search(r'(>=|<=|>|<|=)?\s*'+N,text)
    if not m:return None
    op,val=m.group(1),float(m.group(2))
    r={'<':(-math.inf,val,False,False),'<=':(-math.inf,val,False,True),
       '>':(val,math.inf,False,False),'>=':(val,math.inf,True,False)}.get(op,(val,val,True,True))
    return r,m.end()

def unit(text,measure):
    m=re.match(r'\s*(%|percent|mg/d[lL]|g/d[lL]|mmol/[lL]|[uµ]mol/[lL]|(?:10\^?9)/[lL]|years?|cc|m[lL])',text,re.I)
    if m:
        u=m.group(1).lower()
        return '%' if u=='percent' else 'years' if u.startswith('year') else u
    return 'scale' if measure in ('ecog','karnofsky') else None

def extract(text):
    out={}
    for measure,pattern in MEASURES.items():
        vals=[]
        for m in re.finditer(pattern,text,re.I):
            tail=text[m.end():m.end()+95]
            # Do not cross a sentence, or another named measurement, to find a number.
            tail=re.split(r';|\n|\.\s+[A-Za-z]',tail)[0]
            tail=re.sub(r'^\s*(?:performance\s+status|score|status|was|is|of|at|predicted|value|level|[:=])\s*','',tail,flags=re.I)
            if re.match(r'^\s*[A-Za-z]',tail) and not re.match(r'^\s*(?:between|greater|less|at least|at most|older|younger|more than|under)',tail,re.I):continue
            found=interval(tail)
            if found and found[1] is not None:
                rng,end=found;vals.append((rng,unit(tail[end:],measure)))
        if vals:out[measure]=vals
    for m in re.finditer(r'\b(\d+(?:\.\d+)?)\s*[- ]year[- ]old\b',text,re.I):
        n=float(m.group(1));out.setdefault('age',[]).append(((n,n,True,True),'years'))
    # Greater than 18 years old / 18 years of age, without an age prefix.
    if 'age' not in out:
        m=re.search(r'((?:greater than|older than|less than|younger than|>=|<=|>|<)?\s*\d+(?:\.\d+)?)\s+years?\s+(?:old|of age)',text,re.I)
        if m:out['age']=[(interval(m.group(1))[0],'years')]
    return out

def subset(e,r):
    el,eh,elc,ehc=e;rl,rh,rlc,rhc=r
    return (el>rl or el==rl and (not elc or rlc)) and (eh<rh or eh==rh and (not ehc or rhc))

def disjoint(e,r):
    return e[1]<r[0] or r[1]<e[0] or e[1]==r[0] and not(e[3] and r[2]) or r[1]==e[0] and not(r[3] and e[2])

def numeric_expected(criterion,evidence):
    c=extract(criterion);e=extract(evidence);answers=[];details=[]
    for measure in c.keys() & e.keys():
        if len(c[measure])!=1 or len(e[measure])!=1:
            details.append(measure+': multiple values; no automatic conclusion');continue
        (r,ru),(v,vu)=c[measure][0],e[measure][0]
        # Percent versus cc, or explicit unknown unit, must never compare.
        if ru is None or vu is None or ru!=vu:
            details.append(measure+': incompatible/unstated units');continue
        result='yes' if subset(v,r) else 'no' if disjoint(v,r) else None
        answers.append(result);details.append(measure+': '+str(result))
    # Multi-measure/compound logic is handled by the semantic checker, not a guessed AND/OR.
    expected=answers[0] if len(answers)==1 and len(c)==1 else None
    return {'attempted':bool(answers),'expected_truth':expected,'detail':'; '.join(details) or 'No compatible supported numeric comparison'}
