"""Development-only trap construction, hand-check gate, execution and per-type scoring."""
import copy
import json
from pathlib import Path
from llm_client import CallFailed
from .common import *
from .analysis import student_labels,div
from .numeric import extract,numeric_expected

TYPES=('NEGATION','FAMILY_HISTORY','HYPOTHETICAL','OLD_VALUE','CONTRADICTION','EVIDENCE_REMOVED','THRESHOLD_SHIFT')
EXPECTED={'NEGATION':{'CONTEXT_ERROR'},'FAMILY_HISTORY':{'CONTEXT_ERROR'},'HYPOTHETICAL':{'CONTEXT_ERROR'},
          'OLD_VALUE':{'CONTEXT_ERROR','CONTRADICTED'},'CONTRADICTION':{'CONTRADICTED'},
          'EVIDENCE_REMOVED':{'HALLUCINATED_EVIDENCE','UNSUPPORTED'},'THRESHOLD_SHIFT':{'LOGIC_ERROR'}}

def add_commands(common):
    p=common('prepare-traps');p.add_argument('--labels',type=Path,required=True);p.add_argument('--statements',type=Path,required=True);p.add_argument('--per-type',type=int,default=20)
    p=common('run-traps');p.add_argument('--traps',type=Path,required=True);p.add_argument('--statements',type=Path,required=True);p.add_argument('--subject-model',required=True);p.add_argument('--subject-backend',choices=['groq','ollama'],required=True);p.add_argument('--subject-max-output',type=int,default=400);p.add_argument('--subject-num-ctx',type=int,default=8192);p.add_argument('--policy',choices=['unknown','forced'],default='unknown');p.add_argument('--limit',type=int,default=5);p.add_argument('--allow-unreviewed-statements',action='store_true')
    p=common('trap-report');p.add_argument('--results',type=Path,required=True)

def prepare(a):
    from .workflow import statement_map,output_path
    if a.split!='dev':raise ValueError('Traps may only use development pairs')
    if not 1<=a.per_type<=20:raise ValueError('Guide permits 1-20 cases per type')
    corpus,rules=select(a.root,a.dataset,'dev');gold,status=student_labels(a.labels,'dev',corpus,rules)
    stm=statement_map(a.statements,rules,corpus,False);pairs={int(r['pair_idx']):r for r in corpus};drafts=[];counts={t:0 for t in TYPES}
    def add(k,kind,operation,text,note,expected,replaced=None):
        if counts[kind]>=a.per_type:return
        p=pairs[k[0]];c=rules[p['trial_id']][k[1]]
        idx=len(drafts)
        drafts.append({'case_idx':idx,'trap_id':kind+'-'+str(idx).zfill(3),'base_pair_idx':k[0],'trial_id':p['trial_id'],'crit_idx':k[1],'kind':c['kind'],
                       'criterion':c['criterion_text'],'trap_type':kind,'operation':operation,'position':'end' if operation=='insert' else 'in_place',
                       'text':text,'replaced_text':replaced,'truth_before':gold[k]['truth'],'expected_truth_after':expected,'note':note,
                       'checked_by_hand':False,'base_note_sha256':hashed(p['patient_orig']),
                       'review_warning':'DRAFT ONLY. Check grammar, compound conditions, other deciding evidence, time interpretation, and expected answer by hand.'})
        counts[kind]+=1
    for k,g in sorted(gold.items()):
        p=pairs[k[0]];c=rules[p['trial_id']][k[1]];note=p['patient_orig'];statement=stm.get((p['trial_id'],k[1]))
        if not statement:continue
        term=statement['key_terms'][0]
        if g['truth']=='unknown':
            for t,text,expected in [('NEGATION','No evidence of '+term+'.','no'),('FAMILY_HISTORY','The patient\'s mother had '+term+'.','unknown'),('HYPOTHETICAL','Rule out '+term+'.','unknown')]:
                add(k,t,'insert',text,note+'\n'+text,expected)
        spans=[s.strip() for s in g.get('evidence_span','').split('||') if s.strip()]
        if g['truth'] in ('yes','no') and g.get('basis')=='stated' and len(spans)==1 and note.count(spans[0])==1:
            add(k,'EVIDENCE_REMOVED','remove',spans[0],note.replace(spans[0],'',1),'unknown')
            measures=extract(spans[0])
            if len(measures)!=1:continue
            measure,values=next(iter(measures.items()))
            if len(values)!=1 or values[0][0][0]!=values[0][0][1]:continue
            unit=values[0][1]
            if unit not in ('scale','%','years'):continue
            title={'ecog':'ECOG','fev1':'FEV1','dlco':'DLCO','age':'Age','karnofsky':'Karnofsky'}.get(measure)
            if not title:continue
            suffix='%' if unit=='%' else ' years' if unit=='years' else ''
            current=values[0][0][0];opposite='no' if g['truth']=='yes' else 'yes';replacement=None
            for candidate in (0,1,2,3,10,17,21,40,50,60,80,100):
                if candidate==current:continue
                phrase=f'{title} {candidate}{suffix}'
                if numeric_expected(c['criterion_text'],phrase)['expected_truth']==opposite:replacement=phrase;break
            if replacement:
                old='Two years ago, before treatment, '+replacement+'.'
                if measure!='age':add(k,'OLD_VALUE','insert',old,note+'\n'+old,g['truth'])
                add(k,'CONTRADICTION','insert',replacement+'.',note+'\n'+replacement+'.','unknown')
                add(k,'THRESHOLD_SHIFT','replace',replacement,note.replace(spans[0],replacement,1),opposite,spans[0])
    out=output_path(a,'traps_DRAFT.jsonl')
    if out.exists():raise ValueError('Do not overwrite a hand-review trap file; choose a new --out')
    jsonl(out,drafts);atomic_json(str(out)+'.summary.json',{'counts':counts,'total':len(drafts),'student_labels':status,'status':'DRAFTS_REQUIRE_MANUAL_CHECK','limit_per_type':a.per_type})
    print('TRAP DRAFTS:',out,'| counts:',counts)
    if not drafts:print('No suitable labelled cases. Complete development student labels and statement review first.')
    return 0

def validate_traps(rows,corpus,rules):
    if not rows:raise ValueError('No traps')
    if sorted(r['case_idx'] for r in rows)!=list(range(len(rows))):raise ValueError('Trap case_idx must be unique 0..N-1')
    pairs={int(r['pair_idx']):r for r in corpus}
    for r in rows:
        if r.get('checked_by_hand') is not True:raise ValueError('Every trap must be hand-checked before model execution')
        if r['trap_type'] not in TYPES or r['expected_truth_after'] not in TRUTHS or r['truth_before'] not in TRUTHS:raise ValueError('Invalid trap type/answer')
        if int(r['base_pair_idx']) not in pairs:raise ValueError('Trap base pair is not development data')
        p=pairs[int(r['base_pair_idx'])];rule=rules[p['trial_id']][int(r['crit_idx'])]
        if r['trial_id']!=p['trial_id'] or r['kind']!=rule['kind'] or r['criterion']!=rule['criterion_text']:raise ValueError('Trap source rule mismatch')
        if r.get('base_note_sha256') not in (None,hashed(p['patient_orig'])):raise ValueError('Trap source note has changed')
        if not isinstance(r['note'],str) or not r['note'].strip():raise ValueError('Empty altered note')
        original=p['patient_orig'];op=r['operation'];text=r['text']
        if op=='insert':
            # Source-preserving insertion, anywhere, not an unrelated rewritten note.
            if text not in r['note'] or norm_note(r['note'].replace(text,'',1))!=norm_note(original):raise ValueError('Insertion does not preserve base note')
        elif op=='remove':
            if original.count(text)!=1 or r['note']!=original.replace(text,'',1):raise ValueError('Removal does not match source operation')
        elif op=='replace':
            old=r.get('replaced_text')
            if not old or original.count(old)!=1 or r['note']!=original.replace(old,text,1):raise ValueError('Replacement does not match source operation')
        else:raise ValueError('Invalid operation')
    return pairs

def norm_note(s):return ' '.join(s.split())

def run(a):
    import plain_ai
    from criteria import map_truth
    from .client import make_client
    from .checker import Checker
    from .workflow import statement_map,output_path,bind_run,finish
    if a.split!='dev':raise ValueError('Trap execution is development-only')
    corpus,rules=select(a.root,a.dataset,'dev');cases=read_jsonl(a.traps);validate_traps(cases,corpus,rules)
    stm=statement_map(a.statements,rules,corpus,a.allow_unreviewed_statements)
    if a.limit:cases=cases[:a.limit]
    judge=make_client(a,a.root);subject_args=copy.copy(a);subject_args.model=a.subject_model;subject_args.backend=a.subject_backend;subject_args.max_output=a.subject_max_output;subject_args.num_ctx=a.subject_num_ctx
    subject=make_client(subject_args,a.root);checker=Checker(judge,a.theta,a.tau,a.support_backend,a.context_backend)
    out=output_path(a,'trap_results_'+a.policy+('_pilot'+str(a.limit) if a.limit else '')+'.jsonl')
    config={'command':'traps','source_sha256':sha(a.traps),'statements_sha256':sha(a.statements),'limit':a.limit,
            'subject':subject.options,'subject_model':a.subject_model,'judge':judge.options,'judge_model':a.model,'theta':a.theta,'tau':a.tau,'context':a.context_backend,'support':a.support_backend}
    mp=bind_run(out,config);done={r['case_idx']:r for r in read_jsonl(out)} if out.exists() else {};errors=[]
    try:
        for c in cases:
            if c['case_idx'] in done:continue
            rule=rules[c['trial_id']][c['crit_idx']]
            sys_prompt=plain_ai.SYSTEM_PROMPT_FORCED if a.policy=='forced' else plain_ai.SYSTEM_PROMPT
            res=subject.chat_json(sys_prompt,plain_ai.build_user(rule['criterion_text'],c['note'],rule['note']),prompt_id='TRAP_FORCED_v1' if a.policy=='forced' else 'TRAP_PLAIN_v1')
            ans=plain_ai.clean_answer(res['data'],('yes','no') if a.policy=='forced' else TRUTHS) if res['ok'] else None
            parse_ok=ans is not None
            if ans is None:ans={'truth':'unknown','evidence':[],'basis':None,'rationale':'','confidence':None}
            pred={'system':'trap_'+a.subject_backend+'_'+a.subject_model+'_'+a.policy,'dataset':'trap_set','pair_idx':c['case_idx'],'crit_idx':c['crit_idx'],'kind':c['kind'],'criterion':c['criterion'],**ans,'verdict':map_truth(ans['truth'],c['kind']),'parse_ok':parse_ok}
            checked=checker.check(pred,c['note'],rule,stm[(c['trial_id'],c['crit_idx'])])
            result={'case_idx':c['case_idx'],'trap_type':c['trap_type'],'expected_truth':c['expected_truth_after'],'prediction':pred,'checker':checked,
                    'source_trap_hash':hashed(c),'hand_checked':True}
            append(out,result);done[c['case_idx']]=result;print('Trap saved:',len(done),'/',len(cases),flush=True)
    except (CallFailed,KeyboardInterrupt) as e:errors.append(type(e).__name__)
    return finish(out,mp,config,len(cases),len(done),errors)

def report(a):
    from .workflow import output_path
    require_complete(a.results);rows=read_jsonl(a.results);result=[]
    for kind in TYPES:
        group=[r for r in rows if r['trap_type']==kind];wrong=[r for r in group if not r['prediction'].get('parse_ok',True) or r['prediction']['truth']!=r['expected_truth']]
        detected=[r for r in wrong if r['checker']['label']!='VERIFIED'];right=[r for r in detected if r['checker']['label'] in EXPECTED[kind]]
        result.append({'type':kind,'cases':len(group),'wrong':len(wrong),'detected_wrong':len(detected),'expected_label_detected':len(right),
                       'trap_rate':div(len(wrong),len(group)),'detection_rate':div(len(detected),len(wrong)),'right_label_rate':div(len(right),len(detected))})
    out=output_path(a,'trap_metrics.json');atomic_json(out,{'basis':'Hand-checked development alterations; not clinical gold','per_type':result,'source_sha256':sha(a.results)})
    print('TRAP REPORT:',out);return 0

def dispatch(a):return {'prepare-traps':prepare,'run-traps':run,'trap-report':report}[a.command](a)
