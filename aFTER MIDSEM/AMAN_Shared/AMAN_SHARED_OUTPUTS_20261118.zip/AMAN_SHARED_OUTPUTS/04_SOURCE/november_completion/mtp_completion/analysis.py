"""Offline scoring. Pair references and student labels are separate data sources."""
import math
import random
import statistics
from collections import Counter,defaultdict
from .common import TRUTHS,LABELS,key,final_label,read_csv,unique,write_csv

def div(a,b):return a/b if b else None

def classification(gold,pred,classes):
    if len(gold)!=len(pred):raise ValueError('Length mismatch')
    cm={g:{p:0 for p in tuple(classes)+('INVALID',)} for g in classes}
    for g,p in zip(gold,pred):
        if g not in cm:raise ValueError('Invalid reference label')
        cm[g][p if p in classes else 'INVALID']+=1
    per={}
    for c in classes:
        tp=cm[c][c];fp=sum(cm[g][c] for g in classes if g!=c);fn=sum(cm[c].values())-tp
        per[c]={'support':sum(cm[c].values()),'precision':div(tp,tp+fp),'recall':div(tp,tp+fn),'f1':div(2*tp,2*tp+fp+fn)}
    f1=[v['f1'] if v['f1'] is not None else 0 for v in per.values()]
    return {'n':len(gold),'accuracy':div(sum(cm[c][c] for c in classes),len(gold)),
            'macro_f1_all_classes':sum(f1)/len(classes),'weighted_f1':div(sum(per[c]['support']*f for c,f in zip(classes,f1)),len(gold)),
            'per_class':per,'confusion_gold_rows':cm}

def binary_metrics(gold,pred):
    tp=sum(g==p==1 for g,p in zip(gold,pred));tn=sum(g==p==0 for g,p in zip(gold,pred))
    fp=sum(g==0 and p==1 for g,p in zip(gold,pred));fn=sum(g==1 and p==0 for g,p in zip(gold,pred))
    sens,spec=div(tp,tp+fn),div(tn,tn+fp)
    denominator=(tp+fp)*(tp+fn)*(tn+fp)*(tn+fn)
    return {'tp':tp,'fp':fp,'tn':tn,'fn':fn,'accuracy':div(tp+tn,len(gold)),
            'balanced_accuracy':(sens+spec)/2 if sens is not None and spec is not None else None,
            'sensitivity':sens,'specificity':spec,'precision':div(tp,tp+fp),'npv':div(tn,tn+fn),
            'f1':div(2*tp,2*tp+fp+fn),'mcc':(tp*tn-fp*fn)/math.sqrt(denominator) if denominator else None}

def target(value):
    v=str(value).strip().lower().replace('_',' ').replace('-',' ')
    if v=='eligible':return 1
    if v in ('not eligible','ineligible'):return 0
    raise ValueError('Pair reference column must explicitly contain Eligible/Not Eligible; choose --target-column correctly')

def pair_rows(corpus,rules,pred,cluster_col='trial_id',target_col='target'):
    from criteria import map_truth,decide
    rows=[]
    for p in corpus:
        idx=int(p['pair_idx']); rr=rules[p['trial_id']]
        missing=[(idx,c['crit_idx']) for c in rr if (idx,c['crit_idx']) not in pred]
        if missing:raise ValueError('Cannot score incomplete pair; predictions are missing')
        vs=[map_truth(pred[(idx,c['crit_idx'])]['truth'],c['kind']) for c in rr]
        rows.append({'pair_idx':idx,'trial_id':p['trial_id'],'cluster':p[cluster_col],
                     'reference':target(p[target_col]),'decision':decide(vs),'n_rules':len(rr),'n_failing':vs.count('not_met')})
    return rows

def pair_metrics(rows,reps=1000):
    gold=[r['reference'] for r in rows];dec=[r['decision'] for r in rows]
    out={'n':len(rows),'decision_counts':dict(Counter(dec)),
         'three_way_exact_accuracy_review_incorrect':div(sum((d=='ELIGIBLE' and g==1) or(d=='NOT_ELIGIBLE' and g==0) for g,d in zip(gold,dec)),len(rows)),
         'binary_review_as_not_eligible':binary_metrics(gold,[int(d=='ELIGIBLE') for d in dec]),
         'binary_review_as_eligible':binary_metrics(gold,[int(d!='NOT_ELIGIBLE') for d in dec]),
         'false_exclusions':sum(g==1 and d=='NOT_ELIGIBLE' for g,d in zip(gold,dec)),
         'false_inclusions':sum(g==0 and d=='ELIGIBLE' for g,d in zip(gold,dec)),
         'eligible_pairs':sum(gold),'ineligible_pairs':len(gold)-sum(gold),'review_count':dec.count('REVIEW'),
         'review_rate':div(dec.count('REVIEW'),len(rows)),
         'sole_reason_false_exclusions':sum(r['reference']==1 and r['decision']=='NOT_ELIGIBLE' and r['n_failing']==1 for r in rows)}
    groups=defaultdict(list)
    for r in rows:groups[r['cluster']].append(r)
    out['per_cluster']={k:{'pairs':len(v),'eligible':sum(r['reference'] for r in v),
                         'false_exclusions':sum(r['reference']==1 and r['decision']=='NOT_ELIGIBLE' for r in v),
                         'false_inclusions':sum(r['reference']==0 and r['decision']=='ELIGIBLE' for r in v),
                         'review':sum(r['decision']=='REVIEW' for r in v)} for k,v in groups.items()}
    if reps and len(groups)>1:
        rng=random.Random(7);units=list(groups);values=[]
        for _ in range(reps):
            sample=[r for u in rng.choices(units,k=len(units)) for r in groups[u]]
            values.append(sum((r['decision']=='ELIGIBLE')==bool(r['reference']) for r in sample)/len(sample))
        values.sort();out['cluster_bootstrap_binary_strict_accuracy_95']={'low':values[int(.025*(len(values)-1))],'high':values[int(.975*(len(values)-1))],'replicates':reps,'clusters':len(groups),'seed':7}
    for prevalence in (.1,.05):
        n1=sum(gold);n0=len(gold)-n1
        if n1 and n0:
            weights=[prevalence/n1 if g else (1-prevalence)/n0 for g in gold]
            forward=sum(w for w,d in zip(weights,dec) if d=='ELIGIBLE')
            correctforward=sum(w for w,g,d in zip(weights,gold,dec) if g and d=='ELIGIBLE')
            out['prevalence_'+str(prevalence)]={'forwarded_share':forward,'forwarded_precision':div(correctforward,forward),'review_share':sum(w for w,d in zip(weights,dec) if d=='REVIEW')}
    return out

def student_labels(path,split,corpus,rules):
    if not path:return {},{'status':'UNAVAILABLE_NO_STUDENT_LABEL_FILE'}
    rows=read_csv(path);expected={(int(r['pair_idx']),c['crit_idx']):c for r in corpus for c in rules[r['trial_id']]}
    selected=[r for r in rows if r.get('split')==split];seen=set();valid={};blank=invalid=0;quoteissues=[]
    for r in selected:
        k=key(r)
        if k in seen:raise ValueError('Duplicate student label')
        seen.add(k)
        if k not in expected:raise ValueError('Student labels include a case outside selected split')
        if r.get('kind')!=expected[k]['kind']:raise ValueError('Student label kind mismatch')
        truth=r.get('truth','').strip().lower()
        if not truth:blank+=1;continue
        if truth not in TRUTHS:invalid+=1;continue
        valid[k]={**r,'truth':truth}
        ev=r.get('evidence_span','').strip();note=r.get('patient_note','')
        spans=[s.strip() for s in ev.split('||') if s.strip()]
        if truth!='unknown' and not spans or any(s not in note for s in spans):quoteissues.append({'pair_idx':k[0],'crit_idx':k[1]})
    return valid,{'status':'COMPLETE_STUDENT_LABELS' if len(valid)==len(selected) and selected else 'INCOMPLETE_STUDENT_LABELS',
                  'assigned_rows':len(selected),'usable_rows':len(valid),'blank_rows':blank,'invalid_rows':invalid,'quote_issue_cases':quoteissues,
                  'caveat':'Student labels, not clinician-confirmed ground truth; report any AI assistance.'}

def quality(gold,pred,checks):
    ids=sorted(gold.keys() & pred.keys() & checks.keys())
    if not ids:return {'status':'UNAVAILABLE_NO_JOINED_STUDENT_LABELS'}
    good=[pred[k]['truth']==gold[k]['truth'] and pred[k].get('parse_ok',True) for k in ids]
    flagged=[checks[k]['label']!='VERIFIED' for k in ids]
    tp=sum(f and not g for f,g in zip(flagged,good));fp=sum(f and g for f,g in zip(flagged,good));fn=sum(not f and not g for f,g in zip(flagged,good))
    return {'n':len(ids),'wrong':sum(not g for g in good),'flagged':sum(flagged),'precision':div(tp,tp+fp),'recall':div(tp,tp+fn),'f1':div(2*tp,2*tp+fp+fn),
            'accuracy_verified':div(sum(g and not f for f,g in zip(flagged,good)),sum(not f for f in flagged)),
            'accuracy_flagged':div(sum(g and f for f,g in zip(flagged,good)),sum(flagged)),
            'verified_share':div(sum(not f for f in flagged),len(ids))}

def student_metrics(gold,pred,checks=None):
    out={}
    for title,subset in [('all',gold),('without_UNSURE',{k:r for k,r in gold.items() if not r.get('comment','').strip().upper().startswith('UNSURE')})]:
        ids=sorted(subset.keys() & pred.keys())
        out[title]={'rule_metrics':classification([subset[k]['truth'] for k in ids],[pred[k]['truth'] if pred[k].get('parse_ok',True) else 'INVALID' for k in ids],TRUTHS) if ids else {'status':'UNAVAILABLE'},
                    'labelled_rows_missing_prediction':len(set(subset)-set(pred))}
        if checks:
            out[title]['checker_quality']=quality(subset,pred,checks)
            out[title]['ablations']={}
            for check in ('citation','entailment','context','logic','contradiction','missed_evidence'):
                altered={k:{**r,'label':final_label(r['checks'],omitted=check)} for k,r in checks.items()}
                q=quality(subset,pred,altered)
                q['wrong_caught_only_by_removed_check']=sum(k in checks and k in pred and checks[k]['label']!='VERIFIED' and altered[k]['label']=='VERIFIED' and pred[k]['truth']!=subset[k]['truth'] for k in subset)
                out[title]['ablations'][check]=q
    return out

def orders(pred,checks):
    from criteria import map_truth,what_could_change
    keys=sorted(pred);rng=random.Random(7);random_order=list(keys);rng.shuffle(random_order);tie={k:i for i,k in enumerate(random_order)}
    group=defaultdict(list)
    for k in keys:group[k[0]].append(k)
    features={}
    for groupkeys in group.values():
        groupkeys=sorted(groupkeys,key=lambda k:k[1]);vs=[map_truth(pred[k]['truth'],pred[k]['kind']) for k in groupkeys]
        nf=vs.count('not_met');impact=what_could_change(vs)
        for k,v,change in zip(groupkeys,vs,impact):
            conf=pred[k].get('confidence');conf=conf if isinstance(conf,(int,float)) and 0<=conf<=1 else .5
            lab=checks[k]['label'];features[k]={'verdict':v,'failing':v=='not_met','n_failing':nf,'flagged':lab!='VERIFIED','label':lab,'confidence':conf,**change}
    def combined(k):
        f=features[k]
        tier=0 if f['failing'] and f['flagged'] else 1 if f['failing'] else 2 if f['flagged'] else 3
        return tier,(f['n_failing'] if f['failing'] else 0),tie[k]
    return {'random':random_order,
            'least_confident':sorted(keys,key=lambda k:(features[k]['confidence'],tie[k])),
            'flagged_first':sorted(keys,key=lambda k:(not features[k]['flagged'],LABELS.index(features[k]['label']),tie[k])),
            'fewest_reasons':sorted(keys,key=lambda k:(not features[k]['failing'],features[k]['n_failing'] if features[k]['failing'] else 0,tie[k])),
            'combined':sorted(keys,key=combined)},features

def simulate(corpus,rules,pred,checks,gold,cluster_col,target_col):
    from criteria import map_truth
    from stats_tools import trial_sign_test,holm
    orderings,features=orders(pred,checks)
    base_rows=pair_rows(corpus,rules,pred,cluster_col,target_col);base=pair_metrics(base_rows,reps=0)
    labels={int(r['pair_idx']):target(r[target_col]) for r in corpus}
    results={};per_unit={}
    for strategy,order in orderings.items():
        results[strategy]=[]
        for budget in (5,10,20,50,100):
            changed={k:dict(v) for k,v in pred.items()};sources=Counter()
            for k in order[:budget]:
                if k in gold:new=gold[k]['truth'];sources['student_label']+=1
                elif labels[k[0]] and map_truth(changed[k]['truth'],changed[k]['kind'])=='not_met':new='unknown';sources['eligible_pair_label_assumption']+=1
                else:sources['unknown_effect']+=1;continue
                changed[k]['truth']=new;changed[k]['verdict']=map_truth(new,changed[k]['kind'])
            after_rows=pair_rows(corpus,rules,changed,cluster_col,target_col);after=pair_metrics(after_rows,reps=0)
            rescued=base['false_exclusions']-after['false_exclusions'];actual=min(budget,len(order))
            results[strategy].append({'budget':budget,'actual_checks':actual,'rescued':rescued,'rescued_per_10_checks':div(10*rescued,actual),
                                      'unknown_effect_checks':sources['unknown_effect'],'correction_sources':dict(sources),'after':after})
            if budget==50:per_unit[strategy]={u:v['false_exclusions'] for u,v in after['per_cluster'].items()}
    contrasts={}
    for strategy in ('flagged_first','fewest_reasons','combined'):
        for baseline in ('random','least_confident'):
            name=strategy+'_vs_'+baseline;contrasts[name]=trial_sign_test(per_unit[strategy],per_unit[baseline])
    adjusted=holm({k:v['sign_test_p_two_sided'] for k,v in contrasts.items()})
    for k in contrasts:contrasts[k]['holm_adjusted_p']=adjusted[k]
    return {'method':'Guide section 9.3 simulation; pair labels used only for scoring/correction effects, never ordering',
            'baseline':base,'strategies':results,'cluster_comparisons_at_50':contrasts},orderings,features

def rejection_risk(rows,features):
    rejected=[r for r in rows if r['decision']=='NOT_ELIGIBLE']
    scores=[]
    for r in rejected:
        fs=[f for k,f in features.items() if k[0]==r['pair_idx'] and f['failing']]
        scores.append({**r,'risk':sum(f['flagged'] for f in fs)/len(fs),'failing_confidence':sum(f['confidence'] for f in fs)/len(fs)})
    ranked=sorted(scores,key=lambda r:(-r['risk'],r['n_failing'],r['failing_confidence'],r['pair_idx']))
    random_order=list(sorted(scores,key=lambda r:r['pair_idx']));random.Random(7).shuffle(random_order)
    total=sum(r['reference'] for r in ranked)
    def score(order):
        return [{'k':k,'actual_selected':min(k,len(order)),'wrongly_excluded_found':sum(r['reference'] for r in order[:k]),
                 'precision':div(sum(r['reference'] for r in order[:k]),min(k,len(order))),
                 'recall':div(sum(r['reference'] for r in order[:k]),total)} for k in (3,5,10)]
    return {'rejected_pairs':len(ranked),'wrongly_excluded':total,'risk_order':score(ranked),'random_order':score(random_order)},ranked

def fixed_broken(gold,before,after):
    ids=set(gold)&set(before)&set(after);fixed=broken=unchanged=0
    for k in ids:
        b=before[k]['truth']==gold[k]['truth'] and before[k].get('parse_ok',True)
        a=after[k]['truth']==gold[k]['truth'] and after[k].get('parse_ok',True)
        fixed+=not b and a;broken+=b and not a;unchanged+=before[k]['truth']==after[k]['truth'] and before[k].get('parse_ok',True)==after[k].get('parse_ok',True)
    return {'n':len(ids),'fixed':fixed,'broken':broken,'unchanged_answer':unchanged,'changed_answer':len(ids)-unchanged,'fixed_minus_broken':fixed-broken}
