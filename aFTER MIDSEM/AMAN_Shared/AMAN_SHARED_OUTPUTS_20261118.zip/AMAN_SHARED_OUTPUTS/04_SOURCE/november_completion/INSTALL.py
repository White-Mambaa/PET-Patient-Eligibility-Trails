#!/usr/bin/env python3
"""Install additive completion files; never overwrites datasets, labels, or original kit code."""
import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import shutil

p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path.home()/'MTP/Akash_Kit');p.add_argument('--install',action='store_true');a=p.parse_args()
root=a.root.resolve();source=Path(__file__).resolve().parent
if not (root/'code/criteria.py').is_file() or not (root/'code/plain_ai.py').is_file():raise SystemExit('STOP: --root must be your existing Akash_Kit directory.')
files=[source/n for n in ('completion.py','completion_selftest.py','run_main_mtp_offline.sh','MAIN_MTP_COMPLETION_README.md','ROADMAP_AND_IMPLEMENTATION.md','requirements_mtp_completion.txt','TEST_RESULTS.md','START_HERE.txt')]
files+=sorted((source/'mtp_completion').glob('*.py'))
if not a.install:
 print('DRY RUN: would install',len(files),'new completion files under',root)
 print('Original code/, datasets/, labelling/, and existing outputs are not replaced. Add --install to proceed.')
 raise SystemExit(0)
stamp=dt.datetime.now().strftime('%Y%m%d_%H%M%S_%f');backup=root/'completion_install_backups'/stamp
log=[]
for src in files:
 rel=src.relative_to(source);dst=root/rel
 if dst.exists():
  saved=backup/rel;saved.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(dst,saved)
 dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
 log.append({'file':str(rel),'sha256':hashlib.sha256(dst.read_bytes()).hexdigest()})
backup.mkdir(parents=True,exist_ok=True)
(backup/'INSTALL_MANIFEST.json').write_text(json.dumps({'installed':log},indent=2))
print('INSTALLED:',root)
print('Next: cd',root)
print('Then: bash run_main_mtp_offline.sh')
