# Actual supervisor guide -> implementation -> remaining evidence

Authoritative source: uploaded `Akash_Kit/Akash_Project_Guide.md`, not the later AAPEMS proposal. The SIGIR README extends the same system to patient-clustered transfer. The original guide's research experiment IDs are **K1-K6** (section 13), and reporting tables are **1-8**. Earlier chat descriptions calling the whole roadmap K1-K8 were a simplification from a separate guidance document.

| Guide requirement | Implementation delivered | Evidence still needed on your laptop |
|---|---|---|
| 6. Student labels, evidence spans, UNSURE, applicability, compound rules | Report joins external CSV labels, preserves missing/invalid counts, all/without-UNSURE results, conflict output; original labelcheck/kappa tools retained | 446 NSCLC and 203 SIGIR assigned labels completed as student work; independent overlap review; labelcheck dispositions |
| 7. Plain AI and forced guess | `baseline`, separate original prompts and same subject model, streaming checkpoints, two-policy option | Complete model-consistent dev outputs and Table 1; existing Qwen plain outputs can be reused |
| 8.1 Statements/keywords | `statements`, reviewed-source CSV, guidance retained, test generation guard | Development statements hand-reviewed and frozen; test statements generated once and not edited |
| 8.2 Citation | Whitespace exact check; rapidfuzz partial alignment and source text; missing-quote handling; development theta calibration queue/grid | Human labels for up to 60 non-verbatim dev quotes, selected/frozen theta |
| 8.3 Support | Option B JSON AI judge; optional option A NLI with verified class mapping and threshold | Real dependency/model setup, both-option development comparison and tau selection |
| 8.4 Context | medspaCy target terms and five assertion flags, extension verification | Confirm installed-version rules and run actual context integration tests; judge alternative is a disclosed experimental variation |
| 8.5 Logic | Deterministic polarity, conservative named-measure interval checks; inferred-logic judge | Real development evaluation, complex unsupported unit cases reviewed; no claim of comprehensive medical numeric parsing |
| 8.6-8.8 Contradiction, missed evidence, precedence | Sentence-level scoring with provenance; complete six-field output and fixed precedence | Real-data tests, annotation-based flag metrics; conflict guard disclosed |
| 8.9 Tests | Deterministic/mocked suite and synthetic workflow tests | rapidfuzz, medspaCy and NLI integrations on installed environment; no claim that absent optional integrations passed |
| 9 / K1 / Table 2 | All five fixed strategies, seed 7, budgets 5/10/20/50/100, guide correction simulation, SVG curve | Complete checker coverage; labelcheck decisions; results treated as simulations, not actual clinical rescue |
| 10 / K5 / Table 7 | Visible-feature rejected-pair risk and random P/R@3/5/10 | Full split evaluation and per-cluster interpretation |
| 11 / K3 / Table 5 | Keep/flag report, same-subject one-feedback re-ask and mandatory recheck, fixed/broken counts | Run repair; evaluate on student-labelled subset and whole-pair dataset labels; disclose AI-assisted references |
| 12 / K4 / Table 6 | Draft generation for seven trap families from suitable dev labels; hard hand-check gate; altered-note execution and per-type scoring | Manually validate each alteration/expected answer; some types may have fewer suitable cases; no test-pair traps |
| 13 / K2 / Tables 3-4 | Checker quality and six remove-one-check ablations, all/without-UNSURE | Actual student labels, complete checker output, precise support/context method reporting |
| 13 / K6 / Table 8 | `compare-datasets`, fixed selected strategy, separate datasets | Same main model, method frozen before transfer; no test-selected winning strategy |
| 14. Counts/uncertainty | Pair confusion metrics, explicit REVIEW policies, trial/patient grouping, clustered bootstrap, sign tests/Holm, prevalence reweighting, SIGIR rule-count baseline | Actual corpus and outputs, inspect failures, compare clustering units and small sample caveats |
| 16. Integrity/test protection | Full-input cache, API limits/pacing/retries, original data preservation, checkpoint INCOMPLETE markers, code/artifact/label hashes and test guard | Complete valid label files and freeze artifacts; human supervision and independent provenance cannot be guaranteed by code |

## Corrections to earlier work

1. `truth` inside a screening JSONL is a model answer, not a reference label. The previous model-field agreement figures do not establish criterion accuracy.
2. Main pair-level metrics CAN be calculated now from complete existing predictions and dataset `target` labels, even while student criterion labels are incomplete. The offline launcher does exactly this.
3. The guide accepts student labels. Expert clinical confirmation is useful but is not introduced as an additional compulsory project requirement by this package.
4. The guide allows standard clinical implications marked inferred. The strict annotation-assistant rubric is a development experiment, not a substitute for the supervisor's annotation policy.
5. Main support option B can use a different judge model, as the guide prefers. Changing the reported subject model from Qwen to a Groq-hosted model is a separate methodological choice; use the same subject for both baseline policies and repairs.
6. Quote punctuation/paraphrase must be distinguished from invented clinical evidence. Retain raw strings and matched text; do not call every non-verbatim quotation a hallucination.
7. Uploaded `MTP_unified_six_checks.py` already consolidates preliminary six-field outputs and distinguishes judge mapping mistakes from baseline mistakes. It was not deleted or silently treated as validated checker generation. The new checker produces the guide's checker-result format directly.
8. Uploaded `MTP_metrics_for_Neha.py` already computes pair-level metrics offline and records reference-column/previous-report mismatches. Its review handling differs from the original evaluate.py binary REVIEW policy. The new report shows both definitions explicitly.

## Status of this delivery

Code is implemented and software-tested with mocked/synthetic inputs. Original real datasets and complete baseline/audit files were excluded from the source ZIP. Therefore this delivery cannot truthfully claim a completed real experiment, final clinical accuracy, human annotation completion, medspaCy/NLI integration success, or held-out evaluation.

First run: `bash run_main_mtp_offline.sh`. It produces actual development pair metrics on your laptop without any API generation requests. Then inspect those reports, finish the chosen checker configuration on development data, and proceed through the remaining guide experiments.
