#!/usr/bin/env python3
"""Run from the Akash_Kit root. No API call occurs for status/report/calibration export."""
from pathlib import Path
import os
import sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'code'))
from mtp_completion.workflow import main
if __name__=='__main__':
    os.umask(0o077)
    try:raise SystemExit(main())
    except KeyboardInterrupt:print('Interrupted; cached responses and checkpoints retained.');raise SystemExit(130)
    except Exception as e:
        # No response bodies, notes or credentials in console error details.
        from llm_client import CallFailed
        if isinstance(e,CallFailed):print('MODEL STOP:',str(e))
        elif isinstance(e,(ValueError,FileNotFoundError,ImportError)):print('STOP:',str(e))
        else:print('STOP:',type(e).__name__,'- inspect the local inputs/configuration.')
        raise SystemExit(2)
