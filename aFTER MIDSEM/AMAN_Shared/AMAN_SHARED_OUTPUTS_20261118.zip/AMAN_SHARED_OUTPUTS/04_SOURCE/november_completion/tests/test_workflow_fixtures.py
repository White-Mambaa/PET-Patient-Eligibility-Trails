"""End-to-end offline tests on a miniature synthetic corpus, not real study results."""
import argparse
import csv
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);a=p.parse_args()
source=a.root.resolve();package=Path(__file__).resolve().parents[1]
def csvfile(path,rows):
 path.parent.mkdir(parents=True,exist_ok=True)
 with path.open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def jsonfile(path,rows):path.write_text(''.join(json.dumps(r)+'\n' for r in rows))
with tempfile.TemporaryDirectory() as td:
 root=Path(td)/'Akash_Kit';root.mkdir();(root/'code').mkdir()
 for name in ('criteria.py','llm_client.py','plain_ai.py','stats_tools.py'):
  shutil.copy2(source/'code'/name,root/'code'/name)
 shutil.copytree(package/'mtp_completion',root/'mtp_completion')
 shutil.copy2(package/'completion.py',root/'completion.py')
 def run(*args,success=True):
  proc=subprocess.run([sys.executable,str(root/'completion.py'),args[0],'--root',str(root),*map(str,args[1:])],capture_output=True,text=True)
  if success and proc.returncode:raise AssertionError(proc.stdout+'\n'+proc.stderr)
  if not success and not proc.returncode:raise AssertionError('Expected refusal')
  return proc
 for dataset in ('nsclc100','sigir204'):
  folder=root/'datasets'/dataset
  corpus=[];rules=[];labels=[];assignment=[]
  for trial,split in [('T01','dev'),('T02','test')]:
   rules += [{'trial_id':trial,'crit_idx':0,'kind':'inclusion','criterion_text':'Greater than 18 years old','note':''},{'trial_id':trial,'crit_idx':1,'kind':'exclusion','criterion_text':'Active brain metastases','note':''}]
   for local in (1,2):
    idx=local+(0 if split=='dev' else 2);eligible=local==1
    note='A 21-year-old patient. No active brain metastases.' if eligible else 'A 17-year-old patient. Active brain metastases.'
    corpus.append({'pair_idx':idx,'trial_id':trial,'patient_id':'PDEV' if split=='dev' else 'PTEST','patient_orig':note,'target':'Eligible' if eligible else 'Not Eligible'})
    for crit,truth,ev in [(0,'yes' if eligible else 'no','21-year-old' if eligible else '17-year-old'),(1,'no' if eligible else 'yes','No active brain metastases' if eligible else 'Active brain metastases')]:
     row={'split':split,'pair_idx':idx,'trial_id':trial,'crit_idx':crit,'kind':'inclusion' if crit==0 else 'exclusion','truth':truth,'patient_note':note,'evidence_span':ev,'basis':'stated','comment':''}
     labels.append(row);assignment.append({**row,'truth':''})
  csvfile(folder/(dataset+'.csv'),corpus);csvfile(folder/'criteria.csv',rules);csvfile(folder/'splits.csv',[{'trial_id':'T01','split':'dev'},{'trial_id':'T02','split':'test'}])
  sheet='my_label_sheet.csv' if dataset=='nsclc100' else 'sigir_label_sheet.csv';final='my_labels_final.csv' if dataset=='nsclc100' else 'my_sigir_labels_final.csv'
  csvfile(root/'labelling'/sheet,assignment);csvfile(root/'labelling'/final,labels)
  pred=[];checks=[]
  for row in labels[:4]:
   r={'system':'fixture','dataset':dataset,'pair_idx':row['pair_idx'],'crit_idx':row['crit_idx'],'kind':row['kind'],'truth':row['truth'],'evidence':[row['evidence_span']],'basis':'stated','confidence':.7,'parse_ok':True,'trace':{'model':'qwen2.5:7b'}}
   if row['pair_idx']==1 and row['crit_idx']==1:r['truth']='yes'
   r['verdict']=('met' if r['truth']=='yes' else 'not_met') if r['kind']=='inclusion' else ('not_met' if r['truth']=='yes' else 'met')
   pred.append(r)
   flagged=row['pair_idx']==1 and row['crit_idx']==1
   c={'citation':{'status':'FOUND'},'context':{'misread':False},'logic':{'valid':True},'contradiction':{'found':False},'entailment':{'consistent_with_truth':not flagged},'missed_evidence':{'found':False}}
   checks.append({'system':'fixture','dataset':dataset,'pair_idx':row['pair_idx'],'crit_idx':row['crit_idx'],'label':'UNSUPPORTED' if flagged else 'VERIFIED','checks':c})
  predpath=root/(dataset+'_pred.jsonl');checkpath=root/(dataset+'_checks.jsonl');jsonfile(predpath,pred);jsonfile(checkpath,checks)
  out=root/('report_'+dataset)
  run('report','--dataset',dataset,'--pred',predpath,'--checks',checkpath,'--labels',root/'labelling'/final,'--bootstrap',50,'--out',out)
  result=json.loads((out/'RESULTS.json').read_text())
  assert result['pair_metrics']['false_exclusions']==1
  assert result['review_simulation']['strategies']['combined'][0]['rescued']==1
  assert result['student_metrics']['all']['checker_quality']['precision']==1
  assert (out/'review_curve.svg').exists()
  if dataset=='sigir204':assert result['cluster_by']=='patient_id' and 'count_the_rules_baseline' in result
  print('PASS complete offline report, labels, strategies, ablations, risk, deferral:',dataset)
 # No API call or key is needed to refuse unfrozen tests.
 refused=run('baseline','--split','test','--backend','groq',success=False)
 assert 'freeze' in refused.stdout.lower()
 artifact=root/'calibration.json';artifact.write_text('{"theta":90}')
 manifest=root/'METHOD_FREEZE.json'
 run('freeze','--labels-file',root/'labelling/my_labels_final.csv','--labels-file',root/'labelling/my_sigir_labels_final.csv','--artifacts',artifact,'--subject-model','qwen2.5:7b','--subject-backend','ollama','--label-provenance','student_unassisted','--out',manifest)
 artifact.write_text('{"theta":85}')
 refused=run('baseline','--split','test','--backend','ollama','--model','qwen2.5:7b','--freeze',manifest,success=False)
 assert 'changed/missing' in refused.stdout
 print('PASS freeze gate and post-freeze mutation refusal')
 # A complete development trap candidate file must be checked before execution.
 statement=root/'reviewed_statements.csv'
 csvfile(statement,[{'trial_id':'T01','crit_idx':i,'criterion':c['criterion_text'],'guidance':'','statement':c['criterion_text'],'key_terms':json.dumps(['age' if i==0 else 'brain metastases']),'reviewed':'true'} for i,c in enumerate(rules[:2])])
 traps=root/'trap_drafts.jsonl'
 run('prepare-traps','--labels',root/'labelling/my_labels_final.csv','--statements',statement,'--out',traps)
 draftrows=[json.loads(x) for x in traps.read_text().splitlines()];assert draftrows and all(not r['checked_by_hand'] for r in draftrows)
 refused=run('run-traps','--traps',traps,'--statements',statement,'--subject-model','qwen2.5:7b','--subject-backend','ollama',success=False)
 assert 'hand-checked' in refused.stdout
 print('PASS development trap drafting and unreviewed execution refusal')
 print('FIXTURE INTEGRATION PASS. No real API calls. Synthetic test metrics are not project results.')
