"""Exercise generation, statement/checkpoint, six checks and repair without API calls."""
import argparse,csv,json,shutil,sys,tempfile
from pathlib import Path
from unittest.mock import patch
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);a=p.parse_args()
package=Path(__file__).resolve().parents[1];sys.path.insert(0,str(a.root.resolve()/'code'));sys.path.insert(0,str(package))
from mtp_completion import workflow as w
from mtp_completion.common import hashed,read_jsonl
class FakeLLM:
 options={'provider':'mock','temperature':0};calls=0
 def check_model_available(self):pass
 def chat_json(self,system,user,prompt_id=''):
  self.calls+=1
  if prompt_id=='RULE_STATEMENT_v1':data={'statement':'The patient has ECOG 0 or 1.','key_terms':['ECOG']}
  elif prompt_id=='SUPPORT_v1':data={'label':'entailment'}
  else:
   truth='no' if prompt_id=='PLAIN_v1' else 'yes'
   data={'truth':truth,'evidence':['ECOG=1'],'basis':'stated','rationale':'Synthetic mock output.','confidence':.7}
  return {'ok':True,'data':data,'raw':json.dumps(data),'attempts':1,'cache_hit':False,'prompt_sha256':hashed([system,user])}
class FakeContext:
 method='mock_context'
 def __init__(self,*a):pass
 def run(self,*a):return {'negated':False,'hypothetical_or_uncertain':False,'family':False,'historical':False,'misread':False}
def csvfile(path,rows):
 path.parent.mkdir(parents=True,exist_ok=True)
 with path.open('w',newline='') as f:
  d=csv.DictWriter(f,fieldnames=list(rows[0]));d.writeheader();d.writerows(rows)
with tempfile.TemporaryDirectory() as td:
 root=Path(td);folder=root/'datasets/nsclc100';folder.mkdir(parents=True)
 csvfile(folder/'nsclc100.csv',[{'pair_idx':1,'trial_id':'T01','patient_id':'P1','patient_orig':'ECOG=1','target':'Eligible'}])
 csvfile(folder/'criteria.csv',[{'trial_id':'T01','crit_idx':0,'kind':'inclusion','criterion_text':'ECOG 0 or 1','note':''}])
 csvfile(folder/'splits.csv',[{'trial_id':'T01','split':'dev'}])
 mock=FakeLLM()
 def run(command,*args):
  with patch.object(sys,'argv',['completion.py',command,'--root',str(root),*map(str,args)]):
   code=w.main();assert code==0,(command,code)
 with patch.object(w,'make_client',return_value=mock),patch('mtp_completion.checker.Context',FakeContext):
  pred=root/'pred.jsonl';stm=root/'statements.csv';checks=root/'checks.jsonl';repair=root/'repair.jsonl'
  run('baseline','--backend','ollama','--model','qwen2.5:7b','--policy','unknown','--limit','0','--out',pred)
  before=mock.calls;run('baseline','--backend','ollama','--model','qwen2.5:7b','--policy','unknown','--limit','0','--out',pred);assert mock.calls==before
  run('statements','--limit','0','--out',stm)
  with stm.open(newline='') as f:reader=csv.DictReader(f);rows=list(reader)
  rows[0]['reviewed']='true';csvfile(stm,rows)
  run('check','--pred',pred,'--statements',stm,'--limit','0','--out',checks)
  assert read_jsonl(checks)[0]['label']=='LOGIC_ERROR'
  run('repair','--pred',pred,'--checks',checks,'--statements',stm,'--subject-model','qwen2.5:7b','--subject-backend','ollama','--out',repair)
  row=read_jsonl(repair)[0];assert row['truth']=='yes' and row['repair']['accepted']
  assert not Path(str(repair)+'.INCOMPLETE').exists()
 print('MODEL WORKFLOW MOCK PASS: baseline checkpoint reuse, statement review, checker precedence, same-subject re-ask and recheck. No real API calls.')
