# Akash → Aman: available outputs and research handoff

Prepared 18 November 2026, India time. This package contains recovered original files and clearly identified historical summaries. It does not establish the current state of Akash's laptop.

## What has actually been completed

| Work | Evidence and status |
|---|---|
| Local-Qwen development screening | Original files recovered and freshly counted: **950 unique NSCLC criterion answers across 50 pairs; 990 unique SIGIR answers across 102 pairs**. Model: `qwen2.5:7b` via Ollama. These are saved predictions, not manual labels. |
| Earlier local-Qwen evidence audit | **1,940 unique AI audit records** recovered and counted. This is an October Qwen audit, separate from the later Groq checker. Its quality has not been independently established. |
| Quote checks, decision-impact analysis and five strategy rankings | Actual CSV files are included. Rankings contain 9,700 rows = 1,940 answers × five strategies. Earlier budget summaries count review candidates, not independently confirmed rescues. |
| November plain-AI / forced-guess comparison | Recorded count tables and reports exist and are included. The individual later forced-guess raw predictions were not found in the inspected archives, so those later runs cannot be reconstructed here row by row. |
| Later Groq checker | Configured model `openai/gpt-oss-20b`. Last supplied terminal snapshot: **707/950 saved automated judgments**. Current coverage is unverified; the actual checkpoint is on the laptop and is absent here. All 95 statement rows were unreviewed at the last inspection, so this run is exploratory. |
| Software | Screening/evaluation code, completion checker, prioritisation, supervisor code and synthetic demo records exist. The last supplied laptop self-test output reported **18 passed**, including medspaCy; this package does not claim new tests were run. |
| Manual annotations | At the last audit, original assigned sheets had **0/446 NSCLC and 0/203 SIGIR** truth fields completed and final files were missing. Old exploratory reviews and AI proposals are not completed independent assignment labels. Current state needs checking. |

## Are we following ma'am's research direction?

The implemented direction matches the question: **which AI criterion answers should be checked first to catch wrongful exclusions with limited review effort?** Implementation and exploratory output generation have progressed. The requested research evaluation is still incomplete.

The immediate missing evidence is:

1. Matching independent human labels for rule accuracy/macro-F1 and checker precision/recall/F1, VERIFIED accuracy and sentence-level evidence scores.
2. A consistent shared screening experiment for the team; do not merge the old Qwen pilot with new Groq runs.
3. The required strategy comparison at **5, 10, 20, 50 and 100 checks**, its rescue graph, and counts of effects that cannot be scored.
4. Five verified examples covering correct flags, missed errors and false flags.
5. Fresh checker coverage and the original source of the unexplained **960** count.

Fixer, trap performance and rejection-risk experiments remain part of the wider project; ma'am places these under the later components when ready.

## Where Aman can start

Following Aman's proposal, he can own the shared Groq **plain-AI and forced-guess screening runs** on the same 950 NSCLC development questions. First agree on a currently accessible model ID, prompts, output schema, criteria/guidance, question IDs, generation settings and bounded quota. Then validate a small pilot and produce separate raw files, configuration and hashes for each mode. A full run for that agreed Groq screening setup is not verified as already complete.

Akash's proposed role is to apply the checker to those exact new predictions and evaluate the checking-order strategy. The old Groq judgments concern the earlier Qwen predictions and cannot simply be reused as judgments of newly generated answers. Each person must complete and lock their assigned human labels independently, following the professor's overlap-comparison process.

## File layout

| Folder/file | Purpose |
|---|---|
| `01_OCTOBER_OUTPUTS/outputs/` | Original raw Qwen predictions, cache, logs, quote checks, AI audit, ranking CSVs and exploratory summaries. Original bytes retained. |
| `02_NOVEMBER_RECORDED_RESULTS/` | Later saved count tables, evidence summaries and closeout snapshot. Raw later run files are missing. |
| `03_HISTORICAL_REPORTS/` | Older PDFs, slides and speaking notes, preserved as historical artifacts. Read the caveats below before reporting their numbers. |
| `04_SOURCE/` | Original kit instructions, criteria, split files, screening prompts/code and November checker/workflow code. Versions are kept separate. |
| `05_SOFTWARE_DEMO/` | Synthetic examples and archived software test transcript. |
| `VERIFIED_COUNTS.json` | Fresh counts/hashes and explicitly dated terminal-only claims. |
| `FILE_MANIFEST.csv` | Every payload file, its SHA-256, origin, scope and evidence status. |
| `MISSING_AND_SEPARATE_FILES.md` | Missing laptop outputs, command-history limitation and separately held annotation materials. |

## Important interpretation rules

- `truth` in a raw model file is a **model prediction**, not a human annotation.
- **707/950** was automated checker coverage, not accuracy or annotation progress.
- The recovered original NSCLC baseline log explicitly contains **`750/950 answered`** and **`950/950 answered`**. It does not explain who introduced 960 or why.
- The earlier Qwen audit and later Groq checker are different experiments. Do not add their counts or substitute one for the other.
- Historical November binary accuracy/F1 treated REVIEW as negative. Ma'am now requires REVIEW to remain separate; those numbers are not the requested current rule-level accuracy or a correctly scored three-outcome eligibility evaluation.
- Ranking files may include reference-defined evaluation columns. Ranking construction must not read reference/human labels. Check the implementation before using any old order as the new study's method.
- Old selected-case analyses and assistant substitutions are exploratory. Neither 22 candidate exclusions nor 20 repair drafts establishes 22 confirmed rescues or 20 successful repairs.
- Original `consistency_snapshot.csv` / `consistency_impact_join.csv` contain only 843 rows and are partial older snapshots, despite the final audit JSONL having 1,940 unique records.
- Preserve missing/failed/unparseable outcomes separately from a genuine clinical `unknown` answer.
- Complete independent labels before consulting model answers for those assigned cases. Independent annotation answer sheets and row-level human review files are held separately from this teammate package.

No new model calls, inference, deletions or external messages were made to assemble this package.
