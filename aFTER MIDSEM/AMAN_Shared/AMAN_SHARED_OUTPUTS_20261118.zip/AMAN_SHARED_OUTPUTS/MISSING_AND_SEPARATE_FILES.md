# Missing and separately held files

## Not available in the inspected saved archives

These are needed from the laptop for a complete up-to-date output handoff:

- `outputs/mtp_completion/nsclc100/dev/plain_ai_qwen_dev_checks_theta95_fallback_exploratory.jsonl` and its `.manifest.json`, any completion/incomplete marker, and relevant compatible input hashes.
- `outputs/mtp_completion/nsclc100/dev/rule_statements_dev95_with_source_fallback.csv` and the separately reviewed statement copy if completed.
- Fresh `outputs/mtp_supervisor/STATUS.json` and successful log `outputs/pet_milestone/nsclc_resume_UyAitQ.log` (or a newer actual run log).
- Individual November plain/forced prediction files, their manifests and `outputs/mtp_parallel/REPORT_INDEX.json`, so saved comparison reports can be traced to original records.
- Individual follow-up/re-ask draft files and their rechecks; saved counts are not substitutes for those records.
- Current `outputs/pet_milestone/day1_.../` audit and baseline-report folders.
- Original shell history or saved commands for both historical screening runs. The recovered output logs prove execution and counts but do not contain the shell invocations. The package includes original source/prompts and defaults; no reconstructed command is presented as the original command.
- The actual file, screenshot or message that introduced `750/960`.

## Separately held independent annotation work

Akash's assigned NSCLC/SIGIR annotation sheets, working human labels, blinded review backups, restricted keys and row-level human review records have not been merged into this teammate package. Their completion remains unverified after the last audit. Submit locked independent files via the supervisor's process.

`SEPARATE_ANNOTATION_ARTIFACTS.json` lists the archived row-level materials kept separate. These are not missing generated predictions.

## Package scope

This is the accessible **shared model/analysis output collection**, with source and historical reports. It is not a complete laptop backup and does not replace raw datasets, independent labels or missing later checkpoints. Unrelated projects, credentials and the large conversation textbook are not included.
