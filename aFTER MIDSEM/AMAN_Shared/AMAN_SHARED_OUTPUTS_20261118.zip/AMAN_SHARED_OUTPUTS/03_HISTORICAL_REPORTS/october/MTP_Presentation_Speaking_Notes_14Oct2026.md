# MTP progress presentation — speaking notes

**Project:** *Check What Can Change the Outcome: Targeted Checking of AI Screening Decisions for Clinical Trials*  
**Results frozen:** 14 October 2026  
**Target talk:** approximately **9–10 minutes** for slides 1–12, followed by Q&A (slide 13).  
**Speakers:** You can split slides **1–6** and **7–12** between the two presenters. The wording below avoids attributing work to a particular person.

> **Important:** The purpose of this talk is to present completed development-stage experiments. Do not claim independent clinical validation, verified rescue of patients, or finished repair/trap experiments.

## Slide 1 — Title (20–25 seconds)

“Good evening. Our MTP is about checking AI-generated clinical-trial screening decisions, particularly the answers that could change the final eligibility outcome. Today we are showing the experiments we have *actually completed*: 1,940 baseline criterion predictions, five prioritization strategies, and a complete 1,940-record model-assisted evidence audit. We will also describe what remains unvalidated.”

## Slide 2 — Research question (35–40 seconds)

“A clinical-trial screening AI reads a patient note and decides whether each inclusion or exclusion rule holds. A mistake in one rule can reject a potentially suitable patient or miss a disqualifying condition. Checking every answer costs time. Our question is: with a fixed checking budget, can we prioritize the rules most likely to change the final decision?”

## Slide 3 — Data and model (40–45 seconds)

“We used the local Qwen2.5 7B model through Ollama. The NSCLC development portion contains 50 patient–trial pairs and 950 criterion answers. The SIGIR development portion contains 102 pairs and 990 criterion answers. In total, that is 152 pairs and 1,940 criterion predictions. A rule answer is yes, no, or unknown; its mapping to eligibility depends on whether it is an inclusion or an exclusion rule.”

## Slide 4 — Baseline results (50–60 seconds)

“Our strict pair accuracy was 50 percent on NSCLC development and 53.9 percent on SIGIR development, using the project's special handling of REVIEW. More interestingly, the baseline rejected 11 of 25 reference-eligible NSCLC pairs and 17 of 49 reference-eligible SIGIR pairs. Of those 28 potential false exclusions, 22 had exactly one failing rule. Those are obvious candidates for targeted checking. But we cannot call all 28 true clinical errors because criterion-level evidence and some reference labels still require adjudication.”

## Slide 5 — What we built (50–55 seconds)

“The intended six checks are quotation authenticity, evidence support, context or timing, answer-to-verdict logic, contradiction, and missed evidence. The local PC1 quotation checker passed four tests. We also generated AI-judge flags for the remaining categories across the development predictions; these outputs are not yet validated as correct. For selection, we created five alternatives: random, confidence, citation flags, decision impact, and combined signals.”

## Slide 6 — Equal-budget findings (55–60 seconds)

“At a review budget of ten, in our union of 44 strategy-selected cases, decision impact surfaced seven baseline–assistant disagreements, combined ranking six, citation one, random one, and confidence none. This suggests that decision-impact ranking concentrates interesting disagreements. However, these 44 cases were selected from the rankings themselves. It is a biased exploratory sample, and disagreements with assistant proposals are not verified mistakes. We therefore do not claim a final precision or superiority rate.”

## Slide 7 — Annotation pilot (40–45 seconds)

“Our selected annotation set contains 44 cases, 22 from each dataset. The assistant produced scorable proposed answers for 42 and deferred two. Twelve proposals disagreed with the baseline. Fifteen human selections were recorded, with three preliminary evidence-supported judgments. No independent clinical adjudication has been completed, so the proposed labels are useful for finding cases to review, not for publishing final checker accuracy.”

## Slide 8 — Patient-level counterfactual results (55–60 seconds)

“We then asked a different question: if we *hypothetically* replace one baseline criterion answer with the proposed answer, does the final patient decision change? Among twelve disagreements, nine transitions changed a rejection to REVIEW, one changed a rejection to ELIGIBLE, one changed REVIEW to NOT_ELIGIBLE, and one did not change the rejection. Therefore eleven out of twelve suggestions altered simulated pair-level decisions. This is a sensitivity analysis—not proof that eleven changes are clinically appropriate.”

## Slide 9 — A case example (50–55 seconds)

“In ANN-021, the inclusion criterion allows ECOG performance status zero or one, and the note explicitly says ECOG one. The baseline returned ‘no,’ giving the patient a failing criterion. Correcting that answer to ‘yes’ changes the simulated pair decision from NOT_ELIGIBLE to ELIGIBLE, because no other rule is failing or unknown in that baseline output. This example had already been examined in our earlier pilot, so it is not independent validation or a proven patient rescue.”

## Slide 10 — AI-judge evidence audit (55–65 seconds)

“We completed the full local Qwen evidence audit for all 1,940 criterion predictions, including a targeted retry for one invalid output. The most important finding is a reliability weakness of the second AI judge. In the first 1,939 audits, 669 suggested truth/verdict pairs—34.5 percent—were logically inconsistent with the inclusion/exclusion mapping. This shows why a judge's free-form proposed verdict cannot be applied automatically. Our follow-up system should preserve the raw answer, derive the verdict deterministically, and seek independent evidence review before applying clinical corrections.”

## Slide 11 — PC1, PC2 and unfinished work (40–45 seconds)

“PC1 has a tested quotation-validation component. The overall ranking and audit work has also been implemented in the development environment. PC2 has three designed, schema-checked trap examples, but no completed controlled-trap detection result or repair-versus-deferral evaluation. Independent annotation, full checker precision and recall, and frozen held-out evaluation are also pending. We are showing our real current state rather than presenting those planned experiments as completed.”

## Slide 12 — Conclusions (45–50 seconds)

“Our current conclusion has three parts. First, the software can run and generate large-scale development results. Second, decision-impact ranking appears to bring potential decision-relevant disagreements toward the top in an exploratory selected cohort. Third, an AI evidence judge is not automatically reliable: we found substantial truth-to-verdict inconsistencies. Next, we need independent rule-level labels, known-answer trap experiments, repair versus deferral evaluation, and frozen held-out comparisons before claiming improved clinical screening.”

## Slide 13 — Q&A

“Thank you. We welcome questions about the checking strategies, counterfactual simulations, and evaluation safeguards.”

---

## Likely questions and concise answers

**Q1. Which AI did the screening? Who built it?**  
“The screening baseline in our experiment is the open-weight Qwen2.5:7b model, run locally using Ollama. We configured the project's screening code and criteria-to-verdict logic; we did not train a new foundation model.”

**Q2. Did you implement a new AI model?**  
“No. The research contribution is the proposed evidence-checking and decision-impact prioritization workflow built around an existing screening model.”

**Q3. What does `unknown` mean?**  
“The note does not establish whether a criterion is true or false. We do not treat missing information as a negative finding. Unknown maps to `not_stated` for both inclusion and exclusion criteria.”

**Q4. Why is a yes for an exclusion criterion a failure?**  
“Because it means the disqualifying condition is present. For an inclusion rule, yes means met. For an exclusion rule, yes means not_met.”

**Q5. What is a sole rejection reason?**  
“A pair with exactly one rule marked `not_met`. Correcting that one rule can remove an automatic rejection, although remaining unknowns may still require REVIEW.”

**Q6. Did you rescue eleven patients?**  
“No. Eleven out of twelve *proposed* single-rule changes altered a simulated patient–trial decision. These have not been independently adjudicated, and nine led only to REVIEW. We do not claim verified patient rescues.”

**Q7. Does the equal-budget result prove decision impact is best?**  
“No. The 44-case set was formed from top-ten lists of the strategies being evaluated and is selection-biased. It is a useful exploratory finding, not an unbiased final comparison.”

**Q8. Why did the second AI judge fail 34.5%?**  
“That percentage refers specifically to logical incompatibility between the judge's proposed truth and verdict on the first 1,939 audits. It is *not* an overall clinical error rate. We can enforce correct mapping deterministically, but that alone does not prove the suggested truth is correct.”

**Q9. What is truly complete?**  
“The development-set Qwen baseline, five ranking outputs, exploratory annotation/pilot comparison, simulated counterfactual analysis, and 1,940/1,940 Qwen judge audit responses. Formal clinical validation and repair/trap evaluation are not complete.”

**Q10. What are PC1 and PC2 working on?**  
“PC1 is responsible for the evidence-checking and prioritization track; PC2 for controlled traps, repair-versus-deferral, and held-out evaluation. Some experiments were also executed on the personal laptop and should not be mistaken for new PC1/PC2 runs.”

## Five things to verify before presenting

- Read slides 4, 6, 8, and 10 carefully: these contain the most important numerical claims and scientific limitations.
- Keep the PPTX and PDF on your laptop and optionally on a permitted external drive.
- If both presenters are speaking, agree on the transition after slide 6.
- Practice the main talk once with a 10-minute timer; if needed, shorten slides 5, 7, and 11.
- Do not run fresh experiments immediately before the talk. Preserve the frozen outputs and be ready to answer questions about what is not yet validated.
