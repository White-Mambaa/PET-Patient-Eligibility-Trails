#!/usr/bin/env python3
"""Open the PET TOOL website and reviewer workspace (Python 3.10+)."""
import argparse
import csv
import json
import sys
from threading import Thread
import webbrowser

from PET_CORE.contracts import RequestError, json_bytes
from PET_CORE.http_app import Portal, PortalServer
from PET_CORE.reviewer import ReviewService
from PET_CORE.study import REVIEW_EXAMPLE, demo, load_results


def self_test():
    service = ReviewService()
    sample = service.training()
    case = service.prepare(REVIEW_EXAMPLE)["screening"]
    if case["criteria"][0]["flags"] != ["NUMERIC_MISMATCH"]:
        raise RuntimeError("Numeric check regression.")
    if case["decisions"] != {"keep": "NOT_ELIGIBLE", "flag_as_unknown": "REVIEW"}:
        raise RuntimeError("Draft rule summary regression.")
    data = load_results()
    if [(r["pairs"], r["correct_binary"]) for r in data["paired_development"][-2:]] != [(152, 80), (152, 87)]:
        raise RuntimeError("Frozen results regression.")
    record = {
        "ticket": sample["ticket"], "reviewer": "TEST-01", "confirmed": True,
        "disposition": "forward_for_trial_review",
        "assessments": [{"id": "performance", "truth": "yes", "rationale": "The training score meets the rule."},
                        {"id": "metastases", "truth": "no", "rationale": "The training note documents absence."}],
    }
    receipt = service.record(record)
    if receipt["derived_rule_status"] != "ELIGIBLE" or receipt["source_note_included"] or receipt["evidence_quotes_included"]:
        raise RuntimeError("Reviewer record regression.")
    for invalid in (
        {**record, "confirmed": False},
        {**record, "ticket": "invalid"},
        {**record, "assessments": record["assessments"][:1]},
        {**record, "disposition": "criteria_not_met"},
    ):
        try:
            service.record(invalid)
        except RequestError:
            pass
        else:
            raise RuntimeError("An invalid reviewer confirmation was accepted.")
    print("PASS: training checks, review context, human confirmation, and frozen development metrics.")
    print(json.dumps(sample["demo"]["decisions"], indent=2))
    print("External model requests: 0")


def main():
    p = argparse.ArgumentParser(description=__doc__)
    group = p.add_mutually_exclusive_group()
    group.add_argument("--self-test", action="store_true")
    group.add_argument("--demo-json", action="store_true", help="Print the synthetic tool output")
    group.add_argument("--metrics-csv", action="store_true", help="Print the frozen development results")
    p.add_argument("--port", type=int, default=8765, help="Local port (0 chooses an available port)")
    p.add_argument("--host", choices=["127.0.0.1"], default="127.0.0.1", help=argparse.SUPPRESS)
    p.add_argument("--strictPort", action="store_true", help=argparse.SUPPRESS)
    p.add_argument("--no-browser", action="store_true", help="Print the address without opening a browser")
    args = p.parse_args()
    if args.self_test:
        return self_test()
    if args.demo_json:
        sys.stdout.buffer.write(json_bytes(demo()))
        return
    if args.metrics_csv:
        rows = load_results()["paired_development"]
        writer = csv.DictWriter(sys.stdout, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
        return
    if not 0 <= args.port <= 65535:
        p.error("--port must be from 0 to 65535.")
    portal = Portal()
    try:
        server = PortalServer((args.host, args.port), portal)
    except OSError as exc:
        if args.strictPort or args.port != 8765:
            p.exit(1, f"Could not open the local port: {exc}. Try --port 0.\n")
        server = PortalServer(("127.0.0.1", 0), portal)
    with server:
        address = f"http://127.0.0.1:{server.server_port}/"
        print(f"PET TOOL: {address}\nOpen this address. Press Ctrl+C to stop.", flush=True)
        if not args.no_browser:
            Thread(target=webbrowser.open, args=(address,), daemon=True).start()
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            print("\nPET TOOL closed.")


if __name__ == "__main__":
    main()
