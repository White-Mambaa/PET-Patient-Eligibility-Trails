"""Deterministic rule parity, privacy boundary and HTTP contract tests."""
import base64
from contextlib import contextmanager
import copy
import gzip
import http.client
import itertools
import json
from threading import Thread
import unittest
from unittest.mock import patch

from PET_CORE.contracts import RequestError, read_case
from PET_CORE.http_app import Portal, PortalServer
from PET_CORE.reviewer import ReviewService, ReviewTickets, TICKET_TTL
from PET_CORE.screening import impact_flags, screen_case
from PET_CORE.study import REVIEW_EXAMPLE
from criteria import what_could_change


def good_review(ticket):
    return {
        "ticket": ticket, "confirmed": True, "reviewer": "EVAL-01",
        "disposition": "forward_for_trial_review",
        "assessments": [
            {"id": "performance", "truth": "yes", "rationale": "The documented performance status meets the training rule."},
            {"id": "metastases", "truth": "no", "rationale": "The training source documents absence of the condition."},
        ],
    }


class ScreeningTests(unittest.TestCase):
    def test_impact_matches_bundled_engine(self):
        for n in range(1, 7):
            for verdicts in itertools.product(("met", "not_met", "not_stated"), repeat=n):
                reference = what_could_change(list(verdicts))
                self.assertEqual(impact_flags(verdicts), [(r["changes"], r["sole_reason"]) for r in reference])

    def test_priority_exact_quote_and_defer(self):
        sample = copy.deepcopy(REVIEW_EXAMPLE)
        sample["criteria"].reverse()
        view = screen_case(read_case(sample))
        self.assertEqual(view["criteria"][0]["id"], "performance")
        self.assertEqual(view["criteria"][0]["flags"], ["NUMERIC_MISMATCH"])
        self.assertEqual(view["criteria"][0]["checks"]["citation"]["exact_matches"], [True])
        self.assertEqual(view["decisions"], {"keep": "NOT_ELIGIBLE", "flag_as_unknown": "REVIEW"})
        sample["criteria"][1]["evidence"] = ["Different wording"]
        row = screen_case(read_case(sample))["criteria"][0]
        self.assertEqual(row["flags"], ["QUOTE_NOT_FOUND"])
        self.assertEqual(row["checks"]["logic"]["status"], "NOT_RUN")


class ReviewerTests(unittest.TestCase):
    def setUp(self):
        self.now = 10_000
        self.service = ReviewService(ReviewTickets(clock=lambda: self.now))

    def test_no_note_or_rescreen_in_record(self):
        ticket = self.service.prepare(REVIEW_EXAMPLE)["ticket"]
        context = json.loads(base64.urlsafe_b64decode(ticket.split(".")[0]))["review"]
        self.assertNotIn("note", context)
        self.assertNotIn(REVIEW_EXAMPLE["note"], json.dumps(context))
        self.assertTrue(all("evidence" not in rule for rule in context["criteria"]))
        with patch("PET_CORE.reviewer.screen_case", side_effect=AssertionError("record rechecked the source note")):
            record = self.service.record(good_review(ticket))
        self.assertEqual(record["derived_rule_status"], "ELIGIBLE")
        self.assertFalse(record["source_note_included"])
        self.assertEqual(record["case_sha256"], context["case_sha256"])
        self.assertNotIn(REVIEW_EXAMPLE["note"], json.dumps(record))

    def test_tampered_expired_and_unconfirmed(self):
        ticket = self.service.training()["ticket"]
        request = good_review(ticket)
        for invalid in ({**request, "ticket": ("A" if ticket[0] != "A" else "B") + ticket[1:]},
                        {**request, "confirmed": False}, {**request, "case": REVIEW_EXAMPLE},
                        {**request, "assessments": request["assessments"][:1]},
                        {**request, "assessments": request["assessments"][:1] * 2}):
            with self.assertRaises(RequestError):
                self.service.record(invalid)
        self.now += TICKET_TTL
        with self.assertRaises(RequestError) as expired:
            self.service.record(request)
        self.assertEqual(expired.exception.status, 410)
        with self.assertRaises(RequestError) as restarted:
            ReviewService().record(request)
        self.assertEqual(restarted.exception.code, "recheck_case")

    def test_unknown_review_does_not_forward(self):
        request = good_review(self.service.training()["ticket"])
        request["assessments"][0]["truth"] = "unknown"
        with self.assertRaises(RequestError):
            self.service.record(request)
        request["disposition"] = "request_more_information"
        self.assertEqual(self.service.record(request)["derived_rule_status"], "REVIEW")


@contextmanager
def serve_for_test():
    with PortalServer(("127.0.0.1", 0), Portal()) as server:
        thread = Thread(target=server.serve_forever, kwargs={"poll_interval": .025}, daemon=True)
        thread.start()
        try:
            yield server.server_port
        finally:
            server.shutdown()
            thread.join()


def request(port, path, payload=None, headers=None, method=None):
    conn = http.client.HTTPConnection("127.0.0.1", port, timeout=3)
    headers = dict(headers or {})
    if payload is not None:
        headers.setdefault("Content-Type", "application/json")
    try:
        conn.request(method or ("GET" if payload is None else "POST"), path,
                     None if payload is None else json.dumps(payload), headers)
        resp = conn.getresponse()
        return resp.status, {k.lower(): v for k, v in resp.getheaders()}, resp.read()
    finally:
        conn.close()


class PortalTests(unittest.TestCase):
    def test_page_routes_and_caching(self):
        with serve_for_test() as port:
            for url, phrase in (("/", b"Trial screening, with the evidence in view"),
                                ("/workspace?start=new", b"Review desk"), ("/evaluation", b"Evaluation results"),
                                ("/guide", b"Using PET")):
                status, headers, body = request(port, url)
                self.assertEqual(status, 200)
                self.assertIn(phrase, body)
                self.assertIn("frame-ancestors 'none'", headers["content-security-policy"])
            status, headers, body = request(port, "/api/v1/evaluation", headers={"Accept-Encoding": "gzip"})
            self.assertEqual(status, 200)
            self.assertEqual(headers["content-encoding"], "gzip")
            plain = gzip.decompress(body)
            self.assertLess(len(body), len(plain))
            rows = json.loads(plain)["paired_development"][-2:]
            self.assertEqual([(r["correct_binary"], r["pairs"]) for r in rows], [(80, 152), (87, 152)])
            status, _, body = request(port, "/api/v1/evaluation", headers={
                "Accept-Encoding": "gzip", "If-None-Match": headers["etag"],
            })
            self.assertEqual((status, body), (304, b""))
            self.assertEqual(request(port, "/ENGINE/code/criteria.py")[0], 404)

    def test_review_http_boundary(self):
        with serve_for_test() as port:
            status, headers, body = request(port, "/api/v1/training")
            self.assertEqual(status, 200)
            self.assertEqual(headers["cache-control"], "no-store")
            sample = json.loads(body)
            self.assertEqual(sample["demo"]["external_calls"], 0)
            status, headers, body = request(port, "/api/v1/reviews", good_review(sample["ticket"]))
            self.assertEqual(status, 200)
            self.assertEqual(headers["cache-control"], "no-store")
            self.assertEqual(json.loads(body)["case_type"], "training")
            self.assertEqual(request(port, "/api/v1/cases", REVIEW_EXAMPLE,
                                     {"Origin": "https://example.invalid"})[0], 403)
            self.assertEqual(request(port, "/", headers={"Host": "example.invalid"})[0], 403)
            case = {**REVIEW_EXAMPLE, "case_id": "EVAL-SAMPLE"}
            status, _, body = request(port, "/api/v1/cases", case)
            self.assertEqual(status, 200)
            receipt = request(port, "/api/v1/reviews", good_review(json.loads(body)["ticket"]))[2]
            self.assertEqual(json.loads(receipt)["case_reference"], "EVAL-SAMPLE")


if __name__ == "__main__":
    unittest.main()
