# PET TOOL

**Patient Eligibility Trials Tool** · Website and review workspace for a supervised hospital evaluation.

## Open the workspace

Extract `PET_TOOL.zip`. It creates a folder named `PET_TOOL_PORTAL`. The website, review desk and evaluation dashboard need Python 3.10 or later, with no API key, model download or Python package install.

On Linux, with the ZIP in Downloads:

```bash
unzip -n "$HOME/Downloads/PET_TOOL.zip" -d "$HOME/Downloads" &&
python3 "$HOME/Downloads/PET_TOOL_PORTAL/START_PET.py"
```

Open the address printed in the terminal if the browser does not open. Leave the terminal running while using PET. Press Ctrl+C in the terminal to close the server.

## A two-minute walkthrough

1. On the **PET TOOL** homepage, choose **Open review workspace** to try the labelled training case. Select the first flagged inclusion criterion, then open the source note and check the highlighted excerpt.
2. Choose a judgement and write a rationale. **Save and continue** opens the next unreviewed criterion. The screening draft and checks are available underneath the reviewer controls. Try **Ask PET → What could change the outcome?** for a short explanation tied to the draft.
3. After assessing every criterion, choose **Record review**. Enter an evaluation reviewer code, choose a disposition and confirm. PET calculates the rule summary from your saved answers. Export the review record or print the reviewer summary before leaving.
4. Open **Evaluation**. Select each cohort to compare precision, recall, F1, accuracy, errors and review workload. **Evidence & audit** explains the source, coverage and limits of the saved results.

For a new evaluation case, use **Open a case for review** on the homepage or **New case** in the workspace. Enter a coded reference, source note and rules, or select **Import JSON**. See `examples/CASE_IMPORT.json` for the format. Each rule needs an ID, `inclusion` or `exclusion` kind, and its text. The optional screening answer describes whether the condition is present (`yes`), absent (`no`) or unknown. It is separate from the reviewer's judgement.

## Files

| File | Purpose |
| --- | --- |
| `START_PET.py` | Launch the review workspace |
| `ARCHITECTURE.md` | Website structure, API, optimizations, benchmarks and design references |
| `EVALUATION_GUIDE.md` | Suggested hospital evaluation tasks, limits and design sources |
| `RESULTS/PAIRED_DEVELOPMENT_RESULTS.csv` | Paired performance counts and scores |
| `RESULTS/Development_Metrics.pdf` | One-page development metrics |
| `RESULTS/Study_Report.pdf`, `RESULTS/Study_Slides.pptx` | Original study report and presentation |
| `RESULTS/Archive_Handoff.pdf`, `ARCHIVE_REVIEW.md` | What was recomputed and checked from the archive |
| `ENGINE/` | Verified study engine and optional local Qwen CLI |

The study files preserve the original titles and numbers for traceability. The review desk and dashboard use the PET TOOL name.

## Checks and scope

```bash
python3 START_PET.py --self-test
python3 TEST_PET.py -v
python3 START_PET.py --metrics-csv
```

The built-in six-check case uses simulated model responses. Imported cases check exact quotes and limited numeric consistency; a reviewer assesses the semantic checks. Ask PET answers questions about the open case with deterministic lookups. The optional model CLI is documented in `ENGINE/README.md`.

Use training cases or hospital-approved de-identified records. In-progress cases and assessments stay in browser memory. A source note is sent to PET when a case is opened or explicitly rechecked; recording a review uses a signed case context and the reviewer’s assessments. Export the record to retain it. Export omits source-note and evidence-quote fields, but includes the reviewer's rationale and the criterion text. A reviewer code is not an authenticated signature.
