# PET TOOL | Website and core architecture

## Design references

The homepage, diagrams, copy, colours and interface are original. The sites below informed the organisation of the experience.

| Observed pattern | How PET applies it |
| --- | --- |
| [Mayo Clinic](https://www.mayoclinic.org/) and [Cleveland Clinic](https://my.clevelandclinic.org/) foreground important destinations; [Cedars-Sinai](https://www.cedars-sinai.org/find-a-doctor.html) offers a focused way into a task. | The header offers one primary workspace action. The homepage offers distinct paths to training, case review and evaluation. |
| [One Medical](https://www.onemedical.com/) and [Parsley Health](https://www.parsleyhealth.com/) explain the service before asking the visitor to act. [Hims](https://www.hims.com/) and [Hers](https://marketing.forhers.com/about/how-it-works/) group journeys into clear steps. | PET opens with a plain explanation and a labelled synthetic workspace illustration. A three-step guide describes the work before reviewers open a case. |
| [Teladoc Health](https://www.teladochealth.com/) and [Oscar Health](https://www.hioscar.com/) distinguish information pages from member or clinician tools. [athenahealth](https://www.athenahealth.com/) groups tools around work. | PET separates the information homepage from the task-focused review, guide and metrics pages. In-workspace navigation preserves a reviewer’s current case. |
| [Zocdoc](https://www.zocdoc.com/) provides task-specific entry points; [Tia](https://asktia.com/join/join-tia/) sets expectations before visitors start a workflow. | PET's new-case link opens the entry form directly. Evaluation limits and what the record contains are described before a user starts. |

Public websites provide design references, not evidence of their internal architecture. PET's core is designed for an evaluation workstation: local, zero install dependencies, and a human review gate.

## Layers

| Layer | Responsibility |
| --- | --- |
| `WEB/` | Homepage; reviewer workspace, training and guide; archived results; in-memory reviewer state |
| `PET_CORE/contracts.py` | Bounds and validates case and criterion fields; immutable case and rule models |
| `PET_CORE/screening.py` | Exact quote checks, limited numeric checks and stable priority ordering |
| `PET_CORE/reviewer.py` | Issues and checks the signed case context; requires complete judgements and explicit reviewer confirmation |
| `PET_CORE/study.py` | Verified development counts and the synthetic six-check fixture |
| `PET_CORE/http_app.py` | Loopback HTTP routes, body limits, origin and host checks, and delivery of preloaded files |
| `ENGINE/` and `RESULTS/` | Preserved study engine and source evidence. Study results, reports, and the archived synthetic output are byte-for-byte unchanged. |

```mermaid
flowchart LR
    A["Browser"] -->|Open case| B["Validate and check"]
    B -->|Checks and signed context| A
    A -->|Context and reviewer answers| C["Confirm review"]
    C -->|Review record| A
    D["Saved study results"] -->|Read only| A
```

## What is optimized

- **Screen once.** Case preparation validates the input, deduplicates repeated quote and numeric checks, and returns the priority queue. Confirmation checks a signed context instead of running screening again or accepting the source note a second time.
- **Linear priority calculation.** Count failing rules once and assign each criterion to one of four stable priority groups. Tests compare the resulting impact flags with the old engine on all 1,092 verdict sequences of length one through six.
- **One training request.** The training fixture and its six-check result are prepared at startup. Opening it uses a single request that returns the fixture and a fresh review context. Direct links to the guide and evaluation do not load a case.
- **Preload and compress.** Static content and aggregate results are read at startup. Text has a prebuilt gzip representation; a matching ETag can return 304 on a repeat request. Case and reviewer responses use `no-store`.

Measured in this build: on one synthetic 40-criterion verdict sequence, the median rule-impact computation fell from about **89 µs to 1.6 µs**. This isolates the calculation, so it is not a measure of page load or hospital workflow time. The aggregate evaluation response is **4,374 bytes raw and 1,557 bytes gzipped**. In a synthetic case with a long note, the confirmation context decreased from **37,171 to 726 bytes**, excluding the reviewer’s assessment fields. The byte reduction depends on the case.

## API and review context

| Route | Purpose |
| --- | --- |
| `GET /api/v1/training` | Labelled synthetic input, cached demonstration and a new context |
| `POST /api/v1/cases` | Validate a supplied case, check evidence, return a priority queue and context |
| `POST /api/v1/reviews` | Validate the context, reviewer confirmation and rationale for every criterion; return an exportable record |
| `GET /api/v1/evaluation` | Serve the frozen aggregate study comparison and audit coverage |

The context contains criterion details, the screening flags, a case fingerprint and a four-hour expiry. It omits source-note and quote fields. It is signed with an in-memory key using [Python HMAC](https://docs.python.org/3/library/hmac.html) and is readable by the holder. It does not authenticate a person or encrypt the contents. A restart or expiry requires a recheck; the reviewer can refresh the context without losing assessments held in the open page.

The evaluation workstation has no persistent patient store, shared accounts, EHR integration or clinical eligibility authority. Use training or approved de-identified cases and keep real eligibility decisions with the trial team.
