"""PET portal application. The bundled, versioned study engine stays in ENGINE."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent.parent
ENGINE = ROOT / "ENGINE"
RESULTS = ROOT / "RESULTS"
WEB = ROOT / "WEB"
sys.path[:0] = [str(ENGINE / "code"), str(ENGINE)]
