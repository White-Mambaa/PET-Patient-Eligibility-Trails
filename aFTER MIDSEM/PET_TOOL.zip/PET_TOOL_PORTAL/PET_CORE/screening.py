"""Pure screening checks: a quote, a narrow numeric comparison, and rule impact."""
import re

from criteria import decide, map_truth
from mtp_completion.numeric import MEASURES, numeric_expected

OFFLINE_SCOPE = "Exact quotes and simple numeric comparisons only. Semantic checks require further review."
MEASURE = "(?:" + "|".join(MEASURES.values()) + ")"
NUMBER = r"\d+(?:\.\d+)?"
UNIT = r"(?:%|percent|mg/dl|g/dl|mmol/l|[uµ]mol/l|10\^?9/l|years?|cc|ml)"
BOUND = re.compile(rf"{MEASURE}\s*(?:score\s+)?(?:>=|<=|>|<|≥|≤|=)?\s*{NUMBER}\s*{UNIT}?\.?", re.IGNORECASE)
ADJACENT_SCALE = re.compile(r"(?i)(?:ECOG|Zubrod)\s+([0-4])\s+or\s+([1-5])\.?")
EXACT_MEASURE = re.compile(rf"{MEASURE}\s*(?:(?:score|was|is)\s+)?[:=]?\s*{NUMBER}\s*{UNIT}?\.?", re.IGNORECASE)
SEMANTIC_CHECKS = ("entailment", "context", "contradiction", "missed_evidence")
FLAGS = ("QUOTE_NOT_FOUND", "NO_QUOTE_CITED", "NUMERIC_MISMATCH")


def impact_flags(verdicts):
    """Would changing this one rule alter the outcome? Count failing rules once."""
    failures = verdicts.count("not_met")
    return [(failures == 1, failures == 1) if v == "not_met" else (failures == 0, False)
            for v in verdicts]


def numeric_check(rule, matches, cached):
    default = {"status": "NOT_RUN", "detail": "Needs an exact standalone measurement and a simple rule."}
    if rule.truth == "unknown" or len(matches) != 1 or not matches[0]:
        return default
    condition, quote = rule.text.strip(), rule.evidence[0].strip()
    pair = ADJACENT_SCALE.fullmatch(condition)
    if not (BOUND.fullmatch(condition) or pair and int(pair[2]) == int(pair[1]) + 1):
        return default
    if not EXACT_MEASURE.fullmatch(quote):
        return default
    key = (condition, quote)
    if key not in cached:
        cached[key] = numeric_expected(condition, quote)
    numeric = cached[key]
    expected = numeric["expected_truth"]
    return {"status": "NOT_RUN" if expected is None else "NUMERIC_MATCH" if expected == rule.truth
            else "NUMERIC_MISMATCH", "detail": numeric["detail"]}


def screen_case(case):
    verdicts = [map_truth(rule.truth, rule.kind) for rule in case.criteria]
    impact = impact_flags(verdicts)
    buckets = [[], [], [], []]
    defer, matches, numeric = [], {}, {}
    for rule, verdict, (changes, sole) in zip(case.criteria, verdicts, impact):
        exact = []
        for quote in rule.evidence:
            if quote not in matches:
                matches[quote] = quote in case.note
            exact.append(matches[quote])
        citation = ("QUOTE_NOT_FOUND" if exact and not all(exact) else "QUOTE_PRESENT" if exact
                    else "NO_QUOTE_CITED" if rule.truth != "unknown" else "NOT_APPLICABLE")
        logic = numeric_check(rule, exact, numeric)
        flags = [flag for flag in (citation, logic["status"]) if flag in FLAGS]
        deferred = "not_stated" if flags else verdict
        defer.append(deferred)
        row = {
            "id": rule.id, "kind": rule.kind, "truth": rule.truth, "verdict": verdict, "flags": flags,
            "checks": {"citation": {"status": citation, "exact_matches": exact}, "logic": logic,
                       **{k: {"status": "NOT_RUN"} for k in SEMANTIC_CHECKS}},
            "could_change_decision": changes, "sole_rejection_reason": sole, "deferred_verdict": deferred,
        }
        # Stable ordering by (has flag, can change the decision) without rechecking the case.
        buckets[(0 if flags else 2) + (0 if changes else 1)].append(row)
    return {
        "case_id": case.case_id, "scope": OFFLINE_SCOPE, "external_calls": 0,
        "decisions": {"keep": decide(verdicts), "flag_as_unknown": decide(defer)},
        "criteria": [row for bucket in buckets for row in bucket],
    }
