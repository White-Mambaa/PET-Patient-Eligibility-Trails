"""Validation shared by the screening and reviewer-record services."""
from dataclasses import dataclass
import json

TRUTHS = ("yes", "no", "unknown")


class RequestError(ValueError):
    def __init__(self, message, status=400, code="invalid_request"):
        super().__init__(message)
        self.status = status
        self.code = code


def json_bytes(value, *, compact=False):
    if compact:
        return json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(",", ":")).encode("utf-8")
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf-8")


def bounded_text(value, field, max_len):
    if not isinstance(value, str) or not value.strip() or len(value) > max_len:
        raise RequestError(f"{field} must be nonempty text of at most {max_len} characters.")
    return value


@dataclass(frozen=True, slots=True)
class Rule:
    id: str
    kind: str
    text: str
    truth: str
    evidence: tuple[str, ...]

    def as_dict(self):
        return {"id": self.id, "kind": self.kind, "text": self.text, "truth": self.truth,
                "evidence": list(self.evidence)}


@dataclass(frozen=True, slots=True)
class Case:
    case_id: str
    trial: str
    note: str
    criteria: tuple[Rule, ...]

    def as_dict(self):
        return {"case_id": self.case_id, "trial": self.trial, "note": self.note,
                "criteria": [r.as_dict() for r in self.criteria]}


def read_case(payload):
    if not isinstance(payload, dict):
        raise RequestError("Enter a case as a JSON object.")
    case_id = bounded_text(payload.get("case_id"), "Case reference", 80).strip()
    trial = bounded_text(payload.get("trial", "Protocol not specified"), "Protocol", 160).strip()
    note = bounded_text(payload.get("note"), "Source note", 40_000)
    raw = payload.get("criteria")
    if not isinstance(raw, list) or not 1 <= len(raw) <= 40:
        raise RequestError("Provide 1 to 40 criteria.")
    rules, seen = [], set()
    for i, rule in enumerate(raw, 1):
        if not isinstance(rule, dict):
            raise RequestError(f"Criterion {i} must be a JSON object.")
        key = bounded_text(rule.get("id"), f"Criterion {i} ID", 80)
        if key in seen:
            raise RequestError("Criterion IDs must be unique.")
        seen.add(key)
        text = bounded_text(rule.get("text"), f"Criterion {i} text", 3000)
        kind, truth = rule.get("kind"), rule.get("truth", "unknown")
        if kind not in ("inclusion", "exclusion") or truth not in TRUTHS:
            raise RequestError(f"Criterion {i} needs kind inclusion/exclusion and truth yes/no/unknown.")
        quotes = rule.get("evidence", [])
        if not isinstance(quotes, list) or len(quotes) > 8:
            raise RequestError(f"Criterion {i} can have up to eight quotes.")
        for quote in quotes:
            bounded_text(quote, f"Criterion {i} quote", 3000)
        rules.append(Rule(key, kind, text, truth, tuple(quotes)))
    return Case(case_id, trial, note, tuple(rules))
