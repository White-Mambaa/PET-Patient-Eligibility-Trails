"""Small HTTP adapter for the portal. Keep file access and clinical inputs separate."""
from dataclasses import dataclass
import gzip
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from urllib.parse import urlsplit

from . import RESULTS, WEB
from .contracts import RequestError, json_bytes
from .reviewer import ReviewService
from .study import load_results

CASE_BODY = 384 * 1024
REVIEW_BODY = 1200 * 1024
CSP = ("default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; "
       "img-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'")
DOWNLOADS = {
    "Archive_Handoff.pdf": "application/pdf",
    "Development_Metrics.pdf": "application/pdf",
    "Study_Report.pdf": "application/pdf",
    "PAIRED_DEVELOPMENT_RESULTS.csv": "text/csv; charset=utf-8",
    "RESULTS_SNAPSHOT.json": "application/json",
    "ARCHIVE_AUDIT_NO_NOTES.json": "application/json",
    "SYNTHETIC_DEMO_OUTPUT.json": "application/json",
    "Study_Slides.pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
}


@dataclass(frozen=True, slots=True)
class Representation:
    body: bytes
    etag: str

    @classmethod
    def of(cls, body):
        return cls(body, '"' + hashlib.sha256(body).hexdigest() + '"')


@dataclass(frozen=True, slots=True)
class Resource:
    plain: Representation
    compressed: Representation | None
    mime: str
    filename: str | None = None

    @classmethod
    def of(cls, body, mime, filename=None):
        zipped = gzip.compress(body, compresslevel=6, mtime=0) if (
            len(body) > 256 and mime.startswith(("text/", "application/json", "image/svg+xml"))) else None
        return cls(Representation.of(body), Representation.of(zipped) if zipped and len(zipped) < len(body) else None,
                   mime, filename)


def wants_gzip(header):
    for value in header.split(","):
        encoding, *options = value.lower().strip().split(";")
        if encoding.strip() == "gzip":
            quality = [option.partition("=")[2] for option in options if option.strip().startswith("q=")]
            try:
                return not quality or 0 < float(quality[0]) <= 1
            except ValueError:
                return False
    return False


class Portal:
    def __init__(self):
        self.reviews = ReviewService()
        assets = {"/": ("index.html", "text/html; charset=utf-8")}
        assets.update({route: ("workspace.html", "text/html; charset=utf-8") for route in
                       ("/workspace", "/evaluation", "/guide")})
        assets.update({"/assets/" + f: (f, mime) for f, mime in (
            ("home.css", "text/css; charset=utf-8"), ("style.css", "text/css; charset=utf-8"),
            ("app.mjs", "text/javascript; charset=utf-8"), ("workflow.mjs", "text/javascript; charset=utf-8"),
            ("evaluation.mjs", "text/javascript; charset=utf-8"), ("pet.svg", "image/svg+xml"),
        )})
        resources, loaded = {}, {}
        for path, (name, mime) in assets.items():
            if name not in loaded:
                loaded[name] = Resource.of((WEB / name).read_bytes(), mime)
            resources[path] = loaded[name]
        resources.update({"/results/" + f: Resource.of((RESULTS / f).read_bytes(), mime, f) for f, mime in DOWNLOADS.items()})
        resources["/api/v1/evaluation"] = Resource.of(json_bytes(load_results(), compact=True), "application/json; charset=utf-8")
        self.resources = resources


class PortalServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address, portal):
        self.portal = portal
        super().__init__(address, Handler)


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_args):
        pass

    def setup(self):
        self.request.settimeout(10)
        super().setup()

    def host_ok(self):
        return self.headers.get("Host") in (f"127.0.0.1:{self.server.server_port}",
                                            f"localhost:{self.server.server_port}")

    def write(self, body, mime, status=200, *, cache="no-store", extra=()):
        self.send_response(status)
        self.send_header("Content-Type", mime)
        self.send_header("Cache-Control", cache)
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy", CSP)
        if status != 304:
            self.send_header("Content-Length", str(len(body)))
        for k, v in extra:
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD" and status != 304:
            self.wfile.write(body)

    def reply(self, payload, status=200):
        return self.write(json_bytes(payload, compact=True), "application/json; charset=utf-8", status)

    def fail(self, message, status, code):
        return self.reply({"error": message, "code": code}, status)

    def static(self, item):
        compressed = item.compressed and wants_gzip(self.headers.get("Accept-Encoding", ""))
        representation = item.compressed if compressed else item.plain
        tags = [x.strip().removeprefix("W/") for x in self.headers.get("If-None-Match", "").split(",")]
        same = "*" in tags or representation.etag in tags
        extra = [("ETag", representation.etag)]
        if item.compressed:
            extra.append(("Vary", "Accept-Encoding"))
        if compressed:
            extra.append(("Content-Encoding", "gzip"))
        if item.filename and not same:
            extra.append(("Content-Disposition", f'attachment; filename="{item.filename}"'))
        return self.write(b"" if same else representation.body, item.mime, 304 if same else 200,
                          cache="private, max-age=0, must-revalidate", extra=extra)

    def do_GET(self):
        if not self.host_ok():
            return self.fail("Open the address printed by PET TOOL.", 403, "invalid_host")
        try:
            route = urlsplit(self.path).path
        except ValueError:
            return self.fail("Invalid route.", 400, "invalid_route")
        if route in self.server.portal.resources:
            return self.static(self.server.portal.resources[route])
        if route == "/api/v1/training":
            return self.reply(self.server.portal.reviews.training())
        return self.fail("Page or endpoint not found.", 404, "not_found")

    do_HEAD = do_GET

    def do_POST(self):
        origin = self.headers.get("Origin")
        if (not self.host_ok() or (origin and origin != "http://" + self.headers["Host"])
                or self.headers.get("Sec-Fetch-Site") == "cross-site"):
            return self.fail("Only requests from the workspace are accepted.", 403, "invalid_origin")
        try:
            route = urlsplit(self.path).path
        except ValueError:
            return self.fail("Invalid route.", 400, "invalid_route")
        if route not in ("/api/v1/cases", "/api/v1/reviews"):
            return self.fail("Endpoint not found.", 404, "not_found")
        if self.headers.get_content_type() != "application/json" or self.headers.get("Transfer-Encoding"):
            return self.fail("Send a JSON request.", 415, "unsupported_media")
        lengths = self.headers.get_all("Content-Length") or []
        try:
            size = int(lengths[0]) if len(lengths) == 1 else 0
        except ValueError:
            size = 0
        if not 0 < size <= (CASE_BODY if route == "/api/v1/cases" else REVIEW_BODY):
            return self.fail("Empty request or request too large.", 413, "body_size")
        try:
            body = self.rfile.read(size)
            if len(body) != size:
                return self.fail("The request was incomplete.", 400, "invalid_body")
            value = json.loads(body.decode("utf-8"))
            reviews = self.server.portal.reviews
            response = reviews.prepare(value) if route == "/api/v1/cases" else reviews.record(value)
            encoded = json_bytes(response, compact=True)
        except RequestError as exc:
            return self.fail(str(exc), exc.status, exc.code)
        except TimeoutError:
            return self.fail("The request timed out.", 408, "request_timeout")
        except (ValueError, UnicodeError, RecursionError):
            return self.fail("Check the input format and text.", 400, "invalid_body")
        return self.write(encoded, "application/json; charset=utf-8")
