"""Frozen study evidence and the labelled training fixture."""
import json

from mtp_week_delivery import self_test as run_engine_demo
from . import RESULTS

COUNT_FIELDS = (
    "pairs", "reference_eligible", "reference_ineligible", "eligible_found",
    "hard_wrong_exclusions", "wrong_inclusions", "review",
)

def division(a, b):
    return a / b if b else None


def score(row):
    n, pos, neg, tp, hard, fp, review = (row[k] for k in COUNT_FIELDS)
    if (any(type(row[k]) is not int or row[k] < 0 for k in COUNT_FIELDS)
            or pos + neg != n or tp + hard > pos or fp > neg
            or not pos - tp - hard <= review <= n - tp - fp - hard):
        raise ValueError("The frozen result counts are inconsistent.")
    tn, fn = neg - fp, pos - tp
    return {
        **row, "correct_binary": tp + tn,
        "binary_accuracy": division(tp + tn, n),
        "eligible_precision": division(tp, tp + fp),
        "eligible_recall": division(tp, pos),
        "eligible_f1": division(2 * tp, 2 * tp + fp + fn),
    }


def load_results():
    data = json.loads((RESULTS / "RESULTS_SNAPSHOT.json").read_text(encoding="utf-8"))
    audit = json.loads((RESULTS / "ARCHIVE_AUDIT_NO_NOTES.json").read_text(encoding="utf-8"))
    closeout = audit["november_closeout"]
    rows = data["paired_development"]
    cohorts = {"NSCLC-100": 50, "SIGIR-204": 102}
    modes = ("Allow unknown", "Forced guess")
    expected = {(d, m): n for d, n in cohorts.items() for m in modes}
    if len(rows) != len(expected) or {(r["dataset"], r["mode"]): r["pairs"] for r in rows} != expected:
        raise ValueError("The frozen paired result table is incomplete.")
    pooled = [
        {"dataset": "Pooled", "mode": mode, **{
            k: sum(r[k] for r in rows if r["mode"] == mode) for k in COUNT_FIELDS
        }}
        for mode in modes
    ]
    return {
        "scope": data["scope"], "model": data["model"],
        "checker": {**data["checker"], **closeout["checker"]},
        "legacy_development": data["legacy_development"], "reask": data["reask"],
        "archive_review": audit["october_raw_recomputed"],
        "held_out": data["held_out"], "paired_development": [score(r) for r in rows + pooled],
    }


def demo():
    result = run_engine_demo()
    result["scope"] = "Synthetic example with deterministic model responses; software test only."
    result["simulated_responses"] = result.pop("generation_attempts")
    return result


REVIEW_EXAMPLE = {
    "case_id": "PET-001",
    "trial": "Thoracic oncology training protocol",
    "note": "ECOG 1. No evidence of brain metastases.",
    "criteria": [
        {"id": "performance", "kind": "inclusion", "text": "ECOG 0 or 1",
         "truth": "no", "evidence": ["ECOG 1"]},
        {"id": "metastases", "kind": "exclusion", "text": "Documented brain metastases",
         "truth": "no", "evidence": ["No evidence of brain metastases"]},
    ],
}
