"""Issue a signed review context and record the human review from that context."""
import base64
from datetime import datetime, timezone
import hashlib
import hmac
import json
import secrets
import time
from uuid import uuid4

from criteria import decide, map_truth

from .contracts import RequestError, TRUTHS, bounded_text, json_bytes, read_case
from .screening import screen_case
from .study import REVIEW_EXAMPLE, demo

DISPOSITIONS = {
    "ELIGIBLE": "forward_for_trial_review",
    "NOT_ELIGIBLE": "criteria_not_met",
    "REVIEW": "request_more_information",
}
REVIEW_FIELDS = frozenset(("ticket", "reviewer", "confirmed", "disposition", "assessments"))
TICKET_TTL = 4 * 60 * 60
TICKET_LIMIT = 768 * 1024


class ReviewTickets:
    """Local integrity check for context. A ticket is readable, not an identity."""

    def __init__(self, *, clock=time.time):
        self._key = secrets.token_bytes(32)
        self._clock = clock

    def _sign(self, body):
        return hmac.digest(self._key, b"PET-review-v1\x00" + body, "sha256")

    def issue(self, context):
        payload = json_bytes({"v": 1, "expires": int(self._clock()) + TICKET_TTL, "review": context}, compact=True)
        body = base64.urlsafe_b64encode(payload)
        return body.decode("ascii") + "." + self._sign(body).hex()

    def verify(self, ticket):
        invalid = RequestError("This review context is no longer valid. Recheck the case to continue.", 409, "recheck_case")
        if not isinstance(ticket, str) or not 1 <= len(ticket) <= TICKET_LIMIT:
            raise invalid
        try:
            body, mac = ticket.split(".", 1)
            body = body.encode("ascii")
            mac = bytes.fromhex(mac)
        except (ValueError, UnicodeError) as exc:
            raise invalid from exc
        if len(mac) != 32 or not hmac.compare_digest(self._sign(body), mac):
            raise invalid
        value = json.loads(base64.urlsafe_b64decode(body))
        if value["v"] != 1:
            raise invalid
        if value["expires"] <= self._clock():
            raise RequestError("The review context expired. Recheck the case to continue.", 410, "recheck_case")
        return value["review"]


def review_context(case, screened, source):
    flags = {r["id"]: r["flags"] for r in screened["criteria"]}
    return {
        "case_reference": case.case_id, "trial": case.trial, "case_type": source,
        "case_sha256": hashlib.sha256(json_bytes(case.as_dict())).hexdigest(),
        "criteria": [{"id": r.id, "kind": r.kind, "criterion": r.text, "supplied_answer": r.truth,
                      "mechanical_flags": flags[r.id]} for r in case.criteria],
    }


class ReviewService:
    def __init__(self, tickets=None):
        self.tickets = tickets if tickets is not None else ReviewTickets()
        training = read_case(REVIEW_EXAMPLE)
        self.training_context = review_context(training, screen_case(training), "training")
        self.training_demo = demo()

    def training(self):
        return {"input": REVIEW_EXAMPLE, "demo": self.training_demo,
                "ticket": self.tickets.issue(self.training_context)}

    def prepare(self, payload):
        case = read_case(payload)
        screened = screen_case(case)
        return {"screening": screened, "ticket": self.tickets.issue(review_context(case, screened, "supplied"))}

    def record(self, payload):
        if not isinstance(payload, dict) or set(payload) - REVIEW_FIELDS:
            raise RequestError("Send the review context and reviewer choices.")
        if payload.get("confirmed") is not True:
            raise RequestError("Confirm the review before recording it.")
        context = self.tickets.verify(payload.get("ticket"))
        reviewer = bounded_text(payload.get("reviewer"), "Reviewer ID", 80).strip()
        raw = payload.get("assessments")
        rules = context["criteria"]
        if not isinstance(raw, list) or len(raw) != len(rules):
            raise RequestError("Record an assessment for each criterion.")
        assessments = {}
        for a in raw:
            if not isinstance(a, dict) or set(a) != {"id", "truth", "rationale"} or not isinstance(a["id"], str) or a["id"] in assessments:
                raise RequestError("Each assessment must reference one distinct criterion.")
            if a["truth"] not in TRUTHS:
                raise RequestError("Choose a judgement for each criterion.")
            assessments[a["id"]] = (a["truth"], bounded_text(a["rationale"], "Assessment rationale", 2000).strip())
        if set(assessments) != {rule["id"] for rule in rules}:
            raise RequestError("The assessments do not match the case criteria.")
        criteria, verdicts = [], []
        for rule in rules:
            truth, rationale = assessments[rule["id"]]
            verdicts.append(map_truth(truth, rule["kind"]))
            criteria.append({**rule, "reviewer_judgement": truth, "rationale": rationale})
        derived = decide(verdicts)
        disposition = payload.get("disposition")
        if disposition not in ("request_more_information", DISPOSITIONS[derived]):
            raise RequestError("Choose a disposition supported by the reviewed criteria.")
        return {
            "format": "pet-review-1", "review_id": str(uuid4()),
            "scope": "screening workflow evaluation; trial team retains eligibility authority",
            **{k: context[k] for k in ("case_type", "case_reference", "trial", "case_sha256")},
            "reviewer_id": reviewer, "recorded_at": datetime.now(timezone.utc).isoformat(),
            "derived_rule_status": derived, "reviewer_disposition": disposition,
            "source_note_included": False, "evidence_quotes_included": False, "assessments": criteria,
        }
