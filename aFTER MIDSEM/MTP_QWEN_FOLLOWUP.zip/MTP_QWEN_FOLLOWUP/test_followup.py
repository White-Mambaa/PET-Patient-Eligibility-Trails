import importlib.util,json,sys,os,tempfile,csv,shutil,subprocess,unittest
from pathlib import Path
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('follow',HERE/'mtp_qwen_followup.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
SOURCE=Path(os.environ.get('MTP_TEST_PROJECT_ROOT',Path.cwd()))
def fixture(root):
 p=root/m.STM;p.parent.mkdir(parents=True);rows=[{'trial_id':'T01','crit_idx':str(i),'kind':'inclusion','criterion':'Adult','guidance':'','statement':'Patient is an adult.','key_terms':'["adult"]'} for i in range(95)]
 with p.open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 d=root/'datasets/nsclc100';d.mkdir(parents=True);(d/'splits.csv').write_text('trial_id,split\nT01,dev\nT04,test\n')
 with (d/'nsclc100.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=['pair_idx','trial_id','patient_orig','target']);w.writeheader();w.writerows([dict(pair_idx=i,trial_id='T01',patient_orig='An adult.',target='HIDDEN_REFERENCE') for i in range(20)])
 pred=[dict(pair_idx=i,crit_idx=0,criterion='Adult',truth='yes',evidence=['adult'],basis='stated',rationale='Adult stated.',verdict='met') for i in range(20)]
 (root/'outputs/plain_ai_qwen_dev.jsonl').write_text('\n'.join(map(json.dumps,pred)))
 (root/m.CHECKS).write_text('\n'.join(json.dumps(dict(pair_idx=i,crit_idx=0,label='VERIFIED' if i%2 else 'UNSUPPORTED',reason='Experimental flag.')) for i in range(20)))
 m.save(root/'outputs/mtp_parallel/state/qwen/STATUS.json',{'status':'COMPLETE'})
class Tests(unittest.TestCase):
 def test_quotes_and_terms(self):
  self.assertFalse(m.valid('case',{'summary':'x','what_to_check':'x','limitations':[],'quoted_evidence':['invented']},{'patient_note':'An adult.'}))
  self.assertFalse(m.valid('rule',{'preserves_meaning':'yes','suggested_statement':'x','suggested_key_terms':['1','2','3','4'],'concerns':[]},{}))
 def test_plan_is_private_and_pinned(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);fixture(root);out=root/'private';out.mkdir();plan=m.prepare(root,out)
   self.assertEqual(len(plan['jobs']),115);self.assertNotIn('HIDDEN_REFERENCE',json.dumps(plan))
   self.assertEqual(plan,m.prepare(root,out));self.assertEqual(len({j['id'] for j in plan['jobs']}),115)
 @unittest.skipUnless((SOURCE/'code/llm_client.py').exists(),'Run from Akash_Kit for local-client integration test')
 def test_mock_local_calls_and_budget(self):
  for limit,expected,status in ((200,115,'DRAFT_PACK_WRITTEN'),(2,2,'PAUSED')):
   with self.subTest(limit=limit),tempfile.TemporaryDirectory() as d:
    root=Path(d);fixture(root);(root/'code').mkdir();shutil.copy2(SOURCE/'code/llm_client.py',root/'code/llm_client.py')
    h=root/'harness.py';h.write_text('''import importlib.util,sys,io,json,urllib.request
spec=importlib.util.spec_from_file_location('p',sys.argv[1]);p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
def fake(req,*args,**kwargs):
 url=getattr(req,'full_url',str(req))
 if url.endswith('/api/tags'):return io.BytesIO(b'{"models":[{"name":"qwen2.5:7b"}]}')
 assert url=='http://localhost:11434/api/chat'
 system=json.loads(req.data)['messages'][0]['content']
 data={'preserves_meaning':'uncertain','suggested_statement':'The patient is an adult.','suggested_key_terms':['adult'],'concerns':[]} if 'eligibility-rule wording' in system else {'summary':'A model answer was checked.','what_to_check':'Review criterion against note.','quoted_evidence':['adult'],'limitations':['Not independently reviewed.']}
 return io.BytesIO(json.dumps({'message':{'content':json.dumps(data)},'done_reason':'stop','prompt_eval_count':20}).encode())
urllib.request.urlopen=fake
sys.argv=['mtp_qwen_followup.py','--root',sys.argv[2],'--max-local-calls',sys.argv[3]]
p.main()
''')
    result=subprocess.run([sys.executable,str(h),str(HERE/'mtp_qwen_followup.py'),str(root),str(limit)],capture_output=True,text=True)
    self.assertEqual(result.returncode,0,result.stderr)
    out=root/'outputs/mtp_parallel/private_qwen_followup';self.assertEqual(m.read(out/'LOCAL_BUDGET.json')['attempts'],expected)
    self.assertEqual(m.read(out/'STATUS.json')['status'],status)
    self.assertFalse((root/'labelling').exists())
if __name__=='__main__':unittest.main()
