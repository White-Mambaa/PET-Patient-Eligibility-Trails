# Additional queued local Qwen work

Two deliverables from the original MTP guide still need preparation: review of 95 NSCLC development rule statements/key terms, and 20 worked examples for the write-up/demo. This local job drafts those materials without altering active experiments.

## Start in a spare terminal

Download and unzip this package in Downloads. Keep existing NSCLC, local Qwen and report jobs running.

```bash
unzip -o "$HOME/Downloads/MTP_QWEN_FOLLOWUP.zip" -d "$HOME/Downloads"
cd "$HOME/MTP/Akash_Kit"
.venv/bin/python "$HOME/Downloads/MTP_QWEN_FOLLOWUP/test_followup.py"
systemd-inhibit --what=sleep:idle --mode=block \
  --why="MTP queued local review pack" \
  .venv/bin/python -u "$HOME/Downloads/MTP_QWEN_FOLLOWUP/mtp_qwen_followup.py" \
  --root "$PWD" --hours 36 --max-local-calls 200
```

It immediately snapshots 95 statements and selects 20 development examples from the saved NSCLC checks. It waits for `outputs/mtp_parallel/state/qwen/STATUS.json` to become COMPLETE, then acquires the same local-Qwen job lock before requesting any generations. This keeps the two local jobs sequential. Do not cancel the existing Qwen job to start this one. Additional terminals do not add physical GPU/CPU capacity.

When ready, it uses qwen2.5:7b via local Ollama. It sends zero external API requests, does not read the Groq key file and does not download another model. The shared lock avoids competing with the existing mode-comparison runner; unrelated direct Ollama commands outside that runner are not covered by this lock.

## Outputs

Private folder: `outputs/mtp_parallel/private_qwen_followup` (permissions restricted to your user).

- `PRIVATE_PLAN.json`: pinned source examples and model settings. Contains notes; keep private.
- `PRIVATE_RESULTS.json`: checkpointed AI suggestions and validity flags.
- `LOCAL_BUDGET.json`: cumulative local generation count, capped at 200 across restarts.
- `STATUS.json`: waiting/running/paused/draft-pack status.
- Timestamped export folders: `PRIVATE_RULE_REVIEW_AI.csv`, `PRIVATE_20_WORKED_EXAMPLES_AI.md`, and `SUMMARY_NO_NOTES.json`.

The rule audit proposes wording/key terms and flags concerns. It does not replace the original criterion or guidance. The casebook covers checker-assigned flagged and VERIFIED examples; selection is not an independent accuracy sample. Each explanation distinguishes model output, checker verdict and human review needs. Proposed casebook quotations are accepted only if literal note substrings. This checks quotation validity, not medical sufficiency or clinical correctness.

The script never writes to the original annotation sheets, statements, baseline predictions, main caches or checker outputs. Human judgments stay blank in the drafts. AI suggestions and checker flags are not reference labels. Review the exported documents before using them in the thesis. These drafts do not complete the annotation, repair, trap or held-out experiments.

## Limits and recovery

The 36-hour wall-clock allowance includes waiting for the current Qwen batch. If that batch stops, this job stays waiting until it completes or the allowance ends. It does not fix or restart the baseline worker. The initial snapshot is preserved on resuming, so the examples remain stable even while the checker adds more records.

A failed local request pauses with saved drafts intact. A structurally invalid response is recorded as requiring review, without pretending it is a valid annotation. An additional local call can be used for JSON-format retry; the hard 200-call cap includes retries. The job creates partial review exports on pause. No diagnostic state is changed into an unknown patient truth.

Three tests pass, including a mocked run of the actual local client completing 115 drafts and a hard-budget test pausing after two calls. No live model was invoked during these tests. Actual local speed and explanation quality remain to be assessed on your machine.

## SIGIR 429 status

The current recovery command already queues SIGIR after complete NSCLC coverage. Do not launch a second SIGIR API job alongside it. The existing 34 statements are retained. This follow-up job uses no Groq quota and does not interact with that API queue.
