import importlib.util, json, os
from pathlib import Path
import subprocess, sys, tempfile, unittest
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('parallel',HERE/'mtp_parallel.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
SOURCE=Path(os.environ.get('MTP_TEST_PROJECT_ROOT',Path.cwd()))
class Tests(unittest.TestCase):
 def test_completion_requires_coverage(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'x.jsonl';m.save(str(p)+'.manifest.json',dict(status='COMPLETE',written=2,expected=2));self.assertFalse(m.complete(p))
   p.write_text('{"pair_idx":1,"crit_idx":0}\n'*2);self.assertFalse(m.complete(p))
   p.write_text('{"pair_idx":1,"crit_idx":0}\n{"pair_idx":2,"crit_idx":0}\n');self.assertTrue(m.complete(p))
   Path(str(p)+'.INCOMPLETE').touch();self.assertFalse(m.complete(p))
 def test_schema_checks(self):
  self.assertFalse(m.schema_ok({'statement':'A','key_terms':'A'},'RULE_STATEMENT_v1'))
  self.assertFalse(m.schema_ok({'statement':'A','key_terms':['a','b','c','d']},'RULE_STATEMENT_v1'))
  self.assertTrue(m.schema_ok({'statement':'A','key_terms':['a']},'RULE_STATEMENT_v1'))
  self.assertFalse(m.schema_ok({'label':'yes'},'SUPPORT_v1'))
 def test_plans_are_development_only(self):
  for job in ('sigir','qwen'):
   for stage in m.plan(Path('/example'),job,20):
    a=stage['args'];self.assertEqual(a[a.index('--split')+1],'dev')
  self.assertEqual(len(m.plan(Path('/example'),'qwen',20)),4)
 def test_workspace_refuses_source_change(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);(root/'code').mkdir();(root/'mtp_completion').mkdir();(root/'datasets').mkdir();(root/'labelling').mkdir()
   (root/'completion.py').write_text('old')
   a=m.workspace(root,'sigir');b=m.workspace(root,'qwen');self.assertNotEqual(a,b);self.assertEqual((a/'datasets').resolve(),root/'datasets')
   (root/'completion.py').write_text('new')
   with self.assertRaises(ValueError):m.workspace(root,'sigir')
 @unittest.skipUnless((SOURCE/'mtp_completion/workflow.py').exists(),'Run from Akash_Kit to test actual workflow integration')
 def test_worker_schema_retry_and_hard_budget(self):
  for cap,expected_complete,expected_calls,local in ((2,True,2,False),(1,False,1,False),(1,True,1,True)):
   with self.subTest(cap=cap),tempfile.TemporaryDirectory() as d:
    r=Path(d);root=r/'root';root.mkdir()
    import shutil
    for directory in ('code','mtp_completion'):
     (root/directory).mkdir()
     for p in (SOURCE/directory).glob('*.py'):shutil.copy2(p,root/directory/p.name)
    shutil.copy2(SOURCE/'completion.py',root/'completion.py');(root/'code/stats_tools.py').touch(exist_ok=True)
    folder=root/'datasets/sigir204';folder.mkdir(parents=True);(root/'labelling').mkdir()
    (folder/'criteria.csv').write_text('trial_id,crit_idx,kind,criterion_text,note\nT,0,inclusion,Adult,\n')
    (folder/'splits.csv').write_text('trial_id,split\nT,dev\n')
    (folder/'sigir204.csv').write_text('pair_idx,trial_id,patient_id,patient_orig,target\n0,T,P,An adult.,Eligible\n')
    state=r/'state';state.mkdir();m.save(state/'BUDGET.json',{'attempts':0,'limit':cap})
    out=r/'statements.csv';stage={'name':'test','out':str(out),'args':['statements','--root',str(root),'--dataset','sigir204','--split','dev','--limit','0','--max-calls','20','--pause','0','--retries','0','--out',str(out)]}
    if local:
     out=r/'prediction.jsonl';stage={'name':'local','out':str(out),'args':['baseline','--root',str(root),'--dataset','sigir204','--split','dev','--backend','ollama','--model','qwen2.5:7b','--policy','forced','--limit','0','--num-ctx','8192','--max-output','400','--out',str(out)]}
    cp=state/'JOB.json';m.save(cp,{'workspace':str(root),'state':str(state),'stages':[stage]})
    harness=r/'harness.py';harness.write_text('''import importlib.util,io,json,os,sys,urllib.request
from pathlib import Path
spec=importlib.util.spec_from_file_location('p',sys.argv[1]);p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
calls=[]
def fake(req,*a,**k):
 url=getattr(req,'full_url',str(req))
 if url.endswith('/api/tags'):return io.BytesIO(b'{"models":[{"name":"qwen2.5:7b"}]}')
 calls.append(1)
 if url.endswith('/api/chat'):
  data={'truth':'yes','evidence':['An adult.'],'basis':'stated','rationale':'Adult documented.','confidence':0.9}
  return io.BytesIO(json.dumps({'message':{'content':json.dumps(data)},'done_reason':'stop','prompt_eval_count':10}).encode())
 data={'statement':'Adult','key_terms':['a','b','c','d']} if len(calls)==1 else {'statement':'The patient is an adult.','key_terms':['adult']}
 return io.BytesIO(json.dumps({'choices':[{'finish_reason':'stop','message':{'content':json.dumps(data)}}],'usage':{'total_tokens':10}}).encode())
urllib.request.urlopen=fake
os.environ['GROQ_API_KEY']='TEST_KEY'
target=Path(sys.argv[3]);config=Path(sys.argv[2])
try:p.worker(config,0)
except SystemExit:pass
finally:
 sys.settrace(None)
 target.write_text(str(len(calls)))
''')
    call_file=r/'calls.txt';result=subprocess.run([sys.executable,str(harness),str(HERE/'mtp_parallel.py'),str(cp),str(call_file)],capture_output=True,text=True)
    self.assertEqual(result.returncode,0,result.stderr);self.assertEqual(int(call_file.read_text()),expected_calls)
    self.assertEqual(m.complete(out),expected_complete)
    self.assertEqual(m.read(state/'BUDGET.json')['attempts'],expected_calls)
    if not expected_complete:self.assertFalse(out.exists());self.assertIn('BUDGET',m.read(state/'failure.json')['message'])
if __name__=='__main__':unittest.main()
