# Audit of the supplied snapshot and leftover-work list

The uploaded leftover_work.md is a progress summary; it is not evidence that the listed experiments have been completed. Its workflow is consistent with the original project's broad scope, but its 350/950 checkpoint was superseded by the supplied snapshot: 488/950 at 15:33 IST on 5 Nov.

Confirmed from snapshot:

- Current NSCLC audit: 488 unique rows, zero invalid or duplicated records; run still incomplete.
- Current SIGIR full audit in mtp_completion: not present.
- Assigned student references: 190+108 dev, 256+95 test; all 649 truth fields blank in these sheets.
- Baseline pair reports exist, subject qwen2.5:7b. NSCLC 11 wrong exclusions and 16 REVIEW; SIGIR 17 wrong exclusions and 69 REVIEW.
- Code for checking, analysis and traps exists. This is implementation evidence, not evidence of completed scientific experiments.

Interpretation:

The current API job advances one substantive experiment. Repeated baseline reporting and status messages do not complete the rest. Additional independent SIGIR and local mode-comparison jobs accelerate actual missing work. Human references, reviewed traps, a frozen method and held-out evaluation remain requirements; automation must expose these gaps rather than fill them with model-generated answers.

Engineering checks:

The uploaded supervisor-source workflow, checker, analysis, traps and completion entry-point hashes matched this snapshot. The provided new runner copies these installed modules into independent output scopes, so the original global model-process lock and shared cache do not cause competing jobs to overwrite one another. It records its own code hash and input versions.

Scientific limitation:

The current NSCLC statements include 24 unreviewed source-wording fallback rows. The SIGIR development run uses generated, unreviewed statements and transfers theta=95. These results are exploratory until the method is reviewed and standardised. Mode-specific checks, repairs and trap runs are still next stages, not silently completed by the package.
