# Parallel work for the original MTP

This package adds actual development computation alongside the existing NSCLC V3 run. It does not replace V3, modify its statements/cache/output, fabricate labels or run held-out inference. It uses the installed main project's implementation. This package was checked against the source uploaded for the supervisor; its workflow/checker/analysis/traps hashes matched the supplied snapshot.

## What the snapshot actually established

At 2026-11-05 10:03 UTC (15:33 IST), NSCLC was 488/950, so 462 were still pending then. The snapshot included a completed 20-case checker pilot, no full SIGIR checker output in the current workflow, and 0/649 valid truth labels in the assigned sheets. There may be separate annotation drafts elsewhere; they are not evidence that these reference sheets are complete. Baseline pair reports exist, with 11 NSCLC and 17 SIGIR wrongly excluded pairs. This package does not turn those preliminary results into final validated performance.

## Installation

Download the ZIP to Downloads and extract:

```bash
unzip -o "$HOME/Downloads/MTP_PARALLEL_WORK.zip" -d "$HOME/Downloads"
cd "$HOME/MTP/Akash_Kit"
.venv/bin/python "$HOME/Downloads/MTP_PARALLEL_WORK/test_parallel.py"
```

Five tests cover completed coverage, duplicates, schema validation, dev-only plans, workspace isolation and actual-workflow mocked schema retry/budget enforcement, plus a mocked local Ollama baseline request. These tests make no real API calls. They do not establish live Groq/Ollama performance.

Keep the existing NSCLC V3 terminal running. Use the four additional terminals as follows. Each job has its own lock and stable checkpoint. Rerunning the same job resumes its saved outputs and **retains its cumulative attempt budget**. The 24-hour limit is per launch; a hard limit can leave a stage incomplete.

## Terminal 2: SIGIR development API pipeline

```bash
cd "$HOME/MTP/Akash_Kit"
.venv/bin/python -u "$HOME/Downloads/MTP_PARALLEL_WORK/mtp_parallel.py" sigir --root "$PWD" --hours 24 --max-attempts 6000 --pause 20
```

This generates statements for all SIGIR development rules, then checks all 990 existing SIGIR development predictions. An automatic format retry is allowed once when a requested structured field is malformed. No failed response is changed into a reference label or accepted checker result. Statement review is still pending, so checks are explicitly exploratory. Theta=95 is transferred from NSCLC for this dev run; final method selection/transfer policy must be documented before freeze.

**Budget:** up to 6,000 additional external API attempts across these stages and retries, cumulative across manual restarts. This is a cap, not a prediction of usage or a monetary limit. Tokens remain logged by the existing API client. The job loads authorised Groq keys from the same private key file as V3, can switch on 401/403 rejection, waits on 429/Retry-After and does not rotate keys to bypass limits. Shared account limits still apply. Its 20-second pacing reduces contention with V3; more keys do not create guaranteed throughput.

Workspace: `outputs/mtp_parallel/workspaces/sigir`. All code is copied into the scope, while dataset/label directories are linked read-only by usage. Baseline input predictions are copied and verified. Original data/labels/code are not edited by this job. If the original implementation changes, the job refuses to mix versions.

## Terminal 3: local Qwen answer-mode comparison

```bash
cd "$HOME/MTP/Akash_Kit"
.venv/bin/python -u "$HOME/Downloads/MTP_PARALLEL_WORK/mtp_parallel.py" qwen --root "$PWD" --hours 24 --max-attempts 4500
```

This runs explicit-unknown and forced-guess modes for both development datasets using **qwen2.5:7b**, context 8,192 and max output 400, with matched inference settings. That is up to 3,880 prediction records, with a 4,500 local-generation attempt cap. An initial copy of the saved legacy Qwen cache can avoid recomputing matching prompts. No existing baseline file is overwritten. Cached records count as completed outputs, not new model calls.

**Zero external API calls.** Ollama must already be running locally and qwen2.5:7b installed. The job checks availability and does not automatically download a different model. A laptop with insufficient RAM may need a lab machine; do not replace the primary subject model with a smaller debugging model and report it as the same experiment. Run only this one local model job to avoid overloading the laptop. It can be slowed or stopped without discarding completed rows.

Workspace: `outputs/mtp_parallel/workspaces/qwen`. These fresh paired-mode predictions are a new run. Existing checker outputs belong to their original source answers and are not silently attached to these new predictions. After the mode outputs complete, their corresponding evidence checks remain a next stage before all mode-specific K1/K2 comparisons are complete.

## Terminal 4: automatic reporting

```bash
cd "$HOME/MTP/Akash_Kit"
.venv/bin/python -u "$HOME/Downloads/MTP_PARALLEL_WORK/mtp_parallel.py" reports --root "$PWD" --hours 24
```

Watches completion of the primary NSCLC checker, new SIGIR checker, and the four local prediction runs. It generates separate reports only when source manifests and row coverage are complete. For checked runs the report includes priority orders, equal-budget simulation, rejection-risk lists and keep/flag comparison. For un-checked prediction runs it generates baseline pair metrics. It refreshes a report if original student label sheets change. It declares AI-assisted label provenance conservatively because earlier model suggestions were viewed; discuss exact provenance with Neha.

Results/index: `outputs/mtp_parallel/REPORT_INDEX.json`; live reporting state: `REPORT_STATUS.json`. These are not a claim that the held-out experiment, repairs or traps have finished. Empty labels leave criterion/checker accuracy unavailable. Model-assigned categories are not human-confirmed error types.

Zero external API calls. The watcher is useful automation, not a seven-hour compute-intensive experiment. It can coexist with the previous simple report watcher, but running both is redundant; stop the old watcher first if it is still open. Do not stop V3.

## Terminal 5: guided, blinded reference labelling

```bash
cd "$HOME/MTP/Akash_Kit"
.venv/bin/python "$HOME/Downloads/MTP_PARALLEL_WORK/mtp_parallel.py" review --root "$PWD" --dataset nsclc100 --split dev
```

This is **human work**, not an unattended model job. It displays only the original note, criterion and guidance; no model answers, flags or pair target labels. You type the judgment and exact evidence. It validates field formats and literal quotation, requires explicit save, backs up the sheet privately, then atomically updates that row. It detects changes from another editor rather than overwriting them. Close LibreOffice for the sheet being reviewed. Do not run two review processes on one sheet.

Repeat for SIGIR development with `--dataset sigir204`. Before method freeze, label the assigned test rows using `--split test` as required by the guide. This does not make held-out model calls. Follow the original guide's stated/inferred/absent and not-applicable rules. Use UNSURE comments for interpretation uncertainty. Prior exposure to AI suggestions cannot be undone by a blinded interface; report the assistance honestly.

No API agent should silently fill these fields and call them independent reference labels. If independent annotations are supplied by Neha, use those with their actual provenance instead of duplicating work.

## Real remaining gates from leftover_work.md

| Work item | What this package advances | What still needs completion |
|---|---|---|
| Baselines/two answer modes | Runs matched local Qwen modes and exports pair reports | Checks for the fresh mode outputs; consistency audit against any reused legacy configuration |
| Six evidence checks | Existing NSCLC V3 + separate full SIGIR pipeline | Review flags and VERIFIED examples; validate final statements/calibration; finish any budget-limited stage |
| Reference labels | Blinded helper with per-row saving | Actual human judgments; resolve conflicts and UNSURE; record exposure/assistance |
| K1/K5 priority/risk | Automatic reports on completed original-mode checked runs | Final comparison on both answer modes, with correction-source assumptions explicit |
| K2 checker quality/ablations | Reports update when usable reference labels exist | Sufficient valid joined labels; all/without UNSURE results |
| K3 re-ask repair | Existing `completion.py repair` remains available | Run after matching check coverage is complete; same Qwen subject model; count fixed AND broken |
| K4 seven trap types | Existing trap workflow remains available | Human-reviewed dev statements, source labels and altered-note expected truths before execution |
| Freeze and held-out | No new test inference is launched | Freeze code/settings/labels, then the planned held-out run and final packaging |

The pending gates cannot be reported as complete because other terminals are busy. Do not change active statements or code; review copies, version corrections and standardise the final method before held-out inference. This remains Neha's main MTP; no AAPEMS extension, extra training or new datasets are added.

## Logs, recovery and power

API/local job status and diagnostics: `outputs/mtp_parallel/state/<sigir|qwen>/STATUS.json`, `console.log`, `BUDGET.json`, and `failure.json`. Main V3 keeps its original status path. A persistent invalid response stops with NEEDS_ATTENTION, with completed rows intact. Transport retries are bounded and may occasionally duplicate charges if a response was lost after generation. Local/server and quota failures are not all solved by key fallback.

Keep the charger connected and prevent automatic suspend. V3's existing systemd-inhibit keeps sleep/idle inhibited while V3 runs; if it exits, that inhibitor ends. To keep an independent inhibitor for up to 24 hours, run the included `keep_awake.sh` in a spare tab or disable automatic suspend in Power Settings. Keep the lid open. Closing a foreground terminal stops its job. Ctrl+C stops a worker cleanly; do not use Ctrl+Z to suspend a job that you intend to replace.
