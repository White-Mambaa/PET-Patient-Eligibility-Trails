#!/usr/bin/env bash
set -euo pipefail
exec systemd-inhibit --what=sleep:idle --mode=block --why="MTP parallel development experiments" sleep 24h
