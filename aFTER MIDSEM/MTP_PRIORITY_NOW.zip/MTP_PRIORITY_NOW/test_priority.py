import importlib.util,os,sys,unittest
from pathlib import Path
HERE=Path(__file__).resolve().parent;spec=importlib.util.spec_from_file_location('job',HERE/'mtp_priority_now.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
SOURCE=Path(os.environ.get('MTP_TEST_PROJECT_ROOT',Path.cwd()));sys.path[:0]=[str(SOURCE/'code'),str(SOURCE)]
from criteria import map_truth
from mtp_completion.analysis import pair_rows,pair_metrics,target
class Tests(unittest.TestCase):
 def fixture(self):
  corpus=[dict(pair_idx='0',trial_id='A',patient_id='P0',target='Eligible'),dict(pair_idx='1',trial_id='B',patient_id='P1',target='Not Eligible')]
  rules={'A':[dict(crit_idx=0,kind='inclusion'),dict(crit_idx=1,kind='inclusion')],'B':[dict(crit_idx=0,kind='inclusion'),dict(crit_idx=1,kind='inclusion')]}
  pred={(0,0):dict(truth='no',kind='inclusion',confidence=.8),(0,1):dict(truth='yes',kind='inclusion',confidence=.1),(1,0):dict(truth='no',kind='inclusion',confidence=.2),(1,1):dict(truth='no',kind='inclusion',confidence=.3)}
  return corpus,rules,pred
 def test_sole_reason_first(self):
  _,_,pred=self.fixture();self.assertEqual(m.orders(pred,map_truth)['fewest_reasons'][0],(0,0))
 def test_orders_never_need_reference_or_check_labels(self):
  corpus,_,pred=self.fixture();a=m.orders(pred,map_truth)
  for r in corpus:r['target']='FLIPPED_REFERENCE'
  self.assertEqual(a,m.orders(pred,map_truth));self.assertEqual(a['least_confident'][0],(0,1))
 def test_label_assumption_is_counted_and_not_an_approval(self):
  c,r,p=self.fixture();before={k:dict(v) for k,v in p.items()}
  scored=m.simulation(c,r,p,[(0,0)],1,'trial_id',pair_rows,pair_metrics,map_truth,target)
  self.assertEqual(scored['label_implied_rescues'],1);self.assertEqual(scored['after']['review_count'],1)
  self.assertEqual(scored['eligible_pair_label_assumption_changes'],1);self.assertEqual(p,before)
 def test_unknown_effect_denominator(self):
  c,r,p=self.fixture();s=m.simulation(c,r,p,[(1,0),(1,1)],50,'trial_id',pair_rows,pair_metrics,map_truth,target)
  self.assertEqual(s['actual_checks'],2);self.assertEqual(s['checks_with_unknown_effect'],2);self.assertEqual(s['label_implied_rescues'],0)
if __name__=='__main__':unittest.main()
