# Run a real priority experiment alongside Qwen

This job uses the saved Qwen predictions to compute three required review-order baselines now: random, least_confident and fewest_reasons. It does not need complete checker outputs and does not add Qwen generation or external API traffic.

## Run

```bash
unzip -o "$HOME/Downloads/MTP_PRIORITY_NOW.zip" -d "$HOME/Downloads"
cd "$HOME/MTP/Akash_Kit"
.venv/bin/python "$HOME/Downloads/MTP_PRIORITY_NOW/test_priority.py"
.venv/bin/python "$HOME/Downloads/MTP_PRIORITY_NOW/mtp_priority_now.py" --root "$PWD"
```

Run this in a new terminal while the local Qwen comparison, NSCLC-to-SIGIR recovery queue, report watcher and queued local follow-up remain active. No workers are stopped and no active inputs or caches are edited. The job uses ordinary CPU calculations over the existing development predictions and can finish quickly. More terminals do not create more CPU/GPU capacity.

## Outputs

New timestamped directory under `outputs/mtp_parallel/priority_baselines/`:

- separate NSCLC100 and SIGIR204 directories;
- order_random.csv, order_least_confident.csv and order_fewest_reasons.csv;
- TABLE2_THREE_BASELINES_SIMULATION.csv at review budgets 5,10,20,50,100;
- review_curve.svg;
- RESULTS_NO_NOTES.json with initial harms, counts, correction assumptions, unknown-effect checks, per-cluster results and source hashes;
- SUMMARY_NO_NOTES.json for both datasets.

The script scores the stable legacy development predictions (`plain_ai_qwen_dev.jsonl` and `plain_ai_qwen_sigir_dev.jsonl`). Fresh paired-mode predictions in the other workspace are separate runs. Do not silently attach these results to a different model/prompt/configuration.

## Interpretation

This follows original guide 9.3 for unlabelled answers: if a selected not_met answer belongs to a dataset-Eligible pair, change it to unknown in the simulation. Otherwise the effect is unknown. It uses NO criterion-level reference labels. Ordering functions cannot access patient reference labels; labels are consulted only by the scorer.

A label-implied rescue is a pair no longer rejected; it can mean REVIEW, not automatic approval. This is not an observed human correction, an independently verified clinical error, a criterion accuracy result or the full final five-strategy comparison. Report correction assumptions and unknown-effect counts. Keep the datasets separate and use trial/patient cluster units in final comparisons.

flagged_first and combined still require complete matching checker outputs. Reference annotations, checker quality, repairs, traps and frozen held-out results remain separate requirements. The job does not write any truth labels or call any model.

Four tests cover sole-reason ordering, ordering independence from reference labels, explicit counting of label-implied corrections and unknown-effect denominators, and preservation of the input predictions. No real dataset or model was used in tests.
