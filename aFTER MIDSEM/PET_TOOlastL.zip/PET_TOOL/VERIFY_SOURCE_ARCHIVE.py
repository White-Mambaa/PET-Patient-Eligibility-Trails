#!/usr/bin/env python3
"""Check the original All MTP archive offline. Output is aggregates and hashes only."""

import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import io
import json
import math
from pathlib import Path, PurePosixPath
import re
import sys
import tarfile
from zipfile import ZipFile, BadZipFile

OUTER = "All MTP/"
OCT = OUTER + "MTP_Neha_Maam_Full_Project_20261014_204759.zip"
NOV = OUTER + "MTP_SUBMISSION.zip"
BASE = "PROJECT/"
SUB = "MTP_SUBMISSION/"
CONFIG = {
    "nsclc100": ("NSCLC-100", "plain_ai_qwen_dev", 50, 950),
    "sigir204": ("SIGIR-204", "plain_ai_qwen_sigir_dev", 102, 990),
}
COUNTS = ("pairs", "reference_eligible", "reference_ineligible", "eligible_found",
          "hard_wrong_exclusions", "wrong_inclusions", "review")


class AuditError(ValueError):
    """An audit failure with a message that is safe to display."""


def require(test, message):
    if not test:
        raise AuditError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def table(data):
    reader = csv.DictReader(io.StringIO(data.decode("utf-8-sig"), newline=""))
    rows = list(reader)
    require(len(set(reader.fieldnames or ())) == len(reader.fieldnames or ()) and
            not any(None in row or None in row.values() for row in rows), "Malformed CSV.")
    return rows


def records(data):
    return [json.loads(line) for line in data.splitlines() if line.strip()]


def unique(rows, key, label):
    result = {key(row): row for row in rows}
    require(len(result) == len(rows), "Duplicate key in " + label + ".")
    return result


def id_rule(row):
    return (int(row["pair_idx"]), int(row["crit_idx"]))


def id_all(row):
    return (row["dataset"], *id_rule(row))


def verdict(kind, truth):
    require(kind in ("inclusion", "exclusion") and truth in ("yes", "no", "unknown"),
            "Unexpected rule kind or truth.")
    return "not_stated" if truth == "unknown" else "met" if (
        (truth == "yes") == (kind == "inclusion")) else "not_met"


def normal(text):
    return re.sub(r"\s+", " ", text).strip()


def safe_name(name):
    p = PurePosixPath(name)
    return bool(name and not p.is_absolute() and "\\" not in name and ".." not in p.parts)


def check_zip(raw, depth=0):
    with ZipFile(io.BytesIO(raw)) as z:
        files = z.infolist()
        require(depth < 4 and len(files) <= 300 and sum(f.file_size for f in files) <= 20_000_000,
                "Nested ZIP exceeds the size or depth limit.")
        require(len({f.filename for f in files}) == len(files) and
                all(safe_name(f.filename) and not f.flag_bits & 1 and
                    (f.external_attr >> 16) & 0o170000 != 0o120000 for f in files),
                "Unsafe or duplicate path in a ZIP.")
        require(z.testzip() is None, "A nested ZIP member failed CRC.")
        return 1 + sum(check_zip(z.read(f), depth + 1) for f in files if f.filename.endswith(".zip"))


def read_top(path):
    with tarfile.open(path, "r:xz") as t:
        entries = t.getmembers()
        require(len(entries) <= 500 and sum(m.size for m in entries) <= 30_000_000,
                "Outer archive exceeds the review limits.")
        require(len({m.name for m in entries}) == len(entries) and
                all(safe_name(m.name) and (m.isdir() or m.isfile()) for m in entries),
                "Outer archive has an unsafe or duplicate path.")
        files = {m.name: t.extractfile(m).read() for m in entries if m.isfile()}
    zip_names = [n for n in files if n.endswith(".zip")]
    return files, {
        "outer_members": len(entries), "outer_files": len(files), "direct_zips": len(zip_names),
        "zip_checks_including_nested_copies": sum(check_zip(files[n]) for n in zip_names),
        "source_archive_sha256": sha(path.read_bytes()),
    }


def validate_nov(files):
    with ZipFile(io.BytesIO(files[NOV])) as z:
        signed = z.read(SUB + "SHA256SUMS.txt").decode("utf-8").splitlines()
        require(len(signed) == 8, "Unexpected November submission checksum list.")
        for line in signed:
            want, name = line.split("  ", 1)
            require(sha(z.read(SUB + name)) == want, "November submission checksum mismatch.")
        evidence = json.loads(z.read(SUB + "CLOSEOUT_EVIDENCE_NO_NOTES.json"))
        snapshot = json.loads(z.read(SUB + "RESULTS_SNAPSHOT.json"))
        require(not evidence["unverified"] and evidence["paired_metrics_agree_with_deck"] is True,
                "The original November snapshot had unverified inputs.")
        require(len(evidence["paired_development"]) == len(snapshot["paired_development"]) == 4,
                "The paired comparison is incomplete.")
        groups = defaultdict(list)
        for ev, saved in zip(evidence["paired_development"], snapshot["paired_development"]):
            keys = ("dataset", "mode", *COUNTS)
            require(all(ev[k] == saved[k] for k in keys), "November closeout and report counts differ.")
            n, p, g, tp, hard, fp, review = (ev[k] for k in COUNTS)
            require(all(type(ev[k]) is int and ev[k] >= 0 for k in COUNTS) and
                    n == p + g and 0 < p <= n and tp + hard <= p and fp <= g and
                    p - tp - hard <= review <= n - tp - fp - hard,
                    "Inconsistent November pair counts.")
            calc = {"binary_accuracy": (tp + g - fp) / n,
                    "eligible_recall": tp / p, "eligible_f1": 2 * tp / (tp + p + fp)}
            require(all(math.isclose(ev[k], v, rel_tol=1e-12) for k, v in calc.items()),
                    "Reported November metrics differ from recomputed scores.")
            require(re.fullmatch(r"[a-f0-9]{64}", ev["source"]["sha256"]), "Missing CSV source hash.")
            groups[ev["mode"]].append(ev)
        require(set(groups) == {"Allow unknown", "Forced guess"} and
                all({r["dataset"] for r in group} == {"NSCLC-100", "SIGIR-204"} for group in groups.values()),
                "November comparison has missing cohort modes.")
        pair_sources = [r["source"]["path"] for r in evidence["paired_development"]]
        require(len(set(pair_sources)) == 4, "Duplicated November pair source.")
        pooled = {}
        for mode, group in groups.items():
            x = {k: sum(r[k] for r in group) for k in COUNTS}
            tp, fp = x["eligible_found"], x["wrong_inclusions"]
            x.update(
                binary_accuracy=(tp + x["reference_ineligible"] - fp) / x["pairs"],
                eligible_precision=tp / (tp + fp) if tp + fp else None,
                eligible_recall=tp / x["reference_eligible"],
                eligible_f1=2 * tp / (tp + x["reference_eligible"] + fp),
            )
            pooled[mode] = x
        checker = evidence["checker"]
        require(all(checker[k] == snapshot["checker"][k] for k in ("saved", "expected")) and
                0 < checker["fully_checked_pairs"] <= checker["expected_pairs"],
                "November checker counts conflict.")
        require(evidence["reask"]["saved"] == snapshot["reask"]["saved_records"],
                "November draft count conflicts.")
        return evidence, {
            "snapshot_capture": evidence["captured_at_ist"], "checksum_entries_verified": len(signed),
            "rows_match_original_closeout": len(evidence["paired_development"]), "pooled": pooled,
            "checker": {k: checker[k] for k in ("saved", "expected", "fully_checked_pairs", "expected_pairs")},
            "reask": {k: evidence["reask"][k] for k in ("saved", "planned", "usable_drafts")},
            "pair_decision_csvs_present": sum(SUB + p in z.namelist() for p in pair_sources),
            "raw_checker_checkpoint_present": SUB + checker["path"] in z.namelist(),
            "scope": "Four closeout count rows checked against the report snapshot; raw November predictions and checkpoint are not in the submission.",
        }


def validate_oct(files, november):
    expected_sha = files[OCT + ".sha256"].decode("utf-8").split()[0]
    require(sha(files[OCT]) == expected_sha, "October backup checksum mismatch.")
    predictions, outcomes, tallies = {}, {}, {}
    with ZipFile(io.BytesIO(files[OCT])) as z:
        manifest = table(z.read("FILE_MANIFEST.csv"))
        require(len({m["archive_path"] for m in manifest}) == len(manifest),
                "October manifest repeats a member.")
        for member in manifest:
            b = z.read(member["archive_path"])
            require(len(b) == int(member["bytes"]) and sha(b) == member["sha256"],
                    "October manifest checksum mismatch.")
        for dataset, (title, stem, n_pairs, n_rows) in CONFIG.items():
            root = BASE + "datasets/" + dataset + "/"
            pair_rows = table(z.read(root + dataset + ".csv"))
            pairs = unique(pair_rows, lambda r: int(r["pair_idx"]), "archived pairs")
            split = unique(table(z.read(root + "splits.csv")), lambda r: r["trial_id"], "split")
            crit = unique(table(z.read(root + "criteria.csv")),
                          lambda r: (r["trial_id"], int(r["crit_idx"])), "criterion definitions")
            dev = {k: v for k, v in pairs.items() if split[v["trial_id"]]["split"] == "dev"}
            expected = {(p, c): r for p, v in dev.items() for (t, c), r in crit.items() if t == v["trial_id"]}
            pred_bytes = z.read(BASE + "outputs/" + stem + ".jsonl")
            pred = unique(records(pred_bytes), id_rule, "baseline")
            require(len(dev) == n_pairs and len(expected) == n_rows and pred.keys() == expected.keys(),
                    "October prediction coverage differs from the development split.")
            groups = defaultdict(list)
            exact, spans, cited = 0, 0, 0
            for k, row in pred.items():
                source = expected[k]
                require(row["dataset"] == dataset and row["kind"] == source["kind"] and
                        row["trace"]["trial_id"] == source["trial_id"] and row["trace"]["model"] == "qwen2.5:7b" and
                        row["parse_ok"] is True and row["verdict"] == verdict(row["kind"], row["truth"]),
                        "October baseline record does not match its criterion, model or verdict rule.")
                require(isinstance(row["evidence"], list), "Unexpected baseline evidence structure.")
                quotes = [normal(q) for q in row["evidence"] if normal(q)]
                note = normal(dev[k[0]]["patient_orig"])
                exact += sum(q in note for q in quotes)
                spans += len(quotes)
                cited += bool(row["evidence"])
                groups[k[0]].append((k[1], row["verdict"]))
                predictions[(dataset, *k)] = row
            aggregate = {"dataset": title, "pairs": n_pairs, "criterion_records": n_rows,
                         "reference_eligible": 0, "eligible_found": 0, "hard_wrong_exclusions": 0,
                         "wrong_inclusions": 0, "review": 0, "single_failing_rule": 0,
                         "verbatim_spans": exact, "cited_spans": spans}
            require(all(v["target"] in ("Eligible", "Not Eligible") for v in dev.values()),
                    "Unknown pair reference label.")
            for pair, rr in groups.items():
                fails = [i for i, v in rr if v == "not_met"]
                decision = "NOT_ELIGIBLE" if fails else "REVIEW" if any(v == "not_stated" for _, v in rr) else "ELIGIBLE"
                ref = dev[pair]["target"] == "Eligible"
                aggregate["reference_eligible"] += ref
                aggregate["eligible_found"] += ref and decision == "ELIGIBLE"
                aggregate["hard_wrong_exclusions"] += ref and decision == "NOT_ELIGIBLE"
                aggregate["wrong_inclusions"] += not ref and decision == "ELIGIBLE"
                aggregate["review"] += decision == "REVIEW"
                aggregate["single_failing_rule"] += ref and len(fails) == 1
                outcomes[(dataset, pair)] = (ref, decision, fails)
            quoted = json.loads(z.read(BASE + "outputs/" + stem + "_evidence.json"))
            require((quoted["records"], quoted["records_with_evidence"], quoted["spans"],
                     quoted["exact_substring"]) == (n_rows, cited, spans, exact), "October quote summary does not match source rows.")
            tallies[dataset] = aggregate
            if dataset == "nsclc100":
                require(sha(pred_bytes) == november["checker"]["pred_sha256"],
                        "The October NSCLC baseline does not match the source hash in the November closeout.")

        citation = unique(table(z.read(BASE + "outputs/evidence_checks/real_citation_results.csv")), id_all, "citation audit")
        require(citation.keys() == predictions.keys(), "October citation audit coverage differs from the baseline.")
        cite_status = Counter(r["citation_status"] for r in citation.values())
        require(set(cite_status) <= {"PASS", "FAIL", "NO_EVIDENCE"}, "Unknown citation status.")
        audit = unique(records(z.read(BASE + "outputs/overnight_audit/evidence_audit.jsonl")), id_all, "AI audit")
        require(audit.keys() == predictions.keys(), "October preliminary audit coverage differs from the baseline.")
        inconsistent = 0
        for k, row in audit.items():
            pred = predictions[k]
            require(row["baseline_truth"] == pred["truth"] and row["baseline_verdict"] == pred["verdict"] and
                    row["audit_type"] == "AI_PRELIMINARY" and row["judge_model"] == "qwen2.5:7b",
                    "October preliminary audit refers to a different baseline answer or model.")
            suggestion = row["audit"]
            inconsistent += verdict(pred["kind"], suggestion["suggested_truth"]) != suggestion["suggested_verdict"]

        candidates = {(ds, p, fails[0]) for (ds, p), (ref, _, fails) in outcomes.items() if ref and len(fails) == 1}
        priority = defaultdict(list)
        for row in table(z.read(BASE + "outputs/priority_comparison/priority_rankings.csv")):
            priority[row["strategy"]].append(row)
        budget = {}
        for strategy, rows in priority.items():
            ordered = sorted(rows, key=lambda r: int(r["rank"]))
            require(unique(rows, id_all, "ranking").keys() == predictions.keys() and
                    [int(r["rank"]) for r in ordered] == list(range(1, len(predictions) + 1)) and
                    {id_all(r) for r in rows if r["eligible_rejection_candidate"] == "1"} == candidates,
                    "Archived priority ranking has invalid coverage or candidate labels.")
            budget[strategy] = sum(id_all(r) in candidates for r in ordered[:50])
        expected_budget = {r["strategy"]: int(r["eligible_rejection_candidates_found"])
                           for r in table(z.read(BASE + "outputs/priority_comparison/equal_budget_summary.csv")) if r["budget"] == "50"}
        require(budget == expected_budget and set(budget) == {"random", "confidence", "citation", "decision_impact", "combined"},
                "Recomputed 50-check comparison differs from the archived summary.")

        pref = BASE + "outputs/priority_comparison/"
        proposals = table(z.read(pref + "evaluation_44_exploratory_20261014_155042_941024/case_level_comparison.csv"))
        selected = {id_all(r) for rows in priority.values() for r in rows if int(r["rank"]) <= 10}
        require(unique(proposals, id_all, "exploratory cohort").keys() == selected, "Exploratory cohort differs from the top-ten union.")
        independent = table(z.read(pref + "independent_adjudication_20261014_155813_331513/blinded_44_case_review.csv"))
        simulations = table(z.read(pref + "patient_counterfactual_exploratory_20261014_160609_713057/one_rule_at_a_time.csv"))
        traps = records(z.read(BASE + "outputs/traps/trap_pilot_verified.jsonl"))
        return {
            "manifest_entries_verified": len(manifest), "baseline": list(tallies.values()),
            "citation_rows": len(citation), "citation_status": dict(cite_status),
            "preliminary_ai_audit": {"unique_records": len(audit), "truth_verdict_inconsistent": inconsistent},
            "priority_ranking": {"ranking_rows": sum(map(len, priority.values())), "budget": 50,
                                 "eligible_single_rule_rejection_candidates": budget,
                                 "total_candidates": len(candidates)},
            "selected_proposal_cohort": {
                "rows": len(proposals), "scorable_assistant_proposals": sum(r["assistant_exploratory_scorable"] == "yes" for r in proposals),
                "assistant_disagreements": sum(r["assistant_baseline_disagreement"] == "yes" for r in proposals),
                "filled_independent_truth_labels": sum(bool(r["adjudicated_truth"].strip()) for r in independent),
                "simulated_pair_changes": sum(r["pair_decision_changed"] == "1" for r in simulations),
                "simulated_substitutions": len(simulations),
            },
            "trap_pilot": {"hand_checked_fixture_inputs": sum(r["checked_by_hand"] is True for r in traps),
                           "scope": "Fixture preparation; no trap performance estimate."},
            "october_nsclc_baseline_matches_november_checker_source_hash": True,
        }


def audit(path):
    files, summary = read_top(path)
    evidence, november = validate_nov(files)
    october = validate_oct(files, evidence)
    return {
        "scope": "Offline archive integrity and development-evidence review. No model calls.",
        "archive": summary, "october_raw_recomputed": october, "november_closeout": november,
        "held_out": "No verified held-out performance established by the reviewed evidence.",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    parser.add_argument("--out", type=Path, help="Write the notes-free report to a new JSON file")
    args = parser.parse_args()
    try:
        report = json.dumps(audit(args.archive), ensure_ascii=False, indent=2) + "\n"
        if args.out:
            with args.out.open("x", encoding="utf-8") as f:
                f.write(report)
        else:
            print(report, end="")
    except (OSError, KeyError, ValueError, TypeError, IndexError, BadZipFile, tarfile.TarError) as exc:
        # Give the name of an unexpected parser exception without exposing clinical values.
        msg = str(exc) if isinstance(exc, AuditError) else type(exc).__name__
        print("Archive check stopped: " + msg, file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
