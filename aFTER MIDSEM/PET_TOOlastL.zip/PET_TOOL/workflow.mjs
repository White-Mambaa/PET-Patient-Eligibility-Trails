export const judgementNames = {yes: "Present", no: "Absent", unknown: "Insufficient evidence"};
export const resultNames = {ELIGIBLE: "Criteria met", NOT_ELIGIBLE: "Criteria not met", REVIEW: "More information needed"};
export const dispositions = {
  forward_for_trial_review: "Forward to the trial team",
  criteria_not_met: "Record that criteria are not met",
  request_more_information: "Request more information",
};
export const checks = {
  citation: "Quote match", entailment: "Evidence support", context: "Context",
  logic: "Logic", contradiction: "Contradictory evidence", missed_evidence: "Missed evidence",
};
const flags = {
  LOGIC_ERROR: "The draft disagrees with the rule and cited measurement.",
  NUMERIC_MISMATCH: "The supplied answer conflicts with a simple numeric check.",
  QUOTE_NOT_FOUND: "One or more quotes do not appear exactly in the source note.",
  NO_QUOTE_CITED: "This definite answer has no source quote.",
};

export function node(tag, content, cls) {
  const x = document.createElement(tag);
  if (content !== undefined && content !== null) x.textContent = content;
  if (cls) x.className = cls;
  return x;
}

export function icon(name) {
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  const use = document.createElementNS(svg.namespaceURI, "use");
  svg.setAttribute("class", "icon");
  svg.setAttribute("aria-hidden", "true");
  use.setAttribute("href", "#i-" + name);
  svg.append(use);
  return svg;
}

export function button(label, cls, handler, glyph) {
  const b = node("button", undefined, "button " + cls);
  b.type = "button";
  if (glyph) b.append(icon(glyph));
  b.append(document.createTextNode(label));
  if (handler) b.addEventListener("click", handler);
  return b;
}

export function badge(label, kind = "neutral") {
  return node("span", label, "badge " + kind);
}

export function fileLink(label, file) {
  const a = node("a", undefined, "button secondary");
  a.href = "/results/" + file;
  a.append(icon("download"), document.createTextNode(label));
  return a;
}

export function trainingModel(data, demo) {
  const details = new Map(demo.criteria.map((row) => [row.id, row]));
  const meta = new Map(demo.review_order.map((row) => [row.criterion_id, row]));
  const rules = data.criteria.map((r, i) => {
    const d = details.get(r.id);
    const order = meta.get(r.id);
    return {
      ...r, i: i + 1, issue: d.checker.label === "VERIFIED" ? "" : flags[d.checker.label] || d.checker.reason,
      impact: order.could_change_decision, sole: order.sole_rejection_reason,
      checks: demoChecks(d.checker.checks), draftNote: "Simulated screening answer",
    };
  });
  return {
    input: data, training: true, rules, order: demo.review_order.map((r) => r.criterion_id),
    draftOutcome: demo.decisions.keep,
  };
}

export function suppliedModel(data, result) {
  const details = new Map(result.criteria.map((row) => [row.id, row]));
  return {
    input: data, training: false, draftOutcome: result.decisions.keep,
    order: result.criteria.map((r) => r.id),
    rules: data.criteria.map((r, i) => {
      const d = details.get(r.id);
      return {
        ...r, i: i + 1, evidence: r.evidence || [],
        issue: d.flags.map((s) => flags[s] || "Check the supplied answer.").join(" "),
        impact: d.could_change_decision, sole: d.sole_rejection_reason,
        checks: suppliedChecks(d.checks), draftNote: "Supplied screening answer",
      };
    }),
  };
}

function demoChecks(c) {
  return {
    citation: c.citation.status === "FOUND" ? "Quote found in the training note." : "Review the quote.",
    entailment: c.entailment.nli_label === "entailment" ? "The excerpt supports the rule statement."
      : c.entailment.nli_label === "contradiction" ? "The excerpt contradicts the rule statement." : "Support not established.",
    context: c.context.misread ? "Context flagged." : "No context issue flagged.",
    logic: c.logic.valid ? "No logic issue flagged." : "The answer conflicts with the cited measurement.",
    contradiction: c.contradiction.found ? "A conflicting sentence was flagged." : "No conflicting sentence flagged.",
    missed_evidence: c.missed_evidence.found ? "A relevant uncited sentence was flagged." : "No missed evidence flagged.",
  };
}

function suppliedChecks(c) {
  const cite = {QUOTE_PRESENT: "Exact quote found.", QUOTE_NOT_FOUND: "Quote not found exactly.",
    NO_QUOTE_CITED: "No quote supplied for this answer.", NOT_APPLICABLE: "No quote supplied."};
  return {
    citation: cite[c.citation.status],
    logic: c.logic.status === "NUMERIC_MATCH" ? "The simple numeric check agrees with the answer."
      : c.logic.status === "NUMERIC_MISMATCH" ? "The numeric check conflicts with the answer."
      : "No comparable standalone measurement.",
    entailment: "For the reviewer", context: "For the reviewer",
    contradiction: "For the reviewer", missed_evidence: "For the reviewer",
  };
}

export function reviewedResult(rules, reviewed) {
  if (rules.length === 0 || rules.some((r) => !reviewed.has(r.id))) return null;
  const labels = rules.map((r) => {
    const answer = reviewed.get(r.id).truth;
    if (answer === "unknown") return "unknown";
    return (answer === "yes") === (r.kind === "inclusion") ? "pass" : "fail";
  });
  if (labels.includes("fail")) return "NOT_ELIGIBLE";
  if (labels.includes("unknown")) return "REVIEW";
  return "ELIGIBLE";
}

export function dispositionOptions(outcome) {
  if (!outcome) return [];
  const primary = {ELIGIBLE: "forward_for_trial_review", NOT_ELIGIBLE: "criteria_not_met", REVIEW: "request_more_information"}[outcome];
  return [...new Set([primary, "request_more_information"])];
}

export function groupOutcomes(row) {
  const eligibleReview = row.reference_eligible - row.eligible_found - row.hard_wrong_exclusions;
  const ineligibleReview = row.review - eligibleReview;
  return {
    eligible: {met: row.eligible_found, excluded: row.hard_wrong_exclusions, review: eligibleReview},
    ineligible: {met: row.wrong_inclusions, excluded: row.reference_ineligible - row.wrong_inclusions - ineligibleReview, review: ineligibleReview},
  };
}

export function answerQuestion(question, active, selected, reviewed) {
  if (!active) return {text: "Open a training or evaluation case first. Then I can find its quotes, flags and remaining criteria."};
  const q = question.toLowerCase();
  const numbered = q.match(/(?:rule|criterion)\s+(\d+)/);
  const rule = (numbered && active.rules.find((r) => r.i === Number(numbered[1])))
    || active.rules.find((r) => q.includes(r.text.toLowerCase()) && r.text.length > 2)
    || active.rules.find((r) => r.id === selected);
  if (/quote|source|where.*note|show.*evidence/.test(q) && rule) {
    const quotes = rule.evidence || [];
    const exact = quotes.filter((s) => active.input.note.includes(s));
    if (!quotes.length) return {text: "No quote was supplied for this criterion. Open the source note and assess the rule.", target: rule.id, source: true};
    if (!exact.length) return {text: "The supplied quote does not appear exactly in the note. Open the source note to review it.", target: rule.id, source: true};
    return {text: "Found in the source note for “" + rule.text + "”:\n" + exact.map((s) => "“" + s + "”").join("\n")
      + (exact.length < quotes.length ? "\nOther supplied quotes did not match exactly." : ""),
    target: rule.id, source: true};
  }
  if (/outcome|change.*decision|sole|block/.test(q)) {
    const key = active.order.map((id) => active.rules.find((r) => r.id === id)).find((r) => r.sole);
    if (key) return {text: "“" + key.text + "” is the only rule failing in the screening draft. Changing its assessment can change the rule summary. Review the note before recording an answer.", target: key.id};
    return {text: "No single failing rule drives this draft. Check the criteria in the queue; the rule summary is computed only after you assess each one."};
  }
  if (/flag|why|mismatch|check/.test(q) && rule && !/first|next|review.*left/.test(q)) {
    return {text: rule.issue || "No automated flag was raised for this answer. It still needs your assessment.", target: rule.id};
  }
  if (/unknown|insufficient|information/.test(q)) {
    return {text: "Choose Insufficient evidence when the note does not let you decide whether the condition is present or absent. Say what evidence is missing in your rationale."};
  }
  if (/review|first|next|remaining|progress/.test(q)) {
    const pending = active.order.filter((id) => !reviewed.has(id));
    if (!pending.length) return {text: "All " + active.rules.length + " criteria have assessments. Review your disposition and record the case, or export the review if it is already recorded."};
    const next = active.rules.find((r) => r.id === pending[0]);
    return {text: pending.length + (pending.length === 1 ? " criterion remains. " : " criteria remain. ")
      + "Start with “" + next.text + "”." + (next.issue ? " " + next.issue : ""), target: next.id};
  }
  return {text: "I can find source quotes, explain recorded flags, show which rule drives the draft, and tell you what remains to review."};
}
