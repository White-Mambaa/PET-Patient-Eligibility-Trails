import {badge, fileLink, groupOutcomes, icon, node} from "./workflow.mjs";

const percent = (value) => value == null ? "N/A" : (100 * value).toFixed(1) + "%";
const number = (value) => new Intl.NumberFormat("en-IN").format(value);
const svgNS = "http://www.w3.org/2000/svg";

function graphic(segments) {
  const s = document.createElementNS(svgNS, "svg");
  s.setAttribute("viewBox", "0 0 1000 12");
  s.setAttribute("preserveAspectRatio", "none");
  s.setAttribute("aria-hidden", "true");
  s.setAttribute("class", "chart-svg");
  const rect = (x, w, cls) => {
    const r = document.createElementNS(svgNS, "rect");
    for (const [k, v] of Object.entries({x, y: 0, width: w, height: 12, class: cls})) r.setAttribute(k, v);
    s.append(r);
  };
  rect(0, 1000, "bar-track");
  let x = 0;
  for (const [fraction, name] of segments) {
    const width = Math.max(0, Math.min(1000 - x, 1000 * fraction));
    if (width > 0) rect(x, width, "bar-" + name);
    x += width;
  }
  return s;
}

function card(label, value, detail, warn = false) {
  const k = node("article", null, "panel kpi" + (warn ? " warn" : ""));
  k.append(node("p", label, "kpi-title"), node("p", value, "kpi-value"), node("p", detail, "kpi-detail"));
  return k;
}

function section(title, subtitle) {
  const p = node("section", null, "panel analytics-panel");
  p.append(node("h2", title));
  if (subtitle) p.append(node("p", subtitle, "small muted"));
  return p;
}

function callout(title, body) {
  const c = node("div", null, "finding");
  const message = node("div");
  message.append(node("strong", title), node("p", body));
  c.append(icon("info"), message);
  return c;
}

function key(items) {
  const wrap = node("div", null, "legend");
  for (const [label, cls] of items) {
    const x = node("span", null, "legend-item");
    x.append(node("span", null, "swatch " + cls), document.createTextNode(label));
    wrap.append(x);
  }
  return wrap;
}

function pairedBar(name, x, y) {
  const wrap = node("div", null, "bar-metric");
  const rows = node("div", null, "bars");
  [[x, "Allow unknown", "unknown"], [y, "Forced guess", "forced"]].forEach(([v, label, cls]) => {
    const line = node("div", null, "bar-line");
    const value = node("span", percent(v));
    value.setAttribute("aria-label", label + ": " + percent(v));
    line.append(graphic([[v || 0, cls]]), value);
    rows.append(line);
  });
  wrap.append(node("div", name, "metric-name"), rows);
  return wrap;
}

function table(headers, rows, name) {
  const outer = node("div", null, "table-wrap");
  outer.tabIndex = 0;
  outer.setAttribute("role", "region");
  outer.setAttribute("aria-label", name);
  const t = node("table");
  const top = t.createTHead().insertRow();
  headers.forEach((k) => {
    const th = node("th", k); th.scope = "col"; top.append(th);
  });
  const body = t.createTBody();
  rows.forEach((data) => {
    const row = body.insertRow();
    data.forEach((value, i) => {
      const cell = node(i === 0 ? "th" : "td", value, i > 1 ? "num" : "");
      if (!i) cell.scope = "row";
      row.append(cell);
    });
  });
  outer.append(t);
  return outer;
}

function metrics(row) {
  return [
    row.mode, row.pairs, percent(row.binary_accuracy) + " (" + row.correct_binary + "/" + row.pairs + ")",
    row.eligible_precision == null ? "N/A" : percent(row.eligible_precision) + " (" + row.eligible_found + "/" + (row.eligible_found + row.wrong_inclusions) + ")",
    percent(row.eligible_recall) + " (" + row.eligible_found + "/" + row.reference_eligible + ")",
    percent(row.eligible_f1), row.hard_wrong_exclusions + "/" + row.reference_eligible,
    row.wrong_inclusions + "/" + row.reference_ineligible, row.review + "/" + row.pairs,
  ];
}

function studyResults(data, cohort, onCohort) {
  const rows = data.paired_development.filter((r) => r.dataset === cohort);
  const u = rows.find((r) => r.mode === "Allow unknown");
  const f = rows.find((r) => r.mode === "Forced guess");
  const wrap = node("div");
  const context = node("div", null, "eval-context");
  const heading = node("div");
  heading.append(node("h2", "Matched development cohorts"), node("p", "Qwen2.5:7B · Saved 9 November 2026", "small muted"));
  const chooser = node("div", null, "segmented");
  chooser.setAttribute("aria-label", "Select a development cohort");
  for (const id of ["Pooled", "NSCLC-100", "SIGIR-204"]) {
    const pick = node("button", id === "Pooled" ? "All cohorts" : id);
    pick.type = "button"; pick.dataset.cohort = id; pick.setAttribute("aria-pressed", String(id === cohort));
    pick.addEventListener("click", () => onCohort(id));
    chooser.append(pick);
  }
  context.append(heading, chooser);
  const kpis = node("div", null, "kpis");
  kpis.append(
    card("Matched pairs", String(u.pairs), u.reference_eligible + " reference eligible"),
    card("Binary accuracy", percent(u.binary_accuracy) + " → " + percent(f.binary_accuracy), "Allow unknown → forced guess"),
    card("Hard wrong exclusions", u.hard_wrong_exclusions + " → " + f.hard_wrong_exclusions, "Of " + u.reference_eligible + " reference-eligible pairs", true),
    card("Sent to review", u.review + " → " + f.review, "Of " + u.pairs + " matched pairs"),
  );
  const finding = callout("Fewer reviews came with more hard wrong exclusions",
    "On this cohort, forced guessing removed " + (u.review - f.review) + " review decisions. Hard wrong exclusions increased by "
    + (f.hard_wrong_exclusions - u.hard_wrong_exclusions) + ". Accuracy counts REVIEW as a negative prediction.");
  const grid = node("div", null, "analytics-grid");
  const comparison = section("Classification measures", "Pair level · Eligible is the positive class");
  comparison.append(key([["Allow unknown", "unknown"], ["Forced guess", "forced"]]));
  const bars = node("div", null, "bar-chart");
  bars.append(pairedBar("Accuracy", u.binary_accuracy, f.binary_accuracy),
    pairedBar("Eligible recall", u.eligible_recall, f.eligible_recall),
    pairedBar("Eligible F1", u.eligible_f1, f.eligible_f1));
  comparison.append(bars);
  const eligible = section("What happened to eligible pairs", u.reference_eligible + " reference-eligible pairs in each mode");
  eligible.append(key([["Screened in", "confirmed"], ["Hard wrong exclusion", "excluded"], ["Sent to review", "reviewed"]]));
  for (const row of rows) {
    const count = groupOutcomes(row).eligible;
    const outcome = node("div", null, "outcome-block");
    outcome.append(node("h3", row.mode),
      graphic([[count.met / row.reference_eligible, "confirmed"], [count.excluded / row.reference_eligible, "excluded"],
        [count.review / row.reference_eligible, "reviewed"]]),
      node("p", count.met + " screened in · " + count.excluded + " hard exclusions · " + count.review + " in review", "counts-line"));
    eligible.append(outcome);
  }
  grid.append(comparison, eligible);
  const values = section("Detailed metrics", "Counts and denominators for the selected cohort");
  values.classList.add("table-panel");
  values.append(table(["Answer mode","Pairs","Accuracy","Precision","Recall","F1","Hard wrong exclusions","Wrong inclusions","Review"],
    rows.map(metrics), "Pair-level performance measures"),
    node("p", "Precision is N/A if there are no eligible predictions. High precision here reflects few positive predictions; compare recall and the counts.", "table-note"));
  const definitions = node("details", null, "audit-details");
  definitions.append(node("summary", "Outcome counts by reference label and metric definitions"));
  const breakdown = rows.flatMap((r) => {
    const c = groupOutcomes(r);
    return [[r.mode, "Eligible", c.eligible.met, c.eligible.excluded, c.eligible.review],
      [r.mode, "Ineligible", c.ineligible.met, c.ineligible.excluded, c.ineligible.review]];
  });
  definitions.append(table(["Answer mode","Reference label","Screened in","Ruled out","Review"], breakdown, "Outcome counts by reference label"),
    node("p", "A hard wrong exclusion is a NOT_ELIGIBLE result for a reference-eligible pair. Review remains a separate outcome in the count table. For binary scores it is grouped with NOT_ELIGIBLE. Recall is the share of reference-eligible pairs screened in; F1 combines eligible precision and recall.", "table-note"));
  values.append(definitions);
  wrap.append(context, kpis, finding, grid, values);
  return wrap;
}

function auditResults(data) {
  const review = data.archive_review;
  const summary = data.legacy_development;
  const audit = review.preliminary_ai_audit;
  const priority = review.priority_ranking;
  const saved = data.checker;
  const drafts = data.reask.saved_records;
  const wrap = node("div");
  const context = node("div", null, "eval-context");
  const heading = node("div");
  heading.append(node("h2", "Evidence and checker coverage"), node("p", "October raw archive and the separate November closeout", "small muted"));
  context.append(heading, badge("Development evidence", "info"));
  const kpis = node("div", null, "kpis");
  kpis.append(
    card("October predictions", number(summary.criterion_rows), "Unique criterion records across " + summary.pairs + " pairs"),
    card("Matching evidence spans", percent(summary.verbatim_spans / summary.cited_spans),
      number(summary.verbatim_spans) + " of " + number(summary.cited_spans) + " after whitespace normalisation"),
    card("November checker coverage", saved.saved + " / " + saved.expected, saved.fully_checked_pairs + " of " + saved.expected_pairs + " NSCLC pairs fully checked"),
    card("Repair drafts", String(drafts), "Awaiting verified recheck"),
  );
  const grid = node("div", null, "analytics-grid");
  const ranking = section("Review priority at a fixed budget", "October development run · First " + priority.budget + " criteria per order");
  const b = node("div", null, "bar-chart");
  const labels = [["decision_impact","Decision impact"],["combined","Combined"],["citation","Citation"],["confidence","Confidence"],["random","Archived random"]];
  labels.forEach(([id, label]) => {
    const n = priority.eligible_single_rule_rejection_candidates[id];
    const row = node("div", null, "bar-metric");
    const line = node("div", null, "bar-line");
    line.append(graphic([[n / priority.budget, "unknown"]]), node("span", String(n)));
    row.append(node("div", label, "metric-name"), line);
    b.append(row);
  });
  ranking.append(b, node("p", "A candidate is the sole failing answer on a reference-eligible pair. Counts are retrospective, without independent confirmation of rescues.", "table-note"));
  const provenance = section("What the archive established", "Keep matching, coverage and correctness separate");
  const list = node("ul", null, "metadata");
  for (const [label, value] of [
    ["Wrong exclusions with one failing rule", summary.single_failing_rule + " / " + summary.hard_wrong_exclusions],
    ["October preliminary audit records", number(audit.unique_records)],
    ["Internally inconsistent audit suggestions", number(audit.truth_verdict_inconsistent)],
    ["Independent checker accuracy", "Unestablished"],
    ["Held-out performance", "Unestablished"],
  ]) {
    const li = node("li");
    li.append(node("span", label), node("strong", value));
    list.append(li);
  }
  provenance.append(list, node("p", "November coverage is from the saved closeout. The raw November pair decisions and checker checkpoint were absent from the archive.", "table-note"));
  grid.append(ranking, provenance);
  const docs = section("Study documents", "Original study outputs and notes-free archive verification");
  docs.classList.add("table-panel");
  const links = node("div", null, "downloads");
  links.append(fileLink("Metrics sheet", "Development_Metrics.pdf"), fileLink("Technical report", "Study_Report.pdf"),
    fileLink("Study slides", "Study_Slides.pptx"), fileLink("Archive handoff", "Archive_Handoff.pdf"),
    fileLink("Audit data", "ARCHIVE_AUDIT_NO_NOTES.json"));
  docs.append(links);
  wrap.append(context, kpis, grid, docs);
  return wrap;
}

export function renderEvaluation(parent, data, tab, cohort, onCohort) {
  parent.replaceChildren(tab === "audit" ? auditResults(data) : studyResults(data, cohort, onCohort));
}
