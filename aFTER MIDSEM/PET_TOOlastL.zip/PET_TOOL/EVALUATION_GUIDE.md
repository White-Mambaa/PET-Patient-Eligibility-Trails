# PET TOOL | Hospital evaluation guide

## Evaluate the workflow

Use a supervised session with a training case or a hospital-approved de-identified case. Have each reviewer work from the criteria and source note; the trial team retains responsibility for the actual eligibility decision.

| Task | What to observe |
| --- | --- |
| Find the rule driving the initial exclusion in the training case | Can the reviewer find the flagged criterion and open the source quote without help? |
| Save a judgement that differs from the draft | Does the reviewer understand which value was supplied and which one they recorded? Does the rationale survive criterion changes? |
| Record uncertainty on a criterion with missing information | Is it clear what remains uncertain, and can the reviewer choose to request more information? |
| Record and export the review | Do the disposition, reviewer code, timestamp, criterion decisions and rationales match the session? |
| Compare the two answer policies on one cohort | Can the reviewer explain why binary accuracy and hard wrong exclusions both rose when guessing was forced? |

For each task, capture time to complete, whether assistance was needed, any mistaken interpretation, and the reviewer’s suggested improvement. For a first exercise, the synthetic training note documents ECOG 1 and no evidence of brain metastases. After recording judgements and rationales for both criteria, the reviewer can choose the trial-team handoff disposition. This tests the controls on a known case.

## What the result tabs show

- **Policy comparison:** 152 matched development pairs across two cohorts, with explicit denominators for classification and review workload. `REVIEW` counts as negative in binary accuracy, but stays separate in the outcome counts.
- **Evidence & audit:** October raw record verification, the retrospective ranking comparison at 50 checks, and November closeout coverage. Matching spans and saved checker coverage are different measurements from clinical correctness.
- Independent clinical checker accuracy, accepted repair effectiveness, and held-out performance have not been established. This release does not include shared accounts, EHR integration, a persistent audit store or an authenticated reviewer identity. Those require a separate site and deployment review before handling identifiable records or using the tool for care.

## Design references

- [NHS digital service manual: colour](https://service-manual.nhs.uk/design-system/styles/colour) and [components](https://service-manual.nhs.uk/design-system/components). PET uses its own navy and teal palette, clear status text, distinct review flags and consistently grouped controls.
- [FDA: independently reviewing the basis of clinical decision support](https://www.fda.gov/medical-devices/digital-health-center-excellence/step-6-software-function-intended-provide-clinical-decision-support). The design shows the source quote, draft and checks separately and requires the reviewer's own judgement and rationale. This is a design reference.
- [DECIDE-AI: early-stage clinical evaluation reporting](https://www.bmj.com/content/377/bmj-2022-070904). The suggested tasks check human interpretation and workflow as well as whether the software runs.
