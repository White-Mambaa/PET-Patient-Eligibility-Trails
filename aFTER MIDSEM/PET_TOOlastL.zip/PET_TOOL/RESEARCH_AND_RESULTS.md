# Research question, implementation and evidence

## Project question

Can we use the effect of a rule on the pair decision to guide where a human reviewer spends a limited review budget? An unsupported answer can drive an exclusion even when the other answers are correct.

| Reference named in the project guide | What it contributes | What this MTP delivers |
| --- | --- | --- |
| Jin et al., [Matching patients to clinical trials with large language models](https://doi.org/10.1038/s41467-024-53081-z), *Nature Communications* (2024), TrialGPT | Criterion-level assessment with explanations and locations of supporting sentences | The Qwen screening baseline returns criterion truth and evidence. A separate checker inspects the quote, support, context, logic, contradictions and missed evidence. |
| Zhou et al., [Accountable AI with Grounded, Faithful, Consistent, Actionable Rationales: A Case Study in Clinical Trial Matching with VERDICT](https://arxiv.org/abs/2609.03366), preprint (2026) | Pivotal conditions and a test of how changing them affects the decision | The tool uses an explicit pair rule to measure the effect of changing one criterion at a time. It surfaces flagged failing rules, especially a sole reason for rejection, for review. |

These references motivate the approach. The delivered system uses its own pair aggregation and experimental setup. The literature scores cannot be compared directly with the development pair scores here.

## Measured and exploratory output

1. **Paired development experiment.** Local Qwen2.5:7B screened the same 50 NSCLC-100 and 102 SIGIR-204 pairs with both answer policies. Allow unknown produced **52.6% pooled binary accuracy, 2.7% eligible recall and 5.3% F1**. Forced guess produced **57.2% accuracy, 12.2% recall and 21.7% F1**. REVIEW counts as negative in these binary scores. Forced guessing reduced review from **88 to 0** and increased hard wrong exclusions from **27 to 65** among **74 reference-eligible pairs**. The dataset breakdown and precision denominators are in the metrics PDF.
2. **Earlier, separate Qwen development baseline.** Recomputed from 1,940 archived criterion predictions: **22 of 28** wrong exclusions had a single failing rule. **980 of 1,099** cited spans matched after normalising whitespace. A text match does not establish whether the quote supports the answer.
3. **Exploratory ranking comparison.** In the October backup, all five orders cover the same 1,940 criteria. At a budget of 50 checks, the archived combined and decision-impact orders each surfaced **22** reference-defined candidates; the citation, confidence and archived random orders surfaced **1, 0 and 0**. A candidate is the sole failing answer on a reference-eligible pair. This is a retrospective count, without independent criterion adjudication or a measured patient rescue rate.
4. **Checker and repair status.** The 9 November offline closeout recorded **706 of 950** saved legacy NSCLC development checker judgments and **36 of 50** fully checked pairs. The repair pilot saved **20 parseable drafts**. These are closeout counts. The raw November checkpoint and pair decisions are absent from the archive. Accepted repairs, independent checker precision and recall, and held-out performance were unavailable at closeout.
5. **Runnable output.** The deterministic example exercises the six-check software, the review order, the effect of deferral and acceptance of a repair after recheck. It demonstrates the implementation on a synthetic case.

## Audit trail

- `RESULTS/RESULTS_SNAPSHOT.json` records the source, date, scope and raw counts used in the reports.
- `python3 START_PET.py --metrics-csv` rebuilds the six result rows from that snapshot. The numerator for binary accuracy is eligible pairs correctly predicted plus reference-ineligible pairs not predicted eligible. The positive class for precision, recall and F1 is ELIGIBLE.
- `python3 START_PET.py --demo-json` reruns the software example and prints its structured result.
- The exploratory ranking comparison was recomputed from the October backup's archived rankings and pair reference labels. `ARCHIVE_REVIEW.md` describes how to reproduce it and how it differs from the later comparison.
