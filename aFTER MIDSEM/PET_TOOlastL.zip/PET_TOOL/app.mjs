import {
  answerQuestion, badge, button, checks, dispositionOptions, dispositions, icon, judgementNames,
  node, resultNames, reviewedResult, suppliedModel, trainingModel,
} from "./workflow.mjs";
import {renderEvaluation} from "./evaluation.mjs";

const $ = (id) => document.getElementById(id);
const pages = {review: "Review desk", evaluation: "Evaluation", guide: "Using PET"};
const state = {
  active: null, selected: null, reviewed: new Map(), drafts: new Map(), recorded: null, exported: false,
  filter: "all", evaluation: "comparison", cohort: "Pooled", results: null, loadingResults: false,
};
let noticeTimer;
let caseRequest = 0;
let visiblePage = "review";
const nl = new Intl.DateTimeFormat(undefined, {dateStyle: "medium", timeStyle: "short"});
const ruleType = (rule) => rule.kind === "inclusion" ? "Inclusion" : "Exclusion";
const currentRule = () => state.active?.rules.find((r) => r.id === state.selected);
const orderedRules = () => state.active ? state.active.order.map((id) => state.active.rules.find((r) => r.id === id)) : [];

async function api(route, payload) {
  const options = payload === undefined ? {} : {
    method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify(payload),
  };
  const response = await fetch("/api/" + route, options);
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "The workspace could not complete this action.");
  return data;
}

function notice(message) {
  clearTimeout(noticeTimer);
  const n = $("notice");
  n.textContent = message;
  n.hidden = false;
  noticeTimer = setTimeout(() => { n.hidden = true; }, 3400);
}

function changed() {
  return !state.exported && (state.reviewed.size > 0 ||
    [...state.drafts.values()].some((r) => Boolean(r.truth || r.rationale?.trim())));
}

function canReplace() {
  return !changed() || window.confirm("This case has review work that has not been exported. Open a different case and discard it?");
}

window.addEventListener("beforeunload", (e) => {
  if (changed()) {
    e.preventDefault();
    e.returnValue = "";
  }
});

function setPage() {
  const requested = location.hash.slice(1);
  const page = Object.hasOwn(pages, requested) ? requested : requested === "content" ? visiblePage : "review";
  visiblePage = page;
  for (const name of Object.keys(pages)) $("page-" + name).hidden = name !== page;
  document.querySelectorAll("[data-page]").forEach((a) => {
    if (a.dataset.page === page) a.setAttribute("aria-current", "page");
    else a.removeAttribute("aria-current");
  });
  $("breadcrumb-page").textContent = pages[page];
  if (page === "evaluation") loadResults();
}

function showResults() {
  if (!state.results) return;
  renderEvaluation($("evaluation-body"), state.results, state.evaluation, state.cohort, (id) => {
    state.cohort = id;
    showResults();
    [...document.querySelectorAll("[data-cohort]")].find((b) => b.dataset.cohort === id)?.focus();
  });
}

async function loadResults() {
  if (state.results) return showResults();
  if (state.loadingResults) return;
  state.loadingResults = true;
  const box = $("evaluation-body");
  try {
    state.results = await api("results");
    showResults();
  } catch {
    const failure = node("div", null, "loading");
    failure.append(node("p", "The archived results could not be opened."), button("Try again", "secondary", loadResults));
    box.replaceChildren(failure);
  } finally {
    state.loadingResults = false;
  }
}

function resetCase(model) {
  state.active = model;
  state.selected = model.order[0];
  state.reviewed.clear();
  state.drafts.clear();
  state.recorded = null;
  state.exported = false;
  state.filter = "all";
  $("messages").replaceChildren();
  $("case-status").hidden = true;
  $("case-workspace").hidden = false;
  renderCase();
}

async function openTraining(initial = false) {
  if (!initial && !canReplace()) return;
  const version = ++caseRequest;
  const trigger = $("load-training");
  const status = $("case-status");
  trigger.disabled = true;
  if (!state.active) {
    status.hidden = false;
    status.textContent = "Opening the training case…";
  }
  try {
    const [input, demo] = await Promise.all([api("review-example"), api("demo", {})]);
    if (version !== caseRequest) return;
    resetCase(trainingModel(input, demo));
    if (!initial) notice("Training case opened.");
  } catch {
    if (version !== caseRequest) return;
    if (!state.active) status.textContent = "The training case could not be opened. Select Training case to retry.";
    else notice("The training case could not be opened.");
  } finally {
    trigger.disabled = false;
  }
}

function renderCaseBand() {
  const {input, training} = state.active;
  const wrap = $("case-band");
  const context = node("div", null, "case-context");
  const emblem = node("div", null, "case-icon");
  emblem.append(icon("file"));
  const label = node("div");
  label.append(node("p", "Current case", "eyebrow"), node("div", input.case_id, "case-title"),
    node("p", input.trial || "Protocol not specified", "case-trial"));
  context.append(emblem, label);
  const statuses = node("div", null, "case-badges");
  const count = state.reviewed.size;
  statuses.append(badge(training ? "Training case" : "Evaluation case", "light"),
    badge(state.recorded ? "Review recorded" : count === 0 ? "Awaiting review" : "In review", state.recorded ? "good" : "info"));
  wrap.replaceChildren(context, statuses);
}

function focusRule(id, source = false, focus = true) {
  if (!state.active?.rules.some((r) => r.id === id)) return;
  state.selected = id;
  const visible = state.filter === "all" || (state.filter === "saved") === state.reviewed.has(id);
  if (!visible) state.filter = "all";
  renderQueue();
  renderDetail(source);
  if (focus) $("selected-rule-title")?.focus();
}

function renderQueue() {
  const all = orderedRules();
  const items = all.filter((r) => state.filter === "all" || (state.filter === "saved") === state.reviewed.has(r.id));
  const list = $("criteria-list");
  $("queue-count").textContent = all.length;
  $("queue-filter").querySelectorAll("button").forEach((b) => {
    b.setAttribute("aria-pressed", String(b.dataset.filter === state.filter));
  });
  list.replaceChildren();
  if (!items.length) list.append(node("li", state.filter === "saved" ? "No assessments recorded yet." : "All criteria in this case have assessments.", "empty"));
  for (const rule of items) {
    const done = state.reviewed.has(rule.id);
    const li = node("li");
    const b = node("button", null, "criterion-button");
    b.type = "button";
    if (rule.id === state.selected) b.setAttribute("aria-current", "true");
    const index = node("span", done ? null : String(rule.i).padStart(2, "0"), "rule-index");
    if (done) index.append(icon("check"));
    const content = node("span");
    content.append(node("span", ruleType(rule), "rule-meta"), node("span", rule.text, "rule-name"),
      done ? badge(judgementNames[state.reviewed.get(rule.id).truth], "good")
        : rule.issue ? badge("Check flagged", "attn") : badge("To review"));
    b.append(index, content);
    b.addEventListener("click", () => focusRule(rule.id));
    li.append(b);
    list.append(li);
  }
  const area = $("case-progress");
  const title = node("div", null, "progress-label");
  title.append(node("span", "Reviewer progress"), node("span", state.reviewed.size + " of " + all.length, "tabular"));
  const progress = node("progress");
  progress.max = all.length;
  progress.value = state.reviewed.size;
  progress.setAttribute("aria-label", "Criteria with saved assessments");
  const done = state.recorded
    ? button("Export review record", "primary", exportReview, "download")
    : button("Record review", "primary", openRecord, "arrow");
  done.id = "review-complete";
  done.disabled = !state.recorded && (state.reviewed.size !== all.length || pendingEdits());
  area.replaceChildren(title, progress, node("p", state.recorded ? "Review completed for this session."
    : state.reviewed.size !== all.length ? "Assess every criterion to record the review." : "Ready for your confirmation.", "small muted"), done);
}

function appendNote(parent, note, quotes) {
  const spans = [...new Set(quotes)].map((quote) => ({quote, start: note.indexOf(quote)}))
    .filter((s) => s.start >= 0).sort((a,b) => a.start - b.start);
  let end = 0;
  for (const {quote, start} of spans) {
    if (start < end) continue;
    parent.append(document.createTextNode(note.slice(end, start)), node("mark", quote));
    end = start + quote.length;
  }
  parent.append(document.createTextNode(note.slice(end)));
}

function evidencePanel(rule, showSource) {
  const wrap = node("section", null, "evidence");
  const heading = node("h3", null, "evidence-title");
  heading.append(icon("file"), document.createTextNode("Source evidence"));
  wrap.append(heading);
  const note = state.active.input.note;
  for (const quote of rule.evidence || []) {
    const block = node("blockquote", null, "quote");
    block.append(node("span", "“" + quote + "”"), note.includes(quote) ? badge("Exact match", "good") : badge("Not found", "attn"));
    wrap.append(block);
  }
  if (!rule.evidence?.length) wrap.append(node("p", "No quote supplied. Read the source note to make your assessment.", "small muted"));
  const d = node("details", null, "source-details");
  d.open = showSource;
  const full = node("div", null, "source-note");
  full.tabIndex = 0;
  appendNote(full, note, rule.evidence || []);
  d.append(node("summary", "Open source note"), full);
  wrap.append(d);
  return wrap;
}

function draftPanel(rule) {
  const d = node("details", null, "audit-details");
  d.append(node("summary", "Screening draft and evidence checks"));
  d.append(node("p", rule.draftNote + ": " + judgementNames[rule.truth] + ".", "small muted"));
  const grid = node("dl", null, "check-grid");
  for (const [k, title] of Object.entries(checks)) grid.append(node("dt", title), node("dd", rule.checks[k]));
  d.append(grid);
  if (!state.active.training) d.append(node("p", "Exact quote and limited numeric checks are available for supplied answers.", "small muted"));
  return d;
}

function assessmentPanel(rule) {
  const done = state.reviewed.get(rule.id);
  const draft = state.drafts.get(rule.id) || done || {};
  const readonly = Boolean(state.recorded);
  const form = node("form", null, "assessment");
  form.append(node("h3", "Your assessment"),
    node("p", "Based on the evidence, is the condition present?", "small muted"));
  const choices = node("fieldset", null, "choices");
  choices.append(node("legend", "Criterion judgement", "sr-only"));
  for (const [truth, label] of Object.entries(judgementNames)) {
    const item = node("label", null, "choice");
    const radio = node("input");
    radio.type = "radio"; radio.name = "judgement"; radio.value = truth;
    radio.checked = draft.truth === truth; radio.required = true; radio.disabled = readonly;
    radio.addEventListener("change", () => {
      state.drafts.set(rule.id, {...(state.drafts.get(rule.id) || draft), truth});
      state.exported = false;
      renderQueue();
    });
    item.append(radio, document.createTextNode(label));
    choices.append(item);
  }
  const rationale = node("textarea");
  rationale.rows = 2; rationale.required = true; rationale.maxLength = 2000; rationale.readOnly = readonly;
  rationale.value = draft.rationale || "";
  rationale.placeholder = "State what supports your answer or what is missing.";
  rationale.addEventListener("input", () => {
    state.drafts.set(rule.id, {...(state.drafts.get(rule.id) || draft), rationale: rationale.value});
    state.exported = false;
    const gate = $("review-complete");
    if (gate) gate.disabled = state.reviewed.size !== state.active.rules.length || pendingEdits();
  });
  const reason = node("label", "Rationale");
  reason.append(rationale);
  const actions = node("div", null, "assessment-actions");
  const error = node("span", "", "form-error");
  error.setAttribute("role", "alert");
  const save = button(readonly ? "Assessment recorded" : done ? "Update assessment" : "Save and continue", "primary", null, readonly ? "check" : "arrow");
  save.type = "submit"; save.disabled = readonly;
  actions.append(error, save);
  form.append(choices, reason, actions);
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    if (state.recorded) return;
    const truth = form.querySelector('input[name="judgement"]:checked')?.value;
    if (!truth || !rationale.value.trim()) {
      error.textContent = "Choose a judgement and enter your rationale.";
      return;
    }
    state.reviewed.set(rule.id, {truth, rationale: rationale.value.trim()});
    state.drafts.delete(rule.id);
    state.exported = false;
    const next = orderedRules().find((item) => !state.reviewed.has(item.id));
    if (next) {
      state.selected = next.id;
      if (state.filter === "saved") state.filter = "all";
    }
    renderCase();
    if (next && next.id !== rule.id) $("selected-rule-title")?.focus();
    else if ($("review-complete") && !$("review-complete").disabled) $("review-complete").focus();
    notice(next ? "Assessment saved." : "All criteria assessed. Record the review when ready.");
  });
  return form;
}

function renderDetail(showSource = false) {
  const rule = currentRule();
  const detail = $("criterion-detail");
  if (!rule) return detail.replaceChildren(node("p", "Choose a criterion from the queue.", "empty"));
  const head = node("div", null, "detail-header");
  const label = node("div");
  const h = node("h2", rule.text);
  h.id = "selected-rule-title"; h.tabIndex = -1;
  label.append(node("p", "Criterion " + String(rule.i).padStart(2, "0"), "eyebrow"), h);
  head.append(label, badge(ruleType(rule), "info"));
  const sub = node("p", rule.kind === "exclusion"
    ? "A condition that is present may block trial screening." : "A condition that is present supports this inclusion rule.", "detail-sub");
  detail.replaceChildren(head, sub);
  if (rule.issue || rule.sole) {
    const flag = node("div", null, "flag-note");
    flag.append(icon("info"), node("p", (rule.sole ? "This is the only failing rule in the draft. " : "") + rule.issue));
    detail.append(flag);
  }
  detail.append(evidencePanel(rule, showSource), assessmentPanel(rule), draftPanel(rule));
}

function renderReceipt() {
  const target = $("recorded-card");
  const rec = state.recorded;
  target.hidden = !rec;
  if (!rec) return target.replaceChildren();
  const head = node("div", null, "receipt-head");
  const title = node("div");
  title.append(node("p", "PET TOOL · Reviewer record", "eyebrow"), node("h2", dispositions[rec.reviewer_disposition]),
    node("p", rec.case_reference + " · " + rec.trial, "receipt-note small muted"));
  const actions = node("div", null, "actions");
  actions.append(button("Reopen review", "secondary", () => {
    if (!window.confirm("Reopen this case? Export the current review first if you need to keep it.")) return;
    state.recorded = null; state.exported = false; renderCase();
    notice("Review reopened. Record it again after any changes.");
  }), button("Print review", "secondary", printReview, "file"),
  button("Export JSON", "primary", exportReview, "download"));
  head.append(title, actions);
  const items = node("dl", null, "receipt-grid");
  for (const [key, value] of [
    ["Reviewer ID", rec.reviewer_id],
    ["Recorded", nl.format(new Date(rec.recorded_at))],
    ["Rule summary", resultNames[rec.derived_rule_status]],
  ]) {
    const entry = node("div");
    entry.append(node("dt", key), node("dd", value)); items.append(entry);
  }
  const list = node("ol", null, "receipt-rules");
  for (const a of rec.assessments) {
    const row = node("li");
    const summary = node("div", null, "receipt-rule-heading");
    summary.append(node("strong", a.criterion), badge(judgementNames[a.reviewer_judgement], "info"));
    row.append(summary, node("p", a.rationale, "small muted"));
    list.append(row);
  }
  target.replaceChildren(head, items, list,
    node("p", "The export includes the reviewer’s rationale. Source note and quote fields are omitted.", "receipt-note small muted"));
}

function renderCase() {
  renderCaseBand(); renderQueue(); renderDetail(); renderReceipt();
}

function pendingEdits() {
  return [...state.drafts].some(([id, draft]) => {
    const done = state.reviewed.get(id);
    return done && (draft.truth !== done.truth || draft.rationale?.trim() !== done.rationale);
  });
}

function openRecord() {
  if (!state.active || state.recorded) return;
  const status = reviewedResult(state.active.rules, state.reviewed);
  if (!status || pendingEdits()) {
    notice("Save every assessment and any edits before recording the review.");
    return;
  }
  $("record-form").reset();
  $("record-error").textContent = "";
  $("record-preview").textContent = "Rule summary from your assessments: " + resultNames[status] + ".";
  const field = $("review-disposition");
  field.replaceChildren();
  const placeholder = node("option", "Select a disposition");
  placeholder.value = ""; placeholder.disabled = true; placeholder.selected = true;
  field.append(placeholder);
  for (const option of dispositionOptions(status)) {
    const o = node("option", dispositions[option]); o.value = option; field.append(o);
  }
  $("record-dialog").showModal();
}

function exportReview() {
  const rec = state.recorded;
  if (!rec) return;
  const link = node("a");
  const url = URL.createObjectURL(new Blob([JSON.stringify(rec, null, 2) + "\n"], {type: "application/json"}));
  link.href = url;
  link.download = "PET-review-" + rec.review_id.slice(0, 8) + ".json";
  document.body.append(link); link.click(); link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
  state.exported = true;
  notice("Review export prepared.");
}

function printReview() {
  if (!state.recorded) return;
  document.body.classList.add("print-review");
  window.addEventListener("afterprint", () => document.body.classList.remove("print-review"), {once: true});
  window.print();
}

function appendRule() {
  const box = $("input-rules");
  if (box.children.length >= 40) { $("case-error").textContent = "Up to 40 criteria can be added."; return; }
  const row = node("div", null, "input-rule");
  const top = node("div", null, "input-rule-title");
  const title = node("strong", "Criterion " + (box.children.length + 1));
  top.append(title, button("Remove", "quiet", () => {
    if (box.children.length === 1) { $("case-error").textContent = "Keep at least one criterion."; return; }
    row.remove(); renumberRules();
  }));
  const label = (text, control, key) => {
    const field = node("label", text);
    control.dataset.rule = key; field.append(control); return field;
  };
  const select = (pairs) => {
    const s = node("select");
    pairs.forEach(([val, text]) => { const o = node("option", text); o.value = val; s.append(o); });
    return s;
  };
  const text = node("input"); text.maxLength = 3000; text.required = true; text.placeholder = "Enter the criterion as written in the protocol";
  const choices = node("div", null, "two-fields");
  choices.append(label("Criterion type", select([["inclusion","Inclusion"],["exclusion","Exclusion"]]), "kind"),
    label("Screening answer", select([["unknown","No answer supplied"],["yes","Present"],["no","Absent"]]), "truth"));
  const quote = node("textarea"); quote.rows = 2; quote.maxLength = 12000; quote.placeholder = "Optional — one exact quote per line";
  row.append(top, label("Criterion text", text, "text"), choices, label("Evidence quotes", quote, "evidence"));
  box.append(row);
}

function renumberRules() {
  [...$("input-rules").children].forEach((row, i) => {
    row.querySelector(".input-rule-title strong").textContent = "Criterion " + (i + 1);
  });
}

function normaliseImport(raw) {
  if (!raw || typeof raw !== "object" || Array.isArray(raw) ||
      typeof raw.case_id !== "string" || typeof raw.note !== "string" || !Array.isArray(raw.criteria)) {
    throw new Error("The JSON file needs a case_id, note and criteria list.");
  }
  const trial = raw.trial ?? "";
  if (typeof trial !== "string" || trial.trim().length > 160) throw new Error("Protocol must be text of up to 160 characters.");
  return {
    case_id: raw.case_id.trim(), trial: trial.trim() || "Protocol not specified", note: raw.note,
    criteria: raw.criteria.map((r) => {
      if (!r || typeof r !== "object" || Array.isArray(r)) throw new Error("Each criterion must be a JSON object.");
      return {id: r.id, kind: r.kind, text: r.text, truth: r.truth ?? "unknown", evidence: r.evidence ?? []};
    }),
  };
}

async function openCase(raw) {
  const input = normaliseImport(raw);
  if (!canReplace()) return;
  const version = ++caseRequest;
  const trigger = $("open-case-button");
  const file = $("case-file");
  trigger.disabled = true; file.disabled = true;
  $("case-error").textContent = "";
  try {
    const result = await api("review", input);
    if (version !== caseRequest) return;
    resetCase(suppliedModel(input, result));
    $("case-dialog").close();
    if (location.hash !== "#review") location.hash = "review";
    notice("Case opened for review.");
  } finally {
    trigger.disabled = false; file.disabled = false;
  }
}

function ask(q) {
  const question = q.trim();
  if (!question) return;
  const log = $("messages");
  const input = node("article", null, "message mine");
  input.append(node("p", "You", "speaker"), node("p", question));
  const output = node("article", null, "message");
  const answer = answerQuestion(question, state.active, state.selected, state.reviewed);
  output.append(node("p", "PET", "speaker"), node("p", answer.text));
  if (answer.target) output.append(button(answer.source ? "Open source note" : "Go to criterion", "quiet", () => {
    $("ask-dialog").close();
    if (location.hash !== "#review") { location.hash = "review"; setPage(); }
    focusRule(answer.target, answer.source);
  }, "arrow"));
  log.append(input, output);
  while (log.children.length > 24) log.firstChild.remove();
  log.scrollTop = log.scrollHeight;
  $("question").value = "";
}

$("new-case").addEventListener("click", () => {
  $("case-form").reset();
  $("case-error").textContent = "";
  $("input-rules").replaceChildren();
  appendRule();
  $("case-dialog").showModal();
});
$("load-training").addEventListener("click", () => openTraining());
$("add-rule").addEventListener("click", () => { $("case-error").textContent = ""; appendRule(); });
$("case-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const raw = {case_id: $("input-case-id").value, trial: $("input-trial").value, note: $("input-note").value,
    criteria: [...$("input-rules").children].map((row, i) => {
      const get = (k) => row.querySelector('[data-rule="' + k + '"]').value;
      return {id: "criterion-" + (i + 1), kind: get("kind"), truth: get("truth"), text: get("text").trim(),
        evidence: get("evidence").split("\n").map((s) => s.trim()).filter(Boolean)};
    })};
  try { await openCase(raw); }
  catch (error) { $("case-error").textContent = error.message; }
});
$("case-file").addEventListener("change", async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  try {
    if (file.size > 384 * 1024) throw new Error("Choose a JSON case smaller than 384 KB.");
    let payload;
    try { payload = JSON.parse(await file.text()); }
    catch { throw new Error("The selected file is not valid JSON."); }
    await openCase(payload);
  } catch (error) {
    $("case-error").textContent = error.message;
  } finally { e.target.value = ""; }
});
$("record-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const active = state.active;
  if (!active || pendingEdits() || state.recorded) return;
  const b = $("record-button");
  b.disabled = true;
  $("record-error").textContent = "";
  try {
    const record = await api("record", {
      case: active.input, reviewer: $("reviewer-id").value.trim(),
      disposition: $("review-disposition").value, confirmed: $("review-confirmed").checked,
      assessments: [...state.reviewed].map(([id, a]) => ({id, ...a})),
    });
    if (active !== state.active) return;
    state.recorded = record; state.exported = false;
    $("record-dialog").close();
    renderCase();
    $("recorded-card").scrollIntoView({block: "nearest"});
    notice("Review recorded. Export a copy before closing.");
  } catch (error) {
    $("record-error").textContent = error.message;
  } finally { b.disabled = false; }
});
$("queue-filter").querySelectorAll("button").forEach((b) => b.addEventListener("click", () => {
  state.filter = b.dataset.filter; renderQueue();
}));
$("open-assistant").addEventListener("click", () => $("ask-dialog").showModal());
document.querySelectorAll("[data-close]").forEach((b) => b.addEventListener("click", () => $(b.dataset.close).close()));
document.querySelectorAll("[data-question]").forEach((b) => b.addEventListener("click", () => ask(b.dataset.question)));
document.querySelectorAll("[data-evaluation]").forEach((b) => b.addEventListener("click", () => {
  state.evaluation = b.dataset.evaluation;
  document.querySelectorAll("[data-evaluation]").forEach((other) => other.setAttribute("aria-pressed", String(other === b)));
  loadResults();
}));
$("ask-form").addEventListener("submit", (e) => { e.preventDefault(); ask($("question").value); });
window.addEventListener("hashchange", setPage);
setPage();
openTraining(true);
