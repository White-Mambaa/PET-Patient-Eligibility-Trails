# What the uploaded archive verifies

The upload is a collection of project snapshots, scripts and prior submissions. The review found **140 files** in the outer archive and checked **21 ZIP occurrences** including nested copies. All ZIP integrity checks passed. The **110** checksummed entries in the October backup and **8** checksummed entries in the November submission matched. Historical utilities were inventoried; the supported software entry point for this release is `START_PET.py`.

## 1. October backup: recomputed from the raw records

Source: `MTP_Neha_Maam_Full_Project_20261014_204759.zip` within `All MTP.tar.xz`. Its stored corpus and split files identify the development pairs and criteria. Every baseline prediction was matched to its development pair and criterion. The audit checked record IDs, model name and truth-to-verdict mapping without making model requests.

| Dataset | Development pairs | Unique criterion predictions | Hard wrong exclusions | With one failing rule | Matched evidence spans |
|---|---:|---:|---:|---:|---:|
| NSCLC-100 | 50 | 950 | 11 | 9 | 443/497 |
| SIGIR-204 | 102 | 990 | 17 | 13 | 537/602 |
| Total | 152 | 1,940 | 28 | 22 | 980/1,099 |

Evidence span matching is an exact substring check after whitespace normalisation. The older citation-status export covers the same 1,940 criterion IDs (879 PASS, 118 FAIL, 943 NO_EVIDENCE). The preliminary Qwen audit also covers those 1,940 IDs. **669 suggestions disagree with their own truth-to-verdict mapping**; this is an internal consistency check.

### Ranking and repair exploration

The 9,700 ranking rows cover the same 1,940 criteria in each of five orders. The review recomputed the candidate labels from the dataset references and the baseline decisions.

| Review order | Reference-defined candidates among first 50 checks |
|---|---:|
| Archived random order | 0 |
| Confidence | 0 |
| Citation | 1 |
| Decision impact | 22 |
| Combined | 22 |

A candidate is the sole failing rule on a reference-eligible pair. This compares the archived orders on the development set at one fixed budget; it does not show that a reviewer actually corrected any of these cases. The 44-case annotation sample is the union of the five top-ten lists. It contains 42 scorable assistant proposals and 12 disagreements with the baseline. Eleven of the 12 simulated substitutions change a pair decision. The independent adjudication sheet has zero filled truth labels. Three manually checked trap inputs are present; a trap performance estimate is not established.

## 2. November submission: checked against the saved closeout

Source: `MTP_SUBMISSION.zip`. Its four mode/dataset count rows agree with the report snapshot. Accuracy, eligible recall and F1 were recomputed from those counts. The 9 November closeout identifies the four source CSVs by SHA-256. The archive does not include those CSVs, the raw November checker checkpoint or the individual re-ask records.

- **Allow unknown:** 80/152 binary accuracy (52.6%), 27/74 hard wrong exclusions, 88 reviews.
- **Forced guess:** 87/152 binary accuracy (57.2%), 65/74 hard wrong exclusions, no reviews.
- **Separate NSCLC checker:** 706/950 saved judgments, 36/50 pairs fully checked, according to the closeout. The archived October NSCLC prediction file matches the source hash recorded for that checkpoint.
- **Repair pilot:** 20 parseable drafts recorded in the closeout; accepted repairs require a verified recheck.

The October and November runs are distinct. The October preliminary audit's 1,940 records are from a different checker workflow and should not be combined with the November 706/950 coverage. The evidence does not establish independent checker accuracy or held-out performance.

## 3. Software and files to share

The release brings the checked reports and original notes-free closeout into one package with the local reviewer, deterministic demo and local Qwen CLI source. The archive's private inputs and case-level outputs, duplicate old builds, bytecode caches, annotation runners and unrelated book collector are kept outside the panel package.

- **Original November evidence:** `RESULTS/CLOSEOUT_EVIDENCE_NO_NOTES.json`.
- **Machine-readable archive review:** `RESULTS/ARCHIVE_AUDIT_NO_NOTES.json`.
- **Reproduce from the original archive:** `python3 VERIFY_SOURCE_ARCHIVE.py "/path/to/All MTP.tar.xz"`.
- **Check the packaged tool:** `python3 START_PET.py --self-test`. **Check file integrity:** `sha256sum -c SHA256SUMS.txt`.
