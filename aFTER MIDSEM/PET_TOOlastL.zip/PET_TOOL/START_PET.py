#!/usr/bin/env python3
"""Open PET TOOL, the patient eligibility trials review workspace (Python 3.10+)."""

import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import re
import sys
from urllib.parse import urlsplit
from uuid import uuid4
import webbrowser

ROOT = Path(__file__).resolve().parent
ENGINE = ROOT / "ENGINE"
RESULTS = ROOT / "RESULTS"
sys.path[:0] = [str(ENGINE / "code"), str(ENGINE)]

from criteria import decide, map_truth, what_could_change
from mtp_completion.numeric import MEASURES, numeric_expected
from mtp_week_delivery import self_test as run_engine_demo

MAX_BODY = 384 * 1024
CHECKS = ("citation", "entailment", "context", "logic", "contradiction", "missed_evidence")
OFFLINE_SCOPE = "Exact quotes and simple numeric comparisons only. Semantic checks require further review."
COUNT_FIELDS = (
    "pairs", "reference_eligible", "reference_ineligible", "eligible_found",
    "hard_wrong_exclusions", "wrong_inclusions", "review",
)
RESULT_DOWNLOADS = {
    "Archive_Handoff.pdf": "application/pdf",
    "Development_Metrics.pdf": "application/pdf",
    "Study_Report.pdf": "application/pdf",
    "PAIRED_DEVELOPMENT_RESULTS.csv": "text/csv; charset=utf-8",
    "RESULTS_SNAPSHOT.json": "application/json",
    "ARCHIVE_AUDIT_NO_NOTES.json": "application/json",
    "SYNTHETIC_DEMO_OUTPUT.json": "application/json",
    "Study_Slides.pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
}
STATIC = {
    "/": (ROOT / "index.html", "text/html; charset=utf-8", None),
    **{"/" + name: (ROOT / name, "text/javascript; charset=utf-8", None)
       for name in ("app.mjs", "evaluation.mjs", "workflow.mjs")},
    "/style.css": (ROOT / "style.css", "text/css; charset=utf-8", None),
    "/pet.svg": (ROOT / "pet.svg", "image/svg+xml", None),
    **{"/results/" + f: (RESULTS / f, mime, f) for f, mime in RESULT_DOWNLOADS.items()},
}


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf-8")


def division(a, b):
    return a / b if b else None


def score(row):
    n, pos, neg, tp, hard, fp, review = (row[k] for k in COUNT_FIELDS)
    if (any(type(row[k]) is not int or row[k] < 0 for k in COUNT_FIELDS)
            or pos + neg != n or tp + hard > pos or fp > neg
            or not pos - tp - hard <= review <= n - tp - fp - hard):
        raise ValueError("The frozen result counts are inconsistent.")
    tn, fn = neg - fp, pos - tp
    return {
        **row, "correct_binary": tp + tn,
        "binary_accuracy": division(tp + tn, n),
        "eligible_precision": division(tp, tp + fp),
        "eligible_recall": division(tp, pos),
        "eligible_f1": division(2 * tp, 2 * tp + fp + fn),
    }


def load_results():
    data = json.loads((RESULTS / "RESULTS_SNAPSHOT.json").read_text(encoding="utf-8"))
    audit = json.loads((RESULTS / "ARCHIVE_AUDIT_NO_NOTES.json").read_text(encoding="utf-8"))
    closeout = audit["november_closeout"]
    rows = data["paired_development"]
    cohorts = {"NSCLC-100": 50, "SIGIR-204": 102}
    modes = ("Allow unknown", "Forced guess")
    expected = {(d, m): n for d, n in cohorts.items() for m in modes}
    if len(rows) != len(expected) or {(r["dataset"], r["mode"]): r["pairs"] for r in rows} != expected:
        raise ValueError("The frozen paired result table is incomplete.")
    pooled = [
        {"dataset": "Pooled", "mode": mode, **{
            k: sum(r[k] for r in rows if r["mode"] == mode) for k in COUNT_FIELDS
        }}
        for mode in modes
    ]
    return {
        "scope": data["scope"], "model": data["model"],
        "checker": {**data["checker"], **closeout["checker"]},
        "legacy_development": data["legacy_development"], "reask": data["reask"],
        "archive_review": audit["october_raw_recomputed"],
        "held_out": data["held_out"], "paired_development": [score(r) for r in rows + pooled],
    }


def demo():
    result = run_engine_demo()
    result["scope"] = "Synthetic example with deterministic model responses; software test only."
    result["simulated_responses"] = result.pop("generation_attempts")
    return result


REVIEW_EXAMPLE = {
    "case_id": "PET-001",
    "trial": "Thoracic oncology training protocol",
    "note": "ECOG 1. No evidence of brain metastases.",
    "criteria": [
        {"id": "performance", "kind": "inclusion", "text": "ECOG 0 or 1",
         "truth": "no", "evidence": ["ECOG 1"]},
        {"id": "metastases", "kind": "exclusion", "text": "Documented brain metastases",
         "truth": "no", "evidence": ["No evidence of brain metastases"]},
    ],
}

# Only compare a standalone named measurement with an unambiguous bound or
# an adjacent pair of scale values. A flag is a review prompt, never a repair.
MEASURE = "(?:" + "|".join(MEASURES.values()) + ")"
NUMBER = r"\d+(?:\.\d+)?"
UNIT = r"(?:%|percent|mg/dl|g/dl|mmol/l|[uµ]mol/l|10\^?9/l|years?|cc|ml)"
BOUND = re.compile(
    rf"{MEASURE}\s*(?:score\s+)?(?:>=|<=|>|<|≥|≤|=)?\s*{NUMBER}\s*{UNIT}?\.?",
    re.IGNORECASE,
)
ADJACENT_SCALE = re.compile(r"(?i)(?:ECOG|Zubrod)\s+([0-4])\s+or\s+([1-5])\.?")
EXACT_MEASURE = re.compile(rf"{MEASURE}\s*(?:(?:score|was|is)\s+)?[:=]?\s*{NUMBER}\s*{UNIT}?\.?",
                           re.IGNORECASE)


def bounded_text(value, field, max_len):
    if not isinstance(value, str) or not value.strip() or len(value) > max_len:
        raise ValueError(f"{field} must be nonempty text of at most {max_len} characters.")
    return value


def review(payload):
    if not isinstance(payload, dict):
        raise ValueError("Enter a case as a JSON object.")
    case_id = bounded_text(payload.get("case_id"), "case_id", 80)
    if "trial" in payload:
        bounded_text(payload["trial"], "Protocol", 160)
    note = bounded_text(payload.get("note"), "note", 40_000)
    raw = payload.get("criteria")
    if not isinstance(raw, list) or not 1 <= len(raw) <= 40:
        raise ValueError("Provide 1 to 40 criteria.")
    rows, seen = [], set()
    for i, rule in enumerate(raw, 1):
        if not isinstance(rule, dict):
            raise ValueError(f"Criterion {i} must be a JSON object.")
        key = bounded_text(rule.get("id"), f"Criterion {i} id", 80)
        if key in seen:
            raise ValueError("Criterion IDs must be unique.")
        seen.add(key)
        text = bounded_text(rule.get("text"), f"Criterion {i} text", 3000)
        kind, truth = rule.get("kind"), rule.get("truth")
        if kind not in ("inclusion", "exclusion") or truth not in ("yes", "no", "unknown"):
            raise ValueError(f"Criterion {i} needs kind inclusion/exclusion and truth yes/no/unknown.")
        quotes = rule.get("evidence", [])
        if not isinstance(quotes, list) or len(quotes) > 8:
            raise ValueError(f"Criterion {i} evidence must be a list of up to 8 exact quotes.")
        for q in quotes:
            bounded_text(q, f"Criterion {i} quote", 3000)
        spans = [{"quote": q, "exact": q in note} for q in quotes]
        citation = ("QUOTE_NOT_FOUND" if any(not span["exact"] for span in spans) else
                    "QUOTE_PRESENT" if spans else
                    "NO_QUOTE_CITED" if truth != "unknown" else "NOT_APPLICABLE")
        condition = text.strip()
        pair = ADJACENT_SCALE.fullmatch(condition)
        simple = BOUND.fullmatch(condition) or (pair and int(pair[2]) == int(pair[1]) + 1)
        logic = {"status": "NOT_RUN", "detail": "Needs an exact standalone measurement and a simple rule."}
        if (truth != "unknown" and simple and len(spans) == 1 and spans[0]["exact"]
                and EXACT_MEASURE.fullmatch(quotes[0].strip())):
            numeric = numeric_expected(condition, quotes[0])
            expected = numeric["expected_truth"]
            logic = {
                "status": ("NOT_RUN" if expected is None else "NUMERIC_MATCH"
                           if expected == truth else "NUMERIC_MISMATCH"),
                "detail": numeric["detail"],
            }
        flags = [s for s in (citation, logic["status"])
                 if s in ("QUOTE_NOT_FOUND", "NO_QUOTE_CITED", "NUMERIC_MISMATCH")]
        rows.append({
            "id": key, "kind": kind, "condition": text, "truth": truth, "verdict": map_truth(truth, kind),
            "flags": flags, "checks": {
                "citation": {"status": citation, "spans": spans},
                "logic": logic,
                **{name: {"status": "NOT_RUN"} for name in
                   ("entailment", "context", "contradiction", "missed_evidence")},
            },
        })
    keep = [r["verdict"] for r in rows]
    defer = ["not_stated" if r["flags"] else r["verdict"] for r in rows]
    impact = what_could_change(keep)
    for i, row in enumerate(rows):
        row.update(
            could_change_decision=impact[i]["changes"],
            sole_rejection_reason=impact[i]["sole_reason"],
            deferred_verdict=defer[i],
        )
    rows.sort(key=lambda r: (not bool(r["flags"]), not r["could_change_decision"]))
    return {
        "case_id": case_id, "scope": OFFLINE_SCOPE, "external_calls": 0,
        "decisions": {"keep": decide(keep), "flag_as_unknown": decide(defer)}, "criteria": rows,
    }


DISPOSITIONS = {
    "ELIGIBLE": "forward_for_trial_review",
    "NOT_ELIGIBLE": "criteria_not_met",
    "REVIEW": "request_more_information",
}


def record_review(payload):
    """Return a portable record after an explicit human assessment of every criterion."""
    if not isinstance(payload, dict) or payload.get("confirmed") is not True:
        raise ValueError("Confirm the review before recording it.")
    case = payload.get("case")
    screen = review(case)
    reviewer = bounded_text(payload.get("reviewer"), "Reviewer ID", 80).strip()
    trial = bounded_text(case.get("trial", "Protocol not specified"), "Protocol", 160).strip()
    raw = payload.get("assessments")
    if not isinstance(raw, list) or len(raw) != len(case["criteria"]):
        raise ValueError("Record an assessment for each criterion.")
    assessments = {}
    for a in raw:
        if not isinstance(a, dict) or not isinstance(a.get("id"), str) or a["id"] in assessments:
            raise ValueError("Each assessment must reference one distinct criterion.")
        if a.get("truth") not in ("yes", "no", "unknown"):
            raise ValueError("Choose a judgement for each criterion.")
        assessments[a["id"]] = (a["truth"], bounded_text(a.get("rationale"), "Assessment rationale", 2000).strip())
    if set(assessments) != {rule["id"] for rule in case["criteria"]}:
        raise ValueError("The assessments do not match the case criteria.")
    flags = {rule["id"]: rule["flags"] for rule in screen["criteria"]}
    criteria, verdicts = [], []
    for rule in case["criteria"]:
        truth, rationale = assessments[rule["id"]]
        verdicts.append(map_truth(truth, rule["kind"]))
        criteria.append({
            "id": rule["id"], "kind": rule["kind"], "criterion": rule["text"],
            "supplied_answer": rule["truth"], "reviewer_judgement": truth,
            "rationale": rationale, "mechanical_flags": flags[rule["id"]],
        })
    derived = decide(verdicts)
    disposition = payload.get("disposition")
    if disposition not in ("request_more_information", DISPOSITIONS[derived]):
        raise ValueError("Choose a disposition supported by the reviewed criteria.")
    case_hash = hashlib.sha256(json_bytes({
        "case_id": case["case_id"], "trial": trial, "note": case["note"],
        "criteria": [{**{k: r[k] for k in ("id", "kind", "text", "truth")},
                      "evidence": r.get("evidence", [])} for r in case["criteria"]],
    })).hexdigest()
    return {
        "format": "pet-review-1", "review_id": str(uuid4()),
        "scope": "screening workflow evaluation; trial team retains eligibility authority",
        "case_type": "training" if case == REVIEW_EXAMPLE else "supplied",
        "case_reference": screen["case_id"], "trial": trial, "case_sha256": case_hash,
        "reviewer_id": reviewer, "recorded_at": datetime.now(timezone.utc).isoformat(),
        "derived_rule_status": derived, "reviewer_disposition": disposition,
        "source_note_included": False, "evidence_quotes_included": False, "assessments": criteria,
    }


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_args):
        pass  # Do not log submitted text or URLs.

    def setup(self):
        self.request.settimeout(10)
        super().setup()

    def send_content(self, data, mime, status=200, filename=None):
        self.send_response(status)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy",
                         "default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self'; "
                         "base-uri 'none'; form-action 'none'; frame-ancestors 'none'")
        if filename is not None:
            self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(data)

    def reply(self, payload, status=200):
        self.send_content(json_bytes(payload), "application/json; charset=utf-8", status)

    def host_ok(self):
        host = self.headers.get("Host")
        return host in {f"127.0.0.1:{self.server.server_port}", f"localhost:{self.server.server_port}"}

    def do_GET(self):
        if not self.host_ok():
            return self.reply({"error": "Open the printed local address."}, 403)
        route = urlsplit(self.path).path
        if route == "/api/results":
            return self.reply(self.server.results)
        if route == "/api/review-example":
            return self.reply(REVIEW_EXAMPLE)
        if route in STATIC:
            file, mime, filename = STATIC[route]
            if file.is_file():
                return self.send_content(file.read_bytes(), mime, filename=filename)
        return self.reply({"error": "File or endpoint not found."}, 404)

    do_HEAD = do_GET

    def do_POST(self):
        origin = self.headers.get("Origin")
        if not self.host_ok() or (origin and origin != "http://" + self.headers["Host"]):
            return self.reply({"error": "Only local requests from the tool are accepted."}, 403)
        route = urlsplit(self.path).path
        if route not in ("/api/demo", "/api/review", "/api/record"):
            return self.reply({"error": "Endpoint not found."}, 404)
        if self.headers.get_content_type() != "application/json" or self.headers.get("Transfer-Encoding"):
            return self.reply({"error": "Send a JSON request."}, 415)
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            length = 0
        if not 0 < length <= MAX_BODY:
            return self.reply({"error": "Empty request or request too large."}, 413)
        try:
            value = json.loads(self.rfile.read(length))
        except (ValueError, RecursionError, TimeoutError):
            return self.reply({"error": "Invalid case data. Check the input format."}, 400)
        if route == "/api/demo":
            return self.reply(demo())
        try:
            result = record_review(value) if route == "/api/record" else review(value)
            encoded = json_bytes(result)
        except (ValueError, RecursionError) as exc:
            message = str(exc) if not isinstance(exc, (UnicodeError, RecursionError)) else "Invalid input text."
            return self.reply({"error": message}, 400)
        return self.send_content(encoded, "application/json; charset=utf-8")


def self_test():
    output = demo()  # The bundled engine verifies the six checks and the repair recheck.
    original = review(REVIEW_EXAMPLE)
    if original["criteria"][0]["flags"] != ["NUMERIC_MISMATCH"]:
        raise RuntimeError("Numeric check regression.")
    if original["decisions"] != {"keep": "NOT_ELIGIBLE", "flag_as_unknown": "REVIEW"}:
        raise RuntimeError("Offline decision comparison regression.")
    data = load_results()
    if [(r["pairs"], r["correct_binary"]) for r in data["paired_development"][-2:]] != [(152, 80), (152, 87)]:
        raise RuntimeError("Frozen results regression.")
    record = {
        "case": REVIEW_EXAMPLE, "reviewer": "TEST-01", "confirmed": True,
        "disposition": "forward_for_trial_review",
        "assessments": [{"id": "performance", "truth": "yes", "rationale": "The training score meets the rule."},
                        {"id": "metastases", "truth": "no", "rationale": "The training note documents absence."}],
    }
    receipt = record_review(record)
    if receipt["derived_rule_status"] != "ELIGIBLE" or receipt["source_note_included"] or receipt["evidence_quotes_included"]:
        raise RuntimeError("Reviewer record regression.")
    for invalid in (
        {**record, "confirmed": False},
        {**record, "assessments": record["assessments"][:1]},
        {**record, "disposition": "criteria_not_met"},
    ):
        try:
            record_review(invalid)
        except ValueError:
            pass
        else:
            raise RuntimeError("An invalid reviewer confirmation was accepted.")
    print("PASS: training checks, human review gates, and frozen development metrics.")
    print(json.dumps(output["decisions"], indent=2))
    print("External model requests: 0")


def main():
    p = argparse.ArgumentParser(description=__doc__)
    group = p.add_mutually_exclusive_group()
    group.add_argument("--self-test", action="store_true")
    group.add_argument("--demo-json", action="store_true", help="Print the synthetic tool output")
    group.add_argument("--metrics-csv", action="store_true", help="Print the frozen development results")
    p.add_argument("--port", type=int, default=8765, help="Local port (0 chooses an available port)")
    p.add_argument("--no-browser", action="store_true", help="Print the address without opening a browser")
    args = p.parse_args()
    if args.self_test:
        self_test()
    elif args.demo_json:
        sys.stdout.buffer.write(json_bytes(demo()))
    elif args.metrics_csv:
        rows = load_results()["paired_development"]
        writer = csv.DictWriter(sys.stdout, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    else:
        if not 0 <= args.port <= 65535:
            p.error("--port must be from 0 to 65535.")
        try:
            server = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
        except OSError as exc:
            if args.port != 8765:
                p.exit(1, f"Could not open the local port: {exc}. Try --port 0.\n")
            server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        with server:
            server.results = load_results()
            url = f"http://127.0.0.1:{server.server_port}/"
            print(f"PET TOOL: {url}\nOpen this address. Press Ctrl+C to stop.", flush=True)
            if not args.no_browser:
                # Opening the browser must not hold up the local server.
                from threading import Thread
                Thread(target=webbrowser.open, args=(url,), daemon=True).start()
            try:
                server.serve_forever()
            except KeyboardInterrupt:
                print("\nPET TOOL closed.")


if __name__ == "__main__":
    main()
