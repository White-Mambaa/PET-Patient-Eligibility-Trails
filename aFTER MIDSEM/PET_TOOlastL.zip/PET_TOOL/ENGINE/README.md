# Check What Can Change the Outcome

Runnable research prototype: screen a case with Qwen, run the six evidence checks, order
criteria for review, and compare keeping, deferring, and re-asking flagged answers.

## Run the demonstration

Requires Python 3.10+ and the dependencies in requirements_mtp_completion.txt.
Use the existing project environment, or create a virtual environment and install the requirements:

    python3 -m venv .venv
    .venv/bin/python -m pip install -r requirements_mtp_completion.txt

In this extracted folder, run the deterministic demonstration and tests:

    .venv/bin/python mtp_week_delivery.py self-test
    .venv/bin/python completion_selftest.py --root .

With Ollama running locally and qwen2.5:7b installed:

    .venv/bin/python mtp_week_delivery.py case --input SYNTHETIC_CASE.json --max-calls 30

For a new input, use the same schema as SYNTHETIC_CASE.json. Supply the whole note,
each rule's inclusion/exclusion kind, and a reviewed statement and key terms for each rule.
The case command uses loopback Ollama, medspaCy context and a Qwen support judge.
Its same-model judge is a demonstration configuration, separate from the Groq evaluation.
The case results include excerpts. Keep private case input and output local.
This is a research prototype for human review, with no clinical eligibility authority.
A VERIFIED checker verdict means none of the implemented checks flagged the answer.

## Benchmark evaluation

    .venv/bin/python completion.py --help

For benchmarks, use the approved datasets, splits, label sheets and project guide.
They are provided separately from this source ZIP. The benchmark CLI includes the
baseline, checker, reports, repair, traps and freeze commands. Use a registered
method freeze before held-out evaluation. The ZIP includes SHA-256 content hashes.
