#!/usr/bin/env python3
"""Build, demonstrate, and inventory the one-week MTP research tool delivery."""
import argparse
from collections import Counter
import csv
from datetime import datetime
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import urllib.request
import zipfile

MODEL = "qwen2.5:7b"
CHECK_NAMES = ("citation", "entailment", "context", "logic", "contradiction", "missed_evidence")
HERE = Path(__file__).resolve().parent
ROOT_DEFAULT = HERE if (HERE / "completion.py").is_file() else Path.cwd()
WORK = Path("outputs/mtp_week_delivery")
SHEETS = {"nsclc100": ("my_label_sheet.csv", 446), "sigir204": ("sigir_label_sheet.csv", 203)}
NSCLC_CHECKS = Path("outputs/mtp_completion/nsclc100/dev/plain_ai_qwen_dev_checks_theta95_fallback_exploratory.jsonl")
SOURCE = (
    "completion.py", "completion_selftest.py", "requirements_mtp_completion.txt",
    "mtp_completion/__init__.py", "mtp_completion/analysis.py", "mtp_completion/checker.py",
    "mtp_completion/client.py", "mtp_completion/common.py", "mtp_completion/numeric.py",
    "mtp_completion/traps.py", "mtp_completion/workflow.py",
    "code/criteria.py", "code/llm_client.py", "code/plain_ai.py", "code/stats_tools.py", "code/evaluate.py",
)
EXAMPLE = {
    "case_id": "synthetic_ecog_example",
    "note": "ECOG 1. No evidence of brain metastases.",
    "criteria": [
        {"id": "performance", "kind": "inclusion", "text": "ECOG 0 or 1",
         "statement": "The patient has an ECOG score of 0 or 1.", "key_terms": ["ECOG"], "guidance": ""},
        {"id": "metastases", "kind": "exclusion", "text": "Documented brain metastases",
         "statement": "The patient has documented brain metastases.",
         "key_terms": ["brain metastases"], "guidance": ""},
    ],
}
PACKAGE_README = """# Check What Can Change the Outcome

Runnable research prototype: screen a case with Qwen, run the six evidence checks, order
criteria for review, and compare keeping, deferring, and re-asking flagged answers.

## Run the demonstration

Requires Python 3.10+ and the dependencies in requirements_mtp_completion.txt.
Use the existing project environment, or create a virtual environment and install the requirements:

    python3 -m venv .venv
    .venv/bin/python -m pip install -r requirements_mtp_completion.txt

In this extracted folder, run the deterministic demonstration and tests:

    .venv/bin/python mtp_week_delivery.py self-test
    .venv/bin/python completion_selftest.py --root .

With Ollama running locally and qwen2.5:7b installed:

    .venv/bin/python mtp_week_delivery.py case --input SYNTHETIC_CASE.json --max-calls 30

For a new input, use the same schema as SYNTHETIC_CASE.json. Supply the whole note,
each rule's inclusion/exclusion kind, and a reviewed statement and key terms for each rule.
The case command uses loopback Ollama, medspaCy context and a Qwen support judge.
Its same-model judge is a demonstration configuration, separate from the Groq evaluation.
The case results include excerpts. Keep private case input and output local.
This is a research prototype for human review, with no clinical eligibility authority.
A VERIFIED checker verdict means none of the implemented checks flagged the answer.

## Benchmark evaluation

    .venv/bin/python completion.py --help

For benchmarks, use the approved datasets, splits, label sheets and project guide.
They are provided separately from this source ZIP. The benchmark CLI includes the
baseline, checker, reports, repair, traps and freeze commands. Use a registered
method freeze before held-out evaluation. The ZIP includes SHA-256 content hashes.
"""


def file_hash(raw):
    return hashlib.sha256(raw).hexdigest()


def save_json(path, value):
    with path.open("x", encoding="utf-8") as f:
        json.dump(value, f, ensure_ascii=False, indent=2, allow_nan=False)
        f.write("\n")


def load_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def new_run(root, prefix):
    p = root / WORK / datetime.now().strftime(prefix + "_%Y%m%d_%H%M%S_%f")
    p.mkdir(parents=True, exist_ok=False)
    return p


def use_project(root):
    if not (root / "completion.py").is_file() or not (root / "code/llm_client.py").is_file():
        raise ValueError("--root must point to Akash_Kit or the extracted tool folder")
    sys.path[:0] = [str(root / "code"), str(root)]


def valid_input(case):
    if not isinstance(case, dict) or not isinstance(case.get("note"), str) or not case["note"].strip():
        raise ValueError("Case input needs a nonempty 'note'")
    if not isinstance(case.get("case_id"), str) or not case["case_id"].strip():
        raise ValueError("Case input needs a nonempty 'case_id'")
    criteria = case.get("criteria")
    if not isinstance(criteria, list) or not criteria:
        raise ValueError("Case input needs at least one criterion")
    seen = set()
    for i, c in enumerate(criteria, 1):
        if not isinstance(c, dict) or c.get("kind") not in ("inclusion", "exclusion"):
            raise ValueError(f"Criterion {i}: kind must be inclusion or exclusion")
        for field in ("id", "text", "statement"):
            if not isinstance(c.get(field), str) or not c[field].strip():
                raise ValueError(f"Criterion {i}: missing {field}")
        if c["id"] in seen:
            raise ValueError("Criterion IDs must be unique")
        seen.add(c["id"])
        terms = c.get("key_terms")
        if not isinstance(terms, list) or not terms or any(not isinstance(t, str) or not t.strip() for t in terms):
            raise ValueError(f"Criterion {i}: supply a nonempty list of key terms")
        if not isinstance(c.get("guidance", ""), str):
            raise ValueError(f"Criterion {i}: guidance must be text")


def make_client(max_calls, mock=None):
    from llm_client import CallFailed, LocalLLM

    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *args, **kwargs):
            return None

    class BoundedLLM(LocalLLM):
        attempts = 0

        def _send(self, system, user):
            if self.attempts >= max_calls:
                raise CallFailed("Local model call budget reached")
            self.attempts += 1
            return super()._send(system, user)

    if mock is None:
        urllib.request.install_opener(urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect()))
    client = BoundedLLM(MODEL, host="http://127.0.0.1:11434", timeout=150,
                        call_retries=0, parse_retries=0, num_ctx=8192, max_output=400,
                        backend="mock" if mock else "ollama", mock=mock)
    client.check_model_available()
    return client


def case_result(case, client, context, repair_budget, progress=False):
    from criteria import TRUTHS, decide, map_truth
    from llm_client import CallFailed
    import plain_ai
    from mtp_completion.analysis import orders
    from mtp_completion.checker import Checker

    valid_input(case)
    checker = Checker(client, theta=95, tau=.7, support="judge", context=context)
    note, criteria = case["note"], case["criteria"]

    def ask(c, i, feedback=None):
        user = plain_ai.build_user(c["text"], note, c.get("guidance", ""))
        if feedback is not None:
            user += "\nFEEDBACK: " + feedback
        reply = client.chat_json(plain_ai.SYSTEM_PROMPT, user,
                                 prompt_id="REPAIR_ONCE_v1" if feedback is not None else plain_ai.PROMPT_ID)
        answer = plain_ai.clean_answer(reply["data"], TRUTHS) if reply["ok"] else None
        if answer is None:
            return None
        return {**answer, "dataset": "case_cli", "system": "local_qwen_case", "pair_idx": 0, "crit_idx": i,
                "kind": c["kind"], "verdict": map_truth(answer["truth"], c["kind"]), "parse_ok": True}

    def check(c, record):
        rule = {"criterion_text": c["text"], "kind": c["kind"], "note": c.get("guidance", "")}
        return checker.check(record, note, rule, {"statement": c["statement"], "key_terms": c["key_terms"]})

    records, checks = {}, {}
    for i, c in enumerate(criteria):
        key = (0, i)
        if progress:
            print(f"Screening and checking criterion {i + 1}/{len(criteria)}", flush=True)
        records[key] = ask(c, i)
        if records[key] is None:
            raise CallFailed(f"Invalid screening JSON for criterion {i + 1}; no case decision saved")
        checks[key] = check(c, records[key])

    ordering, features = orders(records, checks)
    combined = ordering["combined"]
    flagged = [k for k in combined if checks[k]["label"] != "VERIFIED"]
    flagged_set = set(flagged)
    keep = [r["verdict"] for r in records.values()]
    defer = [r["verdict"] if k not in flagged_set else "not_stated" for k, r in records.items()]
    repair = keep.copy()
    repairs = {}
    for k in flagged[:repair_budget]:
        i, c, before = k[1], criteria[k[1]], checks[k]
        feedback = before["reason"]
        for label, component in (("CONTRADICTED", "contradiction"), ("MISSED_EVIDENCE", "missed_evidence")):
            if before["label"] == label:
                feedback += " Evidence: " + str(before["checks"][component]["sentence"])
        if progress:
            print(f"Re-asking and rechecking criterion {i + 1}", flush=True)
        proposal = ask(c, i, feedback)
        recheck = check(c, proposal) if proposal is not None else None
        accepted = recheck is not None and recheck["label"] == "VERIFIED"
        repair[i] = proposal["verdict"] if accepted else "not_stated"
        repairs[i] = {"accepted_after_recheck": accepted, "proposal": proposal, "recheck": recheck}
    return {
        "case_id": case["case_id"], "scope": "research demonstration; human review",
        "configuration": {"model": client.model, "backend": client.backend, "support": "judge", "context": context,
                          "theta": 95, "same_model_screening_and_support": True, "repair_budget": repair_budget},
        "generation_attempts": client.attempts, "external_calls": 0,
        "decisions": {"keep": decide(keep), "flag_as_unknown": decide(defer), "reask_then_recheck": decide(repair)},
        "review_order": [{"criterion_id": criteria[k[1]]["id"], "checker_label": checks[k]["label"],
                          "could_change_decision": features[k]["changes"], "sole_rejection_reason": features[k]["sole_reason"]}
                         for k in combined],
        "criteria": [{"id": c["id"], "kind": c["kind"], "condition": c["text"], "baseline": records[(0, i)],
                      "checker": checks[(0, i)], "flag_policy_verdict": defer[i], "reask_policy_verdict": repair[i],
                      "repair": repairs.get(i)} for i, c in enumerate(criteria)],
    }


def synthetic_reply(system, user):
    if user.startswith("CONDITION:"):
        ecog = user.startswith("CONDITION: ECOG")
        truth = ("yes" if "\nFEEDBACK:" in user else "no") if ecog else "no"
        quote = "ECOG 1" if ecog else "No evidence of brain metastases"
        return json.dumps({"truth": truth, "evidence": [quote], "basis": "stated",
                           "rationale": "Deterministic fixture response.", "confidence": .8})
    data = json.loads(user)
    if "Identify assertion context" in system:
        negated = data["EVIDENCE"].startswith("No evidence")
        return json.dumps({"negated": negated, "uncertain": False, "hypothetical": False,
                           "family": False, "historical": False,
                           "span": "No evidence of brain metastases" if negated else ""})
    if "STATEMENT" in data:
        statement, evidence = data["STATEMENT"], data["EVIDENCE"]
        label = "neutral"
        if "ECOG" in statement and evidence.startswith("ECOG"):
            label = "entailment"
        elif "metastases" in statement and evidence.startswith("No evidence"):
            label = "contradiction"
        return json.dumps({"label": label})
    raise ValueError("Unexpected prompt in deterministic demo")


def self_test():
    result = case_result(EXAMPLE, make_client(30, synthetic_reply), "judge", 1)
    first = result["criteria"][0]
    ok = (
        set(first["checker"]["checks"]) == set(CHECK_NAMES)
        and first["checker"]["label"] == "LOGIC_ERROR"
        and result["review_order"][0]["criterion_id"] == "performance"
        and result["review_order"][0]["sole_rejection_reason"]
        and result["decisions"] == {"keep": "NOT_ELIGIBLE", "flag_as_unknown": "REVIEW", "reask_then_recheck": "ELIGIBLE"}
        and first["repair"]["accepted_after_recheck"]
        and first["repair"]["recheck"]["label"] == "VERIFIED"
    )
    if not ok:
        raise ValueError("Synthetic workflow regression failed")
    return result


def release(root):
    missing = [name for name in SOURCE if not (root / name).is_file()]
    if missing:
        raise ValueError("Release needs these installed source files: " + ", ".join(missing))
    files = {name: (root / name).read_bytes() for name in SOURCE}
    for name in ("MAIN_MTP_COMPLETION_README.md", "ROADMAP_AND_IMPLEMENTATION.md"):
        if (root / name).is_file():
            files[name] = (root / name).read_bytes()
    files.update({
        "README.md": PACKAGE_README.encode(),
        "mtp_week_delivery.py": Path(__file__).read_bytes(),
        "SYNTHETIC_CASE.json": (json.dumps(EXAMPLE, indent=2) + "\n").encode(),
    })
    with tempfile.TemporaryDirectory(prefix="mtp-release-test-") as directory:
        tmp = Path(directory)
        for name, content in files.items():
            target = tmp / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(content)
        commands = (("mtp_week_delivery.py", "self-test", "--root", str(tmp)),
                    ("completion_selftest.py", "--root", str(tmp)))
        logs = []
        for cmd in commands:
            p = subprocess.run([sys.executable, *cmd], cwd=tmp, capture_output=True, text=True, timeout=180)
            logs.append(f"$ python {' '.join(cmd[:2])}\n{p.stdout}{p.stderr}")
            if p.returncode != 0:
                print(logs[-1], file=sys.stderr)
                raise ValueError("Fresh-copy smoke test failed; no release ZIP created")
    files["SOFTWARE_TESTS.txt"] = "\n\n".join(logs).encode()
    manifest = {name: file_hash(body) for name, body in sorted(files.items())}
    files["SHA256SUMS.json"] = (json.dumps(manifest, indent=2) + "\n").encode()
    out = new_run(root, "release")
    archive = out / "MTP_TOOL_CANDIDATE.zip"
    with zipfile.ZipFile(archive, "x", zipfile.ZIP_DEFLATED) as z:
        for name, data in sorted(files.items()):
            z.writestr("MTP_TOOL/" + name, data)
    with zipfile.ZipFile(archive) as z:
        if z.testzip() or any(file_hash(z.read("MTP_TOOL/" + n)) != h for n, h in manifest.items()):
            raise ValueError("Release archive failed verification")
    print("Fresh-copy synthetic workflow and project software tests passed; see SOFTWARE_TESTS.txt for skips.")
    print("RUNNABLE SOURCE ZIP:", archive)


def read_csv(path):
    return list(csv.DictReader(io.StringIO(path.read_text(encoding="utf-8-sig"), newline="")))


def label_readiness(root, dataset, rules, splits):
    sheet_name, expected_n = SHEETS[dataset]
    sheet = root / "labelling" / sheet_name
    result = {"sheet": sheet_name, "expected_assigned": expected_n, "found": sheet.is_file(),
              "counts": {"dev": Counter(), "test": Counter()}, "duplicate_or_wrong_identity": 0}
    if not sheet.is_file():
        return result, []
    seen, todo = set(), []
    for r in read_csv(sheet):
        split, trial = r["split"], r["trial_id"]
        idx, pair = int(r["crit_idx"]), int(r["pair_idx"])
        k = (split, pair, idx)
        if (k in seen or split not in ("dev", "test") or splits.get(trial) != split
                or trial not in rules or not 0 <= idx < len(rules[trial]) or rules[trial][idx]["kind"] != r["kind"]):
            result["duplicate_or_wrong_identity"] += 1
            continue
        seen.add(k)
        c = result["counts"][split]
        c["assigned"] += 1
        truth = (r.get("truth") or "").strip().lower()
        spans = [q.strip() for q in (r.get("evidence_span") or "").split("||") if q.strip()]
        note = r.get("patient_note") or ""
        if not truth:
            reason = "blank_truth"
        elif truth not in ("yes", "no", "unknown"):
            reason = "invalid_truth"
        elif (truth != "unknown" and not spans) or (spans and any(q not in note for q in spans)):
            reason = "check_evidence_span"
        else:
            c["syntactically_usable"] += 1
            c["unsure"] += (r.get("comment") or "").strip().upper().startswith("UNSURE:")
            continue
        c[reason] += 1
        todo.append({"dataset": dataset, "split": split, "trial_id": trial,
                     "pair_idx": pair, "crit_idx": idx, "issue": reason})
    return result, todo


def statement_readiness(root, dataset, rules, splits):
    expected = {(trial, rule["crit_idx"]) for trial, values in rules.items() if splits.get(trial) == "dev" for rule in values}
    dirs = [root / "outputs/mtp_completion" / dataset / "dev",
            root / "outputs/mtp_parallel/workspaces/sigir/outputs/mtp_completion" / dataset / "dev"]
    paths = sorted({p for d in dirs for p in d.glob("*statement*.csv")})
    versions = []
    for path in paths:
        rows = read_csv(path)
        seen, reviewed, malformed = set(), set(), 0
        for r in rows:
            try:
                trial, idx = r["trial_id"], int(r["crit_idx"])
                k = trial, idx
                if k not in expected or k in seen:
                    malformed += 1
                    continue
                rule = rules[trial][idx]
                terms = json.loads(r["key_terms"])
                if (r["criterion"] != rule["criterion_text"] or r.get("guidance", "") != rule["note"]
                        or not r["statement"].strip() or not isinstance(terms, list) or not terms
                        or any(not isinstance(t, str) or not t.strip() for t in terms)):
                    malformed += 1
                    continue
            except (KeyError, ValueError, AttributeError, TypeError):
                malformed += 1
                continue
            seen.add(k)
            if (r.get("reviewed") or "").strip().lower() in ("true", "yes", "1"):
                reviewed.add(k)
        versions.append(({"path": str(path.relative_to(root)), "covered": len(seen),
                          "reviewed": len(reviewed), "malformed": malformed}, reviewed))
    best = max(versions, key=lambda x: (x[0]["covered"] == len(expected) and x[0]["malformed"] == 0,
                                        x[0]["covered"], x[0]["reviewed"], -x[0]["malformed"])) if versions else (None, set())
    return {"expected_dev": len(expected), "best_single_file": best[0],
            "candidate_files": [meta for meta, _ in versions]}, [
        {"dataset": dataset, "trial_id": t, "crit_idx": i} for t, i in sorted(expected - best[1])
    ]


def check_coverage(root):
    from mtp_completion.common import ensure_checks, hashed, read_jsonl, unique

    pred, ck = root / "outputs/plain_ai_qwen_dev.jsonl", root / NSCLC_CHECKS
    if not pred.is_file() or not ck.is_file():
        return {"saved": None, "expected": 950, "status": "checkpoint or original predictions not found"}
    predictions = unique(read_jsonl(pred))
    raw = ck.read_bytes()
    raw = raw[:raw.rfind(b"\n") + 1]
    checks = unique(json.loads(line) for line in raw.splitlines() if line.strip())
    ensure_checks(checks.values())
    if len(predictions) != 950 or any(k not in predictions or c.get("provenance", {}).get("source_answer_hash") != hashed(predictions[k])
                                      for k, c in checks.items()):
        raise ValueError("NSCLC checker checkpoint does not match the original 950 predictions")
    return {"saved": len(checks), "expected": len(predictions), "status": "development only",
            "incomplete_marker": Path(str(ck) + ".INCOMPLETE").exists(),
            "checkpoint_prefix_sha256": file_hash(raw)}


def baseline_table(root):
    index_path = root / "outputs/mtp_parallel/REPORT_INDEX.json"
    if not index_path.is_file():
        return []
    index = load_json(index_path)
    table = []
    for dataset, expected in (("nsclc100", 50), ("sigir204", 102)):
        for mode in ("unknown", "forced"):
            entry = index.get(dataset + "_" + mode, {})
            if not entry.get("results"):
                continue
            path = (root / entry["results"]).resolve()
            if not path.is_relative_to(root / "outputs") or not path.is_file():
                continue
            r = load_json(path)
            p = r["pair_metrics"]
            if (r.get("dataset"), r.get("split"), r.get("subject_models"), p.get("n")) != (dataset, "dev", [MODEL], expected):
                continue
            table.append({
                "dataset": dataset, "mode": mode, "pairs": expected, "review": p["review_count"],
                "wrong_exclusions": p["false_exclusions"], "eligible": p["eligible_pairs"],
                "wrong_inclusions": p["false_inclusions"], "ineligible": p["ineligible_pairs"],
                "single_rule_wrong_exclusions": p["sole_reason_false_exclusions"],
                "accuracy_review_as_negative": p["binary_review_as_not_eligible"]["accuracy"],
                "source": str(path.relative_to(root)), "source_sha256": file_hash(path.read_bytes()),
            })
    return table


def write_csv(path, fields, rows):
    with path.open("x", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def submission_report(root):
    from criteria import load_criteria, load_splits

    info = {"scope": "delivery inventory and measured development evidence; no model or held-out evaluation",
            "target": "2026-11-12", "labels": {}, "statements": {}}
    todo, stmt_todo = [], []
    for ds in SHEETS:
        d = root / "datasets" / ds
        if not (d / "criteria.csv").is_file() or not (d / "splits.csv").is_file():
            info["labels"][ds] = {"status": "dataset metadata missing"}
            info["statements"][ds] = {"status": "dataset metadata missing"}
            continue
        rules, splits = load_criteria(d / "criteria.csv"), load_splits(d / "splits.csv")
        info["labels"][ds], rows = label_readiness(root, ds, rules, splits)
        info["statements"][ds], st_rows = statement_readiness(root, ds, rules, splits)
        todo.extend(rows)
        stmt_todo.extend(st_rows)
    info["legacy_nsclc_checks"] = check_coverage(root)
    info["table_1_saved_qwen_dev"] = baseline_table(root)
    repairs = root / "outputs/mtp_next_jobs/nsclc_reask_pilot"
    info["saved_reask_records_awaiting_recheck"] = len(list(repairs.glob("case_*.json")))
    cal = root / "outputs/mtp_completion/citation_calibration.csv.selection.json"
    if cal.is_file():
        selection = load_json(cal)
        info["citation_calibration"] = {"theta": selection.get("selected_theta"),
                                       "sample_n": max((r["n"] for r in selection.get("grid", [])), default=0)}
    reports = sorted((root / "outputs/mtp_checker_work").glob("results_*/RESULTS_NO_NOTES.json"))
    if reports:
        last = load_json(reports[-1])
        info["latest_nsclc_checker_report"] = {"source": str(reports[-1].relative_to(root)),
                                              "scope": last.get("scope"), "coverage": last.get("coverage")}
    out = new_run(root, "submission")
    save_json(out / "DELIVERY_EVIDENCE_NO_NOTES.json", info)
    write_csv(out / "LABEL_TODO_NO_NOTES.csv", ("dataset", "split", "trial_id", "pair_idx", "crit_idx", "issue"), todo)
    write_csv(out / "STATEMENT_TODO_NO_NOTES.csv", ("dataset", "trial_id", "crit_idx"), stmt_todo)
    coverage = info["legacy_nsclc_checks"]
    lines = [
        "# MTP delivery evidence and work remaining", "",
        "Working delivery target: 12 November 2026. These are the results located on this machine "
        "at report time. The tool can be packaged and demonstrated now; experiment coverage is tracked separately.", "",
        "## Table 1: completed Qwen development mode reports", "",
        "Accuracy below treats REVIEW as negative; hard wrong exclusion counts include only NOT_ELIGIBLE decisions.", "",
        "| Dataset | Answer mode | Pairs | Wrong exclusions / eligible | Single-rule wrong exclusions | Wrong inclusions / ineligible | Review | Accuracy |",
        "|---|---|---:|---:|---:|---:|---:|---:|",
    ]
    for r in info["table_1_saved_qwen_dev"]:
        a = r["accuracy_review_as_negative"]
        accuracy = "N/A" if a is None else f"{100 * a:.1f}%"
        lines.append(f"| {r['dataset']} | {r['mode']} | {r['pairs']} | "
                     f"{r['wrong_exclusions']}/{r['eligible']} | {r['single_rule_wrong_exclusions']} | "
                     f"{r['wrong_inclusions']}/{r['ineligible']} | {r['review']} | {accuracy} |")
    if not info["table_1_saved_qwen_dev"]:
        lines.append("| Saved reports unavailable | — | — | — | — | — | — | — |")
    lines.extend(["", "## Checker and remaining evaluation", "",
                  f"- Legacy NSCLC: {coverage['saved'] if coverage['saved'] is not None else 'unavailable'}"
                  f"/{coverage['expected']} checker rows on disk. Different run from the matched mode reports.",
                  f"- K3: {info['saved_reask_records_awaiting_recheck']} saved pilot records; repair gains require rechecks and student labels."])
    if "latest_nsclc_checker_report" in info:
        r = info["latest_nsclc_checker_report"]
        lines.append(f"- Latest located K1/K2/K3 flag/K5 report: {r['source']} ({r['scope']}); see its coverage.")
    if "citation_calibration" in info:
        r = info["citation_calibration"]
        lines.append(f"- Recorded citation selection: θ={r['theta']} on {r['sample_n']} labelled examples; review before freezing.")
    lines.extend(["- K4 requires hand-checked development alterations; K6 requires comparable complete checker outputs for both datasets.",
                  "- Run the held-out benchmark once after method and student label freeze.", "",
                  "## Work to assign to reviewers", "",
                  "| Dataset | Split | Assigned found | Syntactically usable | Needs truth/evidence work |",
                  "|---|---|---:|---:|---:|"])
    for ds, r in info["labels"].items():
        if not r.get("found"):
            lines.append(f"| {ds} | Sheet unavailable | — | — | — |")
            continue
        for split, c in r["counts"].items():
            lines.append(f"| {ds} | {split} | {c['assigned']} | {c['syntactically_usable']} | "
                         f"{c['assigned'] - c['syntactically_usable']} |")
        if r["duplicate_or_wrong_identity"] or sum(c["assigned"] for c in r["counts"].values()) != r["expected_assigned"]:
            lines.append(f"| {ds} | Assignment integrity needs review | — | — | — |")
    lines.extend(["", "Counts check allowed truth values and exact spans. They do not establish semantic agreement or independent review.",
                  "Use LABEL_TODO_NO_NOTES.csv to split the work. Complete the assigned sheets and overlap review before freeze.", "",
                  "| Dataset | Development statements covered | Marked reviewed | Expected |",
                  "|---|---:|---:|---:|"])
    for ds, r in info["statements"].items():
        best = r.get("best_single_file") or {}
        lines.append(f"| {ds} | {best.get('covered', '—')} | {best.get('reviewed', '—')} | {r.get('expected_dev', '—')} |")
    lines.extend(["", "STATEMENT_TODO_NO_NOTES.csv lists IDs to check against the best single file located for each dataset.", ""])
    (out / "DELIVERY_REPORT.md").write_text("\n".join(lines), encoding="utf-8")
    print("SUBMISSION REPORT:", out / "DELIVERY_REPORT.md")
    print(f"WORK QUEUES: {len(todo)} label rows with flagged issues; {len(stmt_todo)} development statements to review or supply.")
    print("All counts are read from saved files; no model calls.")


def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="job", required=True)
    for name in ("build", "self-test", "case", "report"):
        a = sub.add_parser(name)
        a.add_argument("--root", type=Path, default=ROOT_DEFAULT)
        if name == "case":
            src = a.add_mutually_exclusive_group(required=True)
            src.add_argument("--input", type=Path)
            src.add_argument("--example", action="store_true")
            a.add_argument("--max-calls", type=int, default=30)
            a.add_argument("--repair-budget", type=int, default=1)
            a.add_argument("--context", choices=("medspacy", "judge"), default="medspacy")
    a = p.parse_args()
    root = a.root.resolve()
    os.umask(0o077)
    try:
        use_project(root)
        from llm_client import CallFailed
        try:
            if a.job == "build":
                release(root)
            elif a.job == "report":
                submission_report(root)
            elif a.job == "self-test":
                r = self_test()
                print("SYNTHETIC WORKFLOW PASS: six checks, decision impact, deferral and repair recheck")
                print(json.dumps(r["decisions"], indent=2))
            else:
                if not 1 <= a.max_calls <= 500 or not 0 <= a.repair_budget <= 20:
                    raise ValueError("Expected --max-calls in 1–500 and --repair-budget in 0–20")
                case = EXAMPLE if a.example else load_json(a.input)
                valid_input(case)
                r = case_result(case, make_client(a.max_calls), a.context, a.repair_budget, progress=True)
                out = new_run(root, "case_demo")
                save_json(out / "CASE_RESULT_PRIVATE.json", r)
                print("CASE RESULT:", out / "CASE_RESULT_PRIVATE.json")
                print("DEMO DECISIONS:", json.dumps(r["decisions"]))
                print("Local model attempts:", r["generation_attempts"], "| External calls: 0")
        except CallFailed as e:
            print(f"LOCAL MODEL STOP: {e}", file=sys.stderr)
            return 2
    except (OSError, ValueError, KeyError, TypeError, ImportError, subprocess.TimeoutExpired) as e:
        print("STOP:", str(e) if type(e) in (ValueError, FileNotFoundError, ImportError)
              else f"input or test error ({type(e).__name__})", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
