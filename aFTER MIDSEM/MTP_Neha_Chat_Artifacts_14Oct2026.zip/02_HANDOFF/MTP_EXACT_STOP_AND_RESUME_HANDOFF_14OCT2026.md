# MTP — Exact Stop Point, Reality Check & Post-Presentation Resumption Guide

**Project:** *Check What Can Change the Outcome: Targeted Checking of AI Screening Decisions for Clinical Trials*  
**Checkpoint date:** 14 October 2026 (IST), after the mid-project progress presentation package was prepared  
**Primary development computer:** `skyee` (`/home/honcho/MTP/Akash_Kit`)  
**Purpose:** This is the authoritative **handoff and resume checkpoint**, not a claim that the overall research project is complete.

> **START HERE AFTER THE PRESENTATION:** We stopped **immediately after the final missing Qwen2.5:7b evidence-audit record was successfully retried**. The audit script reported **1,940/1,940 completed, zero remaining**. We **did not yet execute the separate final unique-ID/integrity verification**, **did not generate a frozen analysis copy with deterministically reconciled verdicts**, and **did not finish independent adjudication, six-check validation, traps, repair-versus-deferral, or held-out evaluation**. Resume with the read-only audit integrity check in Section 10—not with model retraining or rerunning the baseline.

---

## 1. Read this first: our actual reality

We temporarily stopped development to present **real results obtained so far**. The presentation is a **progress presentation**, not the project completion. The freeze means *do not modify the experimental source data during presentation preparation*; it does **not** mean the algorithms are finalized.

### Three levels that must never be confused

| Level | What it means | Where we are |
|---|---|---|
| **Idea / hypothesis** | Checking decision-changing errors should be more useful than checking arbitrarily. | Defined; **not yet proven**. |
| **Working technical output** | Code ran, predictions/checker flags/rankings exist, and simulated decisions were computed. | **Substantial development-stage work completed.** |
| **Defensible research result** | Independent error labels, leakage-aware equal-budget comparisons, controlled traps, repair safety, and frozen held-out tests confirm the benefit. | **Not yet complete.** |

The work has **not** stopped because of a fatal technical blocker. It stopped deliberately for the imminent presentation. The unresolved question is no longer *“Can the system run?”* but *“Are its checks reliable, and does prioritizing them actually improve decisions under a fair evaluation?”*

### One-sentence project explanation

An existing locally hosted screening AI answers clinical-trial eligibility rules from patient notes; **our research builds evidence checks, prioritizes questions that could change the overall screening decision, and evaluates whether checking or repair helps without introducing unsafe new errors**.

**The project is not:** training a new foundation model, replacing a physician, or simply measuring the baseline model's accuracy.

---

## 2. Exact last confirmed action — the stopping point

The **last confirmed successful research execution** on `skyee` was:

```bash
cd ~/MTP/Akash_Kit
MAX_HOURS=1 MAX_RECORDS=1 \
python3 -u experiments/overnight_evidence_audit.py
```

The user-reported terminal output was:

```text
OVERNIGHT EVIDENCE AUDIT
Judge model: qwen2.5:7b
Predictions: 1940
Already completed: 1939
Time limit (hours): 1.0
Max new records (0=unlimited): 1
Completed 1940/1940 | latest 47.79s | errors 0
Record limit reached.
RUN SUMMARY
New successful audits: 1
Errors this run: 0
Total completed: 1940
Remaining: 0
Saved: /home/honcho/MTP/Akash_Kit/outputs/overnight_audit/evidence_audit.jsonl
```

**What happened immediately before that:**

1. The main Qwen evidence-audit run saved **1,939/1,940** outputs.
2. The sole unresolved identity was `('nsclc100', 15, 17)`: an exclusion rule, **“Subjects who are incarcerated.”** The patient note did not state incarceration; baseline truth was `unknown`, mapped to `not_stated`.
3. The AI judge repeatedly returned `support: no_evidence`, while the strict validator accepted only `supported|unsupported|insufficient|uncertain`.
4. We changed **only the validator** in `experiments/overnight_evidence_audit.py`: map `no_evidence` to `insufficient` while preserving `support_original_value: no_evidence` and a normalization marker; a backup was made at `experiments/overnight_evidence_audit.backup_20261014_192823_149300.py`. The patched Python file passed compilation.
5. A single-record retry succeeded. **The original 1,939 audit outputs were not replaced.**
6. We moved to presentation preparation. **The follow-up independent full-file assertion for 1,940 unique IDs was proposed but has not been shown as executed.** Thus the script's 1,940 completion report is confirmed, while final external integrity validation is still a pending housekeeping step.

**Most important instruction:** Do **not** run the full 1,940-criterion audit again. Do **not** rerun baseline model inference. Do **not** apply judge-suggested verdicts automatically.

---

## 3. What files and outputs actually exist on `skyee`

These paths are from successful terminal outputs in our conversation. They refer to the user's Ubuntu filesystem, **not** this chat's file sandbox.

### Development datasets / software

```text
/home/honcho/MTP/Akash_Kit/
├── code/
│   ├── plain_ai.py             # baseline AI screening
│   ├── criteria.py             # inclusion/exclusion truth→verdict mapping
│   ├── evaluate.py             # supplied evaluation code
│   └── ...
├── datasets/
│   ├── nsclc100/
│   │   ├── nsclc100.csv
│   │   ├── criteria.csv
│   │   └── splits.csv
│   └── sigir204/
│       ├── sigir204.csv
│       └── ...
├── experiments/
│   ├── overnight_evidence_audit.py       # patched, validated syntax
│   ├── audit_consistency_analysis.py     # earlier exploratory analysis
│   └── ...
└── outputs/
```

### High-priority experimental artifacts

| Path relative to `~/MTP/Akash_Kit` | What it contains | Last known status |
|---|---|---|
| `outputs/plain_ai_qwen_dev.jsonl` | NSCLC development baseline, 950 criterion records | Completed |
| `outputs/plain_ai_qwen_sigir_dev.jsonl` | SIGIR development baseline, 990 criterion records | Completed |
| `outputs/decision_impact/real_priority_analysis.csv` | 1,940 criterion-level decision-impact records | Generated |
| `outputs/evidence_checks/real_citation_results.csv` | 1,940 quotation-level checker records | Generated |
| `outputs/priority_comparison/priority_rankings.csv` | 9,700 rows = 1,940 × 5 strategies | Generated |
| `outputs/priority_comparison/equal_budget_summary.csv` | Earlier budget summary (20 rows) | Generated; **not independent error accuracy** |
| `outputs/priority_comparison/top10_blinded_annotation.csv` | 44 cases with manual selections and 11 assistant proposal columns | Merged, Batch 3 saved |
| `outputs/priority_comparison/top10_baseline_comparison_key.csv` | 44-case baseline/rank reference | Generated; keep separate from blinded review |
| `outputs/priority_comparison/evaluation_44_exploratory_20261014_155042_941024/` | Exploratory equal-budget outputs | Run completed |
| `outputs/priority_comparison/patient_counterfactual_exploratory_20261014_160609_713057/` | 12 one-rule and pair-level proposed change simulations | Run completed |
| `outputs/priority_comparison/independent_adjudication_20261014_155813_331513/` | Blank blinded sheet and restricted key | **Prepared, not adjudicated** |
| `outputs/overnight_audit/evidence_audit.jsonl` | Qwen judge audits | Runner reports **1,940/1,940** |
| `outputs/overnight_audit/errors.jsonl` | Cumulative errors during previous attempts | Contains historical failures; not automatically current missing records |
| `outputs/overnight_audit/overnight.log` | Long-run operational log | Contains earlier attempts and run messages |
| `outputs/overnight_audit/consistency_snapshot.csv` | Earlier partial analysis of judge consistency | Stale snapshot; **do not confuse with final 1,940-run consistency** |
| `outputs/overnight_audit/priority_inconsistency_review.csv` | Earlier AI-judge inconsistency review queue | Preliminary / not independently verified |
| `outputs/decision_impact/verified_counterfactual_pilot.csv` | Three earlier evidence-supported pilot corrections | **Preliminary**; filename is not independent medical validation |
| `outputs/traps/trap_pilot_verified.jsonl` | Three controlled trap records, manually checked for setup/schema | Trap definitions prepared; detection run not confirmed |

Other files or machine-specific environments may exist. Verify their latest state before treating them as finished.

### Presentation package already prepared in this chat

```text
MTP_Progress_Presentation_14Oct2026.pptx   # 13-slide progress deck
MTP_Progress_Presentation_14Oct2026.pdf    # presentation backup
MTP_Presentation_Speaking_Notes_14Oct2026.md
```

These are **presentation artifacts**, not experimental datasets. Keep a copy alongside this handoff; if the deck needs correction, preserve the original freeze edition.

---

## 4. Baseline: what we genuinely executed

**Screening model:** Qwen2.5:7b (approximately 7.6B parameters), served locally via Ollama. We configured an existing model and screening prompts; we **did not train Qwen**. The **evidence judge is also Qwen2.5:7b**, so its conclusions are not independent model-family corroboration.

| Dataset | Development pairs | Criterion predictions | Current role |
|---|---:|---:|---|
| NSCLC-100 | 50 | 950 | Development analysis |
| SIGIR-204 | 102 | 990 | Development-stage comparison |
| **Combined** | **152** | **1,940** | **Not frozen independent final test** |

The full source datasets include NSCLC-100 (100 pairs) and SIGIR-204 (204 pairs). The 50 and 102 above are **development portions**, not complete dataset sizes.

**Rule-level semantics:**

| Rule kind | `yes` means | `no` means | `unknown` means |
|---|---|---|---|
| Inclusion | `met` | `not_met` | `not_stated` |
| Exclusion | `not_met` | `met` | `not_stated` |

**Pair-level aggregation:** any `not_met` → `NOT_ELIGIBLE`; otherwise any `not_stated` → `REVIEW`; otherwise → `ELIGIBLE`. A `REVIEW` prediction is a third outcome and must be handled explicitly in accuracy/evaluation calculations.

**Development baseline results previously reported:**

- NSCLC: strict pair accuracy **50.0%**; 11 of 25 reference-eligible pairs were marked `NOT_ELIGIBLE`; 16/50 pairs classified `REVIEW`.
- SIGIR: strict pair accuracy **53.9%**; 17 of 49 reference-eligible pairs were marked `NOT_ELIGIBLE`; 69/102 pairs classified `REVIEW`.
- Across both development groups: **28 reference-eligible pairs** automatically rejected, **22 of those 28** with just one failing (`not_met`) criterion.

**Interpretation caveat:** Pair-level reference labels and criterion interpretations may themselves need reconciliation. These are **reference-label disagreements / possible false exclusions**, not automatically clinically adjudicated wrongful rejections. The definitions of strict vs lenient accuracy should be preserved from the evaluator when reporting them.

---

## 5. What we implemented in checking, ranking and annotation

### A. Six intended evidence checks

1. **Quotation authenticity:** Is the claimed evidence actually present in the clinical note?
2. **Evidence support:** Does the quoted/retrieved information support the criterion answer?
3. **Context:** Were negation, patient-versus-family history, timing and similar context interpreted correctly?
4. **Logic:** Is the criterion truth mapped consistently to the inclusion/exclusion verdict?
5. **Contradiction:** Does the note contradict the generated answer?
6. **Missed evidence:** Was material information overlooked?

**Current reality:** A quotation-checking component on PC1 passed four synthetic/local tests; the development environment generated 1,940 citation-status records. The other categories have **AI-generated audit flags for 1,940 outputs** but **have not been validated as six accurate standalone checkers**. A judge flag is not a clinical ground-truth label. The complete orchestrated checker/fixer pipeline has **not** been shown as finished.

**Citation-status counts previously reported (development):** 879 PASS, 118 FAIL, 943 NO_EVIDENCE (sum = 1,940). `FAIL` does not, by itself, prove the rule answer is wrong.

### B. Decision-impact / rejection-risk analysis

Generated criterion-level priority indicators such as `failing_count`, `sole_rejection`, `near_sole_rejection`, and `decision_changing`; a candidate queue contains 39 sole-rejection cases, including 22 reference-eligible pairs. These are **potential checks**, not verified rescued pairs.

### C. Five strategies

`random`, `confidence`, `citation`, `decision_impact`, and `combined` were ranked on the same 1,940 predictions (9,700 ranking rows). An earlier priority-retrieval comparison at budgets 25/50/100/200 counted reference-eligible sole-rejection candidates; this **partly rewards the definition used to construct the decision-impact ranking**, so it cannot establish independent error detection.

### D. 44-case exploratory annotation pilot

- Cases selected as the union of the **top ten under each of five strategies**: 44 unique, 22 NSCLC and 22 SIGIR.
- Original manual workflow: **15 cases processed** (3 preliminary evidence-supported, 8 pending evidence, 2 user-confirmed, 2 deferred); **29 not manually reviewed**.
- Assistant-generated proposals covering all 44: **10 `yes`, 1 `no`, 31 `unknown`, 2 `defer`**. `defer` is a **workflow choice**, not a criterion-truth class.
- The assistant proposals were merged as **11 new columns**, without overwriting manual fields; Batch 3 manual selections were subsequently written.
- **42 scorable assistant proposals** and **12 baseline–assistant truth disagreements**.
- **Zero independently adjudicated rule-level labels** at the last checkpoint. Prior exposure of some reviewed cases further limits blinding.

The blinded-review folder has **44 rows**, a blank independent adjudication sheet, and a **restricted comparison key**. Creating the sheet did not conduct the review.

---

## 6. Exploratory priority and counterfactual results: exact meaning

### Within the fixed 44-case selected cohort: budget 10

| Strategy | Baseline–assistant disagreements found | Scorable among ten |
|---|---:|---:|
| Random | 1 | 9 |
| Confidence | 0 | 10 |
| Citation | 1 | 10 |
| **Decision impact** | **7** | 10 |
| Combined | 6 | 9 |

**Do not report these as error-detection precision or unbiased superiority.** The evaluation set is a union selected *because* the strategies rank those cases highly. It is selection-biased, and the comparison target is assistant judgment, not independent truth.

### Global top-25 sample coverage (not exhaustively labeled)

| Strategy | Annotated among top 25 | Disagreements observed among annotated |
|---|---:|---:|
| Random | 10 | 1 |
| Confidence | 10 | 0 |
| Citation | 10 | 1 |
| Decision impact | 12 | 8 |
| Combined | 16 | 10 |

Do not interpret unannotated records as correct or error-free.

### Simulated patient-level changes for 12 disputed criteria

| Baseline pair decision → proposed pair decision | Count |
|---|---:|
| `NOT_ELIGIBLE → ELIGIBLE` | 1 |
| `NOT_ELIGIBLE → REVIEW` | 9 |
| `REVIEW → NOT_ELIGIBLE` | 1 |
| `NOT_ELIGIBLE → NOT_ELIGIBLE` | 1 |
| **Total** | **12** |

**11/12** proposed one-rule replacements change the simulated pair-level decision. The 12 cases are 12 distinct patient–trial pairs. The proposed labels were not independently adjudicated. **11 is not a verified rescue count or a validated clinical improvement rate.**

Reference-target distribution in these 12: **7 reference Eligible, 5 reference Not Eligible**. Of the **ten rejections removed**, seven have reference label Eligible and three have reference label Not Eligible. One `REVIEW → NOT_ELIGIBLE` case matches a reference Not Eligible label, but its protocol-level correctness is still unadjudicated.

**Concrete examples:**

- `ANN-017`: 78-year-old patient; age ≥18 inclusion; baseline `no`, proposed `yes`; `NOT_ELIGIBLE → REVIEW` (18 other unknowns remain).
- `ANN-019`: ECOG 1 against ECOG 0/1 inclusion; baseline `no`, proposed `yes`; `NOT_ELIGIBLE → REVIEW` (6 unknowns remain).
- `ANN-021`: ECOG 1 against ECOG 0/1; `NOT_ELIGIBLE → ELIGIBLE`; previously reviewed, so not an independently validated example.
- `ANN-038`: bipolar disorder vs DSM-IV Axis I exclusion; proposed `unknown → yes` changes `REVIEW → NOT_ELIGIBLE` (requires precise full-protocol adjudication).

**Separate preliminary repair/counterfactual pilot:** NSCLC pair 25 criterion 3 → ELIGIBLE; pair 26 criterion 3 → REVIEW; pair 48 criterion 13 → REVIEW. These were manually evidence-supported demonstrations, **not a finished fixer evaluation** and not independent clinical adjudications.

---

## 7. Evidence audit: what it showed and what is problematic

### Full generation completed

- `experiments/overnight_evidence_audit.py` queries local **Qwen2.5:7b** against baseline answers and patient notes.
- It returns nested fields: `support`, `context_issue`, `logic_issue`, `contradiction_issue`, `missed_evidence_issue`, `suggested_truth`, `suggested_verdict`, `needs_human_review`, `explanation`.
- After the targeted schema patch and a single-case retry, the **runner reported 1,940/1,940 with zero remaining**.
- Source results should be preserved raw with the patch metadata. Do **not** rewrite the `suggested_verdict` field in place.

### The major reliability finding (measured before the final record)

On the **first 1,939 audit outputs**, a deterministic check found:

| Diagnostic | Count | Meaning |
|---|---:|---|
| **Invalid suggested truth→verdict mapping** | **669 / 1,939 (34.50%)** | Self-inconsistent *output pair*, not clinical error rate |
| `missed_evidence_issue=yes` while suggested truth remained identical to baseline | 924 | Potentially overbroad signal; does not automatically prove false flag |
| Of those 924, both truths were `unknown` | 924 | The flag did not change the criterion truth for those cases |

After adding audit record 1,940, these exact counts must be **recalculated**. Do not silently label **669/1,940** or imply the 34.50% estimate is from all 1,940.

Earlier partial snapshot at **1,905** outputs included: support `supported=793`, `insufficient=1,077`, `unsupported=29`, `uncertain=6`; context `yes=6`; logic `yes=47`; contradiction `yes=3`; missed evidence `yes=954`; human review requested `972`. Those are **older snapshot counts**, not the final full-audit distribution. Recompute them before making an updated table or slide.

**Especially important:** The judge's `logic_issue=yes` flag is not the same measurement as the **669 structurally inconsistent truth/verdict pairs**. Their mismatch itself is a useful reliability question, but the denominator and definitions must be kept separate.

### Why this matters scientifically

A second LLM, especially one of the same model family, cannot be treated as a trusted judge solely because it outputs a confident correction. Our system must:

1. Validate output schema.
2. Keep original evidence and raw judge output.
3. Derive the eligibility verdict **deterministically** from `suggested_truth` and `criterion_kind`.
4. Flag or defer unsupported/ambiguous suggested truths.
5. Measure correctness with independent adjudications and controlled known-answer traps.
6. Quantify improvements *and harms* from applying changes.

**Do not “fix” 669 outputs by assuming the suggested truths are correct.** Deterministic mapping fixes only internal logic. It does not establish the clinical truth of any criterion.

### The one schema retry, precisely

- Failed key: `('nsclc100', 15, 17)`; exclusion “Subjects who are incarcerated.”
- Multiple earlier log entries said `Invalid support: no_evidence`.
- A code patch normalizes `support=no_evidence → insufficient`, preserving the original token in an extra field.
- That is an **output representation normalization**, not a clinical assertion. It must be documented in the methods and inspected on the final record.
- Cumulative `errors.jsonl` entries do not mean the final audit is still missing those records; validate against successful IDs instead.

---

## 8. PC1, PC2 and personal-laptop responsibilities (do not merge machine provenance)

| Machine | Last known address / role | Proven work | Not proven complete |
|---|---|---|---|
| **Personal laptop (`skyee`)** | `/home/honcho/MTP/Akash_Kit` — integration, baseline, rankings, annotation, audits | 950+990 baseline; 1,940 ranking/citation records; 44-case proposals; equal-budget pilot; 12 counterfactuals; final runner-reported 1,940 judge audits | Independent truth validation, final held-out test, full checker accuracy, fixer and trap outcome comparison |
| **PC1 (`Lab303-12`)** | `/home/user/MTP/Akash_Kit` — checking and prioritization | Environment set up after initial Python 3.8 check; citation checker four cases passed (`authentic`, `fabricated`, `mixed`, `missing`) and saved `outputs/evidence_checks/citation_validation.json` | Full six-check integration, 1,940-case end-to-end checker on PC1, reviewed precision/recall, cross-machine sync status |
| **PC2 (`PCLAB3-02`, previously identified)** | Traps, repair/deferral, held-out validation | Planned assignment and supplied framework; some trap setup/testing demonstrated on `skyee` | **No recent PC2 terminal evidence** confirming controlled trap model results, safe repair evaluation or held-out runs |

The supplied framework had previously reported **36/36 NSCLC and 9/9 SIGIR technical checks passing**, but passing framework tests is **not** the same as measured clinical checking quality. Exact PC2 machine state should be rechecked when that machine becomes available.

**Cross-machine rule:** A file generated on `skyee` does not automatically exist on `Lab303-12` or `PCLAB3-02`. Transfer **versioned experiment artifacts**, not vague claims of completion. Avoid running three copies of the same expensive inference if development results can be reused legitimately.

---

## 9. Work deliberately NOT completed (the backlog)

| Work | Present state | Why it matters |
|---|---|---|
| Independently review 44 selected criterion cases | Blank blinded sheet prepared; 0 independent adjudications | Needed to distinguish real baseline errors from disagreement with assistant suggestions |
| Validate all six evidence checks against known truth | Qwen flags exist; individual verified precision/recall absent | Checker reliability is central to the project |
| Deterministic verdict-reconciliation analysis | Mismatch quantified on 1,939; no final reconciled derived dataset confirmed | Prevents automatic use of logically invalid suggestions |
| Final audit ID/count consistency and immutable freeze | Retry success reported; separate complete-file assertion not shown | Reproducibility/integrity |
| Three controlled-trap cases | Definitions and schema checked | Known-answer tests needed; model detection run not confirmed |
| Wider seven-type controlled trap set | Planned | Coverage of different failure modes |
| Repair-versus-deferral study | Not completed | Must count answers repaired **and previously correct answers broken** |
| Full reviewed-priority comparison | Exploratory selected-cohort comparison only | Needs fair denominator and independent verification |
| Held-out NSCLC test + frozen SIGIR transfer | Not shown completed | Needed for generalization claims |
| Final reproducible scientific report | Progress deck exists, final report pending | Needed to explain methods, biases, uncertainty and results |

Do **not** state that all six checks, a calibrated rejection-risk system, or a verified repair system have been fully built and evaluated. Some components exist as partial scripts, rankings, queues or pilot prototypes; the complete measured workflow remains unfinished.

---

## 10. EXACT RESUME POINT: commands to execute in order, after presenting

**Phase 0 — Preserve the presentation snapshot.** Download the PPTX/PDF/speaking notes and keep this Markdown handoff with them. Do not modify the frozen slides merely because additional results become available later; make a versioned revision.

### RESUME COMMAND 1 — Read-only audit integrity check (do this FIRST)

Run in a terminal on **`skyee`**, not PC1/PC2:

```bash
cd ~/MTP/Akash_Kit
python3 - <<'PY'
import json
from pathlib import Path
from collections import Counter

sources = [
    Path('outputs/plain_ai_qwen_dev.jsonl'),
    Path('outputs/plain_ai_qwen_sigir_dev.jsonl'),
]
audit_file = Path('outputs/overnight_audit/evidence_audit.jsonl')

def read(path):
    with path.open(encoding='utf-8') as f:
        return [json.loads(s) for s in f if s.strip()]

def key(r):
    return (str(r['dataset']), int(r['pair_idx']), int(r['crit_idx']))

predictions = [r for p in sources for r in read(p)]
audits = read(audit_file)
expected = [key(r) for r in predictions]
completed = [key(r) for r in audits]
reference = set(expected)
observed = set(completed)
print('Expected baseline records:', len(predictions))
print('Saved audit records:', len(audits))
print('Unique baseline IDs:', len(reference))
print('Unique audit IDs:', len(observed))
print('Missing IDs:', len(reference-observed))
print('Unexpected IDs:', len(observed-reference))
print('Duplicate audit IDs:', len(completed)-len(observed))
print('Audited records by dataset:', dict(Counter(k[0] for k in observed)))
target = [r for r in audits if key(r) == ('nsclc100',15,17)]
print('Patched case count:', len(target))
if target:
    print('Patched case support:', target[0]['audit'].get('support'))
    print('Original support token:', target[0]['audit'].get('support_original_value', '(not needed)'))
assert len(predictions) == len(reference) == 1940
assert len(audits) == len(observed) == 1940
assert reference == observed
assert len(target) == 1
print('FINAL RAW AUDIT INTEGRITY: PASS')
print('Files modified: NO; Ollama calls: 0')
PY
```

**Expected if nothing changed:** `1940` predictions, `1940` unique audits, `0` missing/extra/duplicate IDs, `1` patched case, `PASS`. If any assertion fails, **do not rerun the whole audit**; inspect only the failing identities.

### RESUME COMMAND 2 — Recalculate final 1,940-audit judge consistency (read-only)

```bash
cd ~/MTP/Akash_Kit
python3 - <<'PY'
import json
from pathlib import Path
from collections import Counter

def read(p):
    with Path(p).open(encoding='utf-8') as f:
        return [json.loads(s) for s in f if s.strip()]

def key(r):
    return (r['dataset'], int(r['pair_idx']), int(r['crit_idx']))

base = {key(r):r for p in (
    'outputs/plain_ai_qwen_dev.jsonl',
    'outputs/plain_ai_qwen_sigir_dev.jsonl'
) for r in read(p)}
audits = read('outputs/overnight_audit/evidence_audit.jsonl')
assert len(base) == len(audits) == 1940

def expected(truth, kind):
    if truth == 'unknown': return 'not_stated'
    if kind == 'inclusion': return 'met' if truth == 'yes' else 'not_met'
    if kind == 'exclusion': return 'not_met' if truth == 'yes' else 'met'
    return 'INVALID_KIND'

mismatch = Counter(); flags = Counter(); support = Counter()
for r in audits:
    b=base[key(r)]; a=r['audit']
    t=str(a.get('suggested_truth','')).lower()
    v=str(a.get('suggested_verdict','')).lower()
    exp=expected(t,b['kind']) if t in ('yes','no','unknown') else 'INVALID_TRUTH'
    if v!=exp: mismatch[(b['kind'],t,v,exp)]+=1
    if a.get('missed_evidence_issue')=='yes':
        flags['missed_yes']+=1
        if t==b['truth']: flags['missed_yes_unchanged_truth']+=1
        if t==b['truth']=='unknown': flags['missed_yes_both_unknown']+=1
    if a.get('needs_human_review') is True: flags['review_true']+=1
    support[a.get('support','(missing)')]+=1
print('Audits:',len(audits))
print('Invalid judge truth/verdict mappings:',sum(mismatch.values()))
print('Invalid rate (%):',round(100*sum(mismatch.values())/len(audits),2))
print('Mismatch types:',dict(mismatch))
print('Missed-evidence diagnostics:',dict(flags))
print('Support distribution:',dict(support))
print('Files modified: NO; Ollama calls: 0')
PY
```

**The 669/1,939 estimate becomes final only after this recalculation.** Keep the precise denominator and disclose that this measures **internal consistency**, not medical accuracy.

### RESUME COMMAND 3 — Freeze immutable source copies and provenance

Only after Commands 1–2 pass, create a **new** snapshot directory with an explicit experiment manifest, source SHA-256 hashes, patch information, current script revision, and timestamp. Prefer versioning rather than overwriting. Copy at minimum both baseline JSONLs, the audit JSONL, error log, ranking CSV, original/merged annotation CSV and the scripts actually used. Treat patient notes as sensitive; do not upload source notes or logs to public repositories. This is a planned operation; **it has not been done yet**.

### RESUME COMMAND 4 — Build a *derived*, deterministic audit table

Create a new analysis file with fields such as:

```text
dataset, pair_idx, crit_idx, criterion_kind,
baseline_truth, baseline_verdict,
judge_suggested_truth, judge_suggested_verdict_raw,
judge_verdict_deterministic,
judge_mapping_inconsistent,
support, context_issue, logic_issue,
contradiction_issue, missed_evidence_issue,
needs_human_review, raw_audit_reference
```

Use the `truth→verdict` table from Section 4; **never silently edit the raw judge outputs**. A corrected *mapping* is not a corrected clinical *judgment*. Look at `experiments/audit_consistency_analysis.py`, but verify its assumptions and outputs because existing files may be from an older partial snapshot.

### RESUME COMMAND 5 — Continue actual PC1 and PC2 research

**PC1 track:** validate the six checks with independent adjudications/known-answer traps; characterize false flags; join checking signals with the same decision-impact/ranking universe; evaluate error capture and review workload at matched budgets. Mark sampled/biased evaluations exploratory.

**PC2 track:** run the 3-case trap pilot on local Qwen after the audit has stopped, expand the trap set, compute per-type known-answer detection, then compare conservative deferral versus evidence-grounded repair. Crucially record **newly broken formerly correct answers**, false inclusions, and unresolved REVIEW cases. Freeze the strategy **before** test-set evaluation.

**Next broader step:** only after development methods are frozen, execute NSCLC held-out and SIGIR transfer/generalization evaluation as designed in the guide, with patient/trial grouping and reference-label limitations made explicit.

---

## 11. Decisions and principles for the remainder of the project

1. **No fake completion claims.** A saved file or running Python script is not proof that an experimental research question has been answered.
2. **No silent conversion of `unknown` into `no`.** The note's absence of evidence is not evidence of absence.
3. **No silent judge correction.** Keep `suggested_verdict` raw and store deterministic mapping separately.
4. **Never call preliminary proposals “gold labels.”** Zero independent adjudications so far.
5. **Separate development, selected pilots and untouched test sets.** The top-ten union is rank-selected; do not use it to prove an unbiased precision@10 advantage.
6. **Trace source provenance.** Report which machine and code version generated each artifact; PC1 and PC2 status must be checked, not assumed from PL results.
7. **Count harmful as well as beneficial repairs.** An algorithm that removes a rejection can be wrong, and a correct exclusion may need to be retained.
8. **Measure reviewed cases as actual work.** A `REVIEW` label is not the same as an eligible patient or a rescued patient.
9. **Treat clinical notes as sensitive research data.** Keep data, adjudication and model inference on approved local machines; do not publish notes or identifiable histories.
10. **Preserve today's progress.** Present what was truly done, then resume from the integrity check without restarting inference.

---

## 12. Presentation-specific reality check

The **13-slide progress presentation** and speaking notes were prepared to show completed development-stage outputs. When speaking, use these defensible sentences:

> “We completed 1,940 development criterion predictions and a 1,940-result model-assisted evidence audit. We compared five priority strategies exploratorily and simulated the effect of 12 disputed rule answers on pair-level eligibility. Eleven proposed changes altered simulated decisions. However, these proposals have not yet undergone independent adjudication, and a second AI judge showed substantial inconsistency in how it mapped proposed truths to eligibility verdicts. Validation, controlled traps, repair safety and held-out evaluation remain future work.”

**Do not say:** “Our checker accurately caught 11 clinical errors,” “we rescued 10 patients,” “all six checks are validated,” or “decision-impact ranking has been proven best.”

**Version caveat:** The pre-existing file `Midsem_Slide_MTP.txt` is an **older handoff**, written when only an initial NSCLC baseline pilot had been executed. Its statements such as “ranking not implemented” and “where we stopped: pair-7 pilot” were accurate **for that older date**, but are **obsolete as of this checkpoint**. **This handoff supersedes that older document.**

---

## 13. Ready-to-paste message for a fresh ChatGPT conversation

> We are continuing the MTP “Check What Can Change the Outcome: Targeted Checking of AI Screening Decisions for Clinical Trials.” The authoritative checkpoint is **MTP_EXACT_STOP_AND_RESUME_HANDOFF_14OCT2026.md**. Development laptop: Ubuntu `skyee`, `~/MTP/Akash_Kit`; other computers PC1 `Lab303-12` and PC2 `PCLAB3-02`. We finished 950 NSCLC + 990 SIGIR criterion baseline predictions across 152 dev pairs; 1,940 citation-status rows; 9,700 ranks across five strategies; 44 selected assistant-proposed labels; 12 baseline/assistant disagreements; 11/12 simulated pair-decision changes; and the Qwen evidence-audit runner reported **1,940/1,940** successful audits after fixing one `no_evidence` schema token and retrying one missing record. On the first 1,939 audit outputs, 669 suggested truth/verdict pairs (34.50%) were inconsistent. **No independent criterion adjudications, final six-check accuracy, completed trap-detection or fixer-safety study, or held-out generalization results exist yet.** We paused only for a progress presentation. **FIRST NEXT ACTION:** execute the read-only final audit integrity verification in Section 10, then recalculate consistency on all 1,940, freeze raw results, create a derived deterministic analysis table, and resume PC1/PC2 experiments. Do not restart baseline inference and do not overclaim clinical rescues. Work one terminal command at a time.

---

## 14. Very short “where we are” card

**DONE:** Development baseline (1,940), citation-status output, five rankings, selected 44-case exploration, 12 hypothetical changes, full Qwen audit run (1,940).  
**FOUND:** A promising concentration of decision-relevant disagreements **and** a serious judge mapping-consistency defect (669/1,939 earlier snapshot).  
**NOT DONE:** Independent truth labels, final audit freeze/derived mapping, measured six-check validity, trap detection, safe repair, unbiased held-out results.  
**STOPPED AT:** Single remaining audit successfully retried; presentation preparation began.  
**RESUME WITH:** Final read-only audit integrity + complete 1,940-record consistency analysis.  
**THEN:** Freeze evidence → validate checks → known-answer traps → repair vs deferral → held-out comparisons → final scientific report.

*End of checkpoint. This document describes what had actually been evidenced in the conversation as of 14 October 2026. Status on PC1/PC2 and the final on-disk integrity of the audit need to be rechecked after the presentation.*
