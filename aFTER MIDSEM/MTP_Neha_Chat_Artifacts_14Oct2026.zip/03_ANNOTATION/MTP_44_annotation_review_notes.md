# MTP — 44-case evidence annotation proposals

## Scope and provenance

This package was prepared from the uploaded `top10_blinded_annotation.csv` containing 44 selected criterion–patient pairs: 22 from NSCLC-100 and 22 from SIGIR-204. The uploaded original fields and prior selections are preserved. This is an **assistant-generated proposal**, not independently clinically adjudicated ground truth and not a user/human verification certificate.

The proposed truth labels use the project's rule semantics: **yes** means the specific criterion is true, **no** means the specific criterion is false, and **unknown** means the clinical note cannot determine it. An exclusion rule with truth **yes** corresponds to verdict `not_met`, not `met`. `defer` is an annotation-workflow state, not a truth label, and should not be included in a truth-label confusion matrix.

## Summary

| Proposed label | Count |
|---|---:|
| yes | 10 |
| no | 1 |
| unknown | 31 |
| defer | 2 |
| **Total** | **44** |

Of 15 earlier user-selected labels (10 in uploaded CSV and 5 confirmed in chat but not saved in that file), 5 agree and 10 disagree with the evidence-based proposals. Disagreements are retained, **not silently overwritten**. Cases ANN-001, 002, 004, 005, 006, 007, 008, 010, 011 and 012 need particular attention because a definite or deferred earlier selection conflicts with evidence-only `unknown`.

## Special interpretation cautions

- **ANN-009:** Explicitly documents hysterectomy within 15 days; the major-surgery-within-30-days exclusion is true.
- **ANN-014 and ANN-017:** Document ages 53 and 78, respectively; the adult inclusion criterion is true.
- **ANN-015 and ANN-016:** Explicitly document creatinine above the exclusion threshold and severe COPD due to LVRS, respectively.
- **ANN-018:** Prior lung-cancer treatment is documented, but the *within three years* timing is not.
- **ANN-020:** Explicit absence of anti-PD-1 or PD-L1 treatment supports false for that exclusion criterion.
- **ANN-021:** ECOG score 1 explicitly meets the ECOG 0/1 inclusion rule; this case was already discussed in earlier project work, so annotation is **not independent/blind**.
- **ANN-022:** Prior radiation was for skin cancer, not the current lung cancer; do not count it as evidence that the current-diagnosis therapy restriction was violated.
- **ANN-023:** Respiratory distress is explicitly present.
- **ANN-024:** The pneumonia enrollment criterion has multiple required elements; infiltrates alone do not establish its specific radiographic pattern.
- **ANN-027:** Colonic polyps do not establish gastric/duodenal ulcer history.
- **ANN-028:** Adenomas were found with sigmoidoscopy documented, whereas the criterion says screening/surveillance colonoscopy; mark procedure linkage uncertain pending protocol guidance.
- **ANN-031:** Lithium is specifically exempted, but the medicine list and status *at randomization* are not fully established.
- **ANN-034:** Taking lithium does not by itself establish steady state for 2 weeks and monotherapy requirements.
- **ANN-035:** The extracted inter-episode definition refers to cutoffs not provided; defer for protocol adjudication.
- **ANN-036:** Suicidal thoughts are noted, but the term *high risk of harm* needs clinical risk assessment; note-only truth remains unknown. This is a research annotation, not an assessment of an actual patient.
- **ANN-038:** Bipolar disorder is classified under DSM-IV Axis I, so the exclusion condition is true.
- **ANN-040:** Prescribed medication use is current; the meaning/scope of the protocol's interference qualifier warrants checking.
- **ANN-043:** Progressive dementia/myoclonus are documented; the required EEG/MRI or biopsy criteria are not.
- **ANN-044:** Cognitive impairment is apparent, but whether it represents *comorbid* impairment relative to the study's primary disease is ambiguous; defer.

## How to use the files

1. Download `MTP_44_evidence_based_proposals.csv`, which retains all source fields and adds prefixed `assistant_` columns. Compare the proposed truth, exact evidence excerpt, explanation, confidence, and caveat against each original clinical note.
2. Optionally download `merge_mtp_annotation_proposals.py` and copy both it and the proposal CSV to `~/Downloads/` on the Ubuntu system.
3. Dry-run (no writes): `python3 ~/Downloads/merge_mtp_annotation_proposals.py`
4. To append only proposal columns after examining the preview: `python3 ~/Downloads/merge_mtp_annotation_proposals.py --apply`

The merger matches exact case IDs, trial/criterion identity, notes, and criteria. It refuses mismatches, backs up the original CSV, and **does not change `manual_truth`, `manual_reasoning`, `manual_evidence_quote`, `ambiguity_flag`, or `review_status`.** It does not use Ollama.

## Evaluation warning

The top-10-per-strategy union is a fixed-budget *targeted* annotation pilot, not a random held-out dataset. Several cases were already reviewed in this conversation. Do not label assistant proposals or prior user selections as independently adjudicated truth. For a defensible precision@10 comparison, use only newly adjudicated labels under a documented annotation protocol, and report cases that cannot be judged separately.
