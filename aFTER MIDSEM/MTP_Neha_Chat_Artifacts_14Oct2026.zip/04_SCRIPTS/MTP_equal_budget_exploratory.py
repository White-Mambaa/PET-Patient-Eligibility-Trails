#!/usr/bin/env python3
"""CPU-only, non-destructive exploratory equal-budget evaluation for MTP.

Input: merged top10_blinded_annotation.csv, top10_baseline_comparison_key.csv,
       priority_rankings.csv. Does not call Ollama or alter source files.

Two analyses:
(1) Cohort-conditional same-budget selection among the 44 deliberately sampled cases.
(2) Unrestricted global top-B retrieval, with annotation coverage explicitly shown.

This is NOT a clinical correctness or rescued-patients validation.
"""
import argparse
import csv
import json
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

STRATEGIES = ('random', 'confidence', 'citation', 'decision_impact', 'combined')
COHORT_BUDGETS = (5, 10, 20, 30, 44)
GLOBAL_BUDGETS = (10, 25, 50, 100, 200)
VALID_TRUTHS = {'yes', 'no', 'unknown'}
EXPLICIT_STATUSES = {'EXPLICIT_EVIDENCE_PRELIMINARY'}  # Caveated evidence is not in this strict subset.


def read_csv(path):
    if not path.is_file():
        raise FileNotFoundError(f'Missing required input: {path}')
    with path.open(newline='', encoding='utf-8-sig') as fh:
        rd = csv.DictReader(fh)
        if rd.fieldnames is None:
            raise ValueError(f'No header in {path}')
        return rd.fieldnames, list(rd)


def require(fields, keys, origin):
    absent = set(keys) - set(fields)
    if absent:
        raise ValueError(f'Missing columns in {origin}: {sorted(absent)}')


def key(row):
    return row['dataset'].strip(), int(row['pair_idx']), int(row['crit_idx'])


def write_csv(path, fieldnames, rows):
    with path.open('w', newline='', encoding='utf-8') as fh:
        wr = csv.DictWriter(fh, fieldnames=fieldnames, extrasaction='ignore')
        wr.writeheader()
        wr.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path('.'), help='Project root (default: current directory)')
    parser.add_argument('--output', type=Path, help='Optional new output directory. Must not already exist.')
    args = parser.parse_args()
    root = args.root.expanduser().resolve()
    base = root / 'outputs' / 'priority_comparison'
    annotation_path = base / 'top10_blinded_annotation.csv'
    baseline_path = base / 'top10_baseline_comparison_key.csv'
    rankings_path = base / 'priority_rankings.csv'

    af, ann = read_csv(annotation_path)
    bf, bas = read_csv(baseline_path)
    rf, ranks = read_csv(rankings_path)
    require(af, ['case_id', 'dataset', 'pair_idx', 'crit_idx', 'criterion_kind',
                 'manual_truth', 'review_status', 'assistant_proposed_truth',
                 'assistant_proposal_status', 'assistant_prior_exposure_note',
                 'assistant_evaluation_eligible'], 'annotations')
    require(bf, ['case_id', 'dataset', 'pair_idx', 'crit_idx', 'baseline_truth',
                 'baseline_verdict'], 'baseline key')
    require(rf, ['strategy', 'rank', 'dataset', 'pair_idx', 'crit_idx'], 'rankings')
    if len(ann) != 44 or len(bas) != 44:
        raise ValueError(f'Expected 44 annotation and 44 baseline records, got {len(ann)} and {len(bas)}')
    ann_by_id = {}
    bas_by_id = {}
    ann_keys = set()
    for item in ann:
        cid = item['case_id'].strip()
        if cid in ann_by_id or key(item) in ann_keys:
            raise ValueError(f'Duplicate annotated case: {cid}')
        ann_by_id[cid] = item
        ann_keys.add(key(item))
    for item in bas:
        cid = item['case_id'].strip()
        if cid in bas_by_id:
            raise ValueError(f'Duplicate baseline case: {cid}')
        bas_by_id[cid] = item
    if set(ann_by_id) != set(bas_by_id):
        raise ValueError('Annotation and baseline case_id sets differ')
    for cid, item in ann_by_id.items():
        if key(item) != key(bas_by_id[cid]):
            raise ValueError(f'Baseline join mismatch: {cid}')

    global_positions = {}
    universes = {}
    for strategy in STRATEGIES:
        subset = [r for r in ranks if r['strategy'].strip() == strategy]
        rank_map = {}
        seen_ranks = set()
        for r in subset:
            k = key(r)
            position = int(r['rank'])
            if position < 0 or k in rank_map or position in seen_ranks:
                raise ValueError(f'Duplicate/invalid rank in strategy {strategy}: {k} -> {position}')
            rank_map[k] = position
            seen_ranks.add(position)
        global_positions[strategy] = rank_map
        universes[strategy] = set(rank_map)
    if sum(len(s) for s in global_positions.values()) != len(ranks):
        raise ValueError('Ranking file contains unknown strategies or duplicates')
    if any(universes[s] != universes[STRATEGIES[0]] for s in STRATEGIES[1:]):
        raise ValueError('Strategies do not rank the same criterion universe')
    if not ann_keys.issubset(universes[STRATEGIES[0]]):
        raise ValueError('Some annotated cases are absent from the rankings')
    rank_counts = {s: len(global_positions[s]) for s in STRATEGIES}
    total_universe = len(universes[STRATEGIES[0]])
    if min(rank_counts.values()) < max(GLOBAL_BUDGETS):
        raise ValueError(f'Ranking universe too small for global budgets: {rank_counts}')

    detailed = []
    for cid in sorted(ann_by_id):
        a = ann_by_id[cid]
        b = bas_by_id[cid]
        proposed = a['assistant_proposed_truth'].strip().lower()
        baseline = b['baseline_truth'].strip().lower()
        manual = a['manual_truth'].strip().lower()
        if proposed not in VALID_TRUTHS | {'defer'}:
            raise ValueError(f'Unexpected assistant truth label in {cid}: {proposed}')
        if baseline not in VALID_TRUTHS:
            raise ValueError(f'Unexpected baseline truth label in {cid}: {baseline}')
        if manual not in VALID_TRUTHS | {'', 'defer'}:
            raise ValueError(f'Unexpected manual truth in {cid}: {manual}')
        explicit = a['assistant_proposal_status'].strip() in EXPLICIT_STATUSES
        manual_prelim = a['review_status'].strip() == 'EVIDENCE_SUPPORTED_PRELIMINARY'
        row = {
            'case_id': cid,
            'dataset': a['dataset'],
            'pair_idx': a['pair_idx'],
            'crit_idx': a['crit_idx'],
            'criterion_kind': a['criterion_kind'],
            'baseline_truth': baseline,
            'baseline_verdict': b['baseline_verdict'],
            'assistant_proposed_truth': proposed,
            'assistant_proposal_status': a['assistant_proposal_status'],
            'assistant_exploratory_scorable': 'yes' if proposed in VALID_TRUTHS else 'no',
            'assistant_baseline_disagreement': (
                'yes' if proposed in VALID_TRUTHS and proposed != baseline
                else ('no' if proposed in VALID_TRUTHS else 'not_scorable')
            ),
            'explicit_proposal_preliminary': 'yes' if explicit else 'no',
            'explicit_proposal_disagreement': (
                'yes' if explicit and proposed in VALID_TRUTHS and proposed != baseline else 'no'
            ),
            'manual_truth': manual,
            'manual_review_status': a['review_status'],
            'manual_evidence_preliminary': 'yes' if manual_prelim else 'no',
            'manual_preliminary_disagreement': (
                'yes' if manual_prelim and manual in VALID_TRUTHS and manual != baseline else 'no'
            ),
            'prior_exposure_flag': 'yes' if a['assistant_prior_exposure_note'].strip() else 'no',
            'independently_adjudicated': 'no',
        }
        for s in STRATEGIES:
            row[s + '_global_rank'] = global_positions[s][key(a)]
        detailed.append(row)

    by_id = {r['case_id']: r for r in detailed}
    cohort_rows = []
    for strategy in STRATEGIES:
        ordered = sorted(detailed, key=lambda r: (r[strategy + '_global_rank'], r['case_id']))
        for i, r in enumerate(ordered, 1):
            cohort_rows.append({
                'strategy': strategy, 'cohort_rank': i,
                'global_rank': r[strategy + '_global_rank'],
                'case_id': r['case_id'], 'dataset': r['dataset'],
                'assistant_baseline_disagreement': r['assistant_baseline_disagreement'],
                'manual_review_status': r['manual_review_status'],
            })
    def summarize(records, strategy, budget, mode):
        n = len(records)
        scoreable = sum(r['assistant_exploratory_scorable'] == 'yes' for r in records)
        mismatch = sum(r['assistant_baseline_disagreement'] == 'yes' for r in records)
        explicit_checked = sum(r['explicit_proposal_preliminary'] == 'yes' for r in records)
        explicit_mismatch = sum(r['explicit_proposal_disagreement'] == 'yes' for r in records)
        manual_checked = sum(r['manual_evidence_preliminary'] == 'yes' for r in records)
        manual_mismatch = sum(r['manual_preliminary_disagreement'] == 'yes' for r in records)
        nsclc = sum(r['dataset'] == 'nsclc100' for r in records)
        exposed = sum(r['prior_exposure_flag'] == 'yes' for r in records)
        return {
            'comparison_mode': mode,
            'strategy': strategy,
            'budget': budget,
            'reviewed_cases_in_44_case_sample': n,
            'reviewed_sample_coverage_of_budget': f'{n}/{budget}',
            'assistant_scorable': scoreable,
            'assistant_deferred_or_unscorable': n - scoreable,
            'assistant_baseline_disagreements': mismatch,
            'assistant_disagreement_per_scorable': f'{mismatch / scoreable:.4f}' if scoreable else '',
            'explicit_proposal_preliminary_cases': explicit_checked,
            'explicit_proposal_disagreements': explicit_mismatch,
            'manual_evidence_preliminary_cases': manual_checked,
            'manual_preliminary_disagreements': manual_mismatch,
            'nsclc_cases': nsclc,
            'sigir_cases': n - nsclc,
            'previously_exposed_cases': exposed,
            'independently_adjudicated_cases': 0,
        }

    cohort_summary = []
    global_summary = []
    for s in STRATEGIES:
        ordered = sorted(detailed, key=lambda r: r[s + '_global_rank'])
        for budget in COHORT_BUDGETS:
            cohort_summary.append(summarize(ordered[:budget], s, budget, 'WITHIN_44_CASE_SELECTED_COHORT'))
        for budget in GLOBAL_BUDGETS:
            annotated_at_global_budget = [r for r in detailed if r[s + '_global_rank'] <= budget]
            global_summary.append(summarize(annotated_at_global_budget, s, budget, 'GLOBAL_TOP_B_OBSERVED_ONLY'))

    note = f'''# MTP exploratory equal-budget evaluation (44 selected cases)

Created: {datetime.now().isoformat(timespec='seconds')}
Ranking universe: {total_universe} criterion records per strategy; {len(detailed)} distinct annotated cases in the selected cohort.

## Inputs
- top10_blinded_annotation.csv: user's preserved manual selections plus assistant proposals.
- top10_baseline_comparison_key.csv: held-out baseline answers revealed only during evaluation.
- priority_rankings.csv: unchanged five-method ranking of the full criterion universe.

## Outputs
- case_level_comparison.csv: one record per annotated case, baseline and proposal labels, tier flags, and all 5 ranks. No patient notes copied.
- equal_budget_within_44_cohort.csv: for each strategy at review budgets 5/10/20/30/44, take that many cases **from the already selected union of 44 cases**. Same sample size across strategies, but this is a biased, strategy-selected cohort, not an external evaluation set. The same 44 cases are used for every strategy.
- equal_budget_global_top_b_coverage.csv: for budgets 10/25/50/100/200 in the full {total_universe}-criterion universe, only the already annotated cases in each top-B set can be scored. **Unreviewed cases are missing labels, NOT assumed correct.** Do not compare raw discrepancy counts if coverage differs.
- cohort_ranking_order.csv: case IDs in each strategy's rank order restricted to 44 cases.
- evaluation_metadata.json: basic input counts and methodological warnings.

## Interpretation and caveats
**assistant_baseline_disagreements** counts discrepancies between baseline model truth label and assistant-proposed truth label. It does NOT mean confirmed AI errors, patient rescues, or independent correctness. A proposed `unknown` is compared as its own label, and `defer` is excluded from the scorable denominator.

**explicit_proposal_disagreements** counts only cases marked EXPLICIT_EVIDENCE_PRELIMINARY in the assistant annotations; a quotation existing in a patient note is not an independent adjudication, and some medical criteria need protocol/context review.

**manual_preliminary_disagreements** counts only manual records marked EVIDENCE_SUPPORTED_PRELIMINARY; these are not independent adjudications. USER_CONFIRMED alone does not establish clinical correctness. PENDING_EVIDENCE, DEFERRED, and UNREVIEWED manually remain unverified.

**Major design limitations:** Cases were preselected as the union of the top ten from the five ranked strategies, so rankings influence entry into the cohort (selection bias). Earlier cases/criteria were already examined in conversation (exposure). Assistant and baseline are both model-based; the assistant proposal is not blind independent human ground truth. Decision-impact-based retrieval of sole-rejection flags partly shares the defining logic of the candidate outcome (circularity). The five methods can be described descriptively within this cohort, not tested for independent real-world rescue superiority. Prioritize independent adjudication across a stratified or held-out random selection before inferential claims.

**Scope:** Criterion-level truth-label disagreement only. No counterfactual pair-decision recalculation, no audited repair, no patient-level recovery, no confusion-matrix model accuracy, and no new Ollama inference. `reference_pair_target` intentionally excluded as a criterion-level gold label.
'''
    out_dir = (args.output.expanduser().resolve() if args.output else
               (base / ('evaluation_44_exploratory_' + datetime.now().strftime('%Y%m%d_%H%M%S_%f'))))
    if out_dir.exists():
        raise FileExistsError(f'Output directory already exists; refusing to overwrite: {out_dir}')
    out_dir.mkdir(parents=True)
    write_csv(out_dir / 'case_level_comparison.csv', list(detailed[0]), detailed)
    write_csv(out_dir / 'equal_budget_within_44_cohort.csv', list(cohort_summary[0]), cohort_summary)
    write_csv(out_dir / 'equal_budget_global_top_b_coverage.csv', list(global_summary[0]), global_summary)
    write_csv(out_dir / 'cohort_ranking_order.csv', list(cohort_rows[0]), cohort_rows)
    (out_dir / 'README.md').write_text(note, encoding='utf-8')
    meta = {
        'annotation_count': len(ann), 'baseline_count': len(bas),
        'ranking_rows': len(ranks), 'per_strategy_universe_size': rank_counts,
        'assistant_proposed_counts': dict(Counter(r['assistant_proposed_truth'] for r in detailed)),
        'manual_review_status_counts': dict(Counter(r['manual_review_status'] for r in detailed)),
        'cohort_selection': 'Union of five strategies top-10; biased, not a random control',
        'outcome': 'Exploratory baseline–assistant label disagreement; not verified harm',
        'independent_adjudications': 0,
    }
    (out_dir / 'evaluation_metadata.json').write_text(json.dumps(meta, indent=2) + '\n', encoding='utf-8')

    print('=== MTP EXPLORATORY EQUAL-BUDGET EVALUATION COMPLETE ===')
    print('Full ranked criterion universe per strategy:', total_universe)
    print('Annotated union cohort:', len(detailed))
    print('Manual evidence-supported preliminary:', sum(r['manual_evidence_preliminary'] == 'yes' for r in detailed))
    print('Assistant scorable:', sum(r['assistant_exploratory_scorable'] == 'yes' for r in detailed))
    print('Assistant vs baseline disagreements:', sum(r['assistant_baseline_disagreement'] == 'yes' for r in detailed))
    print('Independent ground-truth adjudications: 0')
    print('\nWITHIN-44-COHORT: budget 10')
    for row in cohort_summary:
        if row['budget'] == 10:
            print(f"{row['strategy']:17} discrepancies={row['assistant_baseline_disagreements']}/{row['assistant_scorable']} scorable, prelim-manual-discrepancies={row['manual_preliminary_disagreements']} (not verified)")
    print('\nGLOBAL top-25 sample coverage (not all ranked cases annotated):')
    for row in global_summary:
        if row['budget'] == 25:
            print(f"{row['strategy']:17} annotated={row['reviewed_sample_coverage_of_budget']} discrepancies observed={row['assistant_baseline_disagreements']}")
    print('\nOUTPUT:', out_dir)
    print('Source files modified: NO')
    print('Ollama calls: 0')

if __name__ == '__main__':
    main()
