#!/usr/bin/env python3
"""Exploratory one-rule and simultaneous-pair counterfactual analysis.

Only assistant-proposed criterion-truth labels are substituted. This script
DOES NOT independently establish ground truth, repair real patient records,
or measure clinical patient rescues. Original research files are read-only.
"""
import argparse
import csv
import json
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

VALID_TRUTHS = {'yes', 'no', 'unknown'}
VALID_VERDICTS = {'met', 'not_met', 'not_stated'}

def load_csv(path):
    with path.open(newline='', encoding='utf-8') as f:
        return list(csv.DictReader(f))

def load_jsonl(path):
    with path.open(encoding='utf-8') as f:
        return [json.loads(line) for line in f if line.strip()]

def normalize(value):
    return str(value).strip().lower()

def truth_to_verdict(truth, kind):
    truth, kind = normalize(truth), normalize(kind)
    if truth not in VALID_TRUTHS:
        raise ValueError(f'Unexpected truth: {truth!r}')
    if kind not in {'inclusion', 'exclusion'}:
        raise ValueError(f'Unexpected criterion kind: {kind!r}')
    if truth == 'unknown':
        return 'not_stated'
    if kind == 'inclusion':
        return 'met' if truth == 'yes' else 'not_met'
    return 'not_met' if truth == 'yes' else 'met'

def pair_summary(verdicts):
    failures = sum(v == 'not_met' for v in verdicts)
    unknowns = sum(v == 'not_stated' for v in verdicts)
    if failures:
        decision = 'NOT_ELIGIBLE'
    elif unknowns:
        decision = 'REVIEW'
    else:
        decision = 'ELIGIBLE'
    return decision, failures, unknowns

def write_csv(path, records, columns):
    with path.open('x', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=columns)
        writer.writeheader()
        writer.writerows(records)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', default='.', help='Akash_Kit project root')
    args = parser.parse_args()
    root = Path(args.root).resolve()
    outbase = root / 'outputs/priority_comparison'
    ann = load_csv(outbase / 'top10_blinded_annotation.csv')
    key = load_csv(outbase / 'top10_baseline_comparison_key.csv')
    assert len(ann) == len(key) == 44, 'Expected 44 annotation/key records'
    ann_by_id = {r['case_id']: r for r in ann}
    key_by_id = {r['case_id']: r for r in key}
    assert len(ann_by_id) == len(key_by_id) == 44
    assert ann_by_id.keys() == key_by_id.keys(), 'Case-ID mismatch'
    for case_id, a in ann_by_id.items():
        k = key_by_id[case_id]
        assert (a['dataset'], a['pair_idx'], a['crit_idx']) == (
            k['dataset'], k['pair_idx'], k['crit_idx']), f'Identity mismatch {case_id}'

    files = {
        'nsclc100': root / 'outputs/plain_ai_qwen_dev.jsonl',
        'sigir204': root / 'outputs/plain_ai_qwen_sigir_dev.jsonl',
    }
    all_records = []
    for dataset, file in files.items():
        loaded = load_jsonl(file)
        for r in loaded:
            assert normalize(r['dataset']) == dataset, (
                f"Dataset identity mismatch in {file}: {r['dataset']!r}"
            )
        all_records.extend(loaded)
    assert len(all_records) == 1940, (
        f'Expected 1940 development predictions, got {len(all_records)}'
    )

    by_rule = {}
    pair_records = defaultdict(dict)
    inconsistencies = []
    for r in all_records:
        dataset = normalize(r['dataset'])
        pair_idx, crit_idx = int(r['pair_idx']), int(r['crit_idx'])
        key3 = (dataset, pair_idx, crit_idx)
        assert key3 not in by_rule, f'Duplicate prediction: {key3}'
        by_rule[key3] = r
        pair_records[(dataset, pair_idx)][crit_idx] = r
        observed = normalize(r['verdict'])
        assert observed in VALID_VERDICTS, f'Unrecognized baseline verdict for {key3}'
        expected = truth_to_verdict(r['truth'], r['kind'])
        if expected != observed:
            inconsistencies.append((key3, expected, observed))
    # If baseline truths and verdicts disagree, stop rather than compute
    # seemingly authoritative eligibility changes from inconsistent inputs.
    if inconsistencies:
        print('ERROR: Baseline truth/verdict mapping is inconsistent.')
        for key3, expected, observed in inconsistencies[:8]:
            print('  ', key3, 'mapped=', expected, 'recorded=', observed)
        raise SystemExit(
            f'{len(inconsistencies)} inconsistent baseline records; '
            'resolve before running the counterfactual.'
        )
    assert len(pair_records) == 152, (
        f'Expected 152 dev pairs, got {len(pair_records)}'
    )

    case_rows = []
    replacements_by_pair = defaultdict(dict)
    for case_id in sorted(ann_by_id):
        a = ann_by_id[case_id]
        k = key_by_id[case_id]
        proposal = normalize(a['assistant_proposed_truth'])
        if proposal not in VALID_TRUTHS:  # excludes the 2 deferrals
            continue
        baseline = normalize(k['baseline_truth'])
        if proposal == baseline:
            continue
        key3 = (normalize(a['dataset']), int(a['pair_idx']), int(a['crit_idx']))
        assert key3 in by_rule, f'Baseline criterion missing: {key3}'
        r = by_rule[key3]
        assert baseline == normalize(r['truth']), (
            f'Baseline-key truth mismatch: {case_id}, {key3}'
        )
        assert normalize(a['criterion_kind']) == normalize(r['kind']), (
            f'Criterion kind mismatch: {case_id}'
        )
        pair_id = key3[:2]
        before_verdicts = {
            ix: normalize(record['verdict'])
            for ix, record in pair_records[pair_id].items()
        }
        before_decision, before_fail, before_unknown = pair_summary(
            before_verdicts.values()
        )
        new_verdict = truth_to_verdict(proposal, a['criterion_kind'])
        after_verdicts = dict(before_verdicts)
        after_verdicts[key3[2]] = new_verdict
        after_decision, after_fail, after_unknown = pair_summary(
            after_verdicts.values()
        )
        assert key3[2] not in replacements_by_pair[pair_id], (
            f'Duplicate replacement in same pair: {key3}'
        )
        replacements_by_pair[pair_id][key3[2]] = (
            new_verdict, case_id, proposal
        )
        case_rows.append({
            'case_id': case_id,
            'dataset': key3[0], 'pair_idx': key3[1],
            'crit_idx': key3[2], 'criterion_kind': a['criterion_kind'],
            'baseline_truth': baseline,
            'assistant_proposed_truth': proposal,
            'baseline_verdict': normalize(r['verdict']),
            'proposed_verdict': new_verdict,
            'before_pair_decision': before_decision,
            'after_one_rule_decision': after_decision,
            'pair_decision_changed': int(before_decision != after_decision),
            'before_fail_count': before_fail,
            'after_fail_count': after_fail,
            'before_unknown_count': before_unknown,
            'after_unknown_count': after_unknown,
            'before_rule_count': len(before_verdicts),
            'reference_pair_target': k.get('reference_pair_target', ''),
            'assistant_proposal_status': a.get('assistant_proposal_status', ''),
            'assistant_prior_exposure_note': a.get('assistant_prior_exposure_note', ''),
            'independently_adjudicated': 'NO',
        })

    assert len(case_rows) == 12, (
        f'Expected 12 baseline–proposal disagreements, got {len(case_rows)}'
    )

    simultaneous_rows = []
    for pair_id in sorted(replacements_by_pair):
        dataset, pair_idx = pair_id
        verdicts = {
            ix: normalize(r['verdict']) for ix, r in pair_records[pair_id].items()
        }
        before_decision, before_fails, before_unknowns = pair_summary(
            verdicts.values()
        )
        revised = dict(verdicts)
        changes = replacements_by_pair[pair_id]
        for crit_idx, (new_verdict, _case_id, _proposed) in changes.items():
            revised[crit_idx] = new_verdict
        after_decision, after_fails, after_unknowns = pair_summary(
            revised.values()
        )
        simultaneous_rows.append({
            'dataset': dataset, 'pair_idx': pair_idx,
            'changed_case_ids': ';'.join(changes[ix][1] for ix in sorted(changes)),
            'number_of_proposed_rule_changes': len(changes),
            'before_pair_decision': before_decision,
            'after_simultaneous_changes_decision': after_decision,
            'pair_decision_changed': int(before_decision != after_decision),
            'before_fail_count': before_fails,
            'after_fail_count': after_fails,
            'before_unknown_count': before_unknowns,
            'after_unknown_count': after_unknowns,
            'independently_adjudicated': 'NO',
        })

    outdir = outbase / (
        'patient_counterfactual_exploratory_'
        + datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    )
    outdir.mkdir(parents=True, exist_ok=False)
    write_csv(outdir / 'one_rule_at_a_time.csv', case_rows, list(case_rows[0]))
    write_csv(outdir / 'simultaneous_per_pair.csv', simultaneous_rows,
              list(simultaneous_rows[0]))
    summary = {
        'baseline_criterion_predictions': len(all_records),
        'baseline_patient_trial_pairs': len(pair_records),
        'annotated_union_cohort': len(ann),
        'assistant_proposal_disagreements': len(case_rows),
        'pairs_with_proposed_changes': len(simultaneous_rows),
        'one_rule_pair_decisions_changed': sum(
            x['pair_decision_changed'] for x in case_rows
        ),
        'simultaneous_pair_decisions_changed': sum(
            x['pair_decision_changed'] for x in simultaneous_rows
        ),
        'one_rule_transition_counts': dict(sorted(Counter(
            x['before_pair_decision'] + ' -> ' + x['after_one_rule_decision']
            for x in case_rows
        ).items())),
        'simultaneous_transition_counts': dict(sorted(Counter(
            x['before_pair_decision'] + ' -> '
            + x['after_simultaneous_changes_decision']
            for x in simultaneous_rows
        ).items())),
        'baseline_truth_verdict_mismatches': len(inconsistencies),
        'independent_adjudications': 0,
        'interpretation': (
            'Hypothetical substitutions based on assistant-proposed labels. '
            'Not confirmed model errors, actual patient rescues, or '
            'out-of-sample priority-strategy effectiveness.'
        ),
    }
    (outdir / 'summary.json').write_text(
        json.dumps(summary, indent=2) + '\n', encoding='utf-8'
    )
    (outdir / 'README.md').write_text(
        '# Exploratory Patient-Level Counterfactuals\n\n'
        'Each one-rule row replaces ONE baseline truth with an assistant-proposed '
        'truth, maps it to a criterion verdict by inclusion/exclusion kind, and '
        'recalculates NOT_ELIGIBLE / REVIEW / ELIGIBLE over ALL other baseline '
        'criteria for that same dataset and pair.\n\n'
        'The simultaneous analysis applies all proposed disagreements in a '
        'pair together, avoiding duplicate counting of the same pair.\n\n'
        '**Important limitations:** No independent ground-truth adjudications. '
        'The 44-case annotation cohort was assembled from top-ten ranking '
        'lists and is selection-biased. This is a diagnostic simulation, not '
        'a clinically verified rescue study. Do not interpret a removal of '
        'NOT_ELIGIBLE as confirmed eligibility or clinical benefit.\n\n'
        'Inputs were read without modification. This command performed no '
        'Ollama inference.\n', encoding='utf-8'
    )
    print('=== PATIENT-LEVEL COUNTERFACTUAL COMPLETE ===')
    print('Baseline criterion predictions:', len(all_records))
    print('Baseline patient–trial pairs:', len(pair_records))
    print('Assistant–baseline disagreements evaluated:', len(case_rows))
    print('Distinct affected pairs:', len(simultaneous_rows))
    print('One-rule changes affecting patient decisions:',
          summary['one_rule_pair_decisions_changed'])
    print('Simultaneous pair decisions changed:',
          summary['simultaneous_pair_decisions_changed'])
    print('\nONE-RULE TRANSITIONS:')
    for transition, count in summary['one_rule_transition_counts'].items():
        print(f'  {transition}: {count}')
    print('\nSIMULTANEOUS PER-PAIR TRANSITIONS:')
    for transition, count in summary['simultaneous_transition_counts'].items():
        print(f'  {transition}: {count}')
    print('\nIndependent ground-truth adjudications: 0')
    print('OUTPUT:', outdir)
    print('Original files modified: NO')
    print('Ollama calls: 0')

if __name__ == '__main__':
    main()
