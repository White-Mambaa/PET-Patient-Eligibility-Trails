#!/usr/bin/env python3
"""Safely append independent assistant proposals to the user's local annotation CSV.

Default behavior is a dry-run. Actual integration requires --apply.
Never overwrites manual_truth, review_status, or any existing human annotation.
"""
import argparse
import collections
import csv
import datetime
import os
import pathlib
import shutil
import tempfile

DEFAULT_TARGET = pathlib.Path.home() / 'MTP/Akash_Kit/outputs/priority_comparison/top10_blinded_annotation.csv'
DEFAULT_PROPOSALS = pathlib.Path.home() / 'Downloads/MTP_44_evidence_based_proposals.csv'
IDENTITY = ('case_id', 'dataset', 'pair_idx', 'trial_id', 'patient_id', 'crit_idx',
            'criterion_kind', 'criterion_text', 'patient_note')


def read_csv(path):
    with path.open(encoding='utf-8-sig', newline='') as handle:
        reader = csv.DictReader(handle)
        assert reader.fieldnames is not None, f'Missing header: {path}'
        rows = list(reader)
        assert len(rows) == 44, f'Expected 44 rows in {path}, found {len(rows)}'
        ids = [r['case_id'] for r in rows]
        assert len(ids) == len(set(ids)), f'Duplicate case_id in {path}'
        return reader.fieldnames, rows


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--proposals', type=pathlib.Path, default=DEFAULT_PROPOSALS)
    ap.add_argument('--target', type=pathlib.Path, default=DEFAULT_TARGET)
    ap.add_argument('--apply', action='store_true', help='Back up original and append proposal columns')
    args = ap.parse_args()
    if not args.target.exists() or not args.proposals.exists():
        ap.error(f'File missing: target={args.target.exists()} proposals={args.proposals.exists()}')
    target_cols, target = read_csv(args.target)
    proposal_cols, proposals = read_csv(args.proposals)
    assistant_cols = [c for c in proposal_cols if c.startswith('assistant_')]
    assert len(assistant_cols) >= 8, 'Missing expected assistant proposal fields'
    keyed = {r['case_id']:r for r in proposals}
    assert set(keyed) == {r['case_id'] for r in target}, 'Case IDs do not match'
    for row in target:
        p = keyed[row['case_id']]
        for field in IDENTITY:
            assert row.get(field) == p.get(field), (
                f'MISMATCH in {row["case_id"]} {field}; refusing to merge'
            )
        for field in assistant_cols:
            if field in target_cols and row.get(field, '') not in ('', p.get(field,'')):
                raise ValueError(f'Existing nonmatching assistant value for {row["case_id"]}.{field}')

    print('PREVIEW: 44/44 IDs and exact patient-note/criterion text matched.')
    print('Proposal labels:', dict(collections.Counter(r['assistant_proposed_truth'] for r in proposals)))
    print('Existing human fields: PRESERVED; new assistant fields:', len(assistant_cols))
    if not args.apply:
        print('DRY RUN ONLY. To write, repeat the command with --apply.')
        return

    backup = args.target.with_name(args.target.stem + '.backup_before_assistant_merge_' +
        datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f') + '.csv')
    shutil.copy2(args.target, backup)
    updated_cols = target_cols + [c for c in assistant_cols if c not in target_cols]
    merged = []
    for old in target:
        updated = dict(old)
        for c in assistant_cols:
            updated[c] = keyed[old['case_id']][c]
        for c in target_cols:
            if not c.startswith('assistant_'):
                assert updated[c] == old[c], f'Human field unexpectedly changed: {old["case_id"]}.{c}'
        merged.append(updated)

    fd, temp = tempfile.mkstemp(prefix='.mtp_proposal_merge_',suffix='.csv',dir=args.target.parent)
    try:
        with os.fdopen(fd,'w',encoding='utf-8',newline='') as f:
            writer = csv.DictWriter(f,fieldnames=updated_cols)
            writer.writeheader()
            writer.writerows(merged)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temp,args.target)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)
    assert read_csv(args.target)[1] == merged, 'Post-write file read verification failed'
    print('MERGE SUCCESSFUL:', args.target)
    print('Backup:',backup)
    print('Original manual labels and statuses have not changed.')

if __name__=='__main__':
    main()
