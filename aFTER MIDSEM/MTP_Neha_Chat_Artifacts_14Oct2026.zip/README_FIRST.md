# MTP progress evidence — submission package for Neha ma'am

**Research project:** Check What Can Change the Outcome: Targeted Checking of AI Clinical-Trial Screening Decisions  
**Progress cutoff:** 14 October 2026 (after final one-record evidence-audit retry)  
**Purpose:** A progress-report evidence package, **not** a finished clinical validation study.

## IMPORTANT: this chat-generated ZIP versus the original Ubuntu experiment outputs

The accompanying ZIP contains **real files available in this ChatGPT workspace**, including the progress presentation, PDF, speaking notes, complete technical handoff, 44-case annotation proposal CSV, uploaded blinded annotation CSV, and scripts used for exploratory analyses. Those files are included with a checksum manifest.

**This ZIP does NOT contain the full original 1,940-row JSONL evidence audit, both baseline JSONLs, the full 9,700-row rank CSV, or the complete result folders from the Ubuntu `skyee` machine**: those files reside at `/home/honcho/MTP/Akash_Kit/` and have not been uploaded to this chat. Do not represent this partial archive as a complete dump of the on-disk experiment outputs.

To obtain the **actual, complete snapshot from `skyee`**, download `build_mtp_neha_submission.py` into `~/Downloads/`, keep this ZIP there, and run:

```bash
cd ~/MTP/Akash_Kit
python3 ~/Downloads/build_mtp_neha_submission.py
```

The script creates a timestamped archive in `~/Downloads/` containing the project tree (source code, experiments, datasets, actual outputs and logs), this chat evidence ZIP when downloaded, and SHA-256 hashes for each source file, plus a separate ZIP checksum file. It makes **zero Ollama calls** and does **not** modify any original project file. Inspect the printed missing-file warnings.

If there are PC1 (`Lab303-12`) and PC2 (`PCLAB3-02`) experiment reports stored only on those other computers, they **must be copied to `skyee` and added**; no local snapshot can capture inaccessible machines. The builder supports `--extra <file_or_folder>` for this.

## Results that were reported before stopping

| Component | Last known result | Scientific status |
|---|---|---|
| NSCLC development baseline | 950 predictions on 50 pairs | Executed; not held-out |
| SIGIR development baseline | 990 predictions on 102 pairs | Executed; not held-out |
| Citation-status checker | 1,940 rows | Automated citation status, not criterion correctness |
| Five priority-ranking strategies | 9,700 rows | Exploratory |
| Selected annotation cohort | 44 cases, 42 scorable assistant proposals | Strategy-selected, not independent gold labels |
| Baseline–proposal disagreements | 12 | Disagreement, not confirmed errors |
| Patient-level counterfactuals | 11/12 proposed corrections changed a simulated decision | Not verified patient rescues |
| Qwen evidence audit | Runner reported 1,940/1,940; 0 remaining | Full execution reported; final unique-ID check still pending |
| Judge mapping inconsistencies | 669/1,939 (34.50%) in penultimate snapshot | Logical inconsistency, **not** clinical error rate |
| Independent ground-truth adjudications | 0 | Pending |
| Controlled traps / repair safety / held-out comparison | Not completed | Pending |

## What should NOT be claimed

- Do not say that 11 *clinical errors* were verified or that 10 patients were clinically rescued.
- Do not call the judge’s suggested labels *ground truth*.
- Do not say all six evidence checks were independently validated.
- Do not say the selected 44-case pilot proves decision-impact ranking is statistically superior.
- Do not silently change the raw judge `suggested_verdict`; its inconsistency is itself an observed result.

## Privacy and recipient review

The supplied research data and annotations may contain clinical-note narratives. Before emailing the full Ubuntu ZIP, verify that Neha ma'am is an authorized recipient and that institutional research-data rules permit transmission. Prefer approved institutional email/storage and avoid public share links.

## Where the exact experiment files should be

See `EXPECTED_LOCAL_OUTPUTS.csv` for known project-relative paths. The **actual** local archive includes `FILE_MANIFEST.csv` (individual file checksums), `CAPTURE_STATUS.json` (capture time, file count and missing paths), `PROJECT/` (on-disk files), and optionally `CHAT_ARTIFACTS/` (these supporting files).
