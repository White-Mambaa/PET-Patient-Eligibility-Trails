# MTP progress-results package — information for Neha ma'am

Project: **Check What Can Change the Outcome — Targeted Checking of AI Clinical-Trial Screening Decisions**
Evidence date: **14 October 2026**. Package capture time is recorded separately in `CAPTURE_STATUS.json`.

## What was actually run

- Development baseline: **950** NSCLC + **990** SIGIR = **1,940 criterion predictions** on **152 patient–trial pairs**. These are **development** splits, not a finished held-out evaluation.
- Citation-status checker: 1,940 records (earlier counts: 879 PASS, 118 FAIL, 943 NO_EVIDENCE).
- Priority ranking: five strategies (`random`, `confidence`, `citation`, `decision_impact`, `combined`), 9,700 rows in the ranking table.
- Exploratory 44-case annotation sample, selected from strategy top-ten lists: **42 scorable assistant proposals**; **12 baseline–proposal disagreements**. The selection procedure introduces bias.
- Patient-level counterfactual exploration: **12 proposed criterion changes**, **11 simulated pair decisions changed** (1 NOT_ELIGIBLE→ELIGIBLE, 9 NOT_ELIGIBLE→REVIEW, 1 REVIEW→NOT_ELIGIBLE, 1 remained NOT_ELIGIBLE).
- Qwen2.5:7b evidence audit: final runner reported **1,940/1,940** successful model-assisted audits after a one-record schema retry. **A separate final unique-ID integrity check was not shown executed at the presentation freeze**.
- Audit reliability diagnostic on the first **1,939** results: **669 (34.50%)** logically inconsistent judge-suggested truth/verdict mappings. That is internal inconsistency, **not clinical error rate**.

## Major research limitations

- **Zero independently adjudicated criterion truth labels** were confirmed at the freeze.
- AI judge flags / suggestions are **not** independently verified clinical labels.
- The 44-case cohort was selected according to the strategies being compared; equal-budget results in this cohort are **exploratory**, not unbiased proof of superiority.
- **Controlled-trap evaluation, repair-versus-deferral safety study, full six-check validation, and held-out final comparisons remain pending.**
- PC1 and PC2 computer outputs are **NOT** automatically present in an archive produced on `skyee`; see `CAPTURE_STATUS.json` and add separately if needed.
- Sensitive patient notes can occur in `datasets/`, `outputs/` and `labelling/`. **Review permission and recipient before sharing** and use an approved secure channel.

## Files in the archive

`PROJECT/` — the actual on-disk project files captured from this machine; `CHAT_ARTIFACTS/` — optional files from the Downloads folder; `FILE_MANIFEST.csv` — paths, byte sizes and SHA-256 checksums; `CAPTURE_STATUS.json` — capture provenance and missing expected results.

**Do not characterize this as a completed clinical decision-support product.** It is a reproducible **mid-project progress submission**.
