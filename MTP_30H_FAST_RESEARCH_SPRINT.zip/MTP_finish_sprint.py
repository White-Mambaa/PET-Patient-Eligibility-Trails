#!/usr/bin/env python3
"""MTP 30-hour CPU-only finishing sprint.

Commands:
  python3 MTP_finish_sprint.py --self-test
  python3 MTP_finish_sprint.py --root ~/MTP/Akash_Kit --task risk
  python3 MTP_finish_sprint.py --root ~/MTP/Akash_Kit --task queue
  python3 MTP_finish_sprint.py --root ~/MTP/Akash_Kit --task score --review-file PATH

No inference, external APIs, new medical labels, test split, source modification,
or automatic clinical corrections. Results are development-only exploratory outputs.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import random
import sys
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

DATASETS = ('nsclc100', 'sigir204')
STRATEGIES = ('random', 'confidence', 'citation', 'decision_impact', 'combined')
BUDGETS = (10, 25, 50, 100, 200, 400, 800)
CHECKS = (
    ('check_1_quote', 'gold_nonverbatim_quote'),
    ('check_2_unsupported', 'gold_unsupported_evidence'),
    ('check_3_context', 'gold_context_error'),
    ('check_4_logic', 'gold_logic_error'),
    ('check_5_contradiction', 'gold_contradiction'),
    ('check_6_missed', 'gold_missed_evidence'),
)


def read_csv(path):
    if not path.is_file():
        raise FileNotFoundError(f'Missing required input: {path}')
    with path.open(newline='', encoding='utf-8-sig') as fh:
        reader = csv.DictReader(fh)
        if not reader.fieldnames:
            raise ValueError(f'No column headers in {path}')
        return list(reader)


def read_jsonl(path):
    if not path.is_file():
        raise FileNotFoundError(f'Missing required input: {path}')
    with path.open(encoding='utf-8') as fh:
        return [json.loads(s) for s in fh if s.strip()]


def write_csv(path, rows, columns=None):
    if not rows and not columns:
        raise ValueError(f'Cannot write empty file without headers: {path}')
    columns = columns or list(rows[0])
    with path.open('x', newline='', encoding='utf-8') as fh:
        writer = csv.DictWriter(fh, fieldnames=columns, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows)


def key(r):
    return (str(r['dataset']).strip(), int(r['pair_idx']), int(r['crit_idx']))


def pairkey(r):
    return (str(r['dataset']).strip(), int(r['pair_idx']))


def unique_index(rows, makekey=key):
    output = {}
    for row in rows:
        k = makekey(row)
        if k in output:
            raise ValueError(f'Duplicate identity: {k}')
        output[k] = row
    return output


def truthy(value):
    if str(value).strip().lower() in ('true', '1', 'yes'):
        return True
    if str(value).strip().lower() in ('false', '0', 'no'):
        return False
    raise ValueError(f'Not a valid bool: {value!r}')


def require(cond, message):
    if not cond:
        raise ValueError(message)


def sha256(path):
    d = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            d.update(chunk)
    return d.hexdigest()


def latest_metrics(root):
    options = sorted(root.glob('outputs/neha_metrics_*/baseline_pair_predictions.csv'))
    if not options:
        raise FileNotFoundError('No baseline_pair_predictions.csv in outputs/neha_metrics_*/; run the previously verified metrics script first.')
    return options[-1]


def latest_unified(root):
    options = sorted(root.glob('outputs/evidence_checks/unified_six_checks_*/unified_six_checks.csv'))
    if not options:
        raise FileNotFoundError('No unified_six_checks.csv in outputs/evidence_checks/unified_six_checks_*/')
    return options[-1]


def new_dir(root, name):
    base = root / 'outputs' / 'research_completion_sprint'
    base.mkdir(parents=True, exist_ok=True)
    tag = datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    folder = base / f'{name}_{tag}'
    folder.mkdir(exist_ok=False)
    return folder


def baseline_data(root):
    pred_paths = [root / 'outputs/plain_ai_qwen_dev.jsonl', root / 'outputs/plain_ai_qwen_sigir_dev.jsonl']
    predictions = unique_index([r for p in pred_paths for r in read_jsonl(p)])
    require(len(predictions) == 1940, f'Expected 1,940 development criterion predictions, found {len(predictions)}')
    require(set(k[0] for k in predictions) == set(DATASETS), 'Unexpected baseline dataset identities')
    for k, r in predictions.items():
        from_truth = r['truth']
        kind = r['kind']
        require(from_truth in ('yes','no','unknown') and kind in ('inclusion','exclusion'), f'Invalid truth/kind for {k}')
        want = 'not_stated' if from_truth == 'unknown' else (('met' if from_truth == 'yes' else 'not_met') if kind == 'inclusion' else ('not_met' if from_truth == 'yes' else 'met'))
        require(r['verdict'] == want, f'Baseline mapping inconsistent: {k}')
    return predictions, pred_paths


def strong_flag(row):
    # These are unverified checker alerts: they trigger REVIEW only, never auto-repair.
    return any(row[col] in ('FLAG_AI', 'FLAG_BASELINE_MAPPING', 'FLAG_NONVERBATIM', 'REVIEW_INVALID_EVIDENCE') for col, _ in CHECKS)


def analyze_risk(root):
    preds, prediction_paths = baseline_data(root)
    rank_path = root / 'outputs/priority_comparison/priority_rankings.csv'
    impact_path = root / 'outputs/decision_impact/real_priority_analysis.csv'
    pair_path = latest_metrics(root)
    unified_path = latest_unified(root)
    ranks = read_csv(rank_path)
    impacts = unique_index(read_csv(impact_path))
    unified = unique_index(read_csv(unified_path))
    pairs = unique_index(read_csv(pair_path), pairkey)
    require(len(pairs) == 152, f'Expected 152 development pairs; got {len(pairs)}')
    require(set(k[0] for k in pairs) == set(DATASETS), 'Unexpected reference dataset')
    require(set(preds) == set(impacts) == set(unified), 'Criterion identities mismatch among baseline, impacts, and six-check output')
    pairgroups = defaultdict(list)
    for k in preds:
        require(k[:2] in pairs, f'Baseline pair missing in metrics: {k}')
        pairgroups[k[:2]].append(k)
        require(impacts[k]['verdict'] == preds[k]['verdict'], f'Impact mismatched verdict: {k}')
        require(unified[k]['baseline_verdict'] == preds[k]['verdict'], f'Unified mismatched verdict: {k}')
    for p, item in pairs.items():
        n_fail = sum(preds[k]['verdict'] == 'not_met' for k in pairgroups[p])
        require(n_fail == int(item['num_not_met']), f'Pair failing-count mismatch: {p}')
        expect_decision = 'NOT_ELIGIBLE' if n_fail else ('REVIEW' if int(item['num_not_stated']) else 'ELIGIBLE')
        require(expect_decision == item['prediction'], f'Pair decision mismatch: {p}')
        for k in pairgroups[p]:
            is_sole = n_fail == 1 and preds[k]['verdict'] == 'not_met'
            require(truthy(impacts[k]['sole_rejection']) == is_sole, f'Sole-rejection metadata mismatch: {k}')
    require(len(ranks) == 9700, f'Expected 9,700 rankings, got {len(ranks)}')
    sorted_lists = {}
    for s in STRATEGIES:
        subset = [r for r in ranks if r['strategy'].strip() == s]
        require(len(subset) == 1940, f'{s}: expected 1,940 rankings, got {len(subset)}')
        require(set(key(r) for r in subset) == set(preds), f'{s}: ranked universe differs from baseline')
        positions = [int(r['rank']) for r in subset]
        require(len(set(positions)) == 1940, f'{s}: duplicate ranks')
        require(sorted(positions) in [list(range(1940)), list(range(1,1941))], f'{s}: ranks must be contiguous from 0 or 1')
        sorted_lists[s] = [key(r) for r in sorted(subset, key=lambda r: int(r['rank']))]
    require({r['strategy'].strip() for r in ranks} == set(STRATEGIES), 'Unknown/missing ranking strategy')

    before_wrong_rejections = {p for p, r in pairs.items() if r['reference'] == 'ELIGIBLE' and r['prediction'] == 'NOT_ELIGIBLE'}
    require(len(before_wrong_rejections) == 28, f'Expected 28 reference-eligible false rejections, got {len(before_wrong_rejections)}')
    baseline_correct = sum(r['reference'] == r['prediction'] for r in pairs.values())
    summaries, actions = [], []
    for strategy, order in sorted_lists.items():
        for budget in BUDGETS:
            chosen = order[:budget]
            for policy in ('sole_rejection', 'sole_plus_checker_flag'):
                candidates = []
                for k in chosen:
                    r = impacts[k]
                    eligible_for_review = truthy(r['sole_rejection']) and (policy == 'sole_rejection' or strong_flag(unified[k]))
                    if eligible_for_review:
                        candidates.append(k)
                selected_pairs = {k[:2] for k in candidates}
                # Conservatively replace selected automatic rejections by REVIEW.
                # Never change any NOT_ELIGIBLE decision to ELIGIBLE without verified rule truth.
                reviewed_wrong = len(before_wrong_rejections & selected_pairs)
                reviewed_correct = sum(pairs[p]['reference'] == 'NOT_ELIGIBLE' for p in selected_pairs)
                correct_after = sum((r['reference'] == ('REVIEW' if p in selected_pairs else r['prediction'])) for p, r in pairs.items())
                require(correct_after == baseline_correct - reviewed_correct, 'Strict accuracy accounting mismatch')
                summaries.append({
                    'strategy': strategy, 'criterion_budget': budget, 'review_policy': policy,
                    'selected_criterion_alerts': len(candidates), 'unique_pairs_deferred': len(selected_pairs),
                    'reference_eligible_false_rejections_reviewed': reviewed_wrong,
                    'false_rejections_remaining_automatic': 28 - reviewed_wrong,
                    'reference_not_eligible_correct_rejections_deferred': reviewed_correct,
                    'reference_eligible_wrong_rejection_coverage': round(reviewed_wrong / 28, 6),
                    'reviewed_wrong_per_deferred_pair': round(reviewed_wrong / len(selected_pairs),6) if selected_pairs else None,
                    'baseline_strict_correct_pairs': baseline_correct,
                    'post_deferral_strict_correct_pairs': correct_after,
                    'post_deferral_strict_accuracy': round(correct_after / len(pairs), 6),
                    'automatic_false_inclusions_after': sum(r['reference']=='NOT_ELIGIBLE' and r['prediction']=='ELIGIBLE' for r in pairs.values()),
                    'total_dev_pairs': len(pairs),
                    'scope': 'DEVELOPMENT_POSTHOC_RISK_COVERAGE_NOT_VERIFIED_ERROR_DETECTION',
                })
                for k in candidates:
                    actions.append({'strategy':strategy,'criterion_budget':budget,'review_policy':policy,
                                    'dataset':k[0],'pair_idx':k[1],'crit_idx':k[2],
                                    'action':'DEFER_PAIR_FOR_HUMAN_REVIEW',
                                    'reason':'Sole failing criterion; checking budget selects this criterion'+ ('; at least one preliminary checker alert' if policy.endswith('checker_flag') else ''),
                                    'clinical_correction_performed':'NO'})
    folder = new_dir(root, 'risk')
    write_csv(folder / 'risk_budget_summary.csv', summaries)
    write_csv(folder / 'proposed_review_actions_NO_GOLD.csv', actions,
              ['strategy','criterion_budget','review_policy','dataset','pair_idx','crit_idx','action','reason','clinical_correction_performed'])
    meta = {'study':'Development posthoc at-risk-pair coverage; no clinical repairs',
            'baseline_pairs':len(pairs),'baseline_wrong_rejections':28,
            'baseline_strict_correct_pairs':baseline_correct,
            'methods':list(STRATEGIES), 'criterion_budgets':list(BUDGETS),
            'policies':['sole_rejection','sole_plus_checker_flag'],
            'gold_reference_only_used_for_posthoc_scoring':True,
            'caveats':['Ranked cases are not independently adjudicated rule errors.',
                       'Reviewing a false rejection prevents an automatic rejection but does not establish eligibility or a patient rescue.',
                       'Choosing sole failing criteria is part of the strategy; this outcome measure may partly reward its own definition.',
                       'Strict accuracy counts every REVIEW as incorrect; preventive risk coverage and strict accuracy trade off.',
                       'Only existing development predictions; not a held-out test.'],
            'sources':{str(p.relative_to(root)):sha256(p) for p in prediction_paths + [rank_path, impact_path, pair_path, unified_path]}}
    (folder / 'manifest.json').write_text(json.dumps(meta,indent=2)+'\n',encoding='utf-8')
    md=['# Development ranking and conservative deferral study','',
        'No clinical answer was automatically corrected. REFERENCE TARGETS ARE USED ONLY TO SCORE EXISTING RANKED CANDIDATES, NOT FOR RANKING.',
        '', 'There were 28 false exclusions under the previously regenerated pair-level baseline; any deferral moves a NOT_ELIGIBLE decision to REVIEW, **not** ELIGIBLE.',
        '', '| Strategy | Budget | Policy | Distinct pairs deferred | Baseline false rejections moved to REVIEW | Correct rejections moved to REVIEW | Remaining automatic false rejections |',
        '|---|---:|---|---:|---:|---:|---:|']
    for r in summaries:
        if r['criterion_budget'] in (25, 100, 200):
            md.append(f"| {r['strategy']} | {r['criterion_budget']} | {r['review_policy']} | {r['unique_pairs_deferred']} | {r['reference_eligible_false_rejections_reviewed']} | {r['reference_not_eligible_correct_rejections_deferred']} | {r['false_rejections_remaining_automatic']} |")
    md += ['', 'Do not call deferred cases rescued patients or verified checker detections. The cohort and ranking metrics are exploratory.']
    (folder/'RISK_AND_DEFERRAL_REPORT.md').write_text('\n'.join(md)+'\n',encoding='utf-8')
    print('=== MTP RISK/DEFERRAL DEVELOPMENT ANALYSIS ===')
    print('Baseline: 152 pairs; 28 automatic false rejections; criteria ranked: 1,940 x 5.')
    print('Analysis rows:',len(summaries),'| review action rows:',len(actions))
    for s in STRATEGIES:
        r=next(x for x in summaries if x['strategy']==s and x['criterion_budget']==100 and x['review_policy']=='sole_rejection')
        print(f"{s} @100: deferred {r['unique_pairs_deferred']} pairs; {r['reference_eligible_false_rejections_reviewed']}/28 false rejections sent to REVIEW")
    print('OUTPUT:',folder)
    print('Files modified: original inputs NO; inference/API calls 0; held-out test data not accessed.')
    return folder


def load_notes(root):
    notes={}
    files=[]
    for ds in DATASETS:
        p=root/f'datasets/{ds}/{ds}.csv'
        files.append(p)
        for r in read_csv(p):
            k=(ds,int(r['pair_idx']))
            if k in notes:
                raise ValueError(f'Duplicate clinical note identity {k}')
            notes[k]=r['patient_orig']
    return notes,files


def build_queue(root, random_per_dataset, targeted_per_check):
    predictions,pred_paths=baseline_data(root)
    unified_path=latest_unified(root)
    checks=unique_index(read_csv(unified_path))
    require(set(checks)==set(predictions), 'Unified six-check keys mismatch with baseline')
    notes,corpus_paths=load_notes(root)
    for k in checks:
        require(k[:2] in notes, f'Missing clinical note for {k}')
    rng=random.Random(20102026)
    selected={}
    for ds in DATASETS:
        population=sorted(k for k in predictions if k[0]==ds)
        require(len(population)>=random_per_dataset, 'Not enough cases for sampling')
        for k in rng.sample(population,random_per_dataset):
            selected.setdefault(k,set()).add('RANDOM_DEV_SAMPLE')
    flag_sample_stats={}
    for column,_ in CHECKS:
        positives=sorted(k for k,r in checks.items() if r[column] in ('FLAG_AI','FLAG_NONVERBATIM','FLAG_BASELINE_MAPPING'))
        pick=rng.sample(positives,min(len(positives),targeted_per_check))
        for k in pick:
            selected.setdefault(k,set()).add('TARGETED_'+column)
        flag_sample_stats[column]={'positive_pool':len(positives),'targeted_selected':len(pick)}
    # Deliberately do NOT include baseline truth/verdict, AI flags or judge suggestion in blinded materials.
    public=[]; private=[]
    for i,k in enumerate(sorted(selected),1):
        p=predictions[k]
        criterion=p.get('criterion') or p.get('criterion_text') or ''
        require(bool(criterion.strip()), f'Criterion text missing {k}')
        cid=f'REVIEW-{i:03d}'
        public.append({'case_id':cid,'dataset':k[0],'pair_idx':k[1], 'crit_idx':k[2],
                       'sampling_cohort':';'.join(sorted(selected[k])),'annotation_status':'PENDING'})
        private.append({'case_id':cid,'dataset':k[0], 'pair_idx':k[1], 'crit_idx':k[2],
                        'criterion_kind':p['kind'],'criterion_text':criterion,
                        'patient_note_PRIVATE_DO_NOT_UPLOAD':notes[k[:2]],
                        **{gold:'' for _,gold in CHECKS},
                        'reviewer_identifier':'','reviewer_confidence':'','reviewer_comments':'',
                        'sampling_cohort':';'.join(sorted(selected[k]))})
    folder=new_dir(root,'adjudication')
    write_csv(folder/'public_case_ids_NO_NOTES.csv',public)
    private_path=folder/'PRIVATE_BLINDED_REVIEW_FILL_LOCALLY.csv'
    write_csv(private_path,private)
    try:
        private_path.chmod(0o600)
    except OSError:
        pass
    summary={'status':'UNLABELLED_BLINDED_QUEUE_PENDING_INDEPENDENT_REVIEW',
             'random_per_dataset':random_per_dataset,'targeted_per_check':targeted_per_check,
             'distinct_cases':len(private),'sample_components':flag_sample_stats,
             'sources':{str(p.relative_to(root)):sha256(p) for p in pred_paths+[unified_path]+corpus_paths},
             'critical_warning':'PRIVATE_BLINDED_REVIEW_FILL_LOCALLY.csv contains full patient notes. Do not upload, email or commit this file. Keep it on the authorized local machine.',
             'label_definition':{'gold_nonverbatim_quote':'1 only for an actually non-verbatim quotation in the baseline evidence field, 0 for all verbatim/none. Not proof of fabricated clinical claims.',
                                 'gold_unsupported_evidence':'1 if an asserted evidential claim lacks support in the note; requires reviewer judgment.',
                                 'gold_context_error':'1 if baseline misreads who/when/negation/qualifier.',
                                 'gold_logic_error':'1 if baseline reasoning or mapping violates written criterion.',
                                 'gold_contradiction':'1 if baseline assertion contradicts note.',
                                 'gold_missed_evidence':'1 if relevant PRESENT evidence is overlooked; absent information is not overlooked evidence.'},
             'caveats':['Targeted sample not representative; do not report pooled clinical prevalence or population accuracy without design adjustment.',
                        'An independent reviewer should label without exposure to baseline/judge results.',
                        'One reviewer does not establish inter-rater agreement; conflicts need adjudication.',
                        'Unset gold labels are not negatives.']}
    (folder/'queue_manifest.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
    print('=== MTP BLINDED SIX-CHECK ADJUDICATION QUEUE ===')
    print('Random development cases:',2*random_per_dataset, '| distinct cases total:',len(private))
    print('Targeted sample requested per check:',targeted_per_check)
    print('PRIVATE REVIEW FILE CONTAINS PATIENT NOTES: KEEP LOCAL, NEVER UPLOAD.')
    print('OUTPUT:',folder)
    print('Independent gold labels currently created: 0. Fill after review.')
    print('Source files modified: NO; Ollama/API calls: 0; test split untouched.')
    return folder


def score_queue(root, path):
    path=path.expanduser().resolve()
    rows=read_csv(path)
    require(len(rows)>0,'Review sheet empty')
    require(len({r['case_id'] for r in rows})==len(rows),'Duplicate review case IDs')
    unified=unique_index(read_csv(latest_unified(root)))
    scores=[]
    for column, gold in CHECKS:
        compared=[]
        for item in rows:
            label=item.get(gold,'').strip().lower()
            if label in ('','defer','uncertain','na','n/a'):
                continue
            require(label in ('0','1'), f"{item['case_id']}: {gold} must be 0, 1, empty, defer or uncertain")
            k=key(item)
            require(k in unified, f'Unrecognized case: {k}')
            flag=unified[k][column]
            # Abstentions/insufficient are not negative; exclude and count separately.
            pred = 1 if flag in ('FLAG_AI','FLAG_NONVERBATIM','FLAG_BASELINE_MAPPING') else (0 if flag in ('NO_FLAG_AI','VERBATIM_MATCH','NO_CITATION') else None)
            compared.append((int(label),pred))
        resolved=[(g,p) for g,p in compared if p is not None]
        tp=sum(g==1 and p==1 for g,p in resolved)
        fp=sum(g==0 and p==1 for g,p in resolved)
        fn=sum(g==1 and p==0 for g,p in resolved)
        tn=sum(g==0 and p==0 for g,p in resolved)
        precision=tp/(tp+fp) if tp+fp else None
        recall=tp/(tp+fn) if tp+fn else None
        f1=2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else None
        scores.append({'check':column,'gold_field':gold,'n_labeled':len(compared),'n_scored_nonabstaining':len(resolved),
                       'n_abstained':len(compared)-len(resolved),'tp':tp,'fp':fp,'fn':fn,'tn':tn,
                       'precision':precision,'recall':recall,'f1':f1,
                       'n_gold_positive':sum(g==1 for g,_ in compared),
                       'n_gold_negative':sum(g==0 for g,_ in compared),
                       'claim_status':'PRELIMINARY_REVIEWED_SAMPLE_ONLY_NOT_POPULATION' if compared else 'NO_GOLD_LABELS'})
    if sum(r['n_labeled'] for r in scores)==0:
        raise ValueError('No labels filled yet. Independent review must be completed first; no metrics can be generated.')
    folder=new_dir(root,'six_check_scores')
    write_csv(folder/'reviewed_checker_metrics.csv',scores)
    (folder/'README.md').write_text('# Reviewed checker metrics (selected development cases)\n\n'
        'Only reviewer-filled binary labels contribute. Unlabeled examples are excluded, not assumed negative. '
        'AI abstention is excluded from precision/recall and its count is reported. '
        'Targeted sampling biases prevalence and pooled metrics; independent review status must be verified. '
        'No test data or auto-repair involved.\n',encoding='utf-8')
    print('=== REVIEWED CHECKER METRICS (SELECTED SAMPLE ONLY) ===')
    for r in scores:
        print(f"{r['check']}: labeled={r['n_labeled']}, scored={r['n_scored_nonabstaining']}, TP={r['tp']} FP={r['fp']} FN={r['fn']} TN={r['tn']} F1={r['f1']}")
    print('OUTPUT:',folder)
    return folder


def selftest():
    assert truthy('True') and truthy('1') and not truthy('false')
    assert pairkey({'dataset':'nsclc100','pair_idx':'3'})==('nsclc100',3)
    assert strong_flag({c:'FLAG_AI' if i==1 else 'NO_FLAG_AI' for i,(c,_) in enumerate(CHECKS)})
    assert not strong_flag({c:'NO_FLAG_AI' for c,_ in CHECKS})
    assert all(0 < b <= 1940 for b in BUDGETS)
    print('SELF-TEST PASS: keys, status flags, boolean decoding, budgets. No files modified.')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=Path('.'))
    parser.add_argument('--task',choices=['risk','queue','score'])
    parser.add_argument('--self-test',action='store_true')
    parser.add_argument('--random-per-dataset',type=int,default=12)
    parser.add_argument('--target-per-check',type=int,default=5)
    parser.add_argument('--review-file',type=Path)
    args=parser.parse_args()
    if args.self_test:
        selftest(); return
    if not args.task:
        parser.error('--task is required unless using --self-test')
    root=args.root.expanduser().resolve()
    if args.task=='risk': analyze_risk(root)
    elif args.task=='queue':
        require(args.random_per_dataset>=1 and args.target_per_check>=0,'Sampling values invalid')
        build_queue(root,args.random_per_dataset,args.target_per_check)
    else:
        if args.review_file is None:
            parser.error('--review-file PATH is required for --task score')
        score_queue(root,args.review_file)


if __name__=='__main__':
    try:
        main()
    except (ValueError,FileNotFoundError,KeyError,TypeError) as exc:
        print('ERROR:',exc,file=sys.stderr)
        sys.exit(2)
