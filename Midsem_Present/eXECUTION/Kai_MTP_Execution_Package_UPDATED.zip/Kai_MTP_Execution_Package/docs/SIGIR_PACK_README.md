# SIGIR pack — Akash

This pack adds the second dataset for Phase 2. It follows the same rules and file formats as the
lung-cancer set, so your code runs on it by pointing it at the SIGIR files.

## 1. Install (10 minutes)

1. Copy the three folders of this pack (`datasets`, `labelling`, `code`) into your kit folder, next to
   the existing ones. When asked, **replace** `code/evaluate.py` and `code/plain_ai.py`. The new versions
   only add SIGIR support; everything you already did still works.
2. Check both datasets:

```bash
cd code
python selftest.py            # still: 36 passed, 0 failed
python check_sigir_pack.py    # new:   9 passed, 0 failed
```

3. Read `datasets/sigir204/README.md` (what the data is) and `datasets/sigir204/CRITERIA_REVIEW.md`
   (how the rules were made and how to read the `note` column).

## 2. What is in the pack

| file | what |
|---|---|
| `datasets/sigir204/sigir204.csv` | 204 patient–trial pairs (14 patients, 204 trials, 100 Eligible); includes `n_rules` |
| `datasets/sigir204/criteria.csv` | 1,911 reviewed rules; a `review` column says how carefully each trial was checked |
| `datasets/sigir204/splits.csv` | the split (by **patient**: 7 development + 7 test patients, 102 pairs each) |
| `datasets/sigir204/patients.csv` | the 14 patients with their split and pair counts |
| `datasets/sigir204/review_log.csv` | every line dropped, joined or moved during the review, and why |
| `labelling/sigir_label_sheet.csv` | **your** 20 SIGIR pairs to label: 203 rule answers (108 development, 95 test) |
| `labelling/my_sigir_pairs.csv` | the list of your 20 SIGIR pairs |
| `code/check_sigir_pack.py` | the check above |
| `code/evaluate.py`, `code/plain_ai.py` | updated: `--cluster-col patient_id`, and output names that include the dataset |

## 3. The five differences from the lung-cancer set

1. **Split by patient, not by trial.** Every trial appears once; every patient appears in 4 to 42 pairs.
   Build and tune on development patients; run the test patients **once**, after freezing.
2. **The unit for comparisons is the patient.** Use `--cluster-col patient_id` and compare systems
   patient by patient (`stats_tools.trial_sign_test` works for any unit). With 7 test patients, no test
   can show a "significant" difference — report counts and say so.
3. **Many more unknowns.** Case summaries are short and the trials are very diverse.
4. **Rule lists vary from 1 to 48 rules**, and Not Eligible pairs have longer lists. Always report the
   count-the-rules baseline (section 6).
5. **Your SIGIR labels are separate** from your lung-cancer labels: `labelling/my_sigir_labels_final.csv`.

## 4. Label your SIGIR pairs

Use exactly the labelling rules of your guide (Section 6), plus the notes table in
`datasets/sigir204/CRITERIA_REVIEW.md`.

1. Label the **development** pairs first (108 rows).
2. Label the **test** pairs (95 rows) **before any system runs on a test patient**.
3. Save as `labelling/my_sigir_labels_final.csv`, commit, and write the commit hash in your notes.
4. Run the label check and send the result to your supervisor:

```bash
python evaluate.py labelcheck --gold ../labelling/my_sigir_labels_final.csv \
    --corpus ../datasets/sigir204/sigir204.csv --out ../labelling/sigir_labelcheck.csv
```

A few of your pairs are also labelled by someone else, to measure agreement. Do not discuss specific
rows until your supervisor says the comparison is done.

## 5. Commands on SIGIR

The same scripts, with the three SIGIR file paths added (run from the `code` folder):

```bash
# the plain-AI system on development patients (writes ../outputs/plain_ai_qwen2.5-7b_sigir204_dev.jsonl)
python plain_ai.py --model qwen2.5:7b --split dev --dataset sigir204 --corpus ../datasets/sigir204/sigir204.csv --criteria ../datasets/sigir204/criteria.csv --splits ../datasets/sigir204/splits.csv

# pair-level scores, per patient, with rarity re-weighting
python evaluate.py pairs --pred ../outputs/plain_ai_qwen2.5-7b_sigir204_dev.jsonl --split dev --cluster-col patient_id --corpus ../datasets/sigir204/sigir204.csv --criteria ../datasets/sigir204/criteria.csv --splits ../datasets/sigir204/splits.csv --target-rate 0.10 --target-rate 0.05

# rule-level scores against your SIGIR labels
python evaluate.py criterion --gold ../labelling/my_sigir_labels_final.csv --pred ../outputs/plain_ai_qwen2.5-7b_sigir204_dev.jsonl --split dev

# quotes
python evaluate.py evidence --pred ../outputs/plain_ai_qwen2.5-7b_sigir204_dev.jsonl --corpus ../datasets/sigir204/sigir204.csv --gold ../labelling/my_sigir_labels_final.csv --split dev
```

Your own system needs the same three paths wherever it reads data. In your code, load them with
`criteria.load_criteria(path)` and `criteria.load_splits(path)`.

## 6. The count-the-rules baseline (required)

On SIGIR, a large part of what looks like "eligibility skill" can come from how long a trial's rule list
is. Show that your results beat this trivial predictor:

```python
import pandas as pd
d = pd.read_csv("../datasets/sigir204/sigir204.csv")
s = pd.read_csv("../datasets/sigir204/splits.csv").set_index("trial_id").split
d["split"] = d.trial_id.map(s)
dev, test = d[d.split == "dev"], d[d.split == "test"]
# choose the cut-off on development patients only
best = max(range(1, 49), key=lambda t: ((dev.n_rules > t) == (dev.target != "Eligible")).mean())
pred_not = test.n_rules > best
print("cut-off", best, "| test accuracy", ((pred_not) == (test.target != "Eligible")).mean(),
      "| wrongly excluded", int((pred_not & (test.target == "Eligible")).sum()), "of", int((test.target == "Eligible").sum()))
```

Also report your main results **split into three groups by rule count** (short, medium and long lists)
to show that a gain is not only in one group.

## 7. Your project on SIGIR (Akash)

- **Rule statements** (guide Section 8.1): generate them for all 1,911 rules, check by hand only the rules
  of your 10 labelled development pairs (108 rows), and never edit the others.
- **Settings.** Keep θ, τ and the support method exactly as frozen before your lung-cancer test run. You
  may report, as a separate check, what values the SIGIR development patients would have chosen.
- **Checking strategies** use the same order files and the SIGIR paths:
  `python evaluate.py targeting --pred <records> --order <order.csv> --budgets 5,10,20,50,100 --split dev
  --gold ../labelling/my_sigir_labels_final.csv --corpus ../datasets/sigir204/sigir204.csv
  --criteria ../datasets/sigir204/criteria.csv --splits ../datasets/sigir204/splits.csv`
- **Traps** stay mainly lung-cancer traps. If you build SIGIR traps, use only your labelled
  development-patient pairs and report them separately.
- **The rejection-risk list and the fixer** work unchanged.
- **Table 8** (the dataset question) compares the lung-cancer test trials with the SIGIR test patients.


## 8. Rules that still apply

- Build on development patients; test patients **once**, after freezing code, prompts and labels.
- Never split the rule text yourself; never edit `criteria.csv`. If a rule looks wrong, write down the trial,
  `crit_idx` and the problem, and tell your supervisor.
- Local models only; keep the data out of public repositories.
- Report SIGIR and lung-cancer results **separately**, each with its own unit (patient / trial).
