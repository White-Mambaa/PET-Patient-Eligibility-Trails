# How the SIGIR rules (`criteria.csv`) were made

The SIGIR trial texts (`inc_orig`, `exc_orig`) are free text with one item per line. Just as for the
lung-cancer set, **you never split them yourself**: every step uses `criteria.csv`, and every `crit_idx`
refers to it.

**Result: 1,911 rules for 204 trials** (1 to 48 per trial, median 7), inclusion rules first.

## How every line was handled

Every line of every trial ends up in exactly one place — a rule, a heading attached to rules, or the
drop log — and the build stops if that is not true. Rule text is always the original text (lines
joined with "; ", list numbers and bullets removed), never rewritten. Interpretation goes in `note`.

| step | what happened | count |
|---|---|---|
| default | one line = one rule | — |
| dropped | the heading line of each list ("inclusion criteria:", ":") | 363 lines |
| dropped | other headings, empty values ("None", "Not specified"), fragments, study procedures, explanations, and healthy-control criteria of one trial that recruits patients only | 92 lines |
| joined | a list introduced by "any of the following" / "one of" / "such as", or an item with its sub-items (from the indentation of the official registry text) | 80 rules |
| joined with heading | a heading that changes the meaning of the lines below it ("Age:", "Hepatic:", "Caregivers:") placed in front of each of them | 75 rules |
| moved to inclusion | lines listed under exclusion but written as requirements ("No previous head trauma") — kept as exclusions they would reverse the meaning; also two items the official registry lists as inclusion, and one trial's healthy-control criteria that appear in its exclusion text | 15 rules |
| notes | how to read a rule (alternatives, conditional rules, caregiver/clinic rules, unclear wording) | 223 rules |

Every drop, join and move is listed in `review_log.csv` with its reason.

## How carefully each trial was checked — the `review` column

| value | trials | rules | meaning |
|---|---|---|---|
| `line_by_line` | 36 | 339 | the trials of the pairs you label; every line read and decided by hand |
| `hand_checked_spots` | 58 | 695 | 42 trials with a warning sign (a line ending in ":", a line starting with "or"/"and", numbered or nested lists, text that differs from the registry), every such spot decided by hand; plus 16 trials fixed after the hand scan described in the next row |
| `automatic_scanned` | 110 | 877 | no warning sign; grouping from the registry indentation; every inclusion list and every exclusion rule starting with "No"/"Not" was then read by hand (the 16 trials that needed a fix moved to the row above) |

The 36 labelled trials are the most reliable. For pair-level results on all 204 pairs, the other rules
are good but not perfect. If you find a mistake, **do not fix it yourself**: write it down (trial,
`crit_idx`, what is wrong) and tell your supervisor, who decides whether a corrected file is issued. A
changed rule file must never be used for a test run that has already happened.

## The most common kinds of hand decision

1. **Alternative groups.** "Patients with ischaemic stroke …" and "Patients with haemorrhagic stroke …"
   as separate lines would require BOTH. Such lines were joined into one rule whose note says
   *true if at least one applies*. The same applies to healthy-control groups and to consent in writing
   versus oral witnessed consent.
2. **"Any of the following" lists.** The introducing line and its items form one rule.
3. **Requirements written under exclusions.** "No previous head trauma" listed under exclusions would
   exclude everyone WITHOUT head trauma. Such lines were moved to inclusion; the note says so.
4. **Rules about someone else.** Caregiver or clinic requirements stay, with a note that the answer is
   usually unknown.
5. **Unclear registry wording** is kept as written; the note gives the reviewer's reading and says it
   is a reading.

## Reading the `note` column when you label

Follow the note exactly, as for the lung-cancer set. The notes you will meet most often:

| note starts with | what to do |
|---|---|
| "Alternatives: …" | `yes` if at least one listed item applies; `no` only if none applies |
| "Applies only to patients who could become pregnant …" | not applicable for everyone else: label `yes` (and set `not_applicable = Y`) |
| "Applies only if the patient …" / "Applies to … only" | if the patient is not in that group: not applicable (label `no` for an exclusion, `yes` for an inclusion) |
| "Written as 'No …'" | `yes` when the patient does NOT have what is listed |
| "A permission, not a requirement" | `yes` unless the note shows something the permission does not cover |
| "About behaviour during the study …" | usually `unknown` |
| "Reviewer's reading …" | label by the reading given, and comment if you disagree |

## How to check any rule yourself

`source_lines` lists the lines a rule came from: split the trial's `inc_orig` or `exc_orig` on line
breaks, drop empty lines, and count from 0. `inc3,inc4` means inclusion lines 3 and 4 joined; a rule
whose `source_lines` mixes `inc` and `exc` combines lines from both lists (see its note).
