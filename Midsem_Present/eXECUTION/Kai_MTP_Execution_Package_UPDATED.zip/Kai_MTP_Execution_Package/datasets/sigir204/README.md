# The SIGIR set (SIGIR-204) — data card

## Files

| file | contents |
|---|---|
| `sigir204.csv` | 204 rows, one row = one patient–trial pair |
| `criteria.csv` | **the 1,911 reviewed rules of the 204 trials — use this for every rule-level step** |
| `splits.csv` | which trials belong to development patients and which to test patients (the split is **by patient**) |
| `patients.csv` | the 14 patients: split, number of pairs, number of Eligible pairs |
| `CRITERIA_REVIEW.md` | how the rules were split and checked, and how to read the `note` and `review` columns |
| `review_log.csv` | every line that was dropped, joined or moved during the review, with the reason |

## What it is

- **204 patient–trial pairs** from a public clinical-trials test collection: **14 patients**, each compared with
  4 to 42 different trials, and **204 different trials** (every pair has its own trial).
- **100 Eligible and 104 Not Eligible** pairs.
- Patient descriptions are short case summaries (287 to 1,288 characters; median 520) with almost no dates.
- Unlike the lung-cancer set, the diseases vary widely: trauma and delirium, bipolar disorder and sleep,
  colorectal polyps, pregnancy and anaemia, stroke, dementia, infections, thyroid disease and others.

## Where it comes from

| step | what |
|---|---|
| original | SIGIR 2016 clinical-trials test collection (Koopman & Zuccon, SIGIR 2016; CSIRO; data at http://doi.org/10.4225/08/5714557510C17). Assessors judged patient–trial pairs on a graded scale. |
| as distributed by TrialGPT | Jin et al., *Nature Communications* 2024. The trial texts and the pair labels used here come from that release. |
| labels | grade 2 = **Eligible**; grade 1 = **Not Eligible** (the trial is relevant to the patient, but the patient does not qualify); grade 0 (not relevant) pairs are not included. The lab checked these grades against the official CSIRO relevance file: 3,835 of 3,835 shared judgements agree. |
| this subset | built in the lab from 1,099 pairs (58 patients, 38.0% eligible): only patients with at least 2 Eligible and at least 2 Not Eligible trials were kept, whole patients were added until about 200 pairs. Result: 204 pairs, 14 patients, 49.0% eligible. |

**What this means for you:**

1. **It is not a random sample** of the collection. It is balanced on purpose and keeps only patients
   with mixed outcomes.
2. **A Not Eligible pair is a hard negative:** the trial is about the patient's condition, but something
   rules the patient out.
3. **Labels are for the whole pair only.** The rule-by-rule answers are what you label yourself.
4. **The rule texts are the TrialGPT versions.** In a few trials they differ from the official 2015 registry
   text. Write "SIGIR-2016 as released with TrialGPT" in your thesis, not just "SIGIR-2016".

## The split — by PATIENT

Each patient appears in several pairs, with different trials. If one patient appeared on both sides, the
test would leak. So the 14 patients are divided into two groups of 7 with 102 pairs each:

- **Development patients:** sigir-20142, sigir-201427, sigir-20147, sigir-201513, sigir-201520, sigir-201521,
  sigir-201523 (102 pairs, 49 Eligible).
- **Test patients:** sigir-201414, sigir-201415, sigir-201514, sigir-201515, sigir-201522, sigir-201529,
  sigir-20156 (102 pairs, 51 Eligible).

`splits.csv` lists the split per trial (every trial belongs to exactly one pair), so the provided code
works unchanged. **When you compare systems, the unit is the patient** (`--cluster-col patient_id`).

## Facts you must know

1. **The number of rules differs a lot between trials:** 1 to 48 (median 7). Not Eligible pairs have more
   rules (median 9) than Eligible pairs (median 6). A system can look good simply by rejecting trials
   with long rule lists. **Always report a count-the-rules baseline** (see your pack README).
2. **Many facts are simply not in the case summary.** Expect far more `unknown` answers than on the
   lung-cancer set.
3. **Several trials describe alternative groups** ("patients with A, or with B", or patients versus
   healthy controls). The review joined such groups into one rule and says so in `note`.
4. **Some rules concern someone other than the patient** (a caregiver, the clinic) or behaviour during the
   study. The `note` column tells you how to label them.

## Rights and use

The original collection is public (CC BY-SA 4.0, per the lab's provenance record; ClinicalTrials.gov terms
apply to the trial texts). Keep the data out of public repositories, use local models only, and cite the
original collection and the TrialGPT release.
