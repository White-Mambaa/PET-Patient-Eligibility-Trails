"""stats_tools.py - small, honest statistics for a small dataset.

reweight()          what your pair-level results would look like if eligible patients were rarer
                    than in the 50/50 lung-cancer set (real screening: most patients do not qualify)
trial_sign_test()   "better in k of 10 trials" plus an exact two-sided sign-test p-value
holm()              Holm correction when you test several things at once

Why these and not the usual confidence intervals: the 100 pairs come from only 10 trials, and pairs
from the same trial are not independent. Treat the TRIAL (lung-cancer set) or the PATIENT (SIGIR) as
the unit when you judge whether a difference is real.
"""
from __future__ import annotations
from math import comb


def reweight(gold: list[int], decision: list[str], target_rate: float) -> dict:
    """Re-weight pair-level results to a different share of eligible pairs.

    gold      1 = Eligible, 0 = Not Eligible (the dataset label)
    decision  ELIGIBLE / NOT_ELIGIBLE / REVIEW for the same pairs
    Eligible pairs get weight target_rate / observed_rate, the others (1-target_rate) / (1-observed_rate).

    Rates computed WITHIN eligible or within ineligible pairs (false exclusion rate, false inclusion
    rate) do not change with rarity. What changes is what a coordinator sees:
      forwarded_share         share of all screened pairs decided ELIGIBLE
      forwarded_precision     share of forwarded pairs that are truly eligible
      review_share            share of all pairs sent to a person
      false_matches_per_true  ineligible pairs forwarded for every eligible pair forwarded
    """
    if len(gold) != len(decision) or not gold:
        raise ValueError("gold and decision must be non-empty and the same length")
    if not 0 < target_rate < 1:
        raise ValueError("target_rate must be between 0 and 1")
    bad = set(decision) - {"ELIGIBLE", "NOT_ELIGIBLE", "REVIEW"}
    if bad:
        raise ValueError(f"unknown decisions: {sorted(bad)}")
    n1 = sum(1 for g in gold if g == 1)
    n0 = len(gold) - n1
    if n1 == 0 or n0 == 0:
        raise ValueError("need both eligible and ineligible pairs")
    p_obs = n1 / len(gold)
    w1, w0 = target_rate / p_obs, (1 - target_rate) / (1 - p_obs)
    total = w1 * n1 + w0 * n0
    fwd1 = sum(1 for g, d in zip(gold, decision) if g == 1 and d == "ELIGIBLE")
    fwd0 = sum(1 for g, d in zip(gold, decision) if g == 0 and d == "ELIGIBLE")
    rev = sum((w1 if g == 1 else w0) for g, d in zip(gold, decision) if d == "REVIEW")
    excl1 = sum(1 for g, d in zip(gold, decision) if g == 1 and d == "NOT_ELIGIBLE")
    wf1, wf0 = w1 * fwd1, w0 * fwd0
    return {
        "target_eligible_rate": target_rate,
        "observed_eligible_rate": p_obs,
        "forwarded_share": (wf1 + wf0) / total,
        "forwarded_precision": wf1 / (wf1 + wf0) if (wf1 + wf0) else float("nan"),
        "review_share": rev / total,
        "false_matches_per_true": wf0 / wf1 if wf1 else float("inf") if wf0 else float("nan"),
        "false_exclusion_rate_unchanged": excl1 / n1,
        "false_inclusion_rate_unchanged": fwd0 / n0,
    }


def sign_test_p(wins: int, losses: int) -> float:
    """Exact two-sided sign test. Ties are dropped before calling this."""
    n = wins + losses
    if n == 0:
        return 1.0
    k = min(wins, losses)
    p = 2 * sum(comb(n, i) for i in range(0, k + 1)) / 2 ** n
    return min(1.0, p)


def trial_sign_test(per_unit_a: dict[str, float], per_unit_b: dict[str, float],
                    lower_is_better: bool = True) -> dict:
    """Compare two systems unit by unit (unit = trial on the lung-cancer set, patient on SIGIR).

    per_unit_a / per_unit_b: {unit: score}, e.g. wrongly excluded eligible pairs per trial.
    Returns how many units A is better, worse, tied, and the exact sign-test p-value.
    """
    if set(per_unit_a) != set(per_unit_b):
        raise ValueError("both systems must be scored on the same units")
    wins = losses = ties = 0
    for u in per_unit_a:
        a, b = per_unit_a[u], per_unit_b[u]
        if a == b:
            ties += 1
        elif (a < b) == lower_is_better:
            wins += 1
        else:
            losses += 1
    return {"units": len(per_unit_a), "a_better": wins, "b_better": losses, "ties": ties,
            "sign_test_p_two_sided": sign_test_p(wins, losses)}


def holm(pvalues: dict[str, float]) -> dict[str, float]:
    """Holm step-down adjusted p-values (controls the chance of ANY false 'finding' in the family)."""
    items = sorted(pvalues.items(), key=lambda kv: kv[1])
    m = len(items)
    out, running = {}, 0.0
    for rank, (name, p) in enumerate(items):
        adj = min(1.0, (m - rank) * p)
        running = max(running, adj)
        out[name] = running
    return out


if __name__ == "__main__":
    r = reweight([1, 1, 0, 0], ["ELIGIBLE", "NOT_ELIGIBLE", "ELIGIBLE", "NOT_ELIGIBLE"], 0.5)
    assert abs(r["forwarded_precision"] - 0.5) < 1e-12
    r = reweight([1, 1, 0, 0], ["ELIGIBLE", "ELIGIBLE", "ELIGIBLE", "NOT_ELIGIBLE"], 0.1)
    # eligible weight 0.2, ineligible 1.8: forwarded = 0.4 true + 1.8 false
    assert abs(r["forwarded_precision"] - 0.4 / 2.2) < 1e-12
    assert abs(sign_test_p(8, 2) - 0.109375) < 1e-12
    assert holm({"a": 0.01, "b": 0.04, "c": 0.03}) == {"a": 0.03, "c": 0.06, "b": 0.06}
    print("stats_tools.py self-test passed")
