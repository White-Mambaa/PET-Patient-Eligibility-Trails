"""plain_ai.py - the PLAIN-AI comparison system.

One local-model call per (patient-trial pair, rule): the whole note plus one rule. The model says
whether the rule's condition is true for the patient (yes / no / unknown) and quotes the note.
Inclusion/exclusion logic is then applied in code (criteria.map_truth).

This is the system you compare your own work against. Run it yourself, on your own computer.

Usage (from the code/ folder)
  python plain_ai.py --model qwen2.5:7b --split dev --dry-run          # print one prompt, call nothing
  python plain_ai.py --model qwen2.5:7b --pairs 7,4                     # two pairs, quick check
  python plain_ai.py --model qwen2.5:7b --split dev                     # the 50 development pairs
  python plain_ai.py --model qwen2.5:7b --split dev --no-unknown        # the "forced guess" variant
  python plain_ai.py --model qwen2.5:7b --split dev --dataset sigir204 --corpus ../datasets/sigir204/sigir204.csv       --criteria ../datasets/sigir204/criteria.csv --splits ../datasets/sigir204/splits.csv     # SIGIR
  python plain_ai.py --model qwen2.5:7b --cases ../outputs/my_cases.jsonl --dataset trap_set
      # altered notes: one JSON per line {"case_idx", "trial_id", "note", "crit_idx" (optional), ...}

Output: one decision record per line (templates/decision_record.schema.json), default
  ../outputs/plain_ai[_forced]_<model>[_<dataset>]_<split>.jsonl   (dataset shown when it is not nsclc100)
If any model call fails for good, the file is still written, a <file>.INCOMPLETE marker is created,
and the script exits with code 2. Do not evaluate an INCOMPLETE run.
"""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path

import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from criteria import DEFAULT_CRITERIA, DEFAULT_SPLITS, load_criteria, load_splits, map_truth  # noqa: E402
from llm_client import CallFailed, LocalLLM  # noqa: E402

DEFAULT_CORPUS = HERE.parent / "datasets" / "nsclc100" / "nsclc100.csv"

PROMPT_ID = "PLAIN_v1"
SYSTEM_PROMPT = """You check one clinical-trial eligibility condition against a patient note.
Decide whether the CONDITION is true for this patient, using only the NOTE.
Answer "yes", "no", or "unknown" (the note does not contain enough information).
Judge the condition exactly as written. Do not decide whether the patient is eligible.
If GUIDANCE is given, follow it.
Copy the exact words from the note that support your answer.
Return JSON only:
{"truth": "yes|no|unknown", "evidence": ["exact text from the note"], "basis": "stated|inferred|absent", "rationale": "one sentence", "confidence": 0.0}
"confidence" is a number from 0.0 to 1.0: how sure you are of "truth"."""

PROMPT_ID_FORCED = "PLAIN_FORCED_v1"
SYSTEM_PROMPT_FORCED = """You check one clinical-trial eligibility condition against a patient note.
Decide whether the CONDITION is true for this patient.
You must answer "yes" or "no". If the note does not contain enough information, give your best guess.
Judge the condition exactly as written. Do not decide whether the patient is eligible.
If GUIDANCE is given, follow it.
Copy the exact words from the note that support your answer (an empty list if there are none).
Return JSON only:
{"truth": "yes|no", "evidence": ["exact text from the note"], "basis": "stated|inferred|absent", "rationale": "one sentence", "confidence": 0.0}
"confidence" is a number from 0.0 to 1.0: how sure you are of "truth"."""


def build_user(criterion_text: str, note: str, guidance: str) -> str:
    parts = [f"CONDITION: {criterion_text}"]
    if guidance and guidance.strip():
        parts.append(f"GUIDANCE: {guidance.strip()}")
    parts.append(f"NOTE: {note}")
    return "\n".join(parts)


def clean_answer(data: dict | None, allowed: tuple[str, ...]) -> dict | None:
    """Validate the model's JSON. Returns None when 'truth' is missing or not allowed."""
    if not data:
        return None
    truth = str(data.get("truth", "")).strip().lower()
    if truth not in allowed:
        return None
    ev = data.get("evidence", [])
    if isinstance(ev, str):
        ev = [ev]
    ev = [str(e) for e in ev if isinstance(e, (str, int, float)) and str(e).strip()] if isinstance(ev, list) else []
    basis = str(data.get("basis", "")).strip().lower()
    conf = data.get("confidence")
    try:
        conf = float(conf)
        conf = conf if 0.0 <= conf <= 1.0 else None
    except (TypeError, ValueError):
        conf = None
    return {"truth": truth, "evidence": ev, "basis": basis if basis in ("stated", "inferred", "absent") else None,
            "rationale": str(data.get("rationale", "") or ""), "confidence": conf}


def model_tag(model: str) -> str:
    return "".join(ch if ch.isalnum() or ch in "._" else "-" for ch in model)


def load_jobs(corpus_path, criteria_path, splits_path, split, pairs, cases_path):
    """Yields (pair_idx, trial_id, note, rules, extra_trace)."""
    criteria = load_criteria(criteria_path)
    if cases_path:
        for line in open(cases_path, encoding="utf-8"):
            if not line.strip():
                continue
            c = json.loads(line)
            rules = criteria[c["trial_id"]]
            if c.get("crit_idx") is not None:
                rules = [r for r in rules if r["crit_idx"] == int(c["crit_idx"])]
            extra = {k: v for k, v in c.items() if k not in ("note", "case_idx", "trial_id", "crit_idx")}
            yield int(c["case_idx"]), c["trial_id"], c["note"], rules, extra
        return
    corpus = pd.read_csv(corpus_path)
    if pairs:
        corpus = corpus[corpus["pair_idx"].isin(pairs)]
        if len(corpus) != len(set(pairs)):
            raise SystemExit(f"some of the requested pairs do not exist: {sorted(pairs)}")
    elif split != "all":
        s = load_splits(splits_path)
        corpus = corpus[corpus["trial_id"].map(s) == split]
    for r in corpus.itertuples():
        yield int(r.pair_idx), r.trial_id, r.patient_orig, criteria[r.trial_id], {}


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):          # Windows consoles: print symbols such as >= safely
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--model", required=True, help="Ollama model tag, e.g. qwen2.5:7b")
    ap.add_argument("--split", choices=["dev", "test", "all"], default="dev")
    ap.add_argument("--pairs", help="comma-separated pair_idx values (overrides --split)")
    ap.add_argument("--cases", help="JSONL of altered notes (overrides --split and --pairs)")
    ap.add_argument("--dataset", default="nsclc100", help="value written in each record's 'dataset' field")
    ap.add_argument("--corpus", default=str(DEFAULT_CORPUS))
    ap.add_argument("--criteria", default=str(DEFAULT_CRITERIA))
    ap.add_argument("--splits", default=str(DEFAULT_SPLITS))
    ap.add_argument("--no-unknown", action="store_true", help="forced-guess variant: the model may not say unknown")
    ap.add_argument("--out")
    ap.add_argument("--cache-dir", default=str(HERE.parent / "outputs" / "cache"))
    ap.add_argument("--num-ctx", type=int, default=8192)
    ap.add_argument("--dry-run", action="store_true", help="print the first prompt and stop")
    ap.add_argument("--backend", choices=["ollama", "mock"], default="ollama", help=argparse.SUPPRESS)
    a = ap.parse_args()

    forced = a.no_unknown
    system = SYSTEM_PROMPT_FORCED if forced else SYSTEM_PROMPT
    prompt_id = PROMPT_ID_FORCED if forced else PROMPT_ID
    allowed = ("yes", "no") if forced else ("yes", "no", "unknown")
    name = f"plain_ai{'_forced' if forced else ''}_{model_tag(a.model)}"
    pairs = [int(x) for x in a.pairs.split(",")] if a.pairs else None
    label = "cases" if a.cases else ("pairs" if pairs else a.split)
    tag = "" if a.dataset == "nsclc100" else f"_{a.dataset}"
    out = Path(a.out) if a.out else HERE.parent / "outputs" / f"{name}{tag}_{label}.jsonl"
    jobs = list(load_jobs(a.corpus, a.criteria, a.splits, a.split, pairs, a.cases))
    n_cells = sum(len(j[3]) for j in jobs)

    if a.dry_run:
        pidx, trial, note, rules, _ = jobs[0]
        print(f"# {len(jobs)} notes, {n_cells} rule questions would be asked. First one (pair {pidx}, {trial}):\n")
        print("SYSTEM:\n" + system + "\n\nUSER:\n" + build_user(rules[0]["criterion_text"], note, rules[0]["note"]))
        return 0

    mock = None
    if a.backend == "mock":        # used only by selftest.py
        mock = lambda s, u: json.dumps({"truth": "unknown" if not forced else "no", "evidence": [],
                                        "basis": "absent", "rationale": "mock", "confidence": 0.5})
    llm = LocalLLM(a.model, cache_dir=a.cache_dir, num_ctx=a.num_ctx, backend=a.backend, mock=mock)
    llm.check_model_available()
    out.parent.mkdir(parents=True, exist_ok=True)
    marker = out.with_name(out.name + ".INCOMPLETE")
    rows, failed, parse_failed, done = [], 0, 0, 0
    print(f"{name}: {len(jobs)} notes, {n_cells} rule questions -> {out}")
    for pidx, trial, note, rules, extra in jobs:
        for rule in rules:
            user = build_user(rule["criterion_text"], note, rule["note"])
            try:
                res = llm.chat_json(system, user, prompt_id=prompt_id)
            except CallFailed as e:
                failed += 1
                print(f"  CALL FAILED pair {pidx} rule {rule['crit_idx']}: {e}")
                continue
            ans = clean_answer(res["data"], allowed) if res["ok"] else None
            parse_ok = ans is not None
            if not parse_ok:
                parse_failed += 1
                ans = {"truth": "unknown", "evidence": [], "basis": None, "rationale": "", "confidence": None}
            rows.append({"system": name, "dataset": a.dataset, "pair_idx": pidx, "crit_idx": rule["crit_idx"],
                         "kind": rule["kind"], "criterion": rule["criterion_text"], "truth": ans["truth"],
                         "verdict": map_truth(ans["truth"], rule["kind"]), "basis": ans["basis"],
                         "evidence": ans["evidence"], "rationale": ans["rationale"], "confidence": ans["confidence"],
                         "parse_ok": parse_ok, "route": "llm",
                         "trace": {"prompt_id": prompt_id, "model": a.model, "trial_id": trial,
                                   "prompt_sha256": res["prompt_sha256"], "attempts": res["attempts"],
                                   "cache_hit": res["cache_hit"], **extra}})
            done += 1
            if done % 50 == 0:
                print(f"  {done}/{n_cells} answered")
    with open(out, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"done: {len(rows)} records written | model calls {llm.stats['calls']} | cache hits "
          f"{llm.stats['cache_hits']} | unparseable answers kept as unknown (parse_ok=false): {parse_failed} | "
          f"failed calls: {failed}")
    if failed:
        marker.write_text(f"{failed} model calls failed; rerun this command (answers are cached).\n", encoding="utf-8")
        print(f"RUN INCOMPLETE -> {marker}. Rerun before evaluating.")
        return 2
    if marker.exists():
        marker.unlink()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
