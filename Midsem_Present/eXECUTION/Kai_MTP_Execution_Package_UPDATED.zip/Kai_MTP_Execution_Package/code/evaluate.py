"""evaluate.py - the scoring script for your project. Every number in your slides comes from here.

Modes
-----
pairs       Patient-trial decisions of a system against the dataset's Eligible / Not Eligible label.
              python evaluate.py pairs --pred ../outputs/plain_ai_qwen2.5-7b_dev.jsonl --split dev
              python evaluate.py pairs --pred ... --split dev --target-rate 0.10 --target-rate 0.05
              SIGIR: add --corpus ../datasets/sigir204/sigir204.csv --criteria ../datasets/sigir204/criteria.csv
                     --splits ../datasets/sigir204/splits.csv --cluster-col patient_id

criterion   Rule-level scores of a system against YOUR frozen labels.
              python evaluate.py criterion --gold ../labelling/my_labels_final.csv --pred ... --split dev

kappa       Agreement between two people who labelled some of the same rule answers.
              python evaluate.py kappa --a first.csv --b second.csv --overlap-only

labelcheck  Labelled pairs whose rule answers contradict the pair's Eligible / Not Eligible label.
            Send every listed pair to your supervisor.
              python evaluate.py labelcheck --gold ../labelling/my_labels_final.csv

evidence    Is the quoted evidence really in the note, and does it overlap your evidence spans?
              python evaluate.py evidence --pred ... [--gold ../labelling/my_labels_final.csv --split dev]

verification  How well a checker separates right from wrong rule answers of one system.
              python evaluate.py verification --gold ../labelling/my_labels_final.csv --pred ... --verif ...

targeting   How many wrongly excluded eligible pairs a person would rescue by checking rule answers
            in a given order, for several numbers of checks.
              python evaluate.py targeting --pred ... --order my_order.csv --budgets 5,10,20,50 --split dev

questions   Summary of a question-asking log: questions asked, decisions reached, harm avoided.
              python evaluate.py questions --log ../outputs/questions_strategyA.jsonl

Units (always state them)
  criterion / evidence / verification -> unit = rule answer (one rule for one patient-trial pair)
  pairs / labelcheck / targeting      -> unit = patient-trial pair
  questions                           -> unit = test case (one note with hidden sentences)

Labels
  truth    yes | no | unknown          is the condition written in the rule true for the patient
  verdict  met | not_met | not_stated  after inclusion/exclusion logic (criteria.map_truth)
  decision ELIGIBLE (all rules met) | NOT_ELIGIBLE (any rule not met) | REVIEW (otherwise)

A missing prediction is scored as 'unknown' and COUNTED in the output. Nothing is dropped.
"""
from __future__ import annotations
import argparse
import json
import re
import sys
from collections import Counter
from pathlib import Path

import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from criteria import DEFAULT_CRITERIA, DEFAULT_SPLITS, decide, load_criteria, load_splits, map_truth  # noqa: E402
from stats_tools import reweight  # noqa: E402

DEFAULT_CORPUS = HERE.parent / "datasets" / "nsclc100" / "nsclc100.csv"
TRUTH_CLASSES = ["yes", "no", "unknown"]
VERIFICATION_LABELS = ["HALLUCINATED_EVIDENCE", "CONTEXT_ERROR", "LOGIC_ERROR", "CONTRADICTED",
                       "UNSUPPORTED", "MISSED_EVIDENCE", "VERIFIED"]


# ----------------------------------------------------------------------------- helpers
def norm_truth(x) -> str:
    v = "" if x is None or (isinstance(x, float) and pd.isna(x)) else str(x).strip().lower()
    if v == "not_stated":
        v = "unknown"
    return v if v in TRUTH_CLASSES else ""


def read_jsonl(path: str) -> list[dict]:
    return [json.loads(l) for l in open(path, encoding="utf-8") if l.strip()]


def read_records(path: str) -> pd.DataFrame:
    df = pd.DataFrame(read_jsonl(path))
    need = {"pair_idx", "crit_idx", "kind", "truth"}
    if df.empty or not need.issubset(df.columns):
        raise ValueError(f"{path} is empty or missing columns {sorted(need - set(df.columns))}")
    if "system" in df.columns and df["system"].nunique() > 1:
        raise ValueError(f"{path} mixes systems {sorted(df['system'].unique())} - use one file per system")
    if df.duplicated(["pair_idx", "crit_idx"]).any():
        raise ValueError(f"{path} has duplicate (pair_idx, crit_idx) rows - one record per rule answer")
    df["truth_raw"] = df["truth"]
    df["truth"] = df["truth"].map(norm_truth)
    return df


def read_gold(path: str, split: str | None) -> pd.DataFrame:
    gold = pd.read_csv(path, encoding="utf-8-sig")
    if split:
        gold = gold[gold["split"] == split]
    gold = gold.assign(gtruth=gold["truth"].map(norm_truth))
    bad = int((gold.gtruth == "").sum())
    if bad:
        raise ValueError(f"{bad} labelled rows have no valid truth (yes/no/unknown) - finish labelling first")
    return gold


def check_not_incomplete(pred_path: str) -> None:
    if Path(pred_path + ".INCOMPLETE").exists():
        raise ValueError(f"{pred_path} is marked INCOMPLETE (some model calls failed). Rerun the system first.")


def classification_report(gold: list[str], pred: list[str], classes: list[str]) -> dict:
    n = len(gold)
    acc = sum(g == p for g, p in zip(gold, pred)) / n if n else float("nan")
    per = {}
    for c in classes:
        tp = sum(g == c and p == c for g, p in zip(gold, pred))
        fp = sum(g != c and p == c for g, p in zip(gold, pred))
        fn = sum(g == c and p != c for g, p in zip(gold, pred))
        prec = tp / (tp + fp) if tp + fp else float("nan")
        rec = tp / (tp + fn) if tp + fn else float("nan")
        f1 = 2 * prec * rec / (prec + rec) if tp and (prec + rec) else 0.0
        per[c] = {"precision": prec, "recall": rec, "f1": f1, "support": sum(g == c for g in gold)}
    present = [c for c in classes if per[c]["support"] > 0]
    macro = sum(per[c]["f1"] for c in present) / len(present) if present else float("nan")
    confusion = {g: {p: sum(1 for a, b in zip(gold, pred) if a == g and b == p) for p in classes} for g in classes}
    return {"n": n, "accuracy": acc, "macro_f1_over_gold_classes": macro, "per_class": per,
            "confusion_gold_rows": confusion}


def cohen_kappa(a: list[str], b: list[str]) -> dict:
    n = len(a)
    if n == 0:
        return {"n": 0, "percent_agreement": float("nan"), "kappa": float("nan")}
    po = sum(x == y for x, y in zip(a, b)) / n
    ca, cb = Counter(a), Counter(b)
    pe = sum((ca[k] / n) * (cb[k] / n) for k in set(ca) | set(cb))
    kappa = (po - pe) / (1 - pe) if pe < 1 else float("nan")
    return {"n": n, "percent_agreement": po, "expected_agreement": pe, "kappa": kappa}


def fmt(x) -> str:
    return "  nan" if isinstance(x, float) and pd.isna(x) else f"{x:.3f}"


def filter_corpus(corpus: pd.DataFrame, split: str | None, splits_path: str,
                  pairs_filter: str | None = None) -> pd.DataFrame:
    if pairs_filter:
        keep = pd.read_csv(pairs_filter)
        if split and "split" in keep.columns:
            keep = keep[keep["split"] == split]
        return corpus[corpus["pair_idx"].isin(keep["pair_idx"])]
    if split:
        s = load_splits(splits_path)
        return corpus[corpus["trial_id"].map(s) == split]
    return corpus


def pair_decisions(corpus: pd.DataFrame, criteria: dict, lookup: dict,
                   cluster_col: str = "trial_id") -> tuple[pd.DataFrame, int]:
    """lookup: (pair_idx, crit_idx) -> truth. Missing answers count as unknown and are counted.
    cluster_col: trial_id for the lung-cancer set, patient_id for SIGIR."""
    rows, missing = [], 0
    for r in corpus.itertuples():
        verdicts = []
        for c in criteria[r.trial_id]:
            t = lookup.get((int(r.pair_idx), c["crit_idx"]))
            if t is None or t == "":
                missing += 1
                t = "unknown"
            verdicts.append(map_truth(t, c["kind"]))
        rows.append({"pair_idx": int(r.pair_idx), "cluster": getattr(r, cluster_col),
                     "gold": int(str(r.target).strip() == "Eligible"), "decision": decide(verdicts),
                     "n_rules": len(verdicts), "n_not_met": sum(v == "not_met" for v in verdicts)})
    return pd.DataFrame(rows), missing


# ----------------------------------------------------------------------------- pairs
def run_pairs(corpus_path: str, pred_path: str, pairs_filter: str | None, split: str | None,
              criteria_path: str = str(DEFAULT_CRITERIA), splits_path: str = str(DEFAULT_SPLITS),
              target_rates: list[float] | None = None, cluster_col: str = "trial_id") -> dict:
    check_not_incomplete(pred_path)
    corpus = filter_corpus(pd.read_csv(corpus_path), split, splits_path, pairs_filter)
    criteria = load_criteria(criteria_path)
    pred = read_records(pred_path)
    lookup = {(int(r.pair_idx), int(r.crit_idx)): r.truth for r in pred.itertuples()}
    parse_failed = 0
    if "parse_ok" in pred.columns:
        parse_failed = int((pred["parse_ok"] == False).sum())  # noqa: E712
    df, missing = pair_decisions(corpus, criteria, lookup, cluster_col)
    eligible, inelig = df[df.gold == 1], df[df.gold == 0]
    out = {
        "unit": "patient-trial pair", "split": split or "all", "n_pairs": len(df), "cluster_by": cluster_col,
        "missing_rule_answers_scored_unknown": missing,
        "unparseable_answers_kept_as_unknown": parse_failed,
        "decision_counts": df.decision.value_counts().to_dict(),
        "accuracy_strict_REVIEW_as_not_eligible": float(((df.decision == "ELIGIBLE").astype(int) == df.gold).mean()),
        "accuracy_lenient_REVIEW_as_eligible": float(((df.decision != "NOT_ELIGIBLE").astype(int) == df.gold).mean()),
        "false_exclusions_count": int((eligible.decision == "NOT_ELIGIBLE").sum()),
        "eligible_pairs_count": int(len(eligible)),
        "false_exclusion_rate": float((eligible.decision == "NOT_ELIGIBLE").mean()) if len(eligible) else float("nan"),
        "false_inclusions_count": int((inelig.decision == "ELIGIBLE").sum()),
        "ineligible_pairs_count": int(len(inelig)),
        "false_inclusion_rate": float((inelig.decision == "ELIGIBLE").mean()) if len(inelig) else float("nan"),
        "review_count": int((df.decision == "REVIEW").sum()),
        "review_rate": float((df.decision == "REVIEW").mean()),
        "not_met_answers_on_eligible_pairs": int(eligible.n_not_met.sum()),
        "wrongful_exclusions_with_a_single_failing_rule": int(((eligible.decision == "NOT_ELIGIBLE")
                                                               & (eligible.n_not_met == 1)).sum()),
        "per_cluster": {},
    }
    for t, g in df.groupby("cluster"):
        e = g[g.gold == 1]
        out["per_cluster"][t] = {"pairs": int(len(g)), "eligible": int(len(e)),
                                 "false_exclusions": int((e.decision == "NOT_ELIGIBLE").sum()),
                                 "false_inclusions": int(((g.gold == 0) & (g.decision == "ELIGIBLE")).sum()),
                                 "review": int((g.decision == "REVIEW").sum())}
    if target_rates and len(eligible) and len(inelig):
        out["reweighted"] = [reweight(df.gold.tolist(), df.decision.tolist(), r) for r in target_rates]
    print(f"\nPAIR LEVEL  (unit = patient-trial pair, split = {out['split']}, n = {out['n_pairs']})")
    print(f"  missing rule answers scored unknown: {missing} | unparseable answers kept as unknown: {parse_failed}")
    print(f"  decisions: {out['decision_counts']}")
    print(f"  WRONGLY EXCLUDED eligible pairs: {out['false_exclusions_count']}/{out['eligible_pairs_count']} "
          f"({fmt(out['false_exclusion_rate'])})   of which with a single failing rule: "
          f"{out['wrongful_exclusions_with_a_single_failing_rule']}")
    print(f"  wrongly included ineligible pairs: {out['false_inclusions_count']}/{out['ineligible_pairs_count']} "
          f"({fmt(out['false_inclusion_rate'])})   sent to REVIEW: {out['review_count']}/{out['n_pairs']}")
    print(f"  accuracy strict {fmt(out['accuracy_strict_REVIEW_as_not_eligible'])} | "
          f"lenient {fmt(out['accuracy_lenient_REVIEW_as_eligible'])}")
    print(f"  'not met' answers on Eligible pairs: {out['not_met_answers_on_eligible_pairs']} "
          f"(each is wrong, unless the pair's label is wrong)")
    print(f"  per {cluster_col.replace('_id', '')} (wrongly excluded / eligible, wrongly included, review):")
    for t, v in out["per_cluster"].items():
        print(f"    {t}: {v['false_exclusions']}/{v['eligible']}  {v['false_inclusions']}  {v['review']}")
    for rw in out.get("reweighted", []):
        print(f"  if {rw['target_eligible_rate']:.0%} of screened pairs were eligible: forwarded "
              f"{fmt(rw['forwarded_share'])} of pairs, of which truly eligible {fmt(rw['forwarded_precision'])}; "
              f"review share {fmt(rw['review_share'])}")
    return out


# ----------------------------------------------------------------------------- criterion
def run_criterion(gold_path: str, pred_path: str, split: str | None) -> dict:
    check_not_incomplete(pred_path)
    gold = read_gold(gold_path, split)[["pair_idx", "crit_idx", "kind", "gtruth"]]
    pred = read_records(pred_path)
    m = gold.merge(pred[["pair_idx", "crit_idx", "truth", "kind"]].rename(columns={"kind": "pkind", "truth": "ptruth"}),
                   on=["pair_idx", "crit_idx"], how="left")
    missing = int(m["ptruth"].isna().sum())
    if (m["pkind"].notna() & (m["pkind"] != m["kind"])).any():
        raise ValueError("kind mismatch between labels and predictions - rule numbers are misaligned")
    m["ptruth"] = m["ptruth"].map(norm_truth).replace("", "unknown")
    m["gverdict"] = [map_truth(t, k) for t, k in zip(m.gtruth, m.kind)]
    m["pverdict"] = [map_truth(t, k) for t, k in zip(m.ptruth, m.kind)]
    out = {"unit": "rule answer", "split": split or "all", "missing_predictions_scored_unknown": missing,
           "truth": classification_report(m.gtruth.tolist(), m.ptruth.tolist(), TRUTH_CLASSES),
           "verdict": classification_report(m.gverdict.tolist(), m.pverdict.tolist(), ["met", "not_met", "not_stated"]),
           "truth_by_kind": {k: classification_report(g.gtruth.tolist(), g.ptruth.tolist(), TRUTH_CLASSES)
                             for k, g in m.groupby("kind")},
           "wrong_not_met": int(((m.pverdict == "not_met") & (m.gverdict != "not_met")).sum())}
    t = out["truth"]
    print(f"\nRULE LEVEL  (unit = rule answer, split = {out['split']}, n = {t['n']}, "
          f"missing predictions scored unknown = {missing})")
    print(f"  truth accuracy {fmt(t['accuracy'])} | macro-F1 {fmt(t['macro_f1_over_gold_classes'])} | "
          f"verdict accuracy {fmt(out['verdict']['accuracy'])} | wrong 'not met' answers {out['wrong_not_met']}")
    print(f"  {'class':<8}{'prec':>7}{'recall':>8}{'f1':>7}{'support':>9}")
    for c in TRUTH_CLASSES:
        p = t["per_class"][c]
        print(f"  {c:<8}{fmt(p['precision']):>7}{fmt(p['recall']):>8}{fmt(p['f1']):>7}{p['support']:>9}")
    return out


# ----------------------------------------------------------------------------- kappa
def run_kappa(a_path: str, b_path: str, disagreements: str | None, overlap_only: bool = False) -> dict:
    a = pd.read_csv(a_path, encoding="utf-8-sig")
    b = pd.read_csv(b_path, encoding="utf-8-sig")
    key = ["pair_idx", "crit_idx"]
    keep_a = [c for c in key + ["split", "trial_id", "kind", "criterion_text", "truth", "evidence_span", "basis"]
              if c in a.columns]
    keep_b = [c for c in key + ["truth", "evidence_span", "basis"] if c in b.columns]
    m = a[keep_a].merge(b[keep_b], on=key, suffixes=("_a", "_b"),
                        how="inner" if overlap_only else "outer", indicator=True)
    if not overlap_only and (m["_merge"] != "both").any():
        raise ValueError("the two sheets do not contain the same rule answers (use --overlap-only)")
    if m.empty:
        raise ValueError("the two sheets share no rule answers")
    m["ta"], m["tb"] = m["truth_a"].map(norm_truth), m["truth_b"].map(norm_truth)
    labelled = m[(m.ta != "") & (m.tb != "")]
    out = {"unit": "rule answer", "cells_compared": len(m), "pairs_compared": int(m.pair_idx.nunique()),
           "cells_labelled_by_both": len(labelled), "cells_unlabelled_or_invalid": len(m) - len(labelled),
           "overall": cohen_kappa(labelled.ta.tolist(), labelled.tb.tolist()),
           "by_kind": {k: cohen_kappa(g.ta.tolist(), g.tb.tolist()) for k, g in labelled.groupby("kind")},
           "confusion_a_rows": {x: {y: int(((labelled.ta == x) & (labelled.tb == y)).sum()) for y in TRUTH_CLASSES}
                                for x in TRUTH_CLASSES}}
    if disagreements:
        d = m[(m.ta != m.tb) | (m.ta == "") | (m.tb == "")].drop(columns=["_merge", "ta", "tb"])
        d.to_csv(disagreements, index=False, encoding="utf-8-sig")
        out["disagreements_written"] = len(d)
    o = out["overall"]
    print(f"\nAGREEMENT  (unit = rule answer, pairs compared = {out['pairs_compared']}, "
          f"answers compared = {out['cells_compared']}, labelled by both = {out['cells_labelled_by_both']})")
    print(f"  percent agreement {fmt(o['percent_agreement'])} | Cohen's kappa {fmt(o['kappa'])}")
    for k, v in out["by_kind"].items():
        print(f"    {k:<10} n={v['n']:<4} agreement {fmt(v['percent_agreement'])} kappa {fmt(v['kappa'])}")
    return out


# ----------------------------------------------------------------------------- labelcheck
def run_labelcheck(gold_path: str, corpus_path: str, out_csv: str | None) -> dict:
    """Labelled pairs whose rule answers contradict the pair's Eligible / Not Eligible label."""
    gold = read_gold(gold_path, None)
    corpus = pd.read_csv(corpus_path).set_index("pair_idx")
    rows = []
    for pid, g in gold.groupby("pair_idx"):
        verdicts = [map_truth(t, k) for t, k in zip(g.gtruth, g.kind)]
        decision = decide(verdicts)
        label = str(corpus.loc[pid, "target"]).strip()
        not_met = [f"{c}: {str(txt)[:80]}" for c, v, txt in zip(g.crit_idx, verdicts, g.criterion_text) if v == "not_met"]
        conflict = (label == "Eligible" and decision == "NOT_ELIGIBLE") or \
                   (label == "Not Eligible" and decision == "ELIGIBLE")
        rows.append({"pair_idx": pid, "split": g.split.iloc[0], "trial_id": g.trial_id.iloc[0], "pair_label": label,
                     "decision_from_labels": decision, "conflict": conflict,
                     "unknown_rules": sum(v == "not_stated" for v in verdicts),
                     "not_met_rules": " || ".join(not_met), "supervisor_decision": ""})
    df = pd.DataFrame(rows)
    if out_csv:
        df.to_csv(out_csv, index=False, encoding="utf-8-sig")
    conflicts = df[df.conflict]
    print(f"\nLABEL CHECK  (unit = labelled patient-trial pair, n = {len(df)})")
    print(f"  decisions from your labels: {df.decision_from_labels.value_counts().to_dict()}")
    print(f"  CONFLICTS with the pair label: {len(conflicts)}  -> send each to your supervisor; "
          f"never change a label yourself to remove a conflict")
    for r in conflicts.itertuples():
        extra = f" | not met: {r.not_met_rules[:160]}" if r.not_met_rules else ""
        print(f"    pair {r.pair_idx} ({r.trial_id}, {r.split}) labelled {r.pair_label}, "
              f"your rule answers say {r.decision_from_labels}{extra}")
    return {"n_pairs": int(len(df)), "conflicts": int(len(conflicts)),
            "decisions": df.decision_from_labels.value_counts().to_dict(),
            "conflict_pairs": [int(x) for x in conflicts.pair_idx]}


# ----------------------------------------------------------------------------- evidence
def _tokens(text: str) -> set[str]:
    return set(re.findall(r"[a-z0-9]+", str(text).lower()))


def run_evidence(corpus_path: str, pred_path: str, gold_path: str | None, split: str | None,
                 notes: dict[int, str] | None = None) -> dict:
    """exact_substring_rate: share of quoted spans found verbatim (whitespace-normalised) in the note.
    gold_overlap_rate: on labelled answers with an evidence span, the share where the system quotes
    at least one span covering >= 50% of the words of one of your spans."""
    norm = lambda s: re.sub(r"\s+", " ", str(s)).strip()
    if notes is None:
        corpus = pd.read_csv(corpus_path)
        notes = dict(zip(corpus.pair_idx.astype(int), corpus.patient_orig))
    pred = read_records(pred_path)
    if "evidence" not in pred.columns:
        raise ValueError("predictions have no 'evidence' field")
    spans = exact = with_ev = 0
    for r in pred.itertuples():
        ev = r.evidence if isinstance(r.evidence, list) else []
        with_ev += int(bool(ev))
        note = norm(notes[int(r.pair_idx)])
        for e in ev:
            if norm(e):
                spans += 1
                exact += int(norm(e) in note)
    out = {"unit": "quoted evidence span", "records": len(pred), "records_with_evidence": with_ev,
           "spans": spans, "exact_substring": exact, "exact_substring_rate": exact / spans if spans else float("nan")}
    if gold_path:
        gold = read_gold(gold_path, split)
        gold = gold[gold["evidence_span"].fillna("").astype(str).str.strip() != ""]
        look = {(int(r.pair_idx), int(r.crit_idx)): (r.evidence if isinstance(r.evidence, list) else [])
                for r in pred.itertuples()}
        hit = 0
        for g in gold.itertuples():
            gspans = [s for s in str(g.evidence_span).split("||") if s.strip()]
            sys_spans = look.get((int(g.pair_idx), int(g.crit_idx)), [])
            hit += int(any(len(_tokens(gs)) and len(_tokens(gs) & _tokens(ss)) / len(_tokens(gs)) >= 0.5
                           for gs in gspans for ss in sys_spans))
        out.update({"labelled_answers_with_span": len(gold), "overlap_hits": hit,
                    "gold_overlap_rate": hit / len(gold) if len(gold) else float("nan")})
    print(f"\nEVIDENCE  (unit = quoted evidence span)")
    print(f"  records {out['records']} | with evidence {with_ev} | spans {spans} | "
          f"found verbatim in the note {exact} -> {fmt(out['exact_substring_rate'])}")
    if gold_path:
        print(f"  your labelled answers with a span: {out['labelled_answers_with_span']} | system quote covers "
              f">=50% of your span: {out['overlap_hits']} -> {fmt(out['gold_overlap_rate'])}")
    return out


# ----------------------------------------------------------------------------- verification
def run_verification(gold_path: str, pred_path: str, verif_path: str, split: str | None,
                     support_path: str | None) -> dict:
    """correct = system truth == your label (rule answer). flagged = checker label != VERIFIED.
    Every labelled answer must have a prediction AND a checker result - missing rows raise an error."""
    gold = read_gold(gold_path, split)[["pair_idx", "crit_idx", "gtruth"]]
    pred = read_records(pred_path)[["pair_idx", "crit_idx", "truth"]]
    ver = pd.DataFrame(read_jsonl(verif_path))
    if ver.duplicated(["pair_idx", "crit_idx"]).any():
        raise ValueError("checker file has duplicate (pair_idx, crit_idx) rows")
    bad = sorted(set(ver["label"]) - set(VERIFICATION_LABELS))
    if bad:
        raise ValueError(f"unknown checker labels: {bad}")
    m = gold.merge(pred, on=["pair_idx", "crit_idx"], how="left").merge(
        ver[["pair_idx", "crit_idx", "label"]], on=["pair_idx", "crit_idx"], how="left")
    miss_pred, miss_ver = int(m["truth"].isna().sum()), int(m["label"].isna().sum())
    if miss_pred or miss_ver:
        raise ValueError(f"{miss_pred} labelled answers lack a prediction and {miss_ver} lack a checker result")
    m["correct"] = m["truth"].map(norm_truth) == m["gtruth"]
    m["flagged"] = m["label"] != "VERIFIED"
    n, inc, fl = len(m), int((~m.correct).sum()), int(m.flagged.sum())
    tp = int((m.flagged & ~m.correct).sum())
    prec = tp / fl if fl else float("nan")
    rec = tp / inc if inc else float("nan")
    ok = m[~m.flagged]
    out = {"unit": "rule answer", "split": split or "all", "n": n, "wrong_answers": inc, "flagged": fl,
           "flag_precision_wrong_given_flagged": prec, "flag_recall_flagged_given_wrong": rec,
           "flag_f1": 2 * prec * rec / (prec + rec) if tp else 0.0,
           "verified_share": len(ok) / n if n else float("nan"),
           "accuracy_of_verified": float(ok.correct.mean()) if len(ok) else float("nan"),
           "accuracy_of_flagged": float(m[m.flagged].correct.mean()) if fl else float("nan"),
           "accuracy_all": float(m.correct.mean()),
           "per_label": {lab: {"count": int((m.label == lab).sum()),
                               "share_wrong": float((~m[m.label == lab].correct).mean()) if (m.label == lab).any()
                               else float("nan")} for lab in VERIFICATION_LABELS}}
    print(f"\nCHECKER QUALITY  (unit = rule answer, split = {out['split']}, n = {n}, wrong answers = {inc})")
    print(f"  flagged {fl} | precision {fmt(prec)} | recall {fmt(rec)} | F1 {fmt(out['flag_f1'])}")
    print(f"  accuracy: all {fmt(out['accuracy_all'])} | VERIFIED {fmt(out['accuracy_of_verified'])} "
          f"(share {fmt(out['verified_share'])}) | flagged {fmt(out['accuracy_of_flagged'])}")
    for lab, v in out["per_label"].items():
        if v["count"]:
            print(f"    {lab:<22} {v['count']:>5}  share wrong {fmt(v['share_wrong'])}")
    if support_path:
        sup = pd.read_csv(support_path, encoding="utf-8-sig")
        j = sup.merge(ver[["pair_idx", "crit_idx", "label"]], on=["pair_idx", "crit_idx"], how="inner")
        j = j[j["support_label"].isin(VERIFICATION_LABELS)]
        out["human_vs_checker"] = cohen_kappa(j["support_label"].tolist(), j["label"].tolist())
        out["human_vs_checker_flag_only"] = cohen_kappa((j["support_label"] != "VERIFIED").map(str).tolist(),
                                                        (j["label"] != "VERIFIED").map(str).tolist())
        h, hb = out["human_vs_checker"], out["human_vs_checker_flag_only"]
        print(f"  your labels vs checker: n={h['n']} | 7-label kappa {fmt(h['kappa'])} | "
              f"flag/no-flag kappa {fmt(hb['kappa'])}")
    return out


# ----------------------------------------------------------------------------- targeting
def run_targeting(corpus_path: str, pred_path: str, order_path: str, budgets: list[int], split: str | None,
                  gold_path: str | None = None, criteria_path: str = str(DEFAULT_CRITERIA),
                  splits_path: str = str(DEFAULT_SPLITS)) -> dict:
    """Simulate a person checking rule answers in the order given, and count rescued eligible pairs.

    A checked answer is replaced by:
      1. your label, if you labelled that answer (gold file), otherwise
      2. for an ELIGIBLE pair whose answer is 'not met': 'not stated' - the person removes a
         rejection reason the note does not support (this assumes the pair's label is right), otherwise
      3. nothing changes (the right answer is not known) - counted as 'checks with unknown effect'.
    """
    check_not_incomplete(pred_path)
    corpus = filter_corpus(pd.read_csv(corpus_path), split, splits_path)
    in_split = set(corpus.pair_idx.astype(int))
    criteria = load_criteria(criteria_path)
    kinds = {(int(r.pair_idx), c["crit_idx"]): c["kind"] for r in corpus.itertuples() for c in criteria[r.trial_id]}
    label = dict(zip(corpus.pair_idx.astype(int), (corpus.target.str.strip() == "Eligible").astype(int)))
    pred = read_records(pred_path)
    pred = pred[pred.pair_idx.astype(int).isin(in_split)]
    base = {(int(r.pair_idx), int(r.crit_idx)): r.truth for r in pred.itertuples()}
    order = pd.read_csv(order_path)
    if not {"pair_idx", "crit_idx"}.issubset(order.columns):
        raise ValueError("the order file needs columns pair_idx, crit_idx (one row per check, best first)")
    if order.duplicated(["pair_idx", "crit_idx"]).any():
        raise ValueError("the order file lists the same rule answer twice")
    order = order[order.pair_idx.astype(int).isin(in_split)]
    unknown_cells = [(int(p), int(c)) for p, c in zip(order.pair_idx, order.crit_idx) if (int(p), int(c)) not in kinds]
    if unknown_cells:
        raise ValueError(f"order file refers to rule answers that do not exist, e.g. {unknown_cells[:3]}")
    gold = {}
    if gold_path:
        g = read_gold(gold_path, None)
        gold = {(int(r.pair_idx), int(r.crit_idx)): r.gtruth for r in g.itertuples()}
    df0, missing = pair_decisions(corpus, criteria, base)
    base_fx = int(((df0.gold == 1) & (df0.decision == "NOT_ELIGIBLE")).sum())
    results = []
    for k in [0] + sorted(set(budgets)):
        truths = dict(base)
        src = Counter()
        changed = 0
        for p, c in list(zip(order.pair_idx.astype(int), order.crit_idx.astype(int)))[:k]:
            old = norm_truth(truths.get((p, c), "unknown")) or "unknown"
            if (p, c) in gold:
                new, how = gold[(p, c)], "your_label"
            elif label[p] == 1 and map_truth(old, kinds[(p, c)]) == "not_met":
                new, how = "unknown", "label_implied"
            else:
                new, how = old, "unknown_effect"
            src[how] += 1
            changed += int(new != old)
            truths[(p, c)] = new
        df, _ = pair_decisions(corpus, criteria, truths)
        fx = int(((df.gold == 1) & (df.decision == "NOT_ELIGIBLE")).sum())
        results.append({"checks": min(k, len(order)), "wrongly_excluded_remaining": fx,
                        "rescued": base_fx - fx, "answers_changed": changed,
                        "checks_with_your_label": src["your_label"], "checks_label_implied": src["label_implied"],
                        "checks_with_unknown_effect": src["unknown_effect"],
                        "wrongly_included": int(((df.gold == 0) & (df.decision == "ELIGIBLE")).sum()),
                        "review": int((df.decision == "REVIEW").sum())})
    out = {"unit": "patient-trial pair", "split": split or "all", "pairs": len(df0),
           "eligible_pairs": int((df0.gold == 1).sum()), "checks_available": len(order),
           "missing_rule_answers_scored_unknown": missing, "results": results}
    print(f"\nTARGETED CHECKING  (unit = patient-trial pair, split = {out['split']}, pairs = {out['pairs']}, "
          f"eligible = {out['eligible_pairs']}, checks in order file = {len(order)})")
    print(f"  {'checks':>6} {'wrongly excl.':>13} {'rescued':>8} {'changed':>8} {'unknown effect':>15} "
          f"{'wrongly incl.':>13} {'review':>7}")
    for r in results:
        print(f"  {r['checks']:>6} {r['wrongly_excluded_remaining']:>13} {r['rescued']:>8} {r['answers_changed']:>8} "
              f"{r['checks_with_unknown_effect']:>15} {r['wrongly_included']:>13} {r['review']:>7}")
    print("  (rescues on unlabelled pairs assume the pair's Eligible label is right)")
    return out


# ----------------------------------------------------------------------------- questions
def _is_true(x) -> bool:
    return isinstance(x, bool) and x or type(x).__name__ == "bool_" and bool(x)


def run_questions(log_path: str, corpus_path: str) -> dict:
    """Question log format (templates/question_record.schema.json), one JSON per line:
      step 0 : the decision before any question    {"strategy","case_idx","pair_idx","step":0,"decision_after",
                                                   "full_info_decision"}
      step n : after the n-th question             {"strategy","case_idx","pair_idx","step":n,"crit_idx",
                                                   "answered": true/false,"decision_after"}
    """
    log = pd.DataFrame(read_jsonl(log_path))
    need = {"strategy", "case_idx", "pair_idx", "step", "decision_after"}
    if log.empty or not need.issubset(log.columns):
        raise ValueError(f"question log needs columns {sorted(need)}")
    if log.duplicated(["strategy", "case_idx", "step"]).any():
        raise ValueError("the log has the same (strategy, case_idx, step) twice")
    corpus = pd.read_csv(corpus_path)
    label = dict(zip(corpus.pair_idx.astype(int), (corpus.target.str.strip() == "Eligible").astype(int)))
    out = {"unit": "test case", "strategies": {}}
    print(f"\nQUESTION ASKING  (unit = test case)")
    for strat, g in log.groupby("strategy"):
        cases = []
        for cid, c in g.groupby("case_idx"):
            c = c.sort_values("step")
            if int(c.step.iloc[0]) != 0:
                raise ValueError(f"strategy {strat}, case {cid}: the log must start with step 0")
            steps = int(c.step.max())
            final = c.decision_after.iloc[-1]
            first_settled = c[c.decision_after != "REVIEW"].step
            full = c.iloc[0].get("full_info_decision") if "full_info_decision" in c.columns else None
            answered = sum(1 for x in c.iloc[1:].get("answered", pd.Series(dtype=object)) if _is_true(x))
            cases.append({"case_idx": int(cid), "eligible": label[int(c.pair_idx.iloc[0])], "questions": steps,
                          "answered": answered, "final": final,
                          "questions_to_settle": int(first_settled.iloc[0]) if len(first_settled) else None,
                          "matches_full_info": (final == full) if isinstance(full, str) else None})
        d = pd.DataFrame(cases)
        el = d[d.eligible == 1]
        settled = d[d.questions_to_settle.notna()]
        s = {"cases": len(d), "questions_mean": float(d.questions.mean()), "questions_total": int(d.questions.sum()),
             "answered_total": int(d.answered.sum()),
             "settled_share": len(settled) / len(d),
             "questions_to_settle_mean": float(settled.questions_to_settle.mean()) if len(settled) else float("nan"),
             "wrongly_excluded": int((el.final == "NOT_ELIGIBLE").sum()), "eligible_cases": len(el),
             "wrongly_included": int(((d.eligible == 0) & (d.final == "ELIGIBLE")).sum()),
             "still_review": int((d.final == "REVIEW").sum()),
             "matches_full_info_share": float(d.matches_full_info.dropna().astype(bool).mean())
             if d.matches_full_info.notna().any() else float("nan")}
        out["strategies"][strat] = s
        print(f"  {strat}: cases {s['cases']} | questions {s['questions_total']} (mean {fmt(s['questions_mean'])}, "
              f"answered {s['answered_total']}) | settled {fmt(s['settled_share'])} after mean "
              f"{fmt(s['questions_to_settle_mean'])} | wrongly excluded {s['wrongly_excluded']}/{s['eligible_cases']} | "
              f"wrongly included {s['wrongly_included']} | still review {s['still_review']} | "
              f"same as full note {fmt(s['matches_full_info_share'])}")
    return out


# ----------------------------------------------------------------------------- main
def main() -> None:
    if hasattr(sys.stdout, "reconfigure"):          # Windows consoles: print symbols such as >= safely
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="mode", required=True)
    p = sub.add_parser("pairs")
    p.add_argument("--pred", required=True); p.add_argument("--split", choices=["dev", "test"])
    p.add_argument("--pairs-filter", help="CSV with a pair_idx column: score only these pairs")
    p.add_argument("--target-rate", type=float, action="append", help="re-weight to this eligible share")
    p.add_argument("--cluster-col", choices=["trial_id", "patient_id"], default="trial_id",
                   help="per-cluster breakdown: trial_id (lung-cancer set) or patient_id (SIGIR)")
    c = sub.add_parser("criterion")
    c.add_argument("--gold", required=True); c.add_argument("--pred", required=True)
    c.add_argument("--split", choices=["dev", "test"])
    k = sub.add_parser("kappa")
    k.add_argument("--a", required=True); k.add_argument("--b", required=True)
    k.add_argument("--disagreements"); k.add_argument("--overlap-only", action="store_true")
    lc = sub.add_parser("labelcheck")
    lc.add_argument("--gold", required=True); lc.add_argument("--out")
    e = sub.add_parser("evidence")
    e.add_argument("--pred", required=True); e.add_argument("--gold"); e.add_argument("--split", choices=["dev", "test"])
    e.add_argument("--cases", help="JSONL of altered notes {case_idx, note}: check quotes against these notes")
    v = sub.add_parser("verification")
    v.add_argument("--gold", required=True); v.add_argument("--pred", required=True)
    v.add_argument("--verif", required=True); v.add_argument("--split", choices=["dev", "test"])
    v.add_argument("--support", help="optional CSV of your own checker-style labels: pair_idx, crit_idx, support_label")
    t = sub.add_parser("targeting")
    t.add_argument("--pred", required=True); t.add_argument("--order", required=True)
    t.add_argument("--budgets", default="5,10,20,50"); t.add_argument("--split", choices=["dev", "test"])
    t.add_argument("--gold")
    q = sub.add_parser("questions")
    q.add_argument("--log", required=True)
    for s in (p, c, k, lc, e, v, t, q):
        s.add_argument("--json", help="also write the full result to this JSON file")
        s.add_argument("--corpus", default=str(DEFAULT_CORPUS))
    for s in (p, t):
        s.add_argument("--criteria", default=str(DEFAULT_CRITERIA))
        s.add_argument("--splits", default=str(DEFAULT_SPLITS))
    a = ap.parse_args()
    if a.mode == "pairs":
        res = run_pairs(a.corpus, a.pred, a.pairs_filter, a.split, a.criteria, a.splits, a.target_rate,
                        a.cluster_col)
    elif a.mode == "criterion":
        res = run_criterion(a.gold, a.pred, a.split)
    elif a.mode == "kappa":
        res = run_kappa(a.a, a.b, a.disagreements, a.overlap_only)
    elif a.mode == "labelcheck":
        res = run_labelcheck(a.gold, a.corpus, a.out)
    elif a.mode == "evidence":
        notes = None
        if a.cases:
            notes = {int(x["case_idx"]): x["note"] for x in read_jsonl(a.cases)}
        res = run_evidence(a.corpus, a.pred, a.gold, a.split, notes)
    elif a.mode == "verification":
        res = run_verification(a.gold, a.pred, a.verif, a.split, a.support)
    elif a.mode == "targeting":
        res = run_targeting(a.corpus, a.pred, a.order, [int(x) for x in a.budgets.split(",")], a.split,
                            a.gold, a.criteria, a.splits)
    else:
        res = run_questions(a.log, a.corpus)
    if a.json:
        json.dump(res, open(a.json, "w", encoding="utf-8"), indent=2, default=str)


if __name__ == "__main__":
    main()
