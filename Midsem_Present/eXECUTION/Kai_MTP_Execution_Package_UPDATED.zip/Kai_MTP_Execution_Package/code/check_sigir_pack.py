"""check_sigir_pack.py - run this after unzipping the SIGIR pack into your kit.

    python check_sigir_pack.py

It checks the SIGIR files, the patient split, your SIGIR label sheet, and that the provided code
works on SIGIR (with a mock model - nothing is sent anywhere). The last line must be
'9 passed, 0 failed'.
"""
from __future__ import annotations
import contextlib
import io
import json
import subprocess
import sys
import tempfile
from pathlib import Path

import pandas as pd

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(HERE))
import evaluate as E  # noqa: E402
from criteria import load_criteria, load_splits, map_truth  # noqa: E402

S = ROOT / "datasets" / "sigir204"
CORPUS, CRITERIA, SPLITS, PATIENTS = S / "sigir204.csv", S / "criteria.csv", S / "splits.csv", S / "patients.csv"
SHEET = ROOT / "labelling" / "sigir_label_sheet.csv"
passed = failed = 0


def check(name: str, ok: bool, detail: str = "") -> None:
    global passed, failed
    passed, failed = passed + bool(ok), failed + (not ok)
    print(f"  {'PASS' if ok else 'FAIL'}  {name}  {'' if ok else detail}")


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    print("\nSIGIR pack")
    corpus = pd.read_csv(CORPUS)
    criteria = load_criteria(CRITERIA)
    splits = load_splits(SPLITS)
    pats = pd.read_csv(PATIENTS)
    check("sigir204.csv: 204 pairs, 14 patients, 204 trials, 100 Eligible",
          len(corpus) == 204 and corpus.patient_id.nunique() == 14 and corpus.trial_id.nunique() == 204
          and int((corpus.target == "Eligible").sum()) == 100)
    n_rules = sum(len(v) for v in criteria.values())
    check("criteria.csv: 1,911 reviewed rules, every trial has at least one inclusion rule",
          n_rules == 1911 and set(criteria) == set(corpus.trial_id)
          and all(any(r["kind"] == "inclusion" for r in v) for v in criteria.values()), f"got {n_rules}")
    check("n_rules column matches criteria.csv (for the count-the-rules baseline)",
          all(corpus.n_rules[i] == len(criteria[t]) for i, t in enumerate(corpus.trial_id)))
    by_patient = corpus.assign(split=corpus.trial_id.map(splits)).groupby("patient_id").split.nunique()
    check("split by patient: 7 dev + 7 test patients, 102 pairs each, no patient in both halves",
          (by_patient == 1).all() and sorted(pats.split.value_counts().tolist()) == [7, 7]
          and corpus.trial_id.map(splits).value_counts().to_dict() == {"dev": 102, "test": 102})
    if SHEET.exists():
        sh = pd.read_csv(SHEET, encoding="utf-8-sig")
        pairs = sh.pair_idx.unique()
        lab = corpus.set_index("pair_idx").target
        exp = int(corpus.set_index("pair_idx").loc[pairs, "n_rules"].sum())
        check("your SIGIR label sheet: 20 pairs (10 Eligible, 10 dev), one row per rule, no label column",
              len(pairs) == 20 and len(sh) == exp and int((lab.loc[pairs] == "Eligible").sum()) == 10
              and int(sh.drop_duplicates("pair_idx").split.eq("dev").sum()) == 10 and "target" not in sh.columns,
              f"{len(pairs)} pairs, {len(sh)} rows (expected {exp})")
        check("every row of the sheet matches criteria.csv",
              all(criteria[t][c]["criterion_text"] == txt
                  for t, c, txt in zip(sh.trial_id, sh.crit_idx, sh.criterion_text)))
    else:
        check("labelling/sigir_label_sheet.csv exists", False, "file missing")
        check("(skipped: no sheet)", False)

    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        out = tmp / "mock.jsonl"
        pairs = corpus[corpus.patient_id == corpus.patient_id.iloc[0]].pair_idx.head(2).tolist()
        cmd = [sys.executable, str(HERE / "plain_ai.py"), "--model", "mock", "--backend", "mock",
               "--dataset", "sigir204", "--corpus", str(CORPUS), "--criteria", str(CRITERIA),
               "--splits", str(SPLITS), "--pairs", ",".join(map(str, pairs)), "--out", str(out),
               "--cache-dir", str(tmp / "cache")]
        proc = subprocess.run(cmd, capture_output=True, text=True)
        recs = [json.loads(l) for l in out.read_text(encoding="utf-8").splitlines()] if out.exists() else []
        exp = sum(len(criteria[t]) for t in corpus.set_index("pair_idx").loc[pairs, "trial_id"])
        check("plain_ai.py runs on SIGIR (mock model) and writes one record per rule",
              proc.returncode == 0 and len(recs) == exp and all(r["dataset"] == "sigir204" for r in recs),
              proc.stderr[-300:])
        rows = []
        for r in corpus.itertuples():
            for c in criteria[r.trial_id]:
                t = "yes" if c["kind"] == "inclusion" else "no"
                rows.append({"system": "s", "pair_idx": int(r.pair_idx), "crit_idx": c["crit_idx"],
                             "kind": c["kind"], "truth": t, "verdict": map_truth(t, c["kind"])})
        allpass = tmp / "allpass.jsonl"
        allpass.write_text("".join(json.dumps(x) + "\n" for x in rows), encoding="utf-8")
        with contextlib.redirect_stdout(io.StringIO()):
            res = E.run_pairs(str(CORPUS), str(allpass), None, "dev", str(CRITERIA), str(SPLITS), None, "patient_id")
        check("pair scoring on SIGIR with a per-patient breakdown (dev: 102 pairs, 7 patients)",
              res["n_pairs"] == 102 and len(res["per_cluster"]) == 7 and res["cluster_by"] == "patient_id")
        check("'everyone passes' on SIGIR dev: no wrongful exclusions, all ineligible pairs wrongly included",
              res["false_exclusions_count"] == 0 and res["false_inclusions_count"] == res["ineligible_pairs_count"])
    print(f"\n{passed} passed, {failed} failed")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
