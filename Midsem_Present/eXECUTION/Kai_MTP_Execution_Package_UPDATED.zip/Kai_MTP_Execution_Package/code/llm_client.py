"""llm_client.py - one safe way to ask a LOCAL model (Ollama) a question and get JSON back.

Use it for every model call in your project, so that all calls follow the same rules:

  * temperature 0 and a fixed seed, JSON output only
  * the FULL prompt is sent - nothing is ever cut to fit. If a prompt looks too long for the
    context window, the call is refused (raise num_ctx) instead of being silently shortened
  * every answer is cached under the SHA-256 of (model + full system prompt + full user prompt +
    options). Never cache on a shortened key: two patients would silently share one answer
  * the model answered but not with valid JSON -> ask again with a reminder (up to parse_retries);
    still invalid -> returned with ok = False. You keep the row and count it
  * the CALL itself failed (server down, timeout) -> retried with waits; still failing ->
    CallFailed is raised. An API failure is NEVER an answer and never becomes "unknown"

Example
    from llm_client import LocalLLM
    llm = LocalLLM("qwen2.5:7b", cache_dir="../outputs/cache")
    r = llm.chat_json(system="Return JSON only: {\"x\": 1}", user="hello", prompt_id="DEMO_v1")
    r["ok"], r["data"], r["raw"]

Ollama: https://github.com/ollama/ollama  (install, then `ollama pull qwen2.5:7b`). The server
listens on http://localhost:11434 and no data leaves your computer.
"""
from __future__ import annotations
import hashlib
import json
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Callable

JSON_REMINDER = ("\n\nYour previous reply was not valid JSON in the required format. "
                 "Reply again with the JSON object only, nothing else.")


class CallFailed(RuntimeError):
    """The model could not be reached or refused the request. Mark the run INCOMPLETE."""


def prompt_key(model: str, system: str, user: str, options: dict) -> str:
    blob = json.dumps([model, system, user, options], sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def parse_json_object(text: str) -> dict | None:
    """The reply must be one JSON object (a fenced ```json block is tolerated)."""
    t = (text or "").strip()
    if t.startswith("```"):
        t = t.strip("`")
        if t.lower().startswith("json"):
            t = t[4:]
    try:
        obj = json.loads(t)
    except (json.JSONDecodeError, TypeError):
        return None
    return obj if isinstance(obj, dict) else None


class LocalLLM:
    def __init__(self, model: str, cache_dir: str | Path | None = None,
                 host: str = "http://localhost:11434", num_ctx: int = 8192, max_output: int = 400,
                 timeout: int = 600, call_retries: int = 4, parse_retries: int = 2,
                 backend: str = "ollama", mock: Callable[[str, str], str] | None = None):
        if backend not in ("ollama", "mock"):
            raise ValueError("backend must be 'ollama' or 'mock'")
        if backend == "mock" and mock is None:
            raise ValueError("the mock backend needs a mock(system, user) -> str function")
        self.model, self.host, self.backend, self.mock = model, host.rstrip("/"), backend, mock
        self.num_ctx, self.max_output, self.timeout = num_ctx, max_output, timeout
        self.call_retries, self.parse_retries = call_retries, parse_retries
        self.options = {"temperature": 0, "seed": 0, "num_ctx": num_ctx, "num_predict": max_output}
        self.cache: dict[str, dict] = {}
        self.cache_file = None
        if cache_dir:
            d = Path(cache_dir)
            d.mkdir(parents=True, exist_ok=True)
            safe = "".join(ch if ch.isalnum() or ch in "._-" else "-" for ch in model)
            self.cache_file = d / f"cache_{safe}.jsonl"
            if self.cache_file.exists():
                for line in self.cache_file.read_text(encoding="utf-8").splitlines():
                    if line.strip():
                        row = json.loads(line)
                        self.cache[row["key"]] = row
        self.stats = {"calls": 0, "cache_hits": 0, "parse_failures": 0}

    # ------------------------------------------------------------------ transport
    def check_model_available(self) -> None:
        if self.backend == "mock":
            return
        try:
            with urllib.request.urlopen(f"{self.host}/api/tags", timeout=10) as r:
                names = {m["name"] for m in json.load(r).get("models", [])}
        except (urllib.error.URLError, TimeoutError, OSError) as e:
            raise CallFailed(f"cannot reach Ollama at {self.host} ({e}). Is it running?") from e
        if self.model not in names:
            raise CallFailed(f"model {self.model!r} is not installed. Run: ollama pull {self.model}  "
                             f"(installed: {sorted(names)})")

    def _send(self, system: str, user: str) -> dict:
        if self.backend == "mock":
            return {"raw": self.mock(system, user), "prompt_tokens": None, "done_reason": "stop"}
        body = json.dumps({"model": self.model, "stream": False, "format": "json", "options": self.options,
                           "messages": [{"role": "system", "content": system},
                                        {"role": "user", "content": user}]}).encode("utf-8")
        last = None
        for attempt in range(self.call_retries + 1):
            try:
                req = urllib.request.Request(f"{self.host}/api/chat", data=body,
                                             headers={"Content-Type": "application/json"})
                with urllib.request.urlopen(req, timeout=self.timeout) as r:
                    out = json.load(r)
                return {"raw": out.get("message", {}).get("content", ""),
                        "prompt_tokens": out.get("prompt_eval_count"), "done_reason": out.get("done_reason")}
            except (urllib.error.URLError, TimeoutError, OSError, json.JSONDecodeError) as e:
                last = e
                if attempt < self.call_retries:
                    time.sleep(2 ** (attempt + 1))
        raise CallFailed(f"model call failed after {self.call_retries + 1} attempts: {last}")

    # ------------------------------------------------------------------ public
    def chat_json(self, system: str, user: str, prompt_id: str = "") -> dict:
        """Returns {ok, data, raw, attempts, cache_hit, prompt_sha256, prompt_id}."""
        est_tokens = (len(system) + len(user)) / 3          # generous estimate: ~3 characters per token
        if est_tokens > self.num_ctx - self.max_output:
            raise CallFailed(f"prompt of ~{int(est_tokens)} tokens may not fit num_ctx={self.num_ctx}; "
                             f"raise num_ctx instead of cutting the text")
        first_key = prompt_key(self.model, system, user, self.options)
        attempts, cache_hit_any, raw = 0, False, ""
        for n in range(self.parse_retries + 1):
            u = user + (JSON_REMINDER if n else "")
            key = prompt_key(self.model, system, u, self.options)
            if key in self.cache:
                hit, cache_hit_any = self.cache[key], True
                self.stats["cache_hits"] += 1
            else:
                hit = self._send(system, u)
                self.stats["calls"] += 1
                hit = {"key": key, "raw": hit["raw"], "prompt_tokens": hit["prompt_tokens"],
                       "done_reason": hit["done_reason"], "prompt_id": prompt_id}
                self.cache[key] = hit
                if self.cache_file:
                    with open(self.cache_file, "a", encoding="utf-8") as f:
                        f.write(json.dumps(hit, ensure_ascii=False) + "\n")
            attempts += 1
            raw = hit["raw"]
            data = parse_json_object(raw) if hit.get("done_reason") != "length" else None
            if data is not None:
                return {"ok": True, "data": data, "raw": raw, "attempts": attempts,
                        "cache_hit": cache_hit_any, "prompt_sha256": first_key, "prompt_id": prompt_id}
        self.stats["parse_failures"] += 1
        return {"ok": False, "data": None, "raw": raw, "attempts": attempts,
                "cache_hit": cache_hit_any, "prompt_sha256": first_key, "prompt_id": prompt_id}


if __name__ == "__main__":
    replies = iter(["not json", '{"answer": 1}'])
    llm = LocalLLM("demo", backend="mock", mock=lambda s, u: next(replies))
    r = llm.chat_json("sys", "user")
    assert r["ok"] and r["data"] == {"answer": 1} and r["attempts"] == 2
    print("llm_client.py self-test passed (mock backend; no model called)")
