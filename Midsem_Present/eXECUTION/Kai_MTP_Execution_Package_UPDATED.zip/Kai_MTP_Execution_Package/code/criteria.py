"""criteria.py - the reviewed trial rules, the inclusion/exclusion logic, and the
"what could change the decision" tool.

Rules come from datasets/nsclc100/criteria.csv: one row per rule of each trial, reviewed by hand.
Do NOT re-split the raw inc_orig / exc_orig text yourself. An automatic splitter was tried and it
broke 6 of the 20 rule lists: it turned exception lists into exclusions, merged real exclusions
together, and dropped a rule. See datasets/nsclc100/CRITERIA_REVIEW.md.

Vocabulary
  truth    : is the condition written in the rule TRUE for this patient?   yes | no | unknown
  verdict  : the rule's outcome after inclusion/exclusion logic            met | not_met | not_stated
  decision : for the whole patient-trial pair                              ELIGIBLE | NOT_ELIGIBLE | REVIEW

Inclusion/exclusion logic is applied here, in code, and nowhere else (never in a prompt):
  inclusion + yes -> met        inclusion + no -> not_met
  exclusion + yes -> not_met    exclusion + no -> met
  anything  + unknown -> not_stated

Decision
  any rule not_met                -> NOT_ELIGIBLE
  every rule met                  -> ELIGIBLE
  otherwise (some rule not_stated) -> REVIEW
"""
from __future__ import annotations
import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_CRITERIA = ROOT / "datasets" / "nsclc100" / "criteria.csv"
DEFAULT_SPLITS = ROOT / "datasets" / "nsclc100" / "splits.csv"
TRUTHS = ("yes", "no", "unknown")
VERDICTS = ("met", "not_met", "not_stated")


def load_criteria(path: str | Path = DEFAULT_CRITERIA) -> dict[str, list[dict]]:
    """trial_id -> rules in crit_idx order: [{crit_idx, kind, criterion_text, note}, ...]"""
    by_trial: dict[str, list[dict]] = {}
    with open(path, encoding="utf-8", newline="") as f:
        for row in csv.DictReader(f):
            by_trial.setdefault(row["trial_id"], []).append(
                {"crit_idx": int(row["crit_idx"]), "kind": row["kind"],
                 "criterion_text": row["criterion_text"], "note": row.get("note", "") or ""})
    for t, rows in by_trial.items():
        rows.sort(key=lambda r: r["crit_idx"])
        if [r["crit_idx"] for r in rows] != list(range(len(rows))):
            raise ValueError(f"{path}: crit_idx for {t} is not 0..n-1")
        if any(r["kind"] not in ("inclusion", "exclusion") for r in rows):
            raise ValueError(f"{path}: bad kind for {t}")
    return by_trial


def load_splits(path: str | Path = DEFAULT_SPLITS) -> dict[str, str]:
    """trial_id -> 'dev' or 'test'. The split is by trial: never tune on a test trial."""
    with open(path, encoding="utf-8", newline="") as f:
        out = {row["trial_id"]: row["split"] for row in csv.DictReader(f)}
    if set(out.values()) - {"dev", "test"}:
        raise ValueError(f"{path}: split must be dev or test")
    return out


def map_truth(truth: str, kind: str) -> str:
    t = str(truth).strip().lower()
    if kind not in ("inclusion", "exclusion"):
        raise ValueError(f"kind must be inclusion or exclusion, got {kind!r}")
    if t not in ("yes", "no"):
        return "not_stated"
    if kind == "inclusion":
        return "met" if t == "yes" else "not_met"
    return "not_met" if t == "yes" else "met"


def decide(verdicts: list[str]) -> str:
    if any(v == "not_met" for v in verdicts):
        return "NOT_ELIGIBLE"
    if verdicts and all(v == "met" for v in verdicts):
        return "ELIGIBLE"
    return "REVIEW"


def decision_details(verdicts: list[str]) -> dict:
    """The decision plus the positions (= crit_idx) of failing, unknown and passing rules."""
    bad = [v for v in verdicts if v not in VERDICTS]
    if bad:
        raise ValueError(f"unknown verdict values: {sorted(set(bad))}")
    return {"decision": decide(verdicts),
            "failing": [i for i, v in enumerate(verdicts) if v == "not_met"],
            "unknown": [i for i, v in enumerate(verdicts) if v == "not_stated"],
            "passing": [i for i, v in enumerate(verdicts) if v == "met"]}


def what_could_change(verdicts: list[str]) -> list[dict]:
    """For every rule answer: what would the decision be if that ONE answer were different?

    met        -> tried as not_met
    not_met    -> tried as met
    not_stated -> tried as met AND as not_met (both reported)

    Returns one dict per rule, in crit_idx order:
      crit_idx        position of the rule
      verdict         the current answer
      decision_now    the current decision
      decision_if     {alternative verdict: decision}
      changes         True if any alternative gives a different decision
      sole_reason     True if this is the ONLY failing rule of a NOT_ELIGIBLE decision
                      (one wrong answer here is enough to turn a patient away wrongly)
    Only one answer is changed at a time.
    """
    details = decision_details(verdicts)
    now = details["decision"]
    sole = details["failing"][0] if len(details["failing"]) == 1 else None
    out = []
    for i, v in enumerate(verdicts):
        alts = {"met": ["not_met"], "not_met": ["met"], "not_stated": ["met", "not_met"]}[v]
        dec_if = {}
        for alt in alts:
            changed = list(verdicts)
            changed[i] = alt
            dec_if[alt] = decide(changed)
        out.append({"crit_idx": i, "verdict": v, "decision_now": now, "decision_if": dec_if,
                    "changes": any(d != now for d in dec_if.values()), "sole_reason": i == sole})
    return out


if __name__ == "__main__":
    assert map_truth("yes", "inclusion") == "met"
    assert map_truth("no", "inclusion") == "not_met"
    assert map_truth("yes", "exclusion") == "not_met"
    assert map_truth("no", "exclusion") == "met"
    assert map_truth("unknown", "exclusion") == "not_stated"
    assert decide(["met", "met"]) == "ELIGIBLE"
    assert decide(["met", "not_stated"]) == "REVIEW"
    assert decide(["met", "not_met", "not_stated"]) == "NOT_ELIGIBLE"
    w = what_could_change(["met", "not_met", "met"])
    assert w[1]["sole_reason"] and w[1]["changes"] and w[1]["decision_if"] == {"met": "ELIGIBLE"}
    w = what_could_change(["not_met", "not_met", "met"])
    assert not any(x["sole_reason"] for x in w) and not w[0]["changes"]
    c = load_criteria()
    n = sum(len(v) for v in c.values())
    s = load_splits()
    print(f"criteria.py self-test passed: {len(c)} trials, {n} reviewed rules, "
          f"dev trials {sorted(t for t in s if s[t] == 'dev')}")
