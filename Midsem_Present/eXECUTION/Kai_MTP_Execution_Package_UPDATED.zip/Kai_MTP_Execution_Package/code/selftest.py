"""selftest.py - run this first. It checks that your copy of the data and code is intact.

    python selftest.py

Every check builds small made-up inputs whose correct answers are known in advance, runs the real
functions on them, and compares. No model is called and nothing leaves your computer.
If anything prints FAIL, stop and fix your setup before doing anything else.
"""
from __future__ import annotations
import contextlib
import hashlib
import io
import json
import subprocess
import sys
import tempfile
from pathlib import Path

import pandas as pd

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(HERE))
import evaluate as E  # noqa: E402
from criteria import decide, load_criteria, load_splits, map_truth, what_could_change  # noqa: E402
from llm_client import LocalLLM  # noqa: E402
from stats_tools import holm, reweight, sign_test_p  # noqa: E402

CORPUS = ROOT / "datasets" / "nsclc100" / "nsclc100.csv"
CRITERIA = ROOT / "datasets" / "nsclc100" / "criteria.csv"
SPLITS = ROOT / "datasets" / "nsclc100" / "splits.csv"
SHEET = ROOT / "labelling" / "my_label_sheet.csv"
PRACTICE = ROOT / "labelling" / "practice_sheet.csv"
passed = failed = 0


def check(name: str, ok: bool, detail: str = "") -> None:
    global passed, failed
    if ok:
        passed += 1
        print(f"  PASS  {name}")
    else:
        failed += 1
        print(f"  FAIL  {name}  {detail}")


def quiet(fn, *args, **kw):
    with contextlib.redirect_stdout(io.StringIO()):
        return fn(*args, **kw)


def write_jsonl(path: Path, rows: list[dict]) -> None:
    path.write_text("".join(json.dumps(r) + "\n" for r in rows), encoding="utf-8")


def records_for(corpus: pd.DataFrame, criteria: dict, truth_fn, system: str = "selftest") -> list[dict]:
    rows = []
    for r in corpus.itertuples():
        for c in criteria[r.trial_id]:
            t = truth_fn(r, c)
            rows.append({"system": system, "dataset": "nsclc100", "pair_idx": int(r.pair_idx),
                         "crit_idx": c["crit_idx"], "kind": c["kind"], "criterion": c["criterion_text"],
                         "truth": t, "verdict": map_truth(t, c["kind"]),
                         "basis": "absent" if t == "unknown" else "stated", "evidence": [], "rationale": ""})
    return rows


def passes(c: dict) -> str:
    return "yes" if c["kind"] == "inclusion" else "no"


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):          # Windows consoles: print symbols such as >= safely
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    print("\n1. Data files")
    corpus = pd.read_csv(CORPUS)
    criteria = load_criteria(CRITERIA)
    splits = load_splits(SPLITS)
    check("lung-cancer set: 100 pairs, 10 trials x 10 patients, 5 Eligible per trial",
          len(corpus) == 100 and corpus.trial_id.nunique() == 10
          and all(len(g) == 10 and (g.target.str.strip() == "Eligible").sum() == 5
                  for _, g in corpus.groupby("trial_id")))
    n_rules = sum(len(v) for v in criteria.values())
    check("criteria.csv: 223 reviewed rules for the 10 trials",
          n_rules == 223 and set(criteria) == set(corpus.trial_id), f"got {n_rules}")
    cells = sum(len(criteria[t]) for t in corpus.trial_id)
    check("2,230 rule answers in total (sum over the 100 pairs)", cells == 2230, f"got {cells}")
    dev_trials = sorted(t for t, s in splits.items() if s == "dev")
    check("split by trial: dev = T01 T02 T03 T05 T09, test = the other 5",
          dev_trials == ["T01", "T02", "T03", "T05", "T09"] and len(splits) == 10)
    if SHEET.exists():
        sheet = pd.read_csv(SHEET, encoding="utf-8-sig")
        labels = corpus.set_index("pair_idx").target.str.strip()
        pairs = sheet.pair_idx.unique()
        check("your label sheet: 20 pairs (2 per trial, 10 Eligible + 10 Not Eligible), 446 rule answers "
              "(dev 190, test 256)",
              len(pairs) == 20 and len(sheet) == 446 and (sheet.split == "dev").sum() == 190
              and (sheet.split == "test").sum() == 256 and sheet.groupby("trial_id").pair_idx.nunique().eq(2).all()
              and (labels.loc[pairs] == "Eligible").sum() == 10,
              f"got {len(pairs)} pairs, {len(sheet)} rows")
        check("your label sheet has no Eligible/Not Eligible column (label from the note alone)",
              "target" not in sheet.columns)
    else:
        check("labelling/my_label_sheet.csv exists", False, "file missing")
    if PRACTICE.exists():
        pr = pd.read_csv(PRACTICE, encoding="utf-8-sig")
        check("practice sheet: pairs 0 and 2, 42 rule answers, not part of your label sheet",
              sorted(pr.pair_idx.unique()) == [0, 2] and len(pr) == 42
              and not (SHEET.exists() and set(pr.pair_idx) & set(pd.read_csv(SHEET, encoding="utf-8-sig").pair_idx)))

    print("\n2. Rule logic and the 'what could change the decision' tool")
    check("inclusion yes->met, no->not_met; exclusion yes->not_met, no->met; unknown->not_stated",
          [map_truth("yes", "inclusion"), map_truth("no", "inclusion"), map_truth("yes", "exclusion"),
           map_truth("no", "exclusion"), map_truth("unknown", "inclusion")]
          == ["met", "not_met", "not_met", "met", "not_stated"])
    check("decision: any not_met -> NOT_ELIGIBLE; all met -> ELIGIBLE; otherwise REVIEW",
          [decide(["met", "not_met"]), decide(["met", "met"]), decide(["met", "not_stated"])]
          == ["NOT_ELIGIBLE", "ELIGIBLE", "REVIEW"])
    w = what_could_change(["met", "not_met", "met"])
    check("a single failing rule is the sole reason: flipping it makes the pair ELIGIBLE, "
          "flipping a passing rule changes nothing",
          w[1]["sole_reason"] and w[1]["decision_if"] == {"met": "ELIGIBLE"} and not w[0]["changes"])
    w = what_could_change(["not_met", "not_met", "not_stated"])
    check("with two failing rules, no single answer changes the decision",
          not any(x["changes"] for x in w) and not any(x["sole_reason"] for x in w))
    w = what_could_change(["met", "not_stated", "not_stated"])
    check("in a REVIEW decision, an unknown rule could change it (to NOT_ELIGIBLE if it fails)",
          w[1]["changes"] and w[1]["decision_if"] == {"met": "REVIEW", "not_met": "NOT_ELIGIBLE"})

    print("\n3. Statistics helpers")
    r = reweight([1, 1, 0, 0], ["ELIGIBLE", "ELIGIBLE", "ELIGIBLE", "NOT_ELIGIBLE"], 0.1)
    check("re-weighting to 10% eligible: forwarded precision 0.4 / 2.2",
          abs(r["forwarded_precision"] - 0.4 / 2.2) < 1e-12 and r["false_exclusion_rate_unchanged"] == 0)
    check("exact sign test: 8 wins vs 2 losses -> p = 0.109375", abs(sign_test_p(8, 2) - 0.109375) < 1e-12)
    check("Holm correction on three p-values", holm({"a": 0.01, "b": 0.04, "c": 0.03}) == {"a": 0.03, "c": 0.06, "b": 0.06})

    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        C, K = str(CORPUS), str(CRITERIA)

        print("\n4. Pair-level scoring on made-up systems with known answers")
        write_jsonl(tmp / "unk.jsonl", records_for(corpus, criteria, lambda r, c: "unknown"))
        res = quiet(E.run_pairs, C, str(tmp / "unk.jsonl"), None, None, K)
        check("'always unknown': every pair REVIEW, 0/50 wrongly excluded, strict accuracy 0.5",
              res["decision_counts"] == {"REVIEW": 100} and res["false_exclusions_count"] == 0
              and res["accuracy_strict_REVIEW_as_not_eligible"] == 0.5)
        write_jsonl(tmp / "pass.jsonl", records_for(corpus, criteria, lambda r, c: passes(c)))
        res = quiet(E.run_pairs, C, str(tmp / "pass.jsonl"), None, None, K)
        check("'everyone passes': all ELIGIBLE, 0 wrongly excluded, 50/50 wrongly included",
              res["decision_counts"] == {"ELIGIBLE": 100} and res["false_inclusions_count"] == 50)
        one_fail = records_for(corpus, criteria, lambda r, c: "no" if c["crit_idx"] == 0 else passes(c))
        write_jsonl(tmp / "fail0.jsonl", one_fail)
        res = quiet(E.run_pairs, C, str(tmp / "fail0.jsonl"), None, "dev", K)
        check("'first rule fails', dev split: 50 pairs, 25/25 wrongly excluded, all by a single failing rule",
              res["n_pairs"] == 50 and res["false_exclusions_count"] == 25
              and res["wrongful_exclusions_with_a_single_failing_rule"] == 25)
        res = quiet(E.run_pairs, C, str(tmp / "pass.jsonl"), None, None, K, str(SPLITS), [0.1])
        check("re-weighting inside pair scoring: at 10% eligible, 'everyone passes' forwards 10% true matches",
              abs(res["reweighted"][0]["forwarded_precision"] - 0.1) < 1e-12)
        rows = records_for(corpus, criteria, lambda r, c: passes(c))
        write_jsonl(tmp / "missing.jsonl", rows[:-7])
        res = quiet(E.run_pairs, C, str(tmp / "missing.jsonl"), None, None, K)
        check("7 missing answers are counted and scored unknown, never dropped",
              res["missing_rule_answers_scored_unknown"] == 7 and res["decision_counts"].get("REVIEW") == 1)

        print("\n5. Agreement (Cohen's kappa)")
        base = pd.DataFrame({"pair_idx": [0] * 6, "crit_idx": range(6), "split": "dev", "kind": "inclusion",
                             "criterion_text": "x", "evidence_span": "", "basis": ""})
        a, b = base.copy(), base.copy()
        a["truth"] = ["yes", "yes", "no", "no", "unknown", "unknown"]
        b["truth"] = ["yes", "no", "no", "no", "unknown", "yes"]
        a.to_csv(tmp / "a.csv", index=False)
        b.to_csv(tmp / "b.csv", index=False)
        k = quiet(E.run_kappa, str(tmp / "a.csv"), str(tmp / "b.csv"), str(tmp / "dis.csv"))
        check("kappa = 0.5 on the worked example (agreement 4/6, chance 1/3)",
              abs(k["overall"]["kappa"] - 0.5) < 1e-9 and k["disagreements_written"] == 2)
        b2 = pd.concat([b.iloc[:4], base.iloc[:2].assign(pair_idx=9, truth="yes")])
        b2.to_csv(tmp / "b2.csv", index=False)
        k = quiet(E.run_kappa, str(tmp / "a.csv"), str(tmp / "b2.csv"), None, True)
        check("--overlap-only compares just the shared answers (4 here)", k["cells_compared"] == 4)

        print("\n6. Rule-level scoring")
        gold_rows = []
        for r in corpus.itertuples():
            for c in criteria[r.trial_id]:
                h = int(hashlib.md5(f"{r.pair_idx}-{c['crit_idx']}".encode()).hexdigest(), 16)
                gold_rows.append({"split": splits[r.trial_id], "pair_idx": r.pair_idx, "trial_id": r.trial_id,
                                  "crit_idx": c["crit_idx"], "kind": c["kind"], "criterion_text": c["criterion_text"],
                                  "truth": ["yes", "no", "unknown"][h % 3], "evidence_span": ""})
        gold = pd.DataFrame(gold_rows)
        gold.to_csv(tmp / "gold.csv", index=False)
        look = {(g.pair_idx, g.crit_idx): g.truth for g in gold.itertuples()}
        same = records_for(corpus, criteria, lambda r, c: look[(r.pair_idx, c["crit_idx"])])
        write_jsonl(tmp / "same.jsonl", same)
        res = quiet(E.run_criterion, str(tmp / "gold.csv"), str(tmp / "same.jsonl"), None)
        check("system identical to the labels: accuracy 1.0", res["truth"]["accuracy"] == 1.0)
        flipped = [dict(x) for x in same]
        for x in flipped[:10]:
            x["truth"] = {"yes": "no", "no": "unknown", "unknown": "yes"}[x["truth"]]
        write_jsonl(tmp / "flip.jsonl", flipped)
        res = quiet(E.run_criterion, str(tmp / "gold.csv"), str(tmp / "flip.jsonl"), None)
        n = res["truth"]["n"]
        check("10 wrong answers: accuracy exactly (n-10)/n", abs(res["truth"]["accuracy"] - (n - 10) / n) < 1e-12)

        print("\n7. Label check")
        g2 = gold.copy()
        elig = int(corpus[corpus.target.str.strip() == "Eligible"].pair_idx.iloc[0])
        g2.loc[g2.kind == "inclusion", "truth"] = "yes"
        g2.loc[g2.kind == "exclusion", "truth"] = "no"
        g2.loc[g2[(g2.pair_idx == elig) & (g2.kind == "inclusion")].index[0], "truth"] = "no"
        g2.to_csv(tmp / "gold_lc.csv", index=False)
        res = quiet(E.run_labelcheck, str(tmp / "gold_lc.csv"), C, None)
        n_not = int((corpus.target.str.strip() == "Not Eligible").sum())
        check("an Eligible pair whose labels say NOT_ELIGIBLE is listed, and every Not Eligible pair whose "
              "labels say ELIGIBLE", elig in res["conflict_pairs"] and res["conflicts"] == 1 + n_not)

        print("\n8. Evidence scoring")
        note0 = str(corpus.set_index("pair_idx").loc[0, "patient_orig"])
        ev = [{"system": "s", "pair_idx": 0, "crit_idx": 0, "kind": "inclusion", "truth": "yes",
               "evidence": [note0[:25]]},
              {"system": "s", "pair_idx": 0, "crit_idx": 1, "kind": "inclusion", "truth": "yes",
               "evidence": ["this sentence is not in the note"]}]
        write_jsonl(tmp / "ev.jsonl", ev)
        res = quiet(E.run_evidence, C, str(tmp / "ev.jsonl"), None, None)
        check("one real quote and one invented quote: found-verbatim rate 0.5",
              res["spans"] == 2 and res["exact_substring"] == 1)

        print("\n9. Checker scoring")
        wrong = {(x["pair_idx"], x["crit_idx"]) for x in flipped[:10]}
        ver = [{"pair_idx": int(g.pair_idx), "crit_idx": int(g.crit_idx),
                "label": "UNSUPPORTED" if (g.pair_idx, g.crit_idx) in wrong else "VERIFIED"} for g in gold.itertuples()]
        write_jsonl(tmp / "ver.jsonl", ver)
        res = quiet(E.run_verification, str(tmp / "gold.csv"), str(tmp / "flip.jsonl"), str(tmp / "ver.jsonl"), None, None)
        check("a checker that flags exactly the 10 wrong answers: precision 1.0, recall 1.0",
              res["flag_precision_wrong_given_flagged"] == 1.0 and res["flag_recall_flagged_given_wrong"] == 1.0)

        print("\n10. Targeted checking simulation")
        dev = corpus[corpus.trial_id.map(splits) == "dev"]
        el = dev[dev.target.str.strip() == "Eligible"].pair_idx.tolist()
        inel = dev[dev.target.str.strip() == "Not Eligible"].pair_idx.tolist()
        good_first = pd.DataFrame({"pair_idx": el + inel, "crit_idx": 0})
        good_first.to_csv(tmp / "order_good.csv", index=False)
        bad_first = pd.DataFrame({"pair_idx": inel + el, "crit_idx": 0})
        bad_first.to_csv(tmp / "order_bad.csv", index=False)
        res = quiet(E.run_targeting, C, str(tmp / "fail0.jsonl"), str(tmp / "order_good.csv"), [10, 25], "dev")
        by = {x["checks"]: x for x in res["results"]}
        check("checking the 25 wrongly failed eligible pairs first rescues 10 after 10 checks, 25 after 25",
              by[0]["wrongly_excluded_remaining"] == 25 and by[10]["rescued"] == 10 and by[25]["rescued"] == 25)
        res = quiet(E.run_targeting, C, str(tmp / "fail0.jsonl"), str(tmp / "order_bad.csv"), [25], "dev")
        by = {x["checks"]: x for x in res["results"]}
        check("checking ineligible pairs first rescues nothing (their effect is unknown without labels)",
              by[25]["rescued"] == 0 and by[25]["checks_with_unknown_effect"] == 25)

        print("\n11. Question-log summary")
        log = [
            {"strategy": "A", "case_idx": 0, "pair_idx": el[0], "step": 0, "decision_after": "REVIEW",
             "full_info_decision": "ELIGIBLE"},
            {"strategy": "A", "case_idx": 0, "pair_idx": el[0], "step": 1, "crit_idx": 3, "answered": True,
             "decision_after": "ELIGIBLE"},
            {"strategy": "A", "case_idx": 1, "pair_idx": inel[0], "step": 0, "decision_after": "REVIEW",
             "full_info_decision": "NOT_ELIGIBLE"},
            {"strategy": "A", "case_idx": 1, "pair_idx": inel[0], "step": 1, "crit_idx": 2, "answered": False,
             "decision_after": "REVIEW"},
            {"strategy": "A", "case_idx": 1, "pair_idx": inel[0], "step": 2, "crit_idx": 5, "answered": True,
             "decision_after": "NOT_ELIGIBLE"},
        ]
        write_jsonl(tmp / "q.jsonl", log)
        res = quiet(E.run_questions, str(tmp / "q.jsonl"), C)["strategies"]["A"]
        check("question log: 3 questions, 2 answered, both cases settled (after 1 and 2 questions), "
              "both match the full note", res["questions_total"] == 3 and res["answered_total"] == 2
              and res["settled_share"] == 1.0 and res["questions_to_settle_mean"] == 1.5
              and res["matches_full_info_share"] == 1.0)

        print("\n12. Model client and plain-AI script (mock model - nothing is sent anywhere)")
        replies = iter(["this is not json", '{"truth": "yes"}'])
        llm = LocalLLM("mock-model", backend="mock", mock=lambda s, u: next(replies))
        got = llm.chat_json("system", "user")
        check("an unparseable answer is asked again once with a reminder, then accepted",
              got["ok"] and got["attempts"] == 2 and got["data"] == {"truth": "yes"})
        out = tmp / "plain_mock.jsonl"
        proc = subprocess.run([sys.executable, str(HERE / "plain_ai.py"), "--model", "mock-model", "--backend", "mock",
                               "--pairs", "7,4", "--out", str(out), "--cache-dir", str(tmp / "cache")],
                              capture_output=True, text=True)
        recs = [json.loads(l) for l in out.read_text(encoding="utf-8").splitlines()] if out.exists() else []
        check("plain_ai.py (mock): pairs 7 and 4 give 42 rule answers with the rule logic applied in code",
              proc.returncode == 0 and len(recs) == 42
              and all(r["verdict"] == map_truth(r["truth"], r["kind"]) for r in recs), proc.stderr[-300:])
        res = quiet(E.run_pairs, C, str(out), None, None, K)
        check("its records can be scored (98 pairs had no answers and are counted as unknown)",
              res["missing_rule_answers_scored_unknown"] == 2230 - 42)

        print("\n13. Refuses bad input")
        write_jsonl(tmp / "dup.jsonl", [same[0], same[0]])
        try:
            E.read_records(str(tmp / "dup.jsonl"))
            ok = False
        except ValueError:
            ok = True
        check("the same rule answer twice is refused", ok)
        write_jsonl(tmp / "mix.jsonl", [dict(same[0]), dict(same[1], system="other")])
        try:
            E.read_records(str(tmp / "mix.jsonl"))
            ok = False
        except ValueError:
            ok = True
        check("two systems in one file are refused", ok)
        (tmp / "pass.jsonl.INCOMPLETE").write_text("x", encoding="utf-8")
        try:
            quiet(E.run_pairs, C, str(tmp / "pass.jsonl"), None, None, K)
            ok = False
        except ValueError:
            ok = True
        check("a run marked INCOMPLETE (failed model calls) is refused", ok)

    print(f"\n{passed} passed, {failed} failed")
    if failed:
        print("STOP: fix your setup before continuing.")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
