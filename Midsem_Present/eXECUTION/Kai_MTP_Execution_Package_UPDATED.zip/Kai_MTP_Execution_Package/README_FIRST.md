# Kai MTP — executed starter package (11 October 2026)

This archive is a **partial, honestly verified execution bundle**, NOT a finished MTP and NOT an AI-performance report.

## Actual executed checks
- **Update 11 October 2026:** NSCLC data files added, `selftest.py` 35 passed / 0 failed. NSCLC development-only rule-count benchmark CSVs added.
- `outputs/logs/sigir_integrity.log`: nine SIGIR pack checks PASS.
- `outputs/logs/nsclc_selftest.log`: 35 passed, 0 failed, after supplying the NSCLC dataset and labelling sheet.
- `outputs/sigir_*summary*.csv`, `sigir_rule_types.csv`, `sigir_rule_length_by_class.csv`: actual dataset measurements.
- `outputs/sigir_rule_count_thresholds_DEV_ONLY.csv`: deterministic count-the-rules development benchmark. Do not present it as AI accuracy or test accuracy.
- `outputs/annotation_completion.csv`: truth labels still blank in both uploaded sheets.
- `outputs/sigir_mock_dev.jsonl` and `sigir_mock_forced_dev.jsonl`: **MOCK / SYNTHETIC ANSWERS FOR PIPELINE TESTING ONLY**, NOT genuine clinical predictions. Corresponding logs contain diagnostic scoring; DO NOT report these scores as model performance.

## Missing prerequisites for completing the project guide
1. NSCLC files now supplied and validated; NSCLC selftest passed (35/35).
2. Independently completed, reviewed and frozen 446 NSCLC and 203 SIGIR rule labels. Never generate human gold truth from model guesses.
3. Local Ollama with the designated model to run real plain-AI and forced-guess inference; this environment does not provide the user's Ollama server.
4. Implementation, tests and validation of the six-part checker, decision-aware ranking, controlled traps, repair/deferral and rejection-risk ranking. These are research tasks in the guide, not pre-existing outputs of the starter kit.
5. Freeze prompts, parameters and code on development data before evaluating the held-out test splits.

## Reproduce locally
`cd code && python check_sigir_pack.py`
`python selftest.py` (after supplying NSCLC files)

Refer to `docs/Akash_Project_Guide.md` and `docs/ANNOTATION_FINDINGS_AND_PRESENTATION_GUIDANCE.md` for the authoritative week-by-week research protocol.
