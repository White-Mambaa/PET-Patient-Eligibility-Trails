# Evaluation talk track

## 1. Evidence checks for clinical trial screening (20 seconds)

“We built a tool to check the evidence behind individual screening answers and rank the ones a reviewer should inspect first. Today I’ll show the tool and the results we have from two matched development cohorts.”

## 2. One rule can drive a wrong exclusion (40 seconds)

“A clinical trial has inclusion and exclusion criteria. A single unsupported failing answer can push an otherwise eligible pair into rejection. In the earlier, separate baseline, 22 of 28 wrong exclusions had one failing rule. That is why we rank answers by whether correcting the rule could change the decision.”

## 3. How the tool works (55 seconds)

“Qwen2.5:7B reads the note and the rule and returns a truth value with an evidence quote. The checker asks six questions: is the quote there, does it support the answer, does its context apply, is the logic consistent, does other evidence contradict it, and was decisive evidence missed? We rank suspect answers by their decision impact. A reviewer can keep the answer, defer it to review, or re-ask once and check the repair.”

## 4. Matched development evaluation (40 seconds)

“We compared the same Qwen model on the same cases with two answer policies. NSCLC-100 contributed 50 patient–trial pairs, 25 reference eligible. SIGIR-204 contributed 102, 49 reference eligible. One policy allows unknown and the other forces an answer. We report hard wrong exclusions, review volume, and accuracy under an explicit binary convention.”

## 5. Forced guessing increased hard wrong exclusions (55 seconds)

“The pattern holds in both datasets. On NSCLC we go from 12 to 22 hard wrong exclusions out of 25 eligible cases. On SIGIR we go from 15 to 43 out of 49. Combined, that is 27 versus 65 out of 74. A hard wrong exclusion means the system says Not Eligible when the dataset reference says Eligible.”

## 6. Review and accuracy measure different things (45 seconds)

“Forced guessing removed 88 review decisions. Its binary accuracy increased modestly under the convention that Review counts as negative, while the hard wrong exclusions rose substantially. These are distinct outcomes. There were no observed wrong inclusions in this development comparison. The counts do not establish clinical safety.”

## 7. Checker and repair status (45 seconds)

“The checker saved 676 of 950 rows in the last confirmed, separate NSCLC legacy checkpoint. Coverage tells us how much was processed. It does not tell us whether the judgments are right. We also saved 20 pilot re-ask records. We have no verified repair success rate or held-out results to report.” Use the local addendum if it verifies newer coverage.

## 8. Offline demo (60 seconds)

“This is a synthetic software test. An unsupported failing rule drives the initial Not Eligible decision. Deferring the flag sends the pair to Review. The re-ask produces a corrected answer and the tool rechecks it before changing the result to Eligible.” Run the self-test command in START_HERE.md, or use the slide as the fallback.

## 9. Contribution and conclusion (30 seconds)

“We delivered an evidence-checking prototype and a matched development comparison. The result shows why review burden and wrong exclusions must be reported separately. To estimate the checker’s effect, the next evaluation needs independent rule labels, verified rechecks and a frozen held-out run.”

## Likely questions

**Which model reads the note?** Qwen2.5:7B via local Ollama for the development comparison. The separate exploratory checkpoint used a Groq-assisted checker.

**Does 676/950 mean 71% accuracy?** No. It is saved checker coverage. Accuracy would require independent correctness labels for those judgments.

**Did the checker fix 20 cases?** Twenty pilot records were saved. A re-ask is only a proposal until a separate check accepts it.

**Why did accuracy rise while exclusions increased?** The binary accuracy calculation groups Review with Not Eligible. A hard rejection and a case sent for review therefore count the same in that metric, even though their practical consequences differ.

**Do the two datasets give a held-out result?** Both comparisons use development splits. The cross-dataset pattern is descriptive evidence on these runs.

**How is the ranking useful?** It surfaces failing and flagged criteria early, especially a sole failing rule whose correction can change the pair decision.
