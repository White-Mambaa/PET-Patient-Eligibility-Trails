# MTP closeout in two days

**Working evaluation date: 11 November 2026. Confirm the slot with the panel.**

The deck and report use recorded development results. The strongest finding is the tradeoff between sending a pair to review and making a hard wrong exclusion. The software demonstration uses synthetic inputs.

## Today: capture the evidence and lock the scope

1. Extract this package into Downloads. Run the offline snapshot command below on the project laptop. Copy the resulting notes-free JSON and Markdown into the submission folder as the evidence addendum.
2. Check the paired-mode table in the addendum against slide 6. If the snapshot has newer checker coverage, present that count from the addendum or update slide 7. Say exactly which run it describes.
3. Put the slide deck, report, tool ZIP and evidence addendum together. Add the team names and identifiers required by your department. Close the experiment scope at this snapshot and use that one cut of the data for evaluation.

### Snapshot the saved results

    cd "$HOME/MTP/Akash_Kit" &&
    .venv/bin/python "$HOME/Downloads/MTP_CLOSEOUT/freeze_closeout.py" --root "$PWD"

This reads saved outputs, verifies matched pair identities and checker provenance, and writes an aggregate snapshot under outputs/mtp_closeout/. It makes no model requests. Use the original deck and report if a saved input cannot be verified; the addendum identifies the missing source.

## Tomorrow: rehearse and check the offline demo

    pack="$HOME/Downloads/MTP_CLOSEOUT"
    unzip -n "$pack/MTP_TOOL_CANDIDATE.zip" -d "$pack"
    "$HOME/MTP/Akash_Kit/.venv/bin/python" \
      "$pack/MTP_TOOL/mtp_week_delivery.py" self-test

The command prints the three decisions for a deterministic synthetic case. It runs without Ollama or a Groq key. The expected result is NOT_ELIGIBLE when keeping the wrong answer, REVIEW when deferring it, and ELIGIBLE after a repair passes recheck.

Rehearse slides 1–7 in about five minutes, the software demo in one minute, then close on slide 9. The timings are suggestions; adapt them to the slot you receive. If the live terminal is unavailable, show slide 8, which records the same fixture outcome.

## What to state in evaluation

- The two modes were compared on 152 matched development patient–trial pairs. Across the 74 reference-eligible pairs, hard wrong exclusions rose from 27 to 65 when guessing was forced; the 88 review decisions fell to zero.
- The checker saved 676 of 950 records at the last confirmed checkpoint. Use the newer count only if the local snapshot verifies it. Coverage is the number of saved judgments.
- The 20 re-ask records are a pilot awaiting verified rechecks. Checker effectiveness and held-out performance remain open.

The archive contains source code and synthetic demo input. Keep real patient notes, prediction excerpts, label sheets and credentials out of the shareable submission.
