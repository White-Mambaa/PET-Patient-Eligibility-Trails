#!/usr/bin/env python3
"""Time-bounded local repeatability experiment on EXISTING MTP development cases.

Uses existing experiments/overnight_evidence_audit.py judge(record,note).
Does NOT alter original predictions/audits, test sets, or claim gold labels.
Output is a resumable dedicated folder with a deterministic manifest.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import random
import runpy
import sys
import time
from collections import Counter
from datetime import datetime
from pathlib import Path

FIELDS = ("support", "context_issue", "logic_issue", "contradiction_issue", "missed_evidence_issue",
          "suggested_truth", "suggested_verdict", "needs_human_review")
SOURCES = {
    "nsclc100": ("outputs/plain_ai_qwen_dev.jsonl", "datasets/nsclc100/nsclc100.csv"),
    "sigir204": ("outputs/plain_ai_qwen_sigir_dev.jsonl", "datasets/sigir204/sigir204.csv"),
}


def read_jsonl(path):
    rows = []
    with path.open(encoding="utf-8") as f:
        for n, line in enumerate(f, 1):
            if line.strip():
                try:
                    v = json.loads(line)
                except Exception as e:
                    raise ValueError(f"Invalid JSON at {path}:{n}: {e}") from e
                if not isinstance(v, dict):
                    raise ValueError(f"Non-object JSON at {path}:{n}")
                rows.append(v)
    return rows


def key(r):
    return (str(r["dataset"]), int(r["pair_idx"]), int(r["crit_idx"]))


def as_index(rows, label):
    found = {}
    for r in rows:
        k = key(r)
        if k in found:
            raise ValueError(f"Duplicate key in {label}: {k}")
        found[k] = r
    return found


def sha256(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def pick_sample(predictions, originals, per_dataset, seed):
    buckets = {}
    for ds in SOURCES:
        keys = sorted(k for k in predictions if k[0] == ds)
        rng = random.Random(f"{seed}|{ds}")
        if len(keys) < per_dataset:
            raise ValueError(f"{ds}: only {len(keys)} baseline records; requested {per_dataset}")
        buckets[ds] = rng.sample(keys, per_dataset)
    # Interleave datasets so a time-limited run covers both even if unfinished.
    return [buckets[ds][i] for i in range(per_dataset) for ds in SOURCES]


def load_project(root):
    predictions = {}
    notes = {}
    input_paths = []
    for ds, (pred_rel, csv_rel) in SOURCES.items():
        p = root / pred_rel
        c = root / csv_rel
        if not p.is_file() or not c.is_file():
            raise FileNotFoundError(f"Missing required baseline inputs: {p} / {c}")
        input_paths.extend([p, c])
        for r in read_jsonl(p):
            x = dict(r)
            x["dataset"] = ds
            k = key(x)
            if k in predictions:
                raise ValueError(f"Duplicate prediction {k}")
            predictions[k] = x
        with c.open(encoding="utf-8-sig", newline="") as f:
            for row in csv.DictReader(f):
                nk = (ds, int(row["pair_idx"]))
                if nk in notes:
                    raise ValueError(f"Duplicate patient note {nk}")
                notes[nk] = row["patient_orig"]
    orig = root / "outputs/overnight_audit/evidence_audit.jsonl"
    if not orig.is_file():
        raise FileNotFoundError(orig)
    input_paths.append(orig)
    originals = as_index(read_jsonl(orig), "original audit")
    if set(predictions) != set(originals):
        extra = sorted(set(predictions) - set(originals))[:5]
        missing = sorted(set(originals) - set(predictions))[:5]
        raise ValueError(f"Prediction and audit IDs differ: baseline_only={extra}, audit_only={missing}")
    for ds, pair, _ in predictions:
        if (ds, pair) not in notes:
            raise ValueError(f"Missing note for {(ds, pair)}")
    return predictions, originals, notes, input_paths


def normalize(v):
    if isinstance(v, bool):
        return str(v).lower()
    return str(v).strip().lower()


def report(records, originals, path):
    lines = ["# Local judge repeatability experiment", "", f"Completed repeat audits: {len(records)}", "",
             "**Important:** Agreement measures self-consistency, not error-detection accuracy or clinical truth.", ""]
    if records:
        lines += ["| Field | Same as original | Agreement on observed repeats |", "|---|---:|---:|"]
        for field in FIELDS:
            comparable = [(originals[key(r)]["audit"].get(field), r["repeat_audit"].get(field)) for r in records]
            agree = sum(normalize(a) == normalize(b) for a, b in comparable)
            lines.append(f"| {field} | {agree}/{len(comparable)} | {agree / len(comparable):.2%} |")
        lines += ["", "## By dataset", ""]
        for ds in SOURCES:
            subset = [r for r in records if r["dataset"] == ds]
            lines.append(f"- {ds}: {len(subset)} repeated")
    lines += ["", "Repeat calls may be deterministic if generation uses a fixed temperature/seed.",
              "Sampling is stratified equally across two datasets, not representative of combined prevalence.",
              "No independent adjudication has been performed by this experiment.", ""]
    path.write_text("\n".join(lines), encoding="utf-8")


def self_test():
    predictions = {("nsclc100", i, 0): {"dataset": "nsclc100", "pair_idx": i, "crit_idx": 0} for i in range(12)}
    predictions.update({("sigir204", i, 0): {"dataset": "sigir204", "pair_idx": i, "crit_idx": 0} for i in range(12)})
    originals = {k: {"audit": {"support": "supported"}} for k in predictions}
    a = pick_sample(predictions, originals, 4, 123)
    b = pick_sample(predictions, originals, 4, 123)
    assert a == b and len(a) == len(set(a)) == 8
    assert Counter(k[0] for k in a) == {"nsclc100": 4, "sigir204": 4}
    assert normalize(True) == "true" and normalize(" YES ") == "yes"
    print("SELF-TEST PASS: deterministic balanced sample, unique joins, normalization.")


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", type=Path, default=Path.cwd())
    p.add_argument("--hours", type=float, default=1.9, help="Stop scheduling new calls after this many hours")
    p.add_argument("--per-dataset", type=int, default=60, help="Max repeated judge calls per dataset")
    p.add_argument("--seed", type=int, default=20261017)
    p.add_argument("--self-test", action="store_true")
    p.add_argument("--dry-run", action="store_true", help="Check all inputs and create no outputs or model calls")
    args = p.parse_args()
    if args.self_test:
        self_test()
        return
    if not (0.1 <= args.hours <= 12):
        p.error("--hours must be in [0.1, 12]")
    if not (1 <= args.per_dataset <= 500):
        p.error("--per-dataset must be in [1, 500]")
    root = args.root.expanduser().resolve()
    preds, originals, notes, paths = load_project(root)
    manifest = {"seed": args.seed, "per_dataset": args.per_dataset,
                "inputs_sha256": {str(p.relative_to(root)): sha256(p) for p in paths},
                "selected_keys": [list(k) for k in pick_sample(preds, originals, args.per_dataset, args.seed)]}
    print("=== MTP LOCAL JUDGE REPEATABILITY ===", flush=True)
    print("Full baseline/audit keys:", len(preds), flush=True)
    print("Selected repeat calls:", len(manifest["selected_keys"]), flush=True)
    print("Maximum hours:", args.hours, flush=True)
    print("Original inputs are READ ONLY; test split is untouched.", flush=True)
    if args.dry_run:
        print("DRY RUN OK: inputs, identity joins and sample validated. No outputs or model calls.")
        return
    outdir = root / "outputs/overnight_audit/local_judge_repeatability"
    outdir.mkdir(parents=True, exist_ok=True)
    manifest_file = outdir / "manifest.json"
    if manifest_file.exists():
        existing_manifest = json.loads(manifest_file.read_text(encoding="utf-8"))
        if existing_manifest != manifest:
            raise ValueError(f"Manifest/input hashes changed. Refusing to mix runs in {outdir}")
    else:
        manifest_file.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    output = outdir / "repeat_audits.jsonl"
    existing_rows = read_jsonl(output) if output.exists() else []
    done = as_index(existing_rows, "repeat output")
    selected = {tuple(x) for x in manifest["selected_keys"]}
    if set(done) - selected:
        raise ValueError("Output contains records outside manifest; refusing to append")
    print("Existing repeated results:", len(done), flush=True)
    sys.path.insert(0, str((root / "code").resolve()))
    audit_file = root / "experiments/overnight_evidence_audit.py"
    module = runpy.run_path(str(audit_file))
    judge = module.get("judge")
    if not callable(judge):
        raise RuntimeError("Existing audit script has no judge(record,note) function")
    model = module.get("MODEL", "unknown")
    print("Model:", model, flush=True)
    if done and any(row.get("judge_model") != model for row in done.values()):
        raise ValueError("Prior output uses a different model; refusing to mix models")
    start = time.monotonic()
    cutoff = start + args.hours * 3600
    fail_count = 0
    errors_file = outdir / "errors.jsonl"
    with output.open("a", encoding="utf-8") as f, errors_file.open("a", encoding="utf-8") as err:
        for ds, pair, crit in map(tuple, manifest["selected_keys"]):
            k = (ds, pair, crit)
            if k in done:
                continue
            if time.monotonic() >= cutoff:
                print("Time limit reached; stopping safely.", flush=True)
                break
            started = time.monotonic()
            try:
                result = judge(preds[k], notes[(ds, pair)])
                if not isinstance(result, dict):
                    raise ValueError("Judge returned non-object")
                record = {"dataset": ds, "pair_idx": pair, "crit_idx": crit,
                          "judge_model": model, "repeat_audit": result,
                          "seconds": round(time.monotonic()-started, 2),
                          "timestamp": datetime.now().astimezone().isoformat()}
                f.write(json.dumps(record, ensure_ascii=False) + "\n")
                f.flush()
                done[k] = record
                print(f"SAVED {len(done)}/{len(selected)} {ds} pair={pair} rule={crit} "
                      f"{record['seconds']}s", flush=True)
            except Exception as exc:
                fail_count += 1
                err.write(json.dumps({"dataset": ds, "pair_idx": pair, "crit_idx": crit,
                                      "error": str(exc)}, ensure_ascii=False) + "\n")
                err.flush()
                print(f"ERROR {k}: {type(exc).__name__}: {exc}", flush=True)
                # Prevent hundreds of failed calls when server is unavailable.
                if fail_count >= 3:
                    print("Three failures; stopping to avoid repeated bad requests.", flush=True)
                    break
    finished = list(done.values())
    report(finished, originals, outdir / "REPEATABILITY_REPORT.md")
    print("=== FINAL SUMMARY ===", flush=True)
    print(f"Completed {len(done)}/{len(selected)}; failures this run {fail_count}", flush=True)
    print("Report:", outdir / "REPEATABILITY_REPORT.md", flush=True)
    print("Original baseline, original evidence audit, and test files modified: NO", flush=True)

if __name__ == "__main__":
    main()
