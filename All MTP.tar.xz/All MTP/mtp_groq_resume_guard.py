#!/usr/bin/env python3
"""Resume the existing NSCLC supervisor after an explicit server cooldown."""
import argparse
from datetime import timezone
from email.utils import parsedate_to_datetime
import fcntl
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import time

SUPERVISOR = "mtp_supervisor_v3.py"
CHECKPOINT = Path(
    "outputs/mtp_completion/nsclc100/dev/"
    "plain_ai_qwen_dev_checks_theta95_fallback_exploratory.jsonl"
)
LONG_WAIT = "Server requests a long wait; resume later. Retry-After="
BUDGET_STOP = "API attempt budget reached; resume from cache"
TOTAL_ROWS = 950
ROUNDS = 10
ATTEMPTS_PER_ROUND = 230
COOLDOWN_BUFFER = 5


def last_stop(lines):
    last = ""
    for line in lines:
        if line.strip():
            last = line.strip()
    return last.removeprefix("STOP DETAIL: ") if last.startswith("STOP DETAIL: ") else None


def retry_wait(detail, elapsed=0, now=None):
    if not detail or not detail.startswith(LONG_WAIT):
        return None
    header = detail[len(LONG_WAIT):].strip()
    try:
        seconds = float(header)
    except ValueError:
        try:
            dt = parsedate_to_datetime(header)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return max(0, dt.timestamp() + COOLDOWN_BUFFER - (time.time() if now is None else now))
        except (ValueError, TypeError, OverflowError, OSError):
            return None
    if not math.isfinite(seconds) or seconds < 0:
        return None
    return max(0, seconds + COOLDOWN_BUFFER - max(0, elapsed))


def count_rows(root):
    raw = (root / CHECKPOINT).read_bytes()
    prefix = raw[:raw.rfind(b"\n") + 1]
    if raw[len(prefix):].strip():
        raise ValueError("Checkpoint has an unfinished final line; inspect it before starting a writer")
    keys = set()
    for line in prefix.splitlines():
        if not line.strip():
            continue
        row = json.loads(line)
        key = (int(row["pair_idx"]), int(row["crit_idx"]))
        if key in keys:
            raise ValueError("Duplicate checkpoint case ID; keep the checkpoint and inspect it")
        keys.add(key)
    if len(keys) > TOTAL_ROWS:
        raise ValueError("Checkpoint contains more than 950 cases")
    return len(keys)


def active_supervisors():
    """Check exact process arguments to avoid matching this launcher's command."""
    pids = []
    for p in Path("/proc").iterdir():
        if not p.name.isdecimal():
            continue
        try:
            if p.stat().st_uid != os.getuid():
                continue
            args = (p / "cmdline").read_bytes().split(b"\0")
        except OSError:
            continue
        if any(os.path.basename(arg) == SUPERVISOR.encode() for arg in args):
            pids.append(p.name)
    return pids


def run_supervisor(root, hours):
    command = [sys.executable, "-u", str(root / SUPERVISOR), "--root", str(root),
               "--hours", str(hours), "--max-attempts", str(ATTEMPTS_PER_ROUND), "--max-restarts", "30"]
    env = os.environ.copy()
    env.pop("GROQ_API_KEY", None)  # Same configured credential pool as the prior resume command.
    detail = None
    with subprocess.Popen(command, cwd=root, env=env, stdin=subprocess.DEVNULL,
                          stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                          encoding="utf-8", errors="replace", bufsize=1) as proc:
        for line in proc.stdout:
            print(line, end="", flush=True)
            if line.strip():
                detail = last_stop((line,))
        return proc.wait(), detail


def finish(root, score_script):
    print("CHECKER COVERAGE COMPLETE: 950 / 950", flush=True)
    if score_script.is_file():
        print("Generating the full development tables from the saved rows.", flush=True)
        return subprocess.run([sys.executable, str(score_script), "score", "--root", str(root)], cwd=root).returncode
    print("Scoring script unavailable; run mtp_checker_work.py score on the saved checkpoint.")
    return 0


def campaign(root, prior_log, score_script):
    end = time.monotonic() + 24 * 3600
    if count_rows(root) == TOTAL_ROWS:
        return finish(root, score_script)
    stop = last_stop(prior_log.read_text(encoding="utf-8", errors="replace").splitlines())
    delay = retry_wait(stop, elapsed=time.time() - prior_log.stat().st_mtime)
    if delay is None:
        raise ValueError("The previous log does not end with a recognised server cooldown")
    print(f"Saved: {count_rows(root)} / {TOTAL_ROWS}. Up to {ROUNDS * ATTEMPTS_PER_ROUND} additional API attempts.")
    for number in range(1, ROUNDS + 1):
        if active_supervisors():
            raise ValueError("A supervisor is already active; leave that run in place")
        if delay + 3600 > end - time.monotonic():
            print("Cooldown does not fit in this 24-hour run; pausing without a new API attempt.")
            return 2
        if delay > 0:
            print(f"Waiting {math.ceil(delay)} seconds before resuming.", flush=True)
            time.sleep(delay)
        if active_supervisors():
            raise ValueError("A supervisor started during the wait; leave that run in place")
        if count_rows(root) == TOTAL_ROWS:
            return finish(root, score_script)
        hours = int((end - time.monotonic()) // 3600)
        if hours < 1:
            print("Time budget reached; checkpoint saved.")
            return 2
        print(f"RESUME ROUND {number}/{ROUNDS}; cap {ATTEMPTS_PER_ROUND} API attempts.", flush=True)
        code, stop = run_supervisor(root, hours)
        saved = count_rows(root)
        if saved == TOTAL_ROWS:
            return finish(root, score_script)
        delay = retry_wait(stop)
        if delay is None and stop == BUDGET_STOP:
            delay = COOLDOWN_BUFFER
        if delay is None:
            print(f"PAUSED: {saved} / {TOTAL_ROWS}; supervisor exit {code}. Inspect the stop detail above.")
            return 2
    print(f"RESUME CAP REACHED: {count_rows(root)} / {TOTAL_ROWS} saved. Review the log before launching again.")
    return 2


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--from-log", type=Path, required=True)
    parser.add_argument("--score-script", type=Path, default=Path(__file__).resolve().with_name("mtp_checker_work.py"))
    args = parser.parse_args()
    root = args.root.resolve()
    os.umask(0o077)
    try:
        if not (root / SUPERVISOR).is_file():
            raise ValueError("The existing supervisor was not found in --root")
        with (root / "outputs/.mtp_groq_resume_guard.lock").open("a", encoding="utf-8") as lock:
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                raise ValueError("A resume launcher is already running") from None
            if active_supervisors():
                raise ValueError("A supervisor is already active; leave that run in place")
            return campaign(root, args.from_log.resolve(), args.score_script.resolve())
    except (OSError, ValueError, KeyError, TypeError) as e:
        print("STOP:", str(e) if type(e) in (ValueError, FileNotFoundError) else type(e).__name__, file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
