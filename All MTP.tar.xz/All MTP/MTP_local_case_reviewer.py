#!/usr/bin/env python3
"""Local-only, resumable clinical-screening *review worksheet editor*.

Uses existing 49-case Stage 3 review sheet; never generates reference labels.
All evidence and notes remain on the local machine. No model, API or network use.

python3 MTP_local_case_reviewer.py --root ~/MTP/Akash_Kit --self-test
python3 MTP_local_case_reviewer.py --root ~/MTP/Akash_Kit --status
python3 MTP_local_case_reviewer.py --root ~/MTP/Akash_Kit

Only a suitably qualified human reviewer should assign evidence labels. Work
performed by a project author must be described as author-reviewed, not independent.
"""
from __future__ import annotations
import argparse
import csv
import os
import shutil
import sys
import tempfile
from collections import Counter
from datetime import datetime
from pathlib import Path

DIR = 'outputs/research_completion_sprint/adjudication_20261020_163130_107196'
INPUT = 'PRIVATE_STAGE3_REPAIR_ADJUDICATION.csv'
WORK = 'PRIVATE_TERMINAL_REVIEW_WORKING.csv'
GOLDS = (
    ('gold_nonverbatim_quote', 'Is any purported direct quotation absent verbatim from the patient note? (Non-verbatim is NOT proof of invented clinical content)'),
    ('gold_unsupported_evidence', 'Does the baseline assert a clinical evidential claim that the note does not support?'),
    ('gold_context_error', 'Does the baseline misread negation, subject, time, or clinical qualifiers?'),
    ('gold_logic_error', 'Does the baseline reasoning or truth-to-verdict mapping violate the specified criterion?'),
    ('gold_contradiction', 'Does the baseline assertion contradict the patient note?'),
    ('gold_missed_evidence', 'Does the note CONTAIN relevant evidence the baseline failed to notice? Missing data alone is NOT overlooked evidence.'),
)
BINARY_ALLOWED = {'', '0', '1', 'uncertain', 'defer'}
TRUTH_ALLOWED = {'', 'yes', 'no', 'unknown', 'uncertain', 'defer'}


def load(path):
    with path.open(encoding='utf-8-sig', newline='') as f:
        rd = csv.DictReader(f)
        if not rd.fieldnames:
            raise ValueError(f'Missing header in {path}')
        return list(rd.fieldnames), list(rd)


def validate(fields, rows):
    needed = {'case_id', 'criterion_kind', 'criterion_text', 'patient_note_PRIVATE_DO_NOT_UPLOAD',
              'baseline_truth', 'baseline_verdict', 'baseline_evidence', 'baseline_rationale',
              'gold_criterion_truth', 'gold_criterion_verdict'} | {name for name,_ in GOLDS}
    if not needed.issubset(fields):
        raise ValueError('Missing worksheet columns: '+', '.join(sorted(needed-set(fields))))
    if len(rows) != 49:
        raise ValueError(f'Expected 49 cases, got {len(rows)}')
    ids = [r['case_id'] for r in rows]
    if len(set(ids)) != len(ids):
        raise ValueError('Duplicate case identifiers')
    for r in rows:
        for name, _ in GOLDS:
            if str(r.get(name) or '').strip().lower() not in BINARY_ALLOWED:
                raise ValueError(f'{r["case_id"]}: invalid {name}; inspect before proceeding')
        if str(r.get('gold_criterion_truth') or '').strip().lower() not in TRUTH_ALLOWED:
            raise ValueError(f'{r["case_id"]}: invalid gold_criterion_truth')
        if str(r.get('gold_criterion_verdict') or '').strip().lower() not in ('', 'met','not_met','not_stated'):
            raise ValueError(f'{r["case_id"]}: invalid gold_criterion_verdict')


def map_truth(truth, kind):
    if truth == 'unknown': return 'not_stated'
    if truth not in ('yes','no') or kind not in ('inclusion','exclusion'):
        raise ValueError('Invalid truth/kind')
    if kind == 'inclusion': return 'met' if truth == 'yes' else 'not_met'
    return 'not_met' if truth == 'yes' else 'met'


def atomic_save(path, fields, rows):
    fd, temp_path = tempfile.mkstemp(prefix='.mtp_review_', suffix='.csv', dir=str(path.parent))
    try:
        with os.fdopen(fd, 'w', encoding='utf-8', newline='') as f:
            w = csv.DictWriter(f, fieldnames=fields, extrasaction='raise')
            w.writeheader()
            w.writerows(rows)
            f.flush()
            os.fsync(f.fileno())
        os.chmod(temp_path, 0o600)
        os.replace(temp_path, path)
    finally:
        if os.path.exists(temp_path): os.unlink(temp_path)


def summary(rows):
    print('\n=== REVIEW PROGRESS ===')
    print('Cases:', len(rows))
    for name,_ in GOLDS:
        n = sum(str(r.get(name) or '').strip() in ('0','1') for r in rows)
        print(f'{name}: {n}/{len(rows)}')
    ct=Counter(str(r.get('gold_criterion_truth') or '').strip().lower() for r in rows)
    print('Criterion truth labels:', {k:v for k,v in ct.items() if k})
    print('These are HUMAN-entered labels; the program never guesses clinical truth.')


class QuitSession(Exception): pass
class SkipCase(Exception): pass


def ask(prompt, previous, choices=None):
    """Return existing on Enter; 's' skip; 'q' quit; '?' show allowed choices."""
    while True:
        display = f' [{previous}]' if previous else ''
        try:
            ans = input(prompt+display+': ').strip()
        except (EOFError, KeyboardInterrupt):
            raise QuitSession()
        low = ans.lower()
        if low == 'q': raise QuitSession()
        if low == 's': raise SkipCase()
        if low == '': return previous
        if low == '?':
            print('Allowed:', ', '.join(sorted(choices or [])) if choices else 'text'); continue
        if choices is not None and low not in choices:
            print('Invalid entry. Use', ', '.join(sorted(choices)), 'or Enter to leave unchanged.'); continue
        return low if choices is not None else ans


def run_session(path, fields, rows):
    print('\nLOCAL REVIEW SESSION. All clinical notes displayed ONLY in this terminal.')
    print('Only assign evidence labels you have actually evaluated; do NOT copy AI judge labels.')
    print('For each prompt: 1=error present, 0=absent, uncertain=not sure, Enter=keep blank/current, s=skip case, q=quit.')
    print('Your edits are saved atomically after every completed case. Close LibreOffice before editing this file.')
    for idx, r in enumerate(rows):
        completed = sum(str(r.get(n) or '').strip().lower() in ('0','1') for n,_ in GOLDS)
        if completed==len(GOLDS) and str(r.get('gold_criterion_truth') or '').lower() in ('yes','no','unknown'):
            continue
        print('\n'+'='*72)
        print(f'CASE {idx+1}/{len(rows)}: {r["case_id"]} ({r.get("dataset")}, pair {r.get("pair_idx")}, rule {r.get("crit_idx")})')
        print('='*72)
        print('CRITERION KIND:',r['criterion_kind'])
        print('CRITERION:\n',r['criterion_text'])
        print('PATIENT NOTE (PRIVATE; DO NOT UPLOAD):\n',r['patient_note_PRIVATE_DO_NOT_UPLOAD'])
        updated=dict(r)
        try:
            print('\nFirst determine criterion truth from note+criterion BEFORE examining baseline answer.')
            t=ask('Criterion truth (yes/no/unknown/uncertain/defer)',
                  str(updated.get('gold_criterion_truth') or '').lower(), TRUTH_ALLOWED)
            updated['gold_criterion_truth']=t
            if t in ('yes','no','unknown'):
                updated['gold_criterion_verdict']=map_truth(t,updated['criterion_kind'])
            elif t in ('defer','uncertain',''):
                updated['gold_criterion_verdict']=''
            print('\n--- BASELINE ANSWER (not independent ground truth) ---')
            print('Truth:',r.get('baseline_truth'),'Verdict:',r.get('baseline_verdict'))
            print('Quoted evidence:',r.get('baseline_evidence'))
            print('Rationale:',r.get('baseline_rationale'))
            for name,question in GOLDS:
                print('\n'+question)
                current=str(updated.get(name) or '').strip().lower()
                updated[name]=ask(name+' (0/1/uncertain/defer)',current,BINARY_ALLOWED)
            if 'reviewer_comments' in updated:
                updated['reviewer_comments']=ask('Optional reviewer comments',
                    str(updated.get('reviewer_comments') or ''))
        except SkipCase:
            print('Case skipped without changes.'); continue
        except QuitSession:
            print('Quit requested; previous cases remain safely saved.'); return
        rows[idx]=updated
        atomic_save(path,fields,rows)
        print('SAVED:',updated['case_id'])
    print('\nNo further uncompleted cases. End of worksheet.')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=Path.cwd())
    p.add_argument('--status',action='store_true')
    p.add_argument('--self-test',action='store_true')
    args=p.parse_args()
    if args.self_test:
        assert map_truth('no','inclusion')=='not_met'
        assert map_truth('no','exclusion')=='met'
        assert map_truth('unknown','exclusion')=='not_stated'
        assert 'gold_logic_error' in dict(GOLDS)
        print('SELF-TEST PASS: deterministic mapping, required label definitions. No files modified.')
        return
    base=args.root.expanduser().resolve()/DIR
    src=base/INPUT
    dest=base/WORK
    if not src.is_file():
        raise FileNotFoundError(f'Required Stage3 worksheet missing: {src}')
    if not dest.exists():
        if args.status:
            path=src
        else:
            fields,rows=load(src)
            validate(fields,rows)
            fd=os.open(dest,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
            with os.fdopen(fd,'w',encoding='utf-8',newline='') as f:
                w=csv.DictWriter(f,fieldnames=fields)
                w.writeheader();w.writerows(rows)
            path=dest
            print('Created private, separate review working file:',dest)
    else:
        path=dest
    fields,rows=load(path)
    validate(fields,rows)
    summary(rows)
    print('WORKSHEET:',path)
    if args.status: return
    run_session(path,fields,rows)
    summary(rows)
    print('Score only if real binary labels were entered. Never label an unreviewed case 0.')
    print('Command: python3 ~/Downloads/MTP_finish_sprint.py --root ~/MTP/Akash_Kit --task score --review-file',str(dest))


if __name__=='__main__':
    try: main()
    except (ValueError,FileNotFoundError) as e:
        print('ERROR:',e,file=sys.stderr)
        raise SystemExit(2)
