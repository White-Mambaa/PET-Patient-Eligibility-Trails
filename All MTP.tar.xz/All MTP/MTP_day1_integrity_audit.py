#!/usr/bin/env python3
"""MTP Day 1: reproducible, OFFLINE baseline + reference-annotation audit.

READS ONLY development baseline predictions and explicit existing project artifacts.
Lists dataset file METADATA only (no dataset or held-out test file contents read).
Does not call Ollama, network, external APIs, or modify source project files.
Never exports patient notes, criterion text, clinical quotes or rationale to reports.
Does not fabricate clinical gold labels or write annotations. Uses Python stdlib.

  python3 MTP_day1_integrity_audit.py --self-test
  python3 MTP_day1_integrity_audit.py --root ~/MTP/Akash_Kit --task all

Output: outputs/research_completion_sprint/day1_integrity_audit_<UTC timestamp>/
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import json
import os
import re
import sys
import tempfile
from collections import Counter, defaultdict
from pathlib import Path

REVIEW_REL = Path('outputs/research_completion_sprint/adjudication_20261020_163130_107196')
WORK = 'PRIVATE_TERMINAL_REVIEW_WORKING.csv'
ORIGINAL = 'PRIVATE_STAGE2_BASELINE_VISIBLE_REVIEW.csv'
CHECK_FIELDS = (
    'gold_nonverbatim_quote', 'gold_unsupported_evidence',
    'gold_context_error', 'gold_logic_error', 'gold_contradiction',
    'gold_missed_evidence',
)
IMMUTABLE = (
    'case_id', 'dataset', 'pair_idx', 'crit_idx', 'criterion_kind',
    'criterion_text', 'patient_note_PRIVATE_DO_NOT_UPLOAD',
    'baseline_truth', 'baseline_verdict', 'baseline_evidence', 'baseline_rationale',
)
EXPECTED = {
    'nsclc_dev': (Path('outputs/plain_ai_qwen_dev.jsonl'), 950, 50),
    'sigir_dev': (Path('outputs/plain_ai_qwen_sigir_dev.jsonl'), 990, 102),
}
KNOWN_ARTIFACTS = {
    'criteria_mapper': 'code/criteria.py',
    'baseline_runner': 'code/plain_ai.py',
    'baseline_evaluator': 'code/evaluate.py',
    'unified_six_checks': 'outputs/evidence_checks/unified_six_checks_20261017_131121_594627/unified_six_checks.csv',
    'decision_impact': 'outputs/decision_impact/real_priority_analysis.csv',
    'priority_rankings': 'outputs/priority_comparison/priority_rankings.csv',
    'synthetic_42': 'outputs/research_completion_sprint/cpu_guarded_synthetic_20261021_223247_656178/synthetic_results.jsonl',
    'source_synthetic_42': 'outputs/research_completion_sprint/overnight_safe_20261020_223633/synthetic_42_cases.jsonl',
    'baseline_metrics_directory': 'outputs/neha_metrics_20261017_123000_928014',
    'human_review_working': str(REVIEW_REL / WORK),
    'human_review_original': str(REVIEW_REL / ORIGINAL),
    'latest_qa_snapshot': 'outputs/research_completion_sprint/offline_chunks_recheck_20261022/02_review_qa_NO_NOTES.json',
}
# Only reproducibility snapshots of development artifacts. Never traverse test files.
HASHED_KNOWN = {key for key in KNOWN_ARTIFACTS if key != 'baseline_metrics_directory'}
ALLOWED_BINARY = {'', '0', '1', 'uncertain', 'defer', 'na', 'n/a'}
ALLOWED_TRUTH = {'', 'yes', 'no', 'unknown', 'uncertain', 'defer'}
ALLOWED_VERDICT = {'', 'met', 'not_met', 'not_stated'}
LABEL_FIELDS = set(CHECK_FIELDS) | {'gold_criterion_truth', 'gold_criterion_verdict'}


def sha256(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def rel(root, path):
    return str(path.relative_to(root))


def read_csv(path):
    with path.open('r', newline='', encoding='utf-8-sig') as f:
        rd = csv.DictReader(f)
        if not rd.fieldnames:
            raise ValueError('Missing CSV header: ' + path.name)
        fields = list(rd.fieldnames)
        rows = list(rd)
    for r in rows:
        if None in r or any(v is None for v in r.values()):
            raise ValueError('CSV malformed (column count mismatch): ' + path.name)
    return fields, rows


def read_jsonl_summary(path, expected_count=None):
    count = 0
    ids = set()
    duplicate = 0
    invalid = 0
    schema = Counter()
    truths, verdicts = Counter(), Counter()
    mapping_bad = 0
    pair_ids = set()
    with path.open('r', encoding='utf-8') as f:
        for lineno, line in enumerate(f, 1):
            if not line.strip():
                continue
            count += 1
            try:
                row = json.loads(line)
                if not isinstance(row, dict):
                    raise ValueError('Non-object JSONL record')
            except (ValueError, TypeError):
                invalid += 1
                continue
            schema.update(row.keys())
            if 'pair_idx' not in row or 'crit_idx' not in row:
                invalid += 1
                continue
            key = (str(row['pair_idx']), str(row['crit_idx']))
            if key in ids:
                duplicate += 1
            ids.add(key)
            pair_ids.add(str(row['pair_idx']))
            truth = str(row.get('truth', '')).strip().lower()
            verdict = str(row.get('verdict', '')).strip().lower()
            kind = str(row.get('criterion_kind', row.get('kind', ''))).strip().lower()
            if truth:
                truths[truth] += 1
            if verdict:
                verdicts[verdict] += 1
            if truth in ('yes','no','unknown') and kind in ('inclusion','exclusion') and verdict:
                if verdict != truth_to_verdict(truth,kind):
                    mapping_bad += 1
    return {
        'rows': count, 'expected_rows': expected_count, 'row_count_matches': count == expected_count if expected_count else None,
        'unique_pair_count': len(pair_ids), 'duplicate_pair_criterion_keys': duplicate,
        'unparseable_or_missing_id_rows': invalid, 'mapping_conflicts_where_evaluable': mapping_bad,
        'truth_counts_if_available': dict(truths), 'verdict_counts_if_available': dict(verdicts),
        'header_fields_observed': sorted(schema), 'sha256': sha256(path),
    }


def truth_to_verdict(truth, kind):
    if truth == 'unknown': return 'not_stated'
    if kind == 'inclusion': return 'met' if truth == 'yes' else 'not_met'
    if kind == 'exclusion': return 'not_met' if truth == 'yes' else 'met'
    raise ValueError('Unknown truth/kind')


def norm(s):
    return re.sub(r'\s+', ' ', str(s or '')).strip()


def short_flag(flags, case_id, severity, category, field, comment):
    flags.append({'case_id':case_id,'priority':severity,'issue':category,'field':field,'reviewer_instruction':comment})


def parse_quotes(s):
    obj = json.loads(s or '[]')
    if isinstance(obj, str): obj = [obj]
    if not isinstance(obj, list) or not all(isinstance(q, str) for q in obj):
        raise ValueError('Non-list/non-string evidence')
    return obj


def conservative_rule_hints(row, flags):
    """Only prompts for human confirmation, not clinical gold suggestions."""
    cid = row['case_id']
    truth = (row.get('gold_criterion_truth') or '').strip().lower()
    if truth != 'yes': return
    criterion = (row.get('criterion_text') or '').lower()
    note = (row.get('patient_note_PRIVATE_DO_NOT_UPLOAD') or '').lower()
    if ('prisoner' in criterion or 'compulsorily detained' in criterion or 'involuntarily incarcerated' in criterion):
        if not any(k in note for k in ['prison', 'incarcerat', 'detain', 'custod', 'involuntar']):
            short_flag(flags,cid,'high','topic_not_documented_but_gold_yes','gold_criterion_truth',
                'Review detention status: do not infer presence or absence from silence. Unknown may be appropriate.')
    if 'non-infectious pneumonitis' in criterion and 'pneumonitis' not in note:
        short_flag(flags,cid,'high','topic_not_documented_but_gold_yes','gold_criterion_truth',
            'Pneumonitis not explicitly mentioned. Verify with clinical reviewer; absence of documentation is not a negative diagnosis.')
    if ('anti-pd-1' in criterion or 'anti-pd-l1' in criterion or 'anti-pd-l-1' in criterion):
        if not any(k in note for k in ['anti-pd', 'nivolumab', 'pembrolizumab', 'atezolizumab', 'durvalumab', 'cemiplimab', 'immunotherap', 'checkpoint']):
            short_flag(flags,cid,'high','prior_therapy_not_documented_but_gold_yes','gold_criterion_truth',
                'No named checkpoint treatment found. Historical therapy needs explicit evidence; do not infer from silence.')
    # Narrow, transparent numeric threshold audit: only when an exactly matched rule is present.
    if 'age' in criterion and ('≥18' in criterion.replace(' ', '') or '>=18' in criterion.replace(' ', '')):
        m = re.search(r'\b(\d{1,3})[- ]year[- ]old\b', note)
        if m and int(m.group(1)) >= 18:
            short_flag(flags,cid,'info','numeric_rule_support_candidate','gold_criterion_truth',
                'The note contains an adult age satisfying the >=18 rule; manually verify this is the patient.')
    if ('fev1' in criterion and ('1200' in criterion and '50%' in criterion)):
        m = re.search(r'fev1(?:\s+of|\s+is|\s+at)?\s*(\d{3,4})\s*cc\s*\((\d{1,3})\s*%\s*predicted\)',note)
        if m:
            cc, pc = map(int,m.groups())
            if cc < 1200 and pc < 50:
                short_flag(flags,cid,'high','numeric_threshold_conflict_candidate','gold_criterion_truth',
                    f'Explicit FEV1 {cc}cc and {pc}% are below BOTH thresholds (1200cc OR 50%). Recheck truth label; do not auto-correct.')


def annotation_audit(root):
    p = root / REVIEW_REL / WORK
    b = root / REVIEW_REL / ORIGINAL
    if not p.is_file() or not b.is_file():
        return {'status':'missing','required':[str(REVIEW_REL/WORK),str(REVIEW_REL/ORIGINAL)]}, []
    fields, rows = read_csv(p)
    base_fields, originals = read_csv(b)
    needed = set(IMMUTABLE) | LABEL_FIELDS | {'verified_supporting_quote'}
    missing = needed - set(fields)
    if missing:
        raise ValueError('Review worksheet missing columns: ' + ', '.join(sorted(missing)))
    if len(rows) != 49 or len(originals) != 49:
        raise ValueError('Expected exactly 49 working and 49 original cases; stop to prevent accidental corruption')
    first = {r['case_id']:r for r in originals}
    if len(first) != 49 or len({r['case_id'] for r in rows})!=49:
        raise ValueError('Duplicate human-review case identifiers')
    if {r['case_id'] for r in rows} != set(first):
        raise ValueError('Working and original case IDs differ; possible worksheet corruption')
    for r in rows:
        for col in IMMUTABLE:
            if r.get(col) != first[r['case_id']].get(col):
                raise ValueError('Immutable patient/source column changed for ' + r['case_id'] + '/' + col)
    flags=[]; labeled_cases=0; label_counts=Counter(); truth_counts=Counter()
    complete_cases=0; case_priority=Counter()
    for row in rows:
        cid=row['case_id']
        labels = [(row.get(f) or '').strip().lower() for f in CHECK_FIELDS]
        truth = (row.get('gold_criterion_truth') or '').strip().lower()
        v = (row.get('gold_criterion_verdict') or '').strip().lower()
        if truth not in ALLOWED_TRUTH:
            short_flag(flags,cid,'high','invalid_truth','gold_criterion_truth','Use yes/no/unknown/uncertain/defer or blank.')
        if v not in ALLOWED_VERDICT:
            short_flag(flags,cid,'high','invalid_gold_verdict','gold_criterion_verdict','Use met/not_met/not_stated or blank.')
        if truth in ('yes','no','unknown'):
            truth_counts[truth] += 1
            if v != truth_to_verdict(truth, row['criterion_kind']):
                short_flag(flags,cid,'high','truth_verdict_inconsistent','gold_criterion_verdict',
                    'Recalculate deterministic inclusion/exclusion mapping; this is not clinical inference.')
            if truth in ('yes','no') and not norm(row.get('verified_supporting_quote')):
                short_flag(flags,cid,'high','definite_truth_without_support_quote','verified_supporting_quote',
                    'Either provide exact supporting note evidence or choose unknown/uncertain. Do not invent a quotation.')
        elif v:
            short_flag(flags,cid,'high','verdict_without_definite_truth','gold_criterion_verdict',
                'Clear the mapped verdict unless truth is yes/no/unknown.')
        for f,label in zip(CHECK_FIELDS, labels):
            if label not in ALLOWED_BINARY:
                short_flag(flags,cid,'high','invalid_binary_label',f,'Enter only 0, 1, uncertain, defer or blank.')
            if label in ('0','1'):
                label_counts[f]+=1
        if truth in ('yes','no','unknown') or any(x in ('0','1') for x in labels):
            labeled_cases+=1
        if truth in ('yes','no','unknown') and all(x in ('0','1') for x in labels):
            complete_cases+=1
        if labels.count('1') >= 5:
            short_flag(flags,cid,'high','five_or_six_errors_marked','six_checks',
                'Independently re-evaluate each error definition. Do not mark all error checks as 1 simply because truth may be wrong.')
        try:
            quotes = parse_quotes(row.get('baseline_evidence'))
            note_norm = norm(row['patient_note_PRIVATE_DO_NOT_UPLOAD'])
            missing_quotes = [q for q in quotes if norm(q) and norm(q) not in note_norm]
            mechanical = '1' if missing_quotes else '0'
            marked = (row.get('gold_nonverbatim_quote') or '').strip().lower()
            if marked in ('0','1') and marked != mechanical:
                short_flag(flags,cid,'high','quoted_evidence_literal_mismatch','gold_nonverbatim_quote',
                    'Mechanical exact quote check disagrees with human label. Recheck punctuation/whitespace; no clinical inference.')
            if not quotes and marked == '1':
                short_flag(flags,cid,'high','no_quote_but_nonverbatim_error_marked','gold_nonverbatim_quote',
                    'No quotation was supplied, so it cannot be a nonverbatim quote.')
        except (ValueError, TypeError):
            short_flag(flags,cid,'high','unparseable_baseline_evidence','baseline_evidence',
                'Source evidence list is malformed. Do not rewrite the source without checking original.')
        support_quote = norm(row.get('verified_supporting_quote'))
        if support_quote and support_quote not in norm(row['patient_note_PRIVATE_DO_NOT_UPLOAD']):
            short_flag(flags,cid,'high','support_quote_not_found_in_note','verified_supporting_quote',
                'Entered supporting quote is not verbatim in the source note. Review locally.')
        conservative_rule_hints(row,flags)
    if sum(truth_counts.values()) >= 10 and len(truth_counts) == 1:
        # global warning only; provide no individual labels
        global_warning='All definite truth labels have the same value. Recheck for systematic yes/no response bias.'
    else: global_warning='Definite truth labels have multiple values or sample is small.'
    severity={'high':0,'review':1,'info':2}
    flags=sorted(flags,key=lambda r:(severity.get(r['priority'],99),r['case_id'],r['issue']))
    for item in flags:case_priority[item['case_id']]+=1
    report={
        'status':'audited','working_rows':len(rows),'original_rows':len(originals),
        'source_columns_unchanged':True,'cases_with_any_binary_or_definite_truth':labeled_cases,
        'fully_binary_labeled_cases_with_definite_truth':complete_cases,
        'truth_counts':dict(truth_counts),'binary_check_counts':dict(label_counts),
        'issue_count':len(flags),'cases_with_issues':len(case_priority),
        'priority_breakdown':dict(Counter(f['priority'] for f in flags)),
        'issue_types':dict(Counter(f['issue'] for f in flags)),
        'global_warning':global_warning,
        'working_sha256':sha256(p),'original_sha256':sha256(b),
        'critical_limitation':'Mechanical flags are not verified clinical judgments. No clinical labels were changed.'
    }
    return report, flags


def artifact_inventory(root):
    tracked={}
    for key, spec in KNOWN_ARTIFACTS.items():
        p=root/spec
        info={'path':spec, 'exists':p.exists(), 'kind':'directory' if p.is_dir() else 'file' if p.is_file() else 'missing'}
        if p.is_file():
            info['bytes']=p.stat().st_size
            if key in HASHED_KNOWN:
                info['sha256']=sha256(p)
        tracked[key]=info
    scripts=[]
    code_dir = root/'code'
    if code_dir.is_dir():
        # No recursion into potentially huge datasets; code only.
        for p in sorted(code_dir.rglob('*.py')):
            if p.is_file() and len(p.relative_to(code_dir).parts) <= 4:
                scripts.append({'path':rel(root,p),'bytes':p.stat().st_size,'sha256':sha256(p)})
    datasets={}
    for dataset in ('nsclc100','sigir204'):
        d=root/'datasets'/dataset
        datasets[dataset]={'exists':d.is_dir(),'entries':[]}
        if d.is_dir():
            for p in sorted(d.iterdir()):
                if p.is_file():
                    datasets[dataset]['entries'].append({'filename':p.name,'bytes':p.stat().st_size})
    # Never enumerate/traverse test partitions or read their contents.
    return {
        'status':'metadata_and_known_artifact_checksums_only',
        'tracked_artifacts':tracked,'code_python_files':scripts,
        'dataset_directory_metadata_only':datasets,
        'not_done':'No held-out content was read; dataset file sizes do not establish dataset correctness.'
    }


def baseline_audit(root):
    reports={}; combined_count=0
    combined_pairs=0
    for key,(rp,count,pairs) in EXPECTED.items():
        p=root/rp
        if not p.is_file():
            reports[key]={'status':'MISSING','expected_rows':count,'expected_pairs':pairs}
            continue
        info=read_jsonl_summary(p,count)
        info['expected_pairs']=pairs
        info['pair_count_matches']=info['unique_pair_count']==pairs
        info['status']='PASS' if info['row_count_matches'] and info['pair_count_matches'] and info['duplicate_pair_criterion_keys']==0 and info['unparseable_or_missing_id_rows']==0 else 'CHECK'
        reports[key]=info
        combined_count += info['rows']
        combined_pairs += info['unique_pair_count']
    # CSV development outputs: count and structural uniqueness only.
    csv_targets={
        'six_check_slots':('outputs/evidence_checks/unified_six_checks_20261017_131121_594627/unified_six_checks.csv',1940),
        'impact_rows':('outputs/decision_impact/real_priority_analysis.csv',1940),
        'ranked_rows':('outputs/priority_comparison/priority_rankings.csv',9700),
    }
    other={}
    for name,(path, expected) in csv_targets.items():
        p=root/path
        if not p.is_file():
            other[name]={'status':'MISSING','expected_rows':expected};continue
        fields, rows=read_csv(p)
        other[name]={'status':'PASS' if len(rows)==expected else 'CHECK','rows':len(rows),
                     'expected_rows':expected,'columns':fields,'sha256':sha256(p)}
        if name=='impact_rows' and {'dataset','pair_idx','crit_idx','verdict'}.issubset(fields):
            unique=set((r['dataset'],r['pair_idx'],r['crit_idx']) for r in rows)
            other[name]['unique_criterion_keys']=len(unique)
            other[name]['duplicate_criterion_keys']=len(rows)-len(unique)
            other[name]['unique_pairs']=len({(r['dataset'],r['pair_idx']) for r in rows})
            other[name]['decision_verdict_counts']=dict(Counter(r['verdict'] for r in rows))
    synthetic_p=root/'outputs/research_completion_sprint/cpu_guarded_synthetic_20261021_223247_656178/synthetic_results.jsonl'
    synthetic={'status':'MISSING'}
    if synthetic_p.is_file():
        r=read_jsonl_summary_generic(synthetic_p)
        synthetic={'status':'PASS' if r['rows']==42 and not r['unparseable_lines'] else 'CHECK',**r}
    return {'status':'development_artifact_validation','datasets':reports,'development_totals':{
        'criteria_records_found':combined_count,'pairs_found':combined_pairs,
        'target_criteria':1940,'target_pairs':152},'other_outputs':other,
        'synthetic_outputs':synthetic,
        'important':'These are integrity checks, NOT evaluation accuracy or independent six-checker accuracy.'}


def read_jsonl_summary_generic(path):
    rows=0; bad=0; cases=set(); duplicate=0
    with path.open(encoding='utf-8') as f:
        for line in f:
            if not line.strip():continue
            rows+=1
            try:
                r=json.loads(line)
                if not isinstance(r,dict):raise ValueError()
            except ValueError:
                bad+=1;continue
            k=r.get('case_idx', r.get('trap_id'))
            if k in cases: duplicate+=1
            cases.add(k)
    return {'rows':rows,'unparseable_lines':bad,'duplicate_case_keys':duplicate,'sha256':sha256(path)}


def write_json(p,obj):
    with p.open('x',encoding='utf-8') as f:
        json.dump(obj,f,ensure_ascii=False,indent=2,sort_keys=True)
        f.write('\n')


def write_csv(p, rows, fields):
    with p.open('x',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='raise')
        w.writeheader();w.writerows(rows)


def create_dir(root):
    parent=root/'outputs'/'research_completion_sprint'
    if not parent.is_dir():
        raise ValueError('Expected sprint outputs directory is missing; check --root')
    run='day1_integrity_audit_' + dt.datetime.now(dt.timezone.utc).strftime('%Y%m%d_%H%M%S_%f')
    out=parent/run
    out.mkdir(mode=0o700)
    os.chmod(out,0o700)
    return out


def self_test():
    assert truth_to_verdict('yes','inclusion')=='met'
    assert truth_to_verdict('no','inclusion')=='not_met'
    assert truth_to_verdict('yes','exclusion')=='not_met'
    assert truth_to_verdict('unknown','exclusion')=='not_stated'
    assert norm(' a\n  b ')== 'a b'
    assert parse_quotes('["quoted evidence"]')==['quoted evidence']
    x=[]
    conservative_rule_hints({'case_id':'TEST-1','gold_criterion_truth':'yes',
                             'criterion_text':'Age ≥18 years.',
                             'patient_note_PRIVATE_DO_NOT_UPLOAD':'A 55-year-old patient.'},x)
    assert any(f['issue']=='numeric_rule_support_candidate' for f in x)
    x=[]
    conservative_rule_hints({'case_id':'TEST-2','gold_criterion_truth':'yes',
                             'criterion_text':'FEV1 with ≥ 1200 cc or ≥ 50% predicted',
                             'patient_note_PRIVATE_DO_NOT_UPLOAD':'FEV1 of 1100 cc (48% predicted).'},x)
    assert any(f['issue']=='numeric_threshold_conflict_candidate' for f in x)
    print('SELF-TEST PASS: 8 checks. No project files modified, no inference.')


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root',type=Path,default=Path.cwd())
    ap.add_argument('--task',choices=['inventory','baseline','annotations','all'],default='all')
    ap.add_argument('--self-test',action='store_true')
    a=ap.parse_args()
    if a.self_test:
        self_test();return
    root=a.root.expanduser().resolve()
    if not (root/'code/criteria.py').is_file() or not (root/'outputs').is_dir():
        raise ValueError('Wrong MTP project root (code/criteria.py and outputs/ required).')
    os.umask(0o077)
    # Calculate first: if the working CSV is corrupt, fail BEFORE generating a misleading report.
    jobs={}
    if a.task in ('inventory','all'): jobs['inventory']=artifact_inventory(root)
    if a.task in ('baseline','all'): jobs['baseline']=baseline_audit(root)
    if a.task in ('annotations','all'):
        audit,flags=annotation_audit(root)
        jobs['annotations']=audit
    else: flags=[]
    out=create_dir(root)
    if 'inventory' in jobs:write_json(out/'01_frozen_input_inventory_NO_NOTES.json',jobs['inventory'])
    if 'baseline' in jobs:write_json(out/'02_development_baseline_integrity_NO_NOTES.json',jobs['baseline'])
    if 'annotations' in jobs:
        write_json(out/'03_annotation_quality_summary_NO_NOTES.json',jobs['annotations'])
        cols=['case_id','priority','issue','field','reviewer_instruction']
        write_csv(out/'04_priority_recheck_queue_NO_NOTES.csv',flags,cols)
        priority=defaultdict(lambda: {'high':0,'review':0,'info':0})
        for f in flags:priority[f['case_id']][f['priority']]+=1
        queue=sorted(priority.items(),key=lambda x:(-x[1]['high'],-x[1]['review'],x[0]))
        write_csv(out/'05_recheck_order_NO_NOTES.csv',[
            {'case_id':cid,'high_priority_issues':cnt['high'],'other_issues':cnt['review']+cnt['info']}
            for cid,cnt in queue],['case_id','high_priority_issues','other_issues'])
    readme=(
        'MTP DAY 1 - OFFLINE RESEARCH AUDIT\n'
        'All output reports exclude clinical notes, criterion text, quoted clinical evidence and rationale.\n'
        'Patient-note content is read locally ONLY for in-memory validation; never exported.\n'
        'Datasets directory entries are inventoried by file metadata ONLY; test contents untouched.\n'
        'All source files remain unchanged. No model calls, no network, no held-out scoring.\n'
        '01 is a SHA-based INPUT MANIFEST, NOT a frozen scientific methodology.\n'
        '02 is a baseline output integrity report, NOT measured accuracy.\n'
        '03 is mechanical annotation quality and label distributions, NOT clinical gold.\n'
        '04 and 05 prioritize LOCAL HUMAN re-review; NO automatic clinical corrections.\n'
        'Suggested local command for each case:\n'
        'python3 ~/Downloads/MTP_targeted_recheck.py --root ~/MTP/Akash_Kit --review --case REVIEW-016\n'
        'For rules: criterion truth is whether the CONDITION is present (including EXCLUSION conditions);\n'
        'unknown means not established from the note; do not infer no from missing evidence.\n'
        'Quotes and clinical judgments need human / domain-expert review.\n'
    )
    (out/'README_NEXT_STEPS_NO_NOTES.txt').write_text(readme,encoding='utf-8')
    print('=== MTP DAY 1 AUDIT ===')
    print('OUTPUT:',out)
    if 'baseline' in jobs:
        for name,item in jobs['baseline']['datasets'].items():
            print(name, 'status:',item['status'],'records:',item.get('rows','MISSING'),
                  'pairs:',item.get('unique_pair_count','MISSING'))
    if 'annotations' in jobs:
        r=jobs['annotations']
        print('REVIEW:',r.get('cases_with_any_binary_or_definite_truth'),'labeled cases;',
              r.get('issue_count'),'issues across',r.get('cases_with_issues'),'cases')
        print('TRUTHS:',r.get('truth_counts'))
    print('No existing data modified. Zero model calls. Held-out contents untouched.')
    print('IMPORTANT: Manual clinical review required to correct the labels.')

if __name__=='__main__':
    try:main()
    except (ValueError,OSError,KeyError,TypeError,json.JSONDecodeError) as e:
        print('AUDIT STOPPED:',type(e).__name__,str(e),file=sys.stderr)
        sys.exit(2)
