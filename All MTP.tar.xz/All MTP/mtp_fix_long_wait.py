#!/usr/bin/env python3
"""Fix V3's Retry-After classification. No model calls or experiment changes."""
import argparse, ast, datetime, fcntl, os
from pathlib import Path

OLD="    if 'http 429' in m: return 'rate_limit'"
NEW="    if 'http 429' in m or ('long wait' in m and 'retry-after' in m): return 'rate_limit'"

def patched(source):
    if NEW in source:return source,False
    if source.count(OLD)!=1:raise ValueError('Unexpected V3 version; nothing changed.')
    text=source.replace(OLD,NEW,1)
    compile(text,'mtp_supervisor_v3.py','exec')
    tree=ast.parse(text);classifier=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='classify')
    scope={};exec(compile(ast.Module(body=[classifier],type_ignores=[]),'<classifier>','exec'),scope)
    cases={'Server requests a long wait; resume later. Retry-After=104':'rate_limit',
           'Groq HTTP 429':'rate_limit','Groq HTTP 503':'server_error',
           'API attempt budget reached':'budget','Groq HTTP 401':'credentials_or_access',
           'Invalid support label':'validation_or_configuration'}
    for message,expected in cases.items():
        if scope['classify'](message)!=expected:raise ValueError('Classifier regression: '+message)
    return text,True

def main():
    a=argparse.ArgumentParser(description=__doc__);a.add_argument('--root',type=Path,default=Path.home()/'MTP/Akash_Kit');args=a.parse_args()
    root=args.root.expanduser().resolve();target=root/'mtp_supervisor_v3.py'
    if not target.is_file():raise SystemExit('Missing installed V3: '+str(target))
    base=root/'outputs/mtp_supervisor';base.mkdir(parents=True,exist_ok=True)
    with (base/'supervisor.lock').open('a') as lock:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise SystemExit('V3 is still active. Stop V3 cleanly before patching; do not touch Qwen/SIGIR jobs.')
        old=target.read_text();new,changed=patched(old)
        if not changed:print('Retry-After fix already installed.');return
        backup=target.with_name(target.name+'.before_retry_fix_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
        backup.write_text(old);os.chmod(backup,0o600)
        temporary=target.with_suffix('.retry.tmp');temporary.write_text(new);os.chmod(temporary,0o600);temporary.replace(target)
    print('FIXED: server-requested long waits now trigger rate-limit backoff.')
    print('Six classification checks passed. Existing Retry-After waiting logic retained.')
    print('Backup:',backup)
    print('No API calls. Predictions, statements, labels, checkpoints and keys unchanged.')
if __name__=='__main__':
    try:main()
    except ValueError as e:raise SystemExit(str(e))
