#!/usr/bin/env python3
"""MTP local synthetic Qwen probe runner, designed for cautious laptop retry.

- Only the pre-existing 42 *fictional/synthetic* prompts, never patient records.
- Local Ollama HTTP 127.0.0.1 only. No external APIs or model downloads.
- Serial CPU-only requests (num_gpu=0), 2 inference threads, 1k context.
- Lower-memory preflight, bounded per-request timeout, cooldown, append/fsync.
- --max-cases 1 for attended preflight; --max-cases 42 --resume same dir afterward.
- CANNOT guarantee protection from a kernel/GPU/hardware freeze.
- Synthetic agreement is NOT clinical gold or verified repair.
"""
import argparse
import ast
import datetime
import json
import os
import re
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

DEFAULT_SRC = ('outputs/research_completion_sprint/'
               'overnight_safe_20261020_223633/synthetic_42_cases.jsonl')
FIELD_NAMES = ('case_idx','trial_id','crit_idx','criterion','note','trap_type',
               'expected_truth_after','synthetic_constructed','checked_by_hand')
EXPECTED_TYPES = {'NEGATION','FAMILY_HISTORY','HYPOTHETICAL','OLD_VALUE',
                  'CONTRADICTION','EVIDENCE_REMOVED','THRESHOLD_SHIFT'}
LOCAL_API = 'http://127.0.0.1:11434/api/'


def available_gib():
    mem = {}
    with open('/proc/meminfo', encoding='utf-8') as f:
        for line in f:
            k, _, val = line.partition(':')
            if k in ('MemAvailable', 'SwapFree', 'MemTotal'):
                mem[k] = int(val.strip().split()[0]) / 1024**2
    return mem


def api(path, payload=None, timeout=12):
    data = None if payload is None else json.dumps(payload).encode('utf-8')
    req = urllib.request.Request(LOCAL_API + path, data=data,
        headers={'Content-Type':'application/json'},method='GET' if data is None else 'POST')
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.load(resp)


def extract_system_prompt(root):
    source = root/'code'/'plain_ai.py'
    tree = ast.parse(source.read_text(encoding='utf-8'))
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'SYSTEM_PROMPT'
                                                 for t in node.targets):
            val = ast.literal_eval(node.value)
            if isinstance(val,str) and 'truth' in val and 'evidence' in val:
                return val
    raise ValueError('Could not extract plain_ai.py baseline SYSTEM_PROMPT. Stop.')


def load_probes(p):
    probes=[]
    with p.open(encoding='utf-8') as f:
        for line in f:
            if line.strip(): probes.append(json.loads(line))
    if len(probes)!=42 or set(r['trap_type'] for r in probes)!=EXPECTED_TYPES:
        raise ValueError('Expected exactly 42 synthetic cases across seven categories')
    if any(not all(k in r for k in FIELD_NAMES) for r in probes):
        raise ValueError('Synthetic case fields missing')
    if any(r['case_idx']!=i or r['trial_id']!='T01' or r['synthetic_constructed'] is not True
           or r['checked_by_hand'] is not False or r['expected_truth_after'] not in ('yes','no','unknown')
           for i,r in enumerate(probes)):
        raise ValueError('Unexpected protocol/identifiers: stopped to prevent using clinical notes')
    if any(len(r['note']) > 1200 for r in probes):
        raise ValueError('Unexpectedly long notes; stopped to avoid accidentally using real records')
    return probes


def parse_truth(raw):
    if not isinstance(raw, str): return None
    text = raw.strip()
    try: obj=json.loads(text)
    except ValueError:
        try:
            pos=text.index('{'); obj,_=json.JSONDecoder().raw_decode(text[pos:])
        except (ValueError,IndexError): return None
    if not isinstance(obj,dict): return None
    truth=str(obj.get('truth') or '').strip().lower()
    return truth if truth in ('yes','no','unknown') else None


def append_atomic_line(f, rec):
    f.write(json.dumps(rec,ensure_ascii=False)+'\n')
    f.flush(); os.fsync(f.fileno())


def selftest():
    assert parse_truth('{"truth":"yes","evidence":[]}')=='yes'
    assert parse_truth('```json\n{"truth":"unknown"}\n```')=='unknown'
    assert parse_truth('{"truth":"maybe"}') is None
    assert {'NEGATION','CONTRADICTION'} <= EXPECTED_TYPES
    print('SELF-TEST PASS: parsing and synthetic-only safeguards; no files changed or model calls.')


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root',type=Path,default=Path.cwd())
    ap.add_argument('--probes',type=Path,default=Path(DEFAULT_SRC))
    ap.add_argument('--resume',type=Path,help='Existing report directory for continuation')
    ap.add_argument('--max-cases',type=int,default=1,help='1 attended first; 42 after successful test')
    ap.add_argument('--model',default='qwen2.5:7b')
    ap.add_argument('--request-timeout',type=int,default=240)
    ap.add_argument('--cooldown-seconds',type=int,default=30)
    ap.add_argument('--self-test',action='store_true')
    args=ap.parse_args()
    if args.self_test: selftest();return
    if not 1<=args.max_cases<=42 or not 30<=args.request_timeout<=600:
        raise ValueError('Unsupported limits')
    root=args.root.expanduser().resolve()
    source=(root/args.probes).resolve() if not args.probes.is_absolute() else args.probes.resolve()
    if not source.is_file(): raise FileNotFoundError(f'Missing synthetic-only probe input: {source}')
    probes=load_probes(source)
    system=extract_system_prompt(root)
    if args.model != 'qwen2.5:7b':
        raise ValueError('This script expects qwen2.5:7b; do not silently alter the comparison')
    status=available_gib()
    print('START RAM GiB:',{k:round(v,2) for k,v in status.items()},flush=True)
    if status.get('MemAvailable',0)<9.0:
        raise RuntimeError('Need 9+ GiB available before launching model; refused')
    tags=api('tags')
    models={m.get('name','') for m in tags.get('models',[])}
    if 'qwen2.5:7b' not in models and not any(n.startswith('qwen2.5:7b-') for n in models):
        raise RuntimeError('qwen2.5:7b is not locally downloaded; do not download in this run')
    if args.resume:
        out=args.resume.expanduser().resolve()
        if not out.is_dir(): raise ValueError('Resume dir does not exist')
        conf=json.loads((out/'run_config.json').read_text())
        if conf.get('source')!=str(source) or conf.get('model')!=args.model:
            raise ValueError('Resume config differs; stopped')
    else:
        stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
        out=root/'outputs'/'research_completion_sprint'/('cpu_guarded_synthetic_'+stamp)
        out.mkdir(mode=0o700,parents=True,exist_ok=False)
        os.chmod(out,0o700)
        (out/'run_config.json').write_text(json.dumps({
            'source':str(source),'model':args.model,'num_gpu':0,'num_ctx':1024,
            'num_thread':2,'num_predict':160,'temperature':0,
            'warning':'Synthetic expectation only, no expert gold, no clinical correction.'},indent=2)+'\n')
        os.chmod(out/'run_config.json',0o600)
    result_path=out/'synthetic_results.jsonl'
    done={}
    if result_path.is_file():
        for line in result_path.read_text(encoding='utf-8').splitlines():
            if not line.strip(): continue
            rec=json.loads(line)
            ix=rec['case_idx']
            if ix in done: raise RuntimeError('Duplicate saved case, refusing to continue')
            if not 0<=ix<42:raise RuntimeError('Unexpected saved case_idx')
            done[ix]=rec
    if any(ix>=args.max_cases for ix in done):
        print('Saved results exceed requested --max-cases; no work to do.',flush=True)
        return
    print('RUN DIR:',out,flush=True)
    print('EXISTING SAVED CASES:',len(done), 'TARGET CASES:',args.max_cases,flush=True)
    print('CPU-ONLY requested (num_gpu=0), 2 threads, sequential, context=1024.',flush=True)
    print('HARD FREEZE CANNOT BE PREVENTED by a Python time limit.',flush=True)
    with result_path.open('a',encoding='utf-8') as f:
        os.chmod(result_path,0o600)
        for r in probes[:args.max_cases]:
            i=r['case_idx']
            if i in done:continue
            s=available_gib()
            if s.get('MemAvailable',0)<6.0:
                print('STOP: available RAM under 6 GiB:',round(s['MemAvailable'],2),flush=True)
                return
            payload={'model':args.model,'system':system,
                     'prompt':'CONDITION: '+r['criterion']+'\nNOTE: '+r['note'],
                     'stream':False,'format':'json',
                     'options':{'temperature':0,'num_ctx':1024,'num_predict':160,
                                'num_thread':2,'num_gpu':0},
                     'keep_alive':0}
            print('CASE',i+1,'/',args.max_cases,r['trap_type'],'RAM_AVAILABLE_GiB',round(s['MemAvailable'],2),flush=True)
            start=time.monotonic()
            try:
                response=api('generate',payload,timeout=args.request_timeout)
                result=parse_truth(response.get('response'))
            except (urllib.error.HTTPError,urllib.error.URLError,TimeoutError,ValueError) as e:
                print('STOP: model request failed:',type(e).__name__,str(e)[:180],flush=True)
                return
            elapsed=round(time.monotonic()-start,2)
            rec={'case_idx':i,'trap_id':r['trap_id'],'trap_type':r['trap_type'],
                 'expected_truth_synthetic_not_gold':r['expected_truth_after'],
                 'predicted_truth':result,'agreement':bool(result==r['expected_truth_after']) if result else None,
                 'seconds':elapsed,'model':'qwen2.5:7b','cpu_only_requested':True,
                 'status':'ok' if result else 'unparseable'}
            append_atomic_line(f,rec)
            print('SAVED:',r['trap_id'],'prediction=',result,'seconds=',elapsed,flush=True)
            if i+1<args.max_cases:
                time.sleep(args.cooldown_seconds)
    print('FINISHED:',result_path,flush=True)
    print('Expected answers are SYNTHETIC CONSTRUCTIONS, not independently verified clinical truth.',flush=True)

if __name__=='__main__':
    try: main()
    except (KeyboardInterrupt,Exception) as e:
        print('ERROR:',type(e).__name__,str(e),file=sys.stderr,flush=True)
        sys.exit(2)
