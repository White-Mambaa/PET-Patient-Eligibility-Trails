#!/usr/bin/env python3
"""MTP DAY-1 WRAP-UP: cautious offline automation + fast human recheck.

Usage (from ~/MTP/Akash_Kit):
  python3 ~/Downloads/MTP_day1_wrapup.py --self-test
  python3 ~/Downloads/MTP_day1_wrapup.py --root "$PWD" --auto
  python3 ~/Downloads/MTP_day1_wrapup.py --root "$PWD" --review
  python3 ~/Downloads/MTP_day1_wrapup.py --root "$PWD" --finalize

--auto: backups, executes EXISTING Day1 audit, builds detailed mechanical review
       diagnostics and a note-free completion report. NEVER edits clinical labels.
--review: single-case-per-screen interactive fast review, requires human confirmation,
          saves private worksheet atomically with backup, leaves uncertain as uncertain.
--finalize: executes audit again and reports which Day1 requirements are still blocked.
No Ollama, GPU, network, test-partition content, or inferred gold labels.
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from collections import Counter, defaultdict
from pathlib import Path

REVIEW_DIR = Path('outputs/research_completion_sprint/adjudication_20261020_163130_107196')
WORK = 'PRIVATE_TERMINAL_REVIEW_WORKING.csv'
ORIGINAL = 'PRIVATE_STAGE2_BASELINE_VISIBLE_REVIEW.csv'
SPRINT = Path('outputs/research_completion_sprint')
FIELDS = ('gold_nonverbatim_quote','gold_unsupported_evidence','gold_context_error',
          'gold_logic_error','gold_contradiction','gold_missed_evidence')
TRUTH = ('yes','no','unknown','uncertain','defer')
CHECK = ('0','1','uncertain','defer')
LABELS = ('gold_criterion_truth',) + FIELDS
IMMUTABLE = ('case_id','dataset','pair_idx','crit_idx','criterion_kind','criterion_text',
             'patient_note_PRIVATE_DO_NOT_UPLOAD','baseline_truth','baseline_verdict',
             'baseline_evidence','baseline_rationale')


def checksum(path: Path) -> str:
    d = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            d.update(chunk)
    return d.hexdigest()


def read_csv(path: Path):
    with path.open('r',encoding='utf-8-sig', newline='') as f:
        rd = csv.DictReader(f)
        fields = rd.fieldnames
        if not fields or len(fields) != len(set(fields)):
            raise ValueError('Missing or duplicate CSV columns in '+str(path))
        rows = list(rd)
    if any(None in row or any(v is None for v in row.values()) for row in rows):
        raise ValueError('Malformed row/column count in '+str(path))
    return fields, rows


def validate(root: Path):
    if not (root/'code/criteria.py').is_file():
        raise ValueError('Wrong project root. Expected code/criteria.py')
    f = root/REVIEW_DIR/WORK
    o = root/REVIEW_DIR/ORIGINAL
    if not f.is_file() or not o.is_file():
        raise FileNotFoundError('Missing existing working/original private review files')
    cols, rows = read_csv(f)
    _, origins = read_csv(o)
    required=set(IMMUTABLE)|set(LABELS)|{'gold_criterion_verdict','verified_supporting_quote','correction_reviewer_notes'}
    if required-set(cols):
        raise ValueError('Missing review columns: '+str(sorted(required-set(cols))))
    if len(rows)!=49 or len(origins)!=49:
        raise ValueError('49 cases required; source integrity uncertain')
    old={r['case_id']:r for r in origins}
    if len(old)!=49 or len({r['case_id'] for r in rows})!=49 or {r['case_id'] for r in rows} != set(old):
        raise ValueError('Missing/duplicate/mismatched review case IDs')
    for row in rows:
        for field in IMMUTABLE:
            if row[field] != old[row['case_id']][field]:
                raise ValueError('Original patient/source column changed for '+row['case_id']+': '+field)
        if row['criterion_kind'].strip().lower() not in ('inclusion','exclusion'):
            raise ValueError('Unexpected criterion kind')
    return f, o, cols, rows


def norm(s):
    return re.sub(r'\s+',' ',str(s or '')).strip()


def parse_evidence(text):
    obj = json.loads(text or '[]')
    if isinstance(obj,str): obj=[obj]
    if not isinstance(obj,list) or not all(isinstance(e,str) for e in obj):
        raise ValueError('Evidence not a list of strings')
    return obj


def quote_status(row):
    try:
        ev = parse_evidence(row.get('baseline_evidence',''))
    except (ValueError,TypeError):
        return 'UNPARSEABLE',None,0
    note = norm(row['patient_note_PRIVATE_DO_NOT_UPLOAD'])
    nonempty = [q for q in ev if norm(q)]
    absent = sum(norm(q) not in note for q in nonempty)
    return ('NO_QUOTES' if not nonempty else 'MATCH' if absent==0 else 'MISMATCH'), ('1' if absent else '0'), len(nonempty)


def map_verdict(truth,kind):
    if truth=='unknown':return 'not_stated'
    if truth not in ('yes','no') or kind not in ('inclusion','exclusion'):
        raise ValueError('Invalid criterion truth/kind')
    return ('met' if truth=='yes' else 'not_met') if kind=='inclusion' else ('not_met' if truth=='yes' else 'met')


def backup_private(file):
    dest=file.with_name('PRIVATE_DAY1_BACKUP_'+dt.datetime.now(dt.timezone.utc).strftime('%Y%m%d_%H%M%S_%f')+'.csv')
    shutil.copy2(file,dest)
    os.chmod(dest,0o600)
    return dest


def write_csv_atomic(path,columns,rows):
    fd,name=tempfile.mkstemp(prefix='.day1_',suffix='.csv',dir=str(path.parent))
    try:
        with os.fdopen(fd,'w',encoding='utf-8',newline='') as f:
            w=csv.DictWriter(f,fieldnames=columns,extrasaction='raise')
            w.writeheader(); w.writerows(rows)
            f.flush(); os.fsync(f.fileno())
        os.chmod(name,0o600)
        os.replace(name,str(path))
    finally:
        if os.path.exists(name):os.unlink(name)


def latest_day1(root):
    dirs = sorted((root/SPRINT).glob('day1_integrity_audit_*'),key=lambda p:p.stat().st_mtime,reverse=True)
    for d in dirs:
        if all((d/n).is_file() for n in ('01_frozen_input_inventory_NO_NOTES.json',
                    '02_development_baseline_integrity_NO_NOTES.json',
                    '03_annotation_quality_summary_NO_NOTES.json',
                    '04_priority_recheck_queue_NO_NOTES.csv')):
            return d
    raise ValueError('No complete Day1 audit found; run --auto first')


def rerun_base_audit(root):
    script=Path.home()/'Downloads'/'MTP_day1_integrity_audit.py'
    if not script.is_file():
        # Fallback to script placed next to this one by user; never install packages.
        script=Path(__file__).with_name('MTP_day1_integrity_audit.py')
    if not script.is_file():
        raise FileNotFoundError('Previous audit missing. Save MTP_day1_integrity_audit.py in ~/Downloads')
    cmd=[sys.executable,str(script),'--root',str(root),'--task','all']
    p=subprocess.run(cmd,text=True,capture_output=True,check=False,timeout=180)
    if p.returncode!=0:
        raise RuntimeError('Previous audit failed: '+p.stderr[-1000:])
    print(p.stdout.strip())
    return latest_day1(root)


def get_flags(day1):
    _,flags=read_csv(day1/'04_priority_recheck_queue_NO_NOTES.csv')
    by_case=defaultdict(list)
    for flag in flags:by_case[flag['case_id']].append(flag)
    return flags,by_case


def write_json(path,obj):
    with path.open('x',encoding='utf-8') as f:
        json.dump(obj,f,indent=2,ensure_ascii=False,sort_keys=True)
        f.write('\n')


def write_csv_new(path,fields,rows):
    with path.open('x',encoding='utf-8',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=fields)
        writer.writeheader();writer.writerows(rows)


def make_report(root,day1,backup=None):
    file,orig,cols,rows=validate(root)
    baseline=json.loads((day1/'02_development_baseline_integrity_NO_NOTES.json').read_text())
    qa=json.loads((day1/'03_annotation_quality_summary_NO_NOTES.json').read_text())
    flags,by_case=get_flags(day1)
    if qa['working_sha256']!=checksum(file) or qa['original_sha256']!=checksum(orig):
        raise RuntimeError('Concurrent review edit detected after audit. Retry --auto / --finalize.')
    records=[]; suggestions=[]
    for row in rows:
        cid=row['case_id']
        state, quote_value, num=quote_status(row)
        current=(row.get('gold_nonverbatim_quote') or '').strip()
        definite=(row.get('gold_criterion_truth') or '').strip().lower()
        reasons=[f['issue'] for f in by_case.get(cid,[])]
        labels=[str(row.get(k) or '').strip().lower() for k in FIELDS]
        auto_hint=''
        if quote_value is not None and current in ('0','1') and current!=quote_value:
            auto_hint='QUOTE FLAG CONFLICT: quote literal check is '+quote_value+'; request human confirmation'
        records.append({'case_id':cid,'review_started':'YES' if any(x in ('0','1') for x in labels) or definite in ('yes','no','unknown') else 'NO',
            'criterion_truth_entered':definite,'binary_check_entries':sum(x in ('0','1') for x in labels),
            'verified_support_quote_present':'YES' if norm(row.get('verified_supporting_quote')) else 'NO',
            'baseline_quote_status':state,'baseline_quotes':num,'literal_quote_flag_candidate':quote_value or '',
            'entered_nonverbatim_flag':current,'high_priority_warning_count':sum(f['priority']=='high' for f in by_case.get(cid,[])),
            'all_warning_types':'|'.join(sorted(set(reasons))),
            'automated_review_hint':auto_hint})
        if auto_hint:suggestions.append(cid)
    records.sort(key=lambda r:(-r['high_priority_warning_count'],r['case_id']))
    started=sum(r['review_started']=='YES' for r in records)
    definites=Counter(r['criterion_truth_entered'] for r in records if r['criterion_truth_entered'] in ('yes','no','unknown'))
    baseline_ok=all(baseline['datasets'].get(k,{}).get('status')=='PASS' for k in ('nsclc_dev','sigir_dev'))
    artifacts_ok=all(baseline['other_outputs'].get(k,{}).get('status')=='PASS' for k in ('six_check_slots','impact_rows','ranked_rows')) and baseline['synthetic_outputs'].get('status')=='PASS'
    report={
        'day':'Day 1 - baseline inventory and annotation review',
        'run_time_utc':dt.datetime.now(dt.timezone.utc).isoformat(),
        'baseline_records':baseline['development_totals']['criteria_records_found'],
        'development_pairs':baseline['development_totals']['pairs_found'],
        'baseline_integrity':'PASS' if baseline_ok else 'CHECK',
        'saved_experiment_artifacts':'PASS' if artifacts_ok else 'CHECK',
        'original_source_columns_unchanged':qa['source_columns_unchanged'],
        'annotation_cases_total':49,'annotation_cases_started':started,
        'annotation_cases_unstarted':49-started,
        'definite_truth_counts_unvalidated':dict(definites),
        'mechanical_qa_warnings':qa['issue_count'],
        'cases_flagged':qa['cases_with_issues'],
        'literal_quote_flag_disagreements':len(suggestions),
        'working_review_sha256':checksum(file),
        'baseline_manifest_directory':str(day1.relative_to(root)),
        'safe_backup_created':backup.name if backup else None,
        'automated_day1_sections_complete':baseline_ok and artifacts_ok and qa['source_columns_unchanged'],
        'human_clinical_corrections_complete':False,
        'scientific_limitation':'All definite human-entered truths currently need substantive review. Mechanically flagged quotes and terminology do not constitute clinical gold. The program does not infer/replace patient eligibility labels.',
        'held_out_test_accessed':False,
        'ollama_calls':0,
    }
    parent=root/SPRINT
    out=parent/('day1_wrapup_'+dt.datetime.now(dt.timezone.utc).strftime('%Y%m%d_%H%M%S_%f'))
    out.mkdir(mode=0o700)
    os.chmod(out,0o700)
    write_json(out/'DAY1_STATUS_NO_NOTES.json',report)
    write_csv_new(out/'RECHECK_49_CASES_NO_NOTES.csv',list(records[0].keys()),records)
    write_json(out/'INPUT_HASHES_NO_NOTES.json',{
        'baseline_nsclc_sha256':baseline['datasets']['nsclc_dev'].get('sha256'),
        'baseline_sigir_sha256':baseline['datasets']['sigir_dev'].get('sha256'),
        'review_original_sha256':checksum(orig),
        'review_working_sha256':checksum(file),
        'day1_report_sha256':checksum(day1/'02_development_baseline_integrity_NO_NOTES.json'),
    })
    message=(
        'MTP DAY 1 STATUS\n'
        'Automation is COMPLETE when baseline and output integrity PASS.\n'
        'Clinical annotation corrections are NOT automatically complete.\n'
        'Why: inference cannot safely determine absent clinical facts or independent reference labels.\n'
        'Use --review to inspect/confirm case-by-case; --finalize to regenerate QA and status.\n'
        'The 49-case worksheet and patient notes stay local/private; NO_NOTES reports contain only IDs and diagnostics.\n'
        'Do NOT use author-entered labels as independent expert gold; do NOT claim clinically verified repairs.\n'
        'No held-out test partition opened. No Ollama or internet calls.\n'
    )
    (out/'README_NEXT_STEP.txt').write_text(message,encoding='utf-8')
    print('\n=== DAY 1 WRAP-UP ===')
    print('OUTPUT:',out)
    print('Baseline:',report['baseline_integrity'],'records:',report['baseline_records'],'pairs:',report['development_pairs'])
    print('Saved six checks/impact/rankings/traps:',report['saved_experiment_artifacts'])
    print('Review started:',started,'/49; potential warnings:',report['mechanical_qa_warnings'],'across',report['cases_flagged'],'cases')
    print('Quote-flag conflicts:',len(suggestions))
    print('AUTOMATED WORK: ', 'COMPLETE' if report['automated_day1_sections_complete'] else 'INCOMPLETE')
    print('CLINICAL ANNOTATION RECHECK: STILL NEEDS QUALIFIED HUMAN CONFIRMATION')
    print('All generated reports omit clinical notes; original labels untouched by audit.')
    return out


def quick_review(root):
    file,orig,fields,rows=validate(root)
    day1=latest_day1(root)
    _,by_case=get_flags(day1)
    candidates=[i for i,r in enumerate(rows) if str(r.get('gold_criterion_truth') or '').strip().lower() in ('yes','no','unknown') or
            any(str(r.get(k) or '').strip().lower() in ('0','1') for k in FIELDS)]
    candidates.sort(key=lambda i:(-sum(f['priority']=='high' for f in by_case.get(rows[i]['case_id'],[])),rows[i]['case_id']))
    print('=== QUICK HUMAN RECHECK: ',len(candidates),'PREVIOUSLY ENTERED CASES ===')
    print('This is NOT autonomous clinical adjudication. Original note stays on this terminal.')
    print('Choices: truth yes/no/unknown/uncertain/defer; six flags 0/1/uncertain/defer.')
    print('Press ENTER to KEEP existing field. Type clear to BLANK the field. Type q to QUIT.')
    print('Do not accept automatic "yes" labels without clinical evidence.')
    made_backup=False; modified=0; confirmed=0
    for position,index in enumerate(candidates,1):
        r=rows[index]; cid=r['case_id']; warnings=by_case.get(cid,[])
        state, mechanical,_=quote_status(r)
        print('\n'+'='*65+'\nCASE',cid,f'({position}/{len(candidates)})',r['dataset'],'pair',r['pair_idx'],'criterion',r['crit_idx'])
        print('KIND:',r['criterion_kind'],'\nCRITERION:\n',r['criterion_text'])
        print('PRIVATE NOTE (local terminal only):\n',r['patient_note_PRIVATE_DO_NOT_UPLOAD'])
        print('BASELINE:',r['baseline_truth'],'/',r['baseline_verdict'])
        print('BASELINE EVIDENCE:',r['baseline_evidence'])
        print('BASELINE RATIONALE:',r['baseline_rationale'])
        print('MECHANICAL EXACT-QUOTE:',state,'=>',mechanical,'(NOT clinical accuracy)')
        print('WARNINGS:',', '.join(sorted(set(f['issue'] for f in warnings))) or 'none')
        print('CURRENT:', ', '.join(k+'='+repr(r.get(k,'')) for k in LABELS))
        try:
            action=input('Action [e=edit, s=skip, q=quit]: ').strip().lower()
        except (EOFError,KeyboardInterrupt):break
        if action in ('q','quit'):break
        if action not in ('e','edit'):continue
        new=dict(r)
        ok=True
        for field in LABELS:
            allowed=set(TRUTH if field=='gold_criterion_truth' else CHECK)
            while True:
                try: answer=input(field+' [current: '+str(new.get(field,''))+'] > ').strip().lower()
                except (EOFError,KeyboardInterrupt):ok=False;break
                if answer=='q':ok=False;break
                if answer=='':break
                if answer=='clear':new[field]='';break
                if answer not in allowed:print('Allowed:',', '.join(sorted(allowed)), 'or Enter/clear/q');continue
                new[field]=answer;break
            if not ok:break
        if not ok:break
        truth=(new.get('gold_criterion_truth') or '').strip().lower()
        new['gold_criterion_verdict']=map_verdict(truth,r['criterion_kind']) if truth in ('yes','no','unknown') else ''
        try:
            quote=input('Exact note supporting truth (Enter keep, clear blank): ')
            if quote.strip().lower()=='clear':new['verified_supporting_quote']=''
            elif quote: 
                if norm(quote) not in norm(r['patient_note_PRIVATE_DO_NOT_UPLOAD']):
                    print('QUOTE NOT FOUND IN NOTE: discard changes, use exact text.');continue
                new['verified_supporting_quote']=quote
            comment=input('Reviewer justification (Enter keep): ').strip()
            if comment:new['correction_reviewer_notes']=comment
        except (EOFError,KeyboardInterrupt):break
        if truth in ('yes','no') and not norm(new.get('verified_supporting_quote')):
            print('WARNING: definite yes/no has NO verified supporting quote. Prefer uncertainty unless justified.')
        if new==r:
            print('UNCHANGED. No correction recorded.');continue
        try: approval=input('TYPE SAVE to write ONLY this reviewed case [otherwise skip]: ').strip()
        except (EOFError,KeyboardInterrupt):break
        if approval!='SAVE':print('Skipped without saving.');continue
        if not made_backup:
            saved=backup_private(file)
            print('ORIGINAL REVIEW BACKUP:',saved)
            made_backup=True
        rows[index]=new
        write_csv_atomic(file,fields,rows)
        modified+=1;confirmed+=1
        print('SAVED:',cid,'; updated labels:',', '.join(f for f in LABELS if new.get(f)!=r.get(f)))
    print('\nRechecked changes saved:',modified,'; 49-source-row integrity preserved.')
    print('Now run --finalize to regenerate full QA; this was author review, not independent expert gold.')


def tests():
    assert map_verdict('yes','inclusion')=='met'
    assert map_verdict('yes','exclusion')=='not_met'
    assert map_verdict('no','exclusion')=='met'
    assert map_verdict('unknown','exclusion')=='not_stated'
    assert norm(' A  B\n')=='A B'
    row={'baseline_evidence':'["Exact text"]','patient_note_PRIVATE_DO_NOT_UPLOAD':'Exact text and another fact.'}
    assert quote_status(row)==('MATCH','0',1)
    row['baseline_evidence']='["unquoted words"]'
    assert quote_status(row)==('MISMATCH','1',1)
    row['baseline_evidence']='[]'
    assert quote_status(row)==('NO_QUOTES','0',0)
    row['baseline_evidence']='not-json'
    assert quote_status(row)[0]=='UNPARSEABLE'
    with tempfile.TemporaryDirectory() as d:
        file=Path(d)/'case.csv'
        write_csv_atomic(file,['case_id','gold_criterion_truth'],[{'case_id':'REVIEW-001','gold_criterion_truth':'unknown'}])
        _,rows=read_csv(file)
        assert rows[0]['gold_criterion_truth']=='unknown'
    print('SELF-TEST PASS: 10 checks; no model calls and no project files changed.')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=Path.cwd())
    group=p.add_mutually_exclusive_group(required=True)
    group.add_argument('--auto',action='store_true')
    group.add_argument('--review',action='store_true')
    group.add_argument('--finalize',action='store_true')
    group.add_argument('--self-test',action='store_true')
    a=p.parse_args()
    if a.self_test:
        tests();return
    root=a.root.expanduser().resolve()
    file,orig,_,_=validate(root)
    os.umask(0o077)
    if a.review:
        quick_review(root);return
    saved=backup_private(file) if a.auto else None
    if saved:print('Private working-sheet backup:',saved.name)
    audit=rerun_base_audit(root)
    out=make_report(root,audit,saved)
    print('Status file:',out/'DAY1_STATUS_NO_NOTES.json')

if __name__=='__main__':
    try:main()
    except (OSError,ValueError,RuntimeError,subprocess.TimeoutExpired,json.JSONDecodeError) as ex:
        print('STOPPED SAFELY:',type(ex).__name__,str(ex),file=sys.stderr)
        sys.exit(2)
