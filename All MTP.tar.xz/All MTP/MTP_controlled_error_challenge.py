#!/usr/bin/env python3
"""MTP: 2-hour local controlled-error sensitivity experiment (development data only).

Perturb ONLY copies of existing baseline screening answers; never modify clinical notes
or original experimental artifacts. Introduce objectively defined violations:
  LOGIC: a verdict incompatible with the unchanged stated truth and criterion kind.
  QUOTE: an invented quotation that is guaranteed absent from the patient note.
  BOTH: both violations together.
The existing Qwen evidence judge is run on each altered answer. Detection metrics
are challenge/proxy metrics for these induced errors, NOT independent clinical
accuracy or full six-checker precision and recall. Resumable and time-limited.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import random
import re
import runpy
import sys
import time
from collections import Counter
from datetime import datetime
from pathlib import Path

INPUTS = {
    "nsclc100": ("outputs/plain_ai_qwen_dev.jsonl", "datasets/nsclc100/nsclc100.csv"),
    "sigir204": ("outputs/plain_ai_qwen_sigir_dev.jsonl", "datasets/sigir204/sigir204.csv"),
}
CONDITIONS = ("LOGIC", "QUOTE", "BOTH")
FLAGS = ("support", "context_issue", "logic_issue", "contradiction_issue", "missed_evidence_issue", "suggested_truth", "suggested_verdict", "needs_human_review")


def load_jsonl(path: Path) -> list[dict]:
    rows = []
    with path.open(encoding="utf-8") as f:
        for lineno, line in enumerate(f, 1):
            if not line.strip():
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"Invalid JSON: {path}:{lineno}: {exc}") from exc
            if not isinstance(row, dict):
                raise ValueError(f"Expected JSON object: {path}:{lineno}")
            rows.append(row)
    return rows


def sha256(path: Path) -> str:
    dig = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            dig.update(block)
    return dig.hexdigest()


def key(row: dict) -> tuple[str, int, int]:
    return str(row["dataset"]), int(row["pair_idx"]), int(row["crit_idx"])


def index(rows, label):
    result = {}
    for row in rows:
        k = key(row)
        if k in result:
            raise ValueError(f"Duplicate {label} identity {k}")
        result[k] = row
    return result


def normalize(value):
    return re.sub(r"\s+", " ", str(value)).strip()


def read_inputs(root):
    sys.path.insert(0, str((root / "code").resolve()))
    from criteria import map_truth
    preds, notes, paths = {}, {}, []
    for ds, (pred_name, corpus_name) in INPUTS.items():
        pred_path, corpus_path = root / pred_name, root / corpus_name
        for p in (pred_path, corpus_path):
            if not p.is_file():
                raise FileNotFoundError(p)
            paths.append(p)
        for row in load_jsonl(pred_path):
            p = dict(row, dataset=ds)
            k = key(p)
            if k in preds:
                raise ValueError(f"Duplicate prediction {k}")
            truth = str(p["truth"]).strip().lower()
            kind = str(p["kind"]).strip().lower()
            verdict = str(p["verdict"]).strip().lower()
            if truth not in {"yes", "no", "unknown"}:
                raise ValueError(f"Unexpected truth {truth!r} for {k}")
            if map_truth(truth, kind) != verdict:
                raise ValueError(f"Original verdict mapping inconsistent for {k}: {truth}, {kind}, {verdict}")
            preds[k] = p
        with corpus_path.open(encoding="utf-8-sig", newline="") as f:
            for row in csv.DictReader(f):
                nk = ds, int(row["pair_idx"])
                if nk in notes:
                    raise ValueError(f"Duplicate clinical note {nk}")
                notes[nk] = row["patient_orig"]
    for ds, pair, _ in preds:
        if (ds, pair) not in notes:
            raise ValueError(f"Missing note {(ds, pair)}")
    audit_path = root / "outputs/overnight_audit/evidence_audit.jsonl"
    if not audit_path.is_file():
        raise FileNotFoundError(audit_path)
    paths.append(audit_path)
    original_audits = index(load_jsonl(audit_path), "audit")
    if set(preds) != set(original_audits):
        raise ValueError("Original 1,940 baseline keys and evidence audit keys do not match")
    return preds, notes, original_audits, paths, map_truth


def build_plan(preds, notes, map_truth, per_dataset, seed):
    if per_dataset % len(CONDITIONS):
        raise ValueError(f"--per-dataset must be divisible by {len(CONDITIONS)}")
    n = per_dataset // len(CONDITIONS)
    buckets = {}
    for ds in INPUTS:
        available = sorted(k for k in preds if k[0] == ds)
        if len(available) < per_dataset:
            raise ValueError(f"Not enough {ds} development records: {len(available)} < {per_dataset}")
        rng = random.Random(f"MTP-controlled-errors|{seed}|{ds}")
        chosen = rng.sample(available, per_dataset)
        buckets[ds] = {c: chosen[i*n:(i+1)*n] for i, c in enumerate(CONDITIONS)}
    plan = []
    # Interleave conditions and datasets so any time cutoff covers all groups.
    for j in range(n):
        for condition in CONDITIONS:
            for ds in INPUTS:
                k = buckets[ds][condition][j]
                plan.append({"case_id": f"{ds}-{k[1]}-{k[2]}-{condition}",
                             "dataset": ds, "pair_idx": k[1], "crit_idx": k[2],
                             "condition": condition})
    return plan


def quote_to_inject(case_id: str) -> str:
    # Synthetic, intentionally nonclinical sentinel. Do not interpret as patient truth.
    marker = hashlib.sha256(case_id.encode()).hexdigest()[:16].upper()
    return f"The clinical record explicitly contains reference marker QZ-{marker} for this eligibility rule."


def make_altered(base, note, condition, case_id, map_truth):
    original = dict(base)
    result = dict(base)
    truth = str(base["truth"]).strip().lower()
    kind = str(base["kind"]).strip().lower()
    expected_verdict = map_truth(truth, kind)
    if str(base["verdict"]).strip().lower() != expected_verdict:
        raise ValueError("Original baseline mapping invalid; refusing to inject")
    assert condition in CONDITIONS
    changed_verdict = False
    quote_injected = False
    fabricated_quote = None
    if condition in {"LOGIC", "BOTH"}:
        # Guaranteed incompatible with unmodified truth and criterion kind.
        alternatives = [v for v in ("met", "not_met", "not_stated") if v != expected_verdict]
        choice = int(hashlib.sha256(case_id.encode()).hexdigest(), 16) % 2
        result["verdict"] = alternatives[choice]
        changed_verdict = True
    if condition in {"QUOTE", "BOTH"}:
        quote = quote_to_inject(case_id)
        if normalize(quote) in normalize(note):
            raise ValueError("Synthetic quotation unexpectedly appears in source note")
        old = result.get("evidence")
        if old is None:
            old_quotes = []
        elif isinstance(old, str):
            old_quotes = [old] if old.strip() else []
        elif isinstance(old, list) and all(isinstance(q, str) for q in old):
            old_quotes = list(old)
        else:
            raise ValueError("Unsupported baseline evidence field")
        result["evidence"] = old_quotes + [quote]
        fabricated_quote = quote
        quote_injected = True
    assert result["truth"] == original["truth"]
    assert changed_verdict == (map_truth(result["truth"], kind) != str(result["verdict"]).strip().lower())
    return result, {"known_mapping_violation": changed_verdict,
                    "known_nonverbatim_quote": quote_injected,
                    "forged_quote": fabricated_quote,
                    "original_verdict": expected_verdict,
                    "submitted_verdict": str(result["verdict"]).strip().lower(),
                    "submitted_truth": truth}


def yn(value):
    return str(value).strip().lower() == "yes"


def summarise(records, out, expected_total):
    lines = ["# MTP controlled-error challenge — local development study", "",
             f"Completed: {len(records)}/{expected_total} planned judge calls", "",
             "**Interpretation:** These are *synthetic answer-level perturbations*, not independently",
             "verified patient evidence errors. No clinical accuracy or six-checker precision/recall is claimed.",
             "The `logic_issue=yes` rate is a challenge-specific flagging rate, not a comprehensive",
             "measure of logic detection. The fabricated quote is a deliberately non-verbatim sentinel.", "",
             "| Condition | Completed | Injected mapping violation | Injected non-verbatim quote | Judge logic_issue=yes | Judge support=unsupported | Judge mapping inconsistent |",
             "|---|---:|---:|---:|---:|---:|---:|"]
    for condition in CONDITIONS:
        rows = [r for r in records if r["condition"] == condition]
        mapping = sum(bool(r["known_mapping_violation"]) for r in rows)
        quote = sum(bool(r["known_nonverbatim_quote"]) for r in rows)
        flagged_logic = sum(yn(r["audit"].get("logic_issue")) for r in rows)
        unsupported = sum(str(r["audit"].get("support", "")).lower() == "unsupported" for r in rows)
        mismatch = sum(bool(r["judge_mapping_inconsistent"]) for r in rows)
        lines.append(f"| {condition} | {len(rows)} | {mapping} | {quote} | {flagged_logic} | {unsupported} | {mismatch} |")
    lines += ["", "## Judge outputs by condition", ""]
    for condition in CONDITIONS:
        rows = [r for r in records if r["condition"] == condition]
        lines.append(f"### {condition} (n={len(rows)})")
        for field in FLAGS:
            counts = Counter(str(r["audit"].get(field, "MISSING")).strip().lower() for r in rows)
            lines.append(f"- {field}: {dict(sorted(counts.items()))}")
        lines.append("")
    lines += ["Original baseline, original 1,940-row audit, clinical notes and test data were read-only.",
              "Changes in the model's suggested clinical truth have NOT been adjudicated.",
              "This challenge samples development criteria rather than creating new independently labelled clinical cases.", ""]
    out.write_text("\n".join(lines), encoding="utf-8")


def self_test():
    def fake_map(truth, kind):
        if truth not in ("yes", "no"):
            return "not_stated"
        return ("met" if truth == "yes" else "not_met") if kind == "inclusion" else ("not_met" if truth == "yes" else "met")
    b = {"truth": "unknown", "verdict": "not_stated", "kind": "exclusion", "evidence": ["original"]}
    for cond in CONDITIONS:
        change, meta = make_altered(b, "unrelated original note", cond, "nsclc100-1-2-" + cond, fake_map)
        assert meta["known_mapping_violation"] == (cond != "QUOTE")
        assert meta["known_nonverbatim_quote"] == (cond != "LOGIC")
        assert (change["verdict"] != b["verdict"]) == (cond != "QUOTE")
        assert len(change["evidence"]) == (1 if cond == "LOGIC" else 2)
        assert b["evidence"] == ["original"]
    preds = {(ds, i, 0): {"dataset":ds,"pair_idx":i,"crit_idx":0} for ds in INPUTS for i in range(15)}
    notes = {(ds,i): "synthetic note" for ds in INPUTS for i in range(15)}
    plan = build_plan(preds, notes, fake_map, per_dataset=12, seed=177)
    assert len(plan) == 24 and len(set(r["case_id"] for r in plan)) == 24
    assert Counter((r["dataset"],r["condition"]) for r in plan) == {(ds,c):4 for ds in INPUTS for c in CONDITIONS}
    print("SELF-TEST PASS: deterministic balanced challenge, guaranteed logic and quote violations, no source mutation.")


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", type=Path, default=Path.cwd())
    p.add_argument("--hours", type=float, default=1.9, help="Stop scheduling calls after this many hours")
    p.add_argument("--per-dataset", type=int, default=90, help="Development cases per dataset; multiple of 3")
    p.add_argument("--seed", type=int, default=20261017)
    p.add_argument("--self-test", action="store_true")
    p.add_argument("--dry-run", action="store_true", help="Validate inputs and sampling; no outputs/model calls")
    args = p.parse_args()
    if args.self_test:
        self_test()
        return
    if not (0.1 <= args.hours <= 12):
        p.error("--hours must be between 0.1 and 12")
    if not (3 <= args.per_dataset <= 400 and args.per_dataset % 3 == 0):
        p.error("--per-dataset must be a multiple of 3 between 3 and 400")
    root = args.root.expanduser().resolve()
    preds, notes, original_audits, paths, map_truth = read_inputs(root)
    plan = build_plan(preds, notes, map_truth, args.per_dataset, args.seed)
    print("=== MTP CONTROLLED-ERROR EVIDENCE-JUDGE CHALLENGE ===", flush=True)
    print("Baseline/audit criteria:", len(preds), flush=True)
    print("Controlled challenge calls:", len(plan), flush=True)
    print("LOGIC, QUOTE, BOTH:", dict(Counter(r["condition"] for r in plan)), flush=True)
    print("Time scheduling limit (hours):", args.hours, flush=True)
    print("Only development predictions are used. Original files and test data are READ ONLY.", flush=True)
    # Preflight ALL interventions before launching any expensive requests.
    for row in plan:
        k = key(row)
        make_altered(preds[k], notes[(k[0], k[1])], row["condition"], row["case_id"], map_truth)
    manifest = {"experiment": "MTP-controlled-error-v1", "seed": args.seed,
                "per_dataset": args.per_dataset,
                "source_hashes": {str(path.relative_to(root)): sha256(path) for path in paths},
                "cases": plan}
    if args.dry_run:
        print(f"DRY RUN OK: all {len(plan)} interventions and source joins validated; model/API calls: 0; files modified: NO.")
        return
    folder = root / "outputs" / "controlled_errors" / "logic_and_quote_challenge"
    folder.mkdir(parents=True, exist_ok=True)
    mf = folder / "manifest.json"
    if mf.exists():
        if json.loads(mf.read_text(encoding="utf-8")) != manifest:
            raise ValueError("Manifest/input hashes differ; refusing to mix experiments")
    else:
        mf.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    result_file = folder / "challenge_audits.jsonl"
    stored = load_jsonl(result_file) if result_file.exists() else []
    done = {}
    planned_ids = {r["case_id"] for r in plan}
    for row in stored:
        case_id = row["case_id"]
        if case_id in done or case_id not in planned_ids:
            raise ValueError(f"Duplicate or unknown saved case {case_id}")
        done[case_id] = row
    print("Existing completed:", len(done), flush=True)
    module_path = root / "experiments" / "overnight_evidence_audit.py"
    module = runpy.run_path(str(module_path))
    judge = module.get("judge")
    if not callable(judge):
        raise RuntimeError("Existing audit does not expose judge(record, note)")
    model = module.get("MODEL", "unknown")
    if done and any(x.get("judge_model") != model for x in done.values()):
        raise ValueError("Configured model differs from prior saved case records")
    print("Judge model:", model, flush=True)
    print("Output:", folder, flush=True)
    errors = 0
    deadline = time.monotonic() + args.hours * 3600
    with result_file.open("a", encoding="utf-8") as out, (folder / "errors.jsonl").open("a", encoding="utf-8") as err:
        for sample in plan:
            case_id = sample["case_id"]
            if case_id in done:
                continue
            if time.monotonic() >= deadline:
                print("Time limit reached; no new calls started.", flush=True)
                break
            k = key(sample)
            altered, perturbation = make_altered(preds[k], notes[(k[0],k[1])], sample["condition"], case_id, map_truth)
            begin = time.monotonic()
            try:
                audit = judge(altered, notes[(k[0],k[1])])
                if not isinstance(audit, dict):
                    raise ValueError("AI judge did not return a JSON object")
                proposed_truth = str(audit.get("suggested_truth", "unknown")).strip().lower()
                proposed_verdict = str(audit.get("suggested_verdict", "")).strip().lower()
                record = {**sample,
                          "judge_model": model,
                          "known_mapping_violation": perturbation["known_mapping_violation"],
                          "known_nonverbatim_quote": perturbation["known_nonverbatim_quote"],
                          "original_verdict": perturbation["original_verdict"],
                          "submitted_verdict": perturbation["submitted_verdict"],
                          "submitted_truth": perturbation["submitted_truth"],
                          "audit": audit,
                          "judge_mapping_inconsistent": map_truth(proposed_truth, preds[k]["kind"]) != proposed_verdict,
                          "seconds": round(time.monotonic() - begin, 2),
                          "created_at": datetime.now().astimezone().isoformat()}
                out.write(json.dumps(record, ensure_ascii=False) + "\n")
                out.flush()
                done[case_id] = record
                print(f"SAVED {len(done)}/{len(plan)} {sample['dataset']} {sample['condition']} "
                      f"pair={sample['pair_idx']} rule={sample['crit_idx']} "
                      f"{record['seconds']}s", flush=True)
            except Exception as exc:
                errors += 1
                err.write(json.dumps({"case_id": case_id, "error": f"{type(exc).__name__}: {exc}",
                                     "created_at": datetime.now().astimezone().isoformat()}) + "\n")
                err.flush()
                print(f"ERROR {case_id}: {type(exc).__name__}: {exc}", flush=True)
                if errors >= 3:
                    print("Three errors; stopping instead of hammering local model.", flush=True)
                    break
    final = list(done.values())
    summarise(final, folder / "CHALLENGE_REPORT.md", len(plan))
    print("=== FINAL SUMMARY ===", flush=True)
    print(f"Completed {len(done)}/{len(plan)}; errors this run: {errors}", flush=True)
    print("Report:", folder / "CHALLENGE_REPORT.md", flush=True)
    print("Original baseline/audit/corpus/test files modified: NO", flush=True)
    print("No external API calls; local existing judge only.", flush=True)


if __name__ == "__main__":
    main()
