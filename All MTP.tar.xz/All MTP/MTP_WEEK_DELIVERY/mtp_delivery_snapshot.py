#!/usr/bin/env python3
"""Offline MTP delivery snapshot. No model calls, no changes to existing inputs/results."""
import argparse
from collections import Counter
import csv
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path

def stamp(): return datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def inspect_checkpoint(p):
    keys=set(); n=invalid=duplicates=0
    with p.open(encoding='utf-8') as f:
        for line in f:
            if not line.strip(): continue
            try:
                r=json.loads(line); k=(r['pair_idx'],r['crit_idx'])
                duplicates+=k in keys; keys.add(k); n+=1
            except (ValueError,KeyError,TypeError): invalid+=1
    mp=Path(str(p)+'.manifest.json'); manifest={}
    if mp.exists():
        try: manifest=json.loads(mp.read_text())
        except ValueError: manifest={'status':'UNREADABLE_MANIFEST'}
    marker=Path(str(p)+'.INCOMPLETE')
    return {'file':p.name,'rows':n,'unique_rows':len(keys),'duplicate_rows':duplicates,
            'invalid_rows':invalid,'manifest_status':manifest.get('status','NO_MANIFEST'),
            'expected_rows':manifest.get('expected'), 'errors':manifest.get('errors',[]),
            'incomplete_marker':marker.exists(), 'sha256':sha(p),
            'warning':'Snapshot of a potentially active file; not a scoring-completeness certificate.'}
def label_counts(p):
    groups={}
    with p.open(encoding='utf-8-sig',newline='') as f:
        for r in csv.DictReader(f):
            split=(r.get('split') or '').strip().lower(); truth=(r.get('truth') or '').strip().lower()
            g=groups.setdefault(split,{'assigned':0,'valid_truth':0,'blank':0,'invalid':0,'unsure':0})
            g['assigned']+=1
            g['valid_truth']+=truth in ('yes','no','unknown')
            g['blank']+=not truth
            g['invalid']+=bool(truth) and truth not in ('yes','no','unknown')
            g['unsure']+=(r.get('comment') or '').strip().upper().startswith('UNSURE:')
    return groups

def collect(root):
    result={'generated_utc':datetime.now(timezone.utc).isoformat(),
       'basis':'Observed local files; no inference of completed study from code availability.',
       'supervisor':None,'dev_checkpoints':{},'assigned_label_counts':{},'dev_reports':[],
       'code_present':{},'warnings':[]}
    p=root/'outputs/mtp_supervisor/STATUS.json'
    if p.exists():
        try:
            s=json.loads(p.read_text())
            # Never copy arbitrary log messages, clinical prompts, or key files.
            result['supervisor']={k:s.get(k) for k in ('status','completed','expected','remaining','requests_this_session','restarts','updated_utc','scope')}
        except ValueError:result['warnings'].append('Supervisor status was unreadable; repeat snapshot.')
    for dataset in ('nsclc100','sigir204'):
        folder=root/'outputs/mtp_completion'/dataset/'dev'
        result['dev_checkpoints'][dataset]=[inspect_checkpoint(p) for p in sorted(folder.glob('*checks*.jsonl'))]
    for name in ('my_label_sheet.csv','sigir_label_sheet.csv'):
        p=root/'labelling'/name
        if p.exists():result['assigned_label_counts'][name]=label_counts(p)
    base=root/'outputs/mtp_completion'
    for p in sorted(base.rglob('RESULTS.json')) if base.exists() else []:
        try:
            r=json.loads(p.read_text())
            if r.get('split')!='dev':continue
            # Allowlist aggregate metrics only; never copy notes or raw records.
            selected={k:r.get(k) for k in ('dataset','split','status','subject_models','pair_metrics','quotation_metrics','unknown_rate','student_label_status','label_provenance','student_metrics','checker_label_distribution','review_simulation','rejection_risk','keep_vs_flag','repair_policy') if k in r}
            selected['relative_report']=str(p.relative_to(root));selected['sha256']=sha(p)
            result['dev_reports'].append(selected)
        except (ValueError,TypeError):result['warnings'].append('Unreadable aggregate report: '+str(p.relative_to(root)))
    for rel in ('completion.py','mtp_completion/checker.py','mtp_completion/analysis.py','mtp_completion/traps.py','mtp_completion/workflow.py','mtp_supervisor_v3.py'):
        p=root/rel;result['code_present'][rel]={'exists':p.is_file(),'sha256':sha(p) if p.is_file() else None}
    return result

def render(r):
    lines=['# MTP delivery snapshot','',f"Generated: {r['generated_utc']}",'',
      'This is a progress audit, not a final scientific result. No API calls were made.','',
      '## Supervisor','', '```json',json.dumps(r['supervisor'],indent=2),'```','',
      '## Development checker coverage','',
      '| Dataset | Checkpoint | Unique rows | Manifest | Invalid rows |',
      '|---|---|---:|---|---:|']
    for d,checks in r['dev_checkpoints'].items():
        for c in checks:lines.append(f"| {d} | {c['file']} | {c['unique_rows']} | {c['manifest_status']} | {c['invalid_rows']} |")
        if not checks:lines.append(f'| {d} | No current checker output found | — | UNCONFIRMED | — |')
    lines+=['','## Assigned student labels','',
      'Counts describe valid truth values; they do not establish annotation correctness, evidence quality or independence.','',
      '| File | Split | Assigned | Valid truth | Blank | UNSURE |','|---|---|---:|---:|---:|---:|']
    for file,groups in r['assigned_label_counts'].items():
        for split,c in groups.items():lines.append(f"| {file} | {split} | {c['assigned']} | {c['valid_truth']} | {c['blank']} | {c['unsure']} |")
    lines+=['','## Development pair-level reports','',
      '| Dataset | Report | Wrong exclusions | Wrong inclusions | REVIEW |','|---|---|---:|---:|---:|']
    for report in r['dev_reports']:
        m=report.get('pair_metrics',{})
        lines.append(f"| {report['dataset']} | {report['relative_report']} | {m.get('false_exclusions','—')} | {m.get('false_inclusions','—')} | {m.get('review_count','—')} |")
    lines+=['','## Remaining scientific gates','',
     '- Review development rule statements and key terms; correct fallback artifacts before freezing.',
     '- Finish assigned student labels following guide 6.3; record assistance and UNSURE rows.',
     '- Complete both answer modes and both datasets with consistent subject-model settings.',
     '- Produce Tables 1–8 from completed, matching runs; leave unavailable cells explicitly unavailable.',
     '- Evaluate keep / flag / re-ask, including right answers broken, plus all seven trap types.',
     '- Freeze code, settings and labels before held-out inference; report the held-out run separately.',
     '- Deliver the runnable existing CLI, installation guide, test results and an end-to-end demo.',
     '- Do not substitute agreement with a model-generated reference for independent accuracy.','']
    if r['warnings']:lines+=['## Warnings','']+['- '+s for s in r['warnings']]
    return '\n'.join(lines)

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--root',type=Path,default=Path.cwd());a=ap.parse_args()
    root=a.root.expanduser().resolve()
    if not (root/'completion.py').is_file():raise SystemExit('Run with --root pointing to Akash_Kit containing completion.py.')
    os.umask(0o077)
    r=collect(root);out=root/'outputs/final_delivery'/stamp();out.mkdir(parents=True,exist_ok=False)
    (out/'SNAPSHOT_NO_NOTES.json').write_text(json.dumps(r,indent=2),encoding='utf-8')
    (out/'DELIVERY_STATUS.md').write_text(render(r),encoding='utf-8')
    print('SNAPSHOT:',out/'SNAPSHOT_NO_NOTES.json');print('REPORT:',out/'DELIVERY_STATUS.md')
    print('No API calls. Existing code, datasets, annotations, checkpoints and keys unchanged.')
if __name__=='__main__': main()
