# MTP delivery plan: 6–12 November 2026

## Scope and evidence

Main project: **Check What Can Change the Outcome**, for Neha Ma'am and Prof. Varun Dutt. Source of requirements: `Akash_Project_Guide.md`, version 1, 17 September 2026, sections 1, 6–16 and 20. This is a delivery schedule for that scope, not a change to the research question. AAPEMS implementation, learned ranking and extra benchmark/model families are outside this sprint.

Last shared evidence on 5 November: 1,940 saved development screening predictions, 152 development patient–trial pairs, baseline reports for both datasets, and an active NSCLC checker checkpoint of 350/950. That is a historical checkpoint, not the current count. The status collector reads the actual laptop state. An older full exploratory audit exists; it is not interchangeable with the current checker configuration.

Confirmed development baseline report counts:

| Dataset | Pairs | Wrong exclusions | Wrong inclusions | REVIEW |
|---|---:|---:|---:|---:|
| NSCLC100 | 50 | 11 | 0 | 16 |
| SIGIR204 | 102 | 17 | 0 | 69 |

These are pair-level results against the dataset's labels. They do not establish criterion accuracy or checker accuracy. In particular, zero wrong inclusions alongside substantial REVIEW does not demonstrate a complete successful screening system. The earlier 92.73% calculation is not an independently validated accuracy result and must not be reused as one.

## Delivery contract: Parts A–E

The existing CLI is the core tool. A new dashboard or a new supervisor version is not a prerequisite for the scientific evaluation. The submission must let a reviewer install dependencies, run the tests, execute a small development example, inspect all six checks, get review orders and a rejection-risk list, evaluate fixes, and inspect exported results. Package one launch path and one frozen implementation, plus reproducibility details. Do not include keys, clinical notes or private datasets in a public submission.

| Part | Existing implementation in the uploaded package | Evidence still needed for final completion |
|---|---|---|
| A: six evidence checks | `completion.py statements` and `check`; checker/numeric/client modules | Reviewed statements, calibration record, completed matching runs, quality against usable student labels |
| B: priority ranking | `report`; five review-order strategies and guide scoring simulation | Equal budgets 5/10/20/50/100; rescue curves; counts; unknown-effect checks; trial/patient comparisons |
| C: rejection-risk list | `report`; `rejected_pair_risk.csv` | Precision/recall at 3/5/10, counts and random comparator |
| D: fixer | `repair` plus `report --after`; keep/flag/re-ask | Same subject model, rechecked proposals, fixed AND broken counts, changed REVIEW burden |
| E: traps | `prepare-traps`, `run-traps`, `trap-report` | Hand-reviewed development alterations across seven types; truth key and per-type results |

Code existence is not evidence that these experiments have finished on the laptop.

## Exact final tables

| Table | Required result | Prerequisites and acceptance |
|---|---|---|
| 1 | Plain AI vs forced guess: student rule accuracy and n; quote rate; wrong exclusions and sole reasons; wrong inclusions; REVIEW | Complete comparable predictions, correct inclusion/exclusion mapping. Label-dependent cells stay unavailable until labels are usable. |
| 2 / K1 | Five strategies at budgets 5,10,20,50,100; rescues per 10 checks at 50; unknown-effect checks; curve | Ranking reads system-visible inputs only. Correction scoring follows guide 9.3; distinguish student corrections from eligible-pair-label assumptions. |
| 3 / K2 | Wrong answers, flagged, flag precision/recall; VERIFIED and flagged accuracy/share | Joined student-labelled predictions and checks. Report all and without UNSURE rows. A checker label alone cannot score itself. |
| 4 / K2 | Remove each check; precision, recall, unique errors caught | Use the same labelled cases, all/without UNSURE. Do not compare different samples. |
| 5 / K3 | Keep, flag, re-ask: fixed, broken, unchanged; pair harms and REVIEW before/after | Preserve baseline and reference labels. Repair with the original subject model. State any top-k repair scope. |
| 6 / K4 | Seven trap types: cases, trap rate, detection rate, right-label rate | Development sources only; confirm each changed note and expected truth by hand. Up to 20/type, fewer if genuinely suitable cases are limited. |
| 7 / K5 | Rejection-risk precision/recall at 3,5,10; random at 5 | Risk features must not read eligibility labels; scoring may read them. |
| 8 / K6 | NSCLC vs SIGIR flag counts, initial wrong exclusions, rescues/check; error-type shares when independently assessed | Same main subject system and prespecified strategy; cluster NSCLC by trial, SIGIR by patient. Do not call model-assigned categories human-confirmed errors. |

Include main harm measures before generic accuracy. Present binary accuracy with its REVIEW policy, three-way decisions, precision/recall/F1 where defined, sample sizes and denominators. Use original package statistics and prevalence reweighting at 0.10 and 0.05. Undefined metrics are unavailable, never silently zero.

## Seven daily deliveries

Assumption: focused daily work plus unattended computation, working quota and supervisor feedback on ambiguities. This schedule is a target, not a guaranteed finish time. It requires completing manual work while model jobs run.

| Date | Automated/computing track | Manual/report track | End-of-day evidence |
|---|---|---|---|
| 6 Nov | Finish/resume current NSCLC development checker; report after full coverage. Inventory missing forced-mode and SIGIR jobs with a bounded request budget. | Review 95 NSCLC statements, especially 24 source-wording fallbacks and their key terms. Recheck citation labels; start original-guide student labels. Read reference map. | Live status, valid NSCLC dev report or exact blocker, requirements/table ledger, measured annotation throughput |
| 7 Nov | Complete comparable NSCLC dev modes/checks; produce K1/K5 outputs. Start/resume SIGIR development preparation/checks sequentially. | Continue labels and draft methods/data sections. Inspect flagged and VERIFIED examples to find checker mistakes. | Tables 1/2/7 dev, curve, reproducible configurations; label count updated |
| 8 Nov | Continue SIGIR dev jobs; run development repair and reviewed traps as their inputs become ready. | Finish remaining annotation work, review exceptions/UNSURE rows, verify altered trap notes and expected answers. | Joined labels, draft Tables 3–6, SIGIR dev coverage |
| 9 Nov | Finish development comparisons; record selected strategy, budgets, model and checker settings. | Resolve label conflicts with Neha; freeze annotations/method and commit/hash code. Define final demo path. | Freeze record, hashes, input coverage, held-out run plan and token budget |
| 10 Nov | Start held-out evaluation only after freeze; checkpoint/resume the same frozen jobs, without tuning on results. | Finish implementation/method descriptions and related work; prepare final table templates. | Frozen-run manifests/usage, actual held-out coverage and blockers |
| 11 Nov | Finish held-out jobs; generate separate NSCLC/SIGIR tables, trial/patient summaries and comparisons. | Check all denominators, limitations, 20 worked examples requested by guide, and demo. | Final draft results, figures, reproducibility package |
| 12 Nov | Verify the final package on a clean environment or documented project venv. | Final report, slides, README and demonstration. State any incomplete experiment and its scope explicitly. | Runnable tool + tests + Tables 1–8 with actual availability + report + demo |

### Annotation workload must be made concrete on 6 November

The last confirmed assigned sheets had 649 rows: 298 development and 351 held-out. Recount actual files first. If still empty, finishing by 9 November is about 163 rows/day across four days. At an illustrative 2–4 minutes/row that is about 5.4–10.9 focused hours/day. Time the first 20 rows; if throughput makes the plan infeasible, tell Neha that day and agree on support or a reduced *reported scope*. Do not wait until submission day.

Follow guide 6.3, including stated/inferred/absent, compound rules, exceptions, not-applicable handling and UNSURE comments. The previous documented-evidence-v2 rubric is more restrictive than the original guide: it must not silently replace that guide. Completed reference labels must be made from notes and criteria; AI suggestions do not become independent student labels. Record earlier exposure or assistance and discuss its effect. Clinical expert approval is not a blanket prerequisite in this student guide; unresolved clinical interpretations can be flagged and discussed.

### Protect the original study

- Keep Qwen2.5:7B as the main subject model if that is the baseline being evaluated; Groq/openai/gpt-oss-20b is the current checker model. A provider is not a model. Do not relabel this as an all-Grok experiment.
- Neha's provision of API access authorises the requested online runs in this session; document that configuration change from the original local-only plan. Do not send unrelated restricted records to a provider.
- Do not rewrite active statements/cache/checkpoints while V3 is running. Review a copy, then version and rerun affected inputs before freeze.
- Fixes must use the same subject model as their baseline. An API judge must not overwrite references or silently replace the Qwen repair model.
- Generate test statements once under the frozen method; never hand-edit them after seeing test examples.
- Preserve failed rows and incomplete run markers. A timeout is not an unknown answer. Never merge outputs from different prompts/settings as one completed run.
- Keep the same primary subject model across the two answer modes and both datasets. Allocate API attempts and tokens from measured usage, not an invented large call count.
- No more supervisor upgrades unless an observed bug blocks completion. Existing saved-key fallback is for rejected credentials, not a guarantee of extra quota. Do not expose keys.
- Papers provide method context, not the reference labels or performance of this implementation.

## The final reviewer demonstration

Use development examples: one supported answer, one numeric/context problem, one unknown with missing information and one sole-rejection reason. Show the quote, checks, label, pair decision, priority order and exported result. Demonstrate keep versus flag and an actual re-ask result if available. Show one altered trap and its predetermined key. Clearly identify model output, human review and simulation results.

Acceptance: the documented commands run, outputs include stable row IDs and provenance, incomplete data cannot be scored as complete, no secrets are bundled, actual counts match tables, and the report lists limitations. A polished appearance is useful only after these work.

## Status collection now

Run `python3 mtp_delivery_snapshot.py --root "$HOME/MTP/Akash_Kit"` from the extracted delivery folder. It requires only the standard library, makes zero API calls and writes a new `outputs/final_delivery/<timestamp>/` folder. It does not stop or alter V3. Upload `SNAPSHOT_NO_NOTES.json` for a current progress audit. Keep its companion Markdown report for Neha. It does not itself complete experiments.
