import importlib.util,json,tempfile,unittest
from pathlib import Path
spec=importlib.util.spec_from_file_location('snapshot',Path(__file__).with_name('mtp_delivery_snapshot.py'))
s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
class Tests(unittest.TestCase):
 def test_incomplete_is_not_complete(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'checks.jsonl';p.write_text('{"pair_idx":1,"crit_idx":2}\n'*2+'{unfinished')
   Path(str(p)+'.manifest.json').write_text('{"status":"INCOMPLETE","expected":950}')
   r=s.inspect_checkpoint(p);self.assertEqual((r['unique_rows'],r['duplicate_rows'],r['invalid_rows']),(1,1,1));self.assertEqual(r['manifest_status'],'INCOMPLETE')
 def test_counts_and_no_note_export(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);labels=root/'labelling';labels.mkdir()
   (labels/'my_label_sheet.csv').write_text('split,truth,comment,patient_note\ndev,,,PRIVATE_CLINICAL_TEXT\ntest,unknown,UNSURE: review,PRIVATE_CLINICAL_TEXT\n')
   r=s.collect(root);c=r['assigned_label_counts']['my_label_sheet.csv'];self.assertEqual(c['dev']['blank'],1);self.assertEqual(c['test']['valid_truth'],1)
   self.assertNotIn('PRIVATE_CLINICAL_TEXT',json.dumps(r));self.assertNotIn('PRIVATE_CLINICAL_TEXT',s.render(r))
 def test_absent_reports_do_not_become_metrics(self):
  with tempfile.TemporaryDirectory() as d:
   r=s.collect(Path(d));self.assertEqual(r['dev_reports'],[]);self.assertEqual(r['supervisor'],None)
if __name__=='__main__':unittest.main()
