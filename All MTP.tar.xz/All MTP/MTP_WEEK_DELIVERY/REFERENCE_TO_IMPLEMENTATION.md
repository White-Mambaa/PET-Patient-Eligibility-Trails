# Reference check and implementation map

Checked 5 November 2026. Source list: original guide sections 2.4 and 20. This is a targeted abstract/metadata/project-page check, not a claim of full-text review of every paper or a systematic literature search. No Telegram content was accessed. Revisit the actual papers for detailed claims in the thesis.

| Original reference | Primary page opened | What it informs in this MTP |
|---|---|---|
| TrialGPT, Jin et al. (2024), *Matching patients to clinical trials with large language models* | https://github.com/ncbi-nlp/TrialGPT | Criterion-based matching and aggregation provide context for the subject answers. The proposed MTP evaluates evidence checking and which answers to review first. Do not copy TrialGPT accuracy numbers into this project's results. |
| VERDICT, Zhou et al. (2026), *Accountable AI with Grounded, Faithful, Consistent, Actionable Rationales* | https://aclanthology.org/2026.emnlp-main.2598/ and https://github.com/stanford-oval/clinical-trial-matching | Explicit assumptions, policy consistency and pivotal conditions motivate the discussion of decision impact. This project must empirically test its human-review ordering; citing VERDICT does not establish that result. |
| Kim et al. (2025), *Correlated Errors in Large Language Models*, arXiv:2506.07962 | https://arxiv.org/abs/2506.07962 | Model errors may correlate; a second model is not an independent truth source. Evaluate checker precision/recall against reviewed labels and use deterministic/context checks. |
| NLI4CT / SemEval-2024 Task 2, Jullien et al. | https://arxiv.org/abs/2404.04963 | Perturbation-based consistency and robustness evaluation informs development traps. Trial-report NLI and patient-note eligibility are different tasks. |
| *Judge, Retrieve, or Abstain*, Badshah et al., guide arXiv:2608.17994 | Author-lab page: https://hypermatrix.cs.dal.ca/selective-prediction/ | Selective evaluation and abstention inform keep/flag/re-ask discussions. The MTP implementation does not automatically inherit conformal risk guarantees. Direct arXiv abstract/HTML fetching was unavailable during this check. |
| León Tramontini, Ghosh, Eickhoff, *Investigating RAG-based Approaches in Clinical Trial and Patient Matching* | https://proceedings.mlr.press/v297/leon-tramontini26a.html | Criteria complexity, longitudinal records and abstention motivate reporting missingness, rule count and REVIEW burden. Publisher page lists PMLR 297:76–87, 2026; inspect the publisher citation rather than mixing a draft's year/page numbers. |
| medspaCy | https://github.com/medspacy/medspacy | Software dependency for context handling; record actual local version. |
| RapidFuzz | https://github.com/rapidfuzz/RapidFuzz | Fuzzy quotation matching; development-labelled theta selection remains necessary. |
| cross-encoder/nli-deberta-v3-base | https://huggingface.co/cross-encoder/nli-deberta-v3-base | Optional support backend. It is not automatically a clinically validated entailment model. Test the actual integration before reporting it. |

## Verification still pending

The guide also lists Qu, Ranaldi, Wang and Valentino, *Neurosymbolic Clinical Trial Matching via LLM-Driven Abduction and Logical Verification*, arXiv:2606.20895. Its direct primary arXiv pages could not be fetched in this session. Search results matched the title and authors, but no performance claim from this paper is relied on here. Open the primary PDF/author repository or upload the paper before final citation-specific analysis. Keep this as pending, not as a disproved reference.

The PhysioNet policy and general tool links in the guide are supplementary references; they are not evidence that this project uses MIMIC. Do not add MIMIC/eICU or the AAPEMS extension to this week's scope.

## Related-work writing rule

For each method: name its actual task, identify the relevant idea, state what this implementation actually does, then point to the local experiment evaluating that idea. Limit novelty language to a qualified claim after checking related work. Do not assert that the priority method wins before results are available.
