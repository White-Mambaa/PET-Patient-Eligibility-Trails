#!/usr/bin/env python3
"""Combine the evaluation files and a verified local closeout snapshot. Offline."""
import argparse
import hashlib
import json
from pathlib import Path
import tempfile
import zipfile

PACK = Path(__file__).resolve().parent
COLUMNS = ("dataset", "mode", "pairs", "reference_eligible", "reference_ineligible", "eligible_found",
           "hard_wrong_exclusions", "wrong_inclusions", "review")
FILES = ("MTP_Evaluation.pptx", "MTP_Final_Report.pdf", "MTP_TOOL_CANDIDATE.zip", "RESULTS_SNAPSHOT.json",
         "README_FOR_PANEL.md", "freeze_closeout.py")


def verify(evidence):
    recorded = json.loads((PACK / "RESULTS_SNAPSHOT.json").read_text(encoding="utf-8"))
    actual = json.loads((evidence / "CLOSEOUT_EVIDENCE_NO_NOTES.json").read_text(encoding="utf-8"))
    if actual.get("unverified"):
        raise ValueError("The local addendum lists unverified sources. Review it before assembling the submission.")
    if actual.get("paired_metrics_agree_with_deck") is not True:
        raise ValueError("The saved paired comparison did not match the deck. Review CLOSEOUT_ADDENDUM.md.")
    want = [[row[k] for k in COLUMNS] for row in recorded["paired_development"]]
    got = [[row[k] for k in COLUMNS] for row in actual["paired_development"]]
    if want != got:
        raise ValueError("The paired metric rows do not match the recorded result snapshot.")
    c = actual["checker"]
    r = recorded["checker"]
    if (c["saved"], c["expected"]) != (r["saved"], r["expected"]):
        raise ValueError(f"This package uses {r['saved']}/{r['expected']} checks. Select that closeout folder.")
    if not actual.get("captured_at_ist", "").startswith("2026-11-09T20:27:17"):
        raise ValueError("Select the verified closeout captured at 20:27 IST on 9 November.")


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--evidence-dir", type=Path, required=True)
    p.add_argument("--out", type=Path, default=PACK.parent / "MTP_SUBMISSION.zip")
    a = p.parse_args()
    try:
        evidence = a.evidence_dir.resolve()
        output = a.out.resolve()
        if output.exists():
            raise FileExistsError("Submission ZIP already exists. Choose another path with --out.")
        verify(evidence)
        files = {name: (PACK / name).read_bytes() for name in FILES}
        for name in ("CLOSEOUT_ADDENDUM.md", "CLOSEOUT_EVIDENCE_NO_NOTES.json"):
            files[name] = (evidence / name).read_bytes()
        files["SHA256SUMS.txt"] = "".join(
            f"{hashlib.sha256(data).hexdigest()}  {name}\n" for name, data in sorted(files.items())
        ).encode()
        with tempfile.TemporaryDirectory(prefix="mtp_submission_", dir=output.parent) as td:
            draft = Path(td) / output.name
            with zipfile.ZipFile(draft, "w", zipfile.ZIP_DEFLATED) as z:
                for name, data in files.items():
                    z.writestr(f"MTP_SUBMISSION/{name}", data)
            with zipfile.ZipFile(draft) as z:
                if z.testzip() is not None:
                    raise ValueError("Submission archive failed integrity check.")
            # Publish without overwriting another submission.
            output.hardlink_to(draft)
        print("SUBMISSION READY:", output)
        print("Verified: 706 / 950 checker records and four matched development result rows. Model calls: 0.")
        return 0
    except (OSError, KeyError, TypeError, ValueError) as e:
        print("STOP:", e)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
