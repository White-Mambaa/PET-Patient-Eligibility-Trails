# Final MTP delivery

The evaluation deck, report and speaker notes use **706 of 950 saved checker records** from the 9 November offline closeout. That count measures coverage of the separate legacy NSCLC development run.

## Assemble the submission on the project laptop

Run this after extracting MTP_FINAL_DELIVERY.zip into Downloads:

    "$HOME/MTP/Akash_Kit/.venv/bin/python" \
      "$HOME/Downloads/MTP_FINAL_DELIVERY/assemble_submission.py" \
      --evidence-dir "$HOME/MTP/Akash_Kit/outputs/mtp_closeout/closeout_20261109_202717_516358_IST"

The command verifies the recorded count and the paired comparison against the local snapshot. It creates MTP_SUBMISSION.zip in Downloads with the slides, report, runnable source, evidence addendum and a checksum manifest. If the department requires names and IDs on the cover, edit the PPTX before assembly.

## Rehearse the offline demo

    pack="$HOME/Downloads/MTP_FINAL_DELIVERY"
    unzip -n "$pack/MTP_TOOL_CANDIDATE.zip" -d "$pack"
    "$HOME/MTP/Akash_Kit/.venv/bin/python" \
      "$pack/MTP_TOOL/mtp_week_delivery.py" self-test

Use SPEAKER_NOTES.md for the talk and slide 8 as a fallback if the terminal is unavailable. The demo uses a synthetic case and makes no model requests.
