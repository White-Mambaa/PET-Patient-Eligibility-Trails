#!/usr/bin/env python3
"""Compute offline criterion-level baseline metrics from saved MTP dev JSONL.

This reports agreement with the existing JSONL `truth` field. It is not a
clinical validation of the six evidence checks or of the author-review sheet.
Only Python's standard library is required. Inputs are read-only.
"""

import argparse
import datetime as dt
import hashlib
import json
import math
import os
import random
import sys
from collections import Counter, defaultdict

LABELS = ("yes", "no", "unknown")
PRED_TO_GOLD = {
    "met": "yes",
    "yes": "yes",
    "not_met": "no",
    "not met": "no",
    "no": "no",
    "not_stated": "unknown",
    "not stated": "unknown",
    "unknown": "unknown",
}


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def norm(value):
    if value is None:
        return ""
    return str(value).strip().lower().replace("-", "_")


def load_jsonl(path, dataset_name):
    rows = []
    malformed = 0
    missing_fields = Counter()
    with open(path, "r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, 1):
            if not line.strip():
                continue
            try:
                obj = json.loads(line)
            except Exception:
                malformed += 1
                continue
            if not isinstance(obj, dict):
                malformed += 1
                continue

            for key in ("truth", "verdict", "pair_idx"):
                if key not in obj:
                    missing_fields[key] += 1

            gold = norm(obj.get("truth"))
            if gold not in LABELS:
                # Do not silently reinterpret uncertain or malformed reference labels.
                continue

            raw_pred = norm(obj.get("verdict"))
            pred = PRED_TO_GOLD.get(raw_pred, "__INVALID__")
            parse_ok = obj.get("parse_ok", True)
            if parse_ok is False:
                pred = "__INVALID__"

            pair = str(obj.get("pair_idx", f"missing_pair_line_{line_no}"))
            rows.append({
                "dataset": dataset_name,
                "pair": pair,
                "gold": gold,
                "pred": pred,
            })
    return rows, {"malformed_jsonl_lines": malformed,
                  "missing_field_counts": dict(missing_fields)}


def safe_div(a, b):
    return (a / b) if b else 0.0


def percentile(sorted_values, p):
    if not sorted_values:
        return None
    ix = (len(sorted_values) - 1) * p
    lo = int(math.floor(ix))
    hi = int(math.ceil(ix))
    if lo == hi:
        return sorted_values[lo]
    frac = ix - lo
    return sorted_values[lo] * (1.0 - frac) + sorted_values[hi] * frac


def clustered_accuracy_ci(rows, reps, seed):
    by_pair = defaultdict(list)
    for r in rows:
        by_pair[(r["dataset"], r["pair"])].append(r["gold"] == r["pred"])
    clusters = list(by_pair.values())
    if len(clusters) < 2 or reps <= 0:
        return None
    rng = random.Random(seed)
    values = []
    nclusters = len(clusters)
    for _ in range(reps):
        correct = total = 0
        for _ in range(nclusters):
            chosen = clusters[rng.randrange(nclusters)]
            total += len(chosen)
            correct += sum(chosen)
        if total:
            values.append(correct / total)
    values.sort()
    return {
        "method": "percentile bootstrap resampling whole patient-trial pairs",
        "replicates": reps,
        "seed": seed,
        "pair_clusters": nclusters,
        "low_95": percentile(values, 0.025),
        "high_95": percentile(values, 0.975),
    }


def score(rows, reps, seed):
    cm = {g: {p: 0 for p in LABELS + ("__INVALID__",)} for g in LABELS}
    for r in rows:
        cm[r["gold"]][r["pred"]] += 1
    n = len(rows)
    correct = sum(cm[k][k] for k in LABELS)
    per_class = {}
    for k in LABELS:
        tp = cm[k][k]
        support = sum(cm[k].values())
        predicted = sum(cm[g][k] for g in LABELS)
        precision = safe_div(tp, predicted)
        recall = safe_div(tp, support)
        f1 = safe_div(2 * precision * recall, precision + recall)
        per_class[k] = {
            "precision": precision,
            "recall": recall,
            "f1": f1,
            "support": support,
            "predicted_count": predicted,
        }
    macro = {
        metric: sum(per_class[k][metric] for k in LABELS) / len(LABELS)
        for metric in ("precision", "recall", "f1")
    }
    weighted = {
        metric: safe_div(sum(per_class[k][metric] * per_class[k]["support"]
                             for k in LABELS), n)
        for metric in ("precision", "recall", "f1")
    }
    non_abstain = sum(r["pred"] in ("yes", "no") for r in rows)
    non_abstain_correct = sum(r["gold"] == r["pred"] and r["pred"] in ("yes", "no")
                              for r in rows)
    pair_correct = defaultdict(list)
    for r in rows:
        pair_correct[(r["dataset"], r["pair"])].append(r["gold"] == r["pred"])
    pair_accuracies = [sum(v) / len(v) for v in pair_correct.values()]
    pair_mean = safe_div(sum(pair_accuracies), len(pair_accuracies))

    return {
        "criterion_rows_scored": n,
        "patient_trial_pairs": len(pair_correct),
        "reference_label_counts": {k: sum(cm[k].values()) for k in LABELS},
        "prediction_counts": {k: sum(cm[g][k] for g in LABELS) for k in LABELS},
        "invalid_or_unparsed_prediction_count": sum(cm[g]["__INVALID__"] for g in LABELS),
        "accuracy": safe_div(correct, n),
        "balanced_accuracy": macro["recall"],
        "macro_avg": macro,
        "weighted_avg": weighted,
        "per_class": per_class,
        "confusion_matrix_gold_rows_predicted_columns": cm,
        "predicted_abstention_rate_unknown": safe_div(sum(cm[g]["unknown"] for g in LABELS), n),
        "non_abstention_coverage_yes_or_no": safe_div(non_abstain, n),
        "selective_accuracy_on_non_abstained_rows": safe_div(non_abstain_correct, non_abstain),
        "mean_per_pair_criterion_accuracy": pair_mean,
        "criterion_accuracy_pair_cluster_bootstrap_95_ci": clustered_accuracy_ci(rows, reps, seed),
    }


def self_test():
    rows = [
        {"dataset": "test", "pair": "1", "gold": "yes", "pred": "yes"},
        {"dataset": "test", "pair": "1", "gold": "no", "pred": "yes"},
        {"dataset": "test", "pair": "2", "gold": "unknown", "pred": "unknown"},
        {"dataset": "test", "pair": "2", "gold": "no", "pred": "__INVALID__"},
    ]
    result = score(rows, 50, 7)
    assert result["criterion_rows_scored"] == 4
    assert abs(result["accuracy"] - 0.5) < 1e-12
    assert result["confusion_matrix_gold_rows_predicted_columns"]["no"]["__INVALID__"] == 1
    assert result["patient_trial_pairs"] == 2
    print("SELF-TEST PASS: metric formulas, invalid predictions, and pair bootstrap")


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root", default=os.getcwd(), help="MTP project root")
    ap.add_argument("--nsclc", default="outputs/plain_ai_qwen_dev.jsonl")
    ap.add_argument("--sigir", default="outputs/plain_ai_qwen_sigir_dev.jsonl")
    ap.add_argument("--bootstrap", type=int, default=2000)
    ap.add_argument("--seed", type=int, default=20261022)
    ap.add_argument("--self-test", action="store_true")
    args = ap.parse_args()
    if args.self_test:
        self_test()
        return 0

    root = os.path.abspath(args.root)
    inputs = {
        "NSCLC100_dev": os.path.join(root, args.nsclc),
        "SIGIR204_dev": os.path.join(root, args.sigir),
    }
    missing = [p for p in inputs.values() if not os.path.isfile(p)]
    if missing:
        print("ERROR: required development prediction file not found:", file=sys.stderr)
        for p in missing:
            print("  " + p, file=sys.stderr)
        return 2

    all_rows = []
    input_info = {}
    dataset_results = {}
    for name, path in inputs.items():
        rows, parse_info = load_jsonl(path, name)
        if not rows:
            print("ERROR: no rows with recognized truth labels in " + path, file=sys.stderr)
            return 3
        all_rows.extend(rows)
        dataset_results[name] = score(rows, args.bootstrap, args.seed)
        input_info[name] = {
            "relative_path": os.path.relpath(path, root),
            "sha256": sha256_file(path),
            "rows_with_recognized_truth": len(rows),
            **parse_info,
        }
    dataset_results["COMBINED_DEV"] = score(all_rows, args.bootstrap, args.seed)

    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    outdir = os.path.join(root, "outputs", "research_completion_sprint",
                          "baseline_metrics_" + stamp)
    os.makedirs(outdir, exist_ok=False)
    report = {
        "title": "MTP development baseline criterion metrics",
        "created_local": dt.datetime.now().astimezone().isoformat(timespec="seconds"),
        "comparison_basis": "Agreement between each JSONL truth field and mapped verdict field.",
        "mapping": {"truth": list(LABELS), "verdict": PRED_TO_GOLD},
        "results": dataset_results,
        "input_inventory": input_info,
        "limitations": [
            "Baseline metrics only; they do not evaluate the proposed six-check system.",
            "Agreement with stored truth fields is not independent clinical adjudication.",
            "The 49-case author-review worksheet is not used as reference truth.",
            "Pair-clustered intervals resample patient-trial pairs; they quantify sampling uncertainty, not label uncertainty.",
            "No model inference, held-out evaluation, or input modification was performed.",
        ],
    }
    outpath = os.path.join(outdir, "BASELINE_METRICS_NO_NOTES.json")
    with open(outpath, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, sort_keys=True)
        f.write("\n")

    print("BASELINE METRICS COMPLETE")
    print("Output:", outpath)
    print("Rows scored:", len(all_rows), "| pairs:", dataset_results["COMBINED_DEV"]["patient_trial_pairs"])
    print("Basis: agreement with saved JSONL truth fields; not independent clinical validation.")
    print("No model calls. No source files changed. No held-out files opened.")
    for name in ("NSCLC100_dev", "SIGIR204_dev", "COMBINED_DEV"):
        s = dataset_results[name]
        print("{}: accuracy={:.4f} macro_F1={:.4f} weighted_F1={:.4f} abstention={:.4f}".format(
            name, s["accuracy"], s["macro_avg"]["f1"], s["weighted_avg"]["f1"],
            s["predicted_abstention_rate_unknown"]))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
