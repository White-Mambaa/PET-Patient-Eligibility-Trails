# Akash — project kit

**Check What Can Change the Outcome: targeted checking of AI screening decisions for clinical trials**

Start with **`Akash_Project_Guide.docx`** (the same text is in `Akash_Project_Guide.md` — copy
commands and prompts from the `.md` file).

## First hour

```bash
cd code
pip install -r requirements.txt
python selftest.py
```

The last line must be `36 passed, 0 failed`. If not, stop and fix your setup.

Then install Ollama (https://github.com/ollama/ollama), run `ollama pull qwen2.5:7b` and
`ollama pull qwen2.5:3b`, and try:

```bash
python plain_ai.py --model qwen2.5:7b --split dev --dry-run
```

## What is in this folder

```
Akash_Kit/
├── README.md                     this file
├── Akash_Project_Guide.docx      your detailed guide (read this)
├── Akash_Project_Guide.md        the same guide as text (copy commands from here)
├── datasets/nsclc100/
│   ├── nsclc100.csv              100 patient–trial pairs
│   ├── criteria.csv              the 223 hand-reviewed rules  <- always use this
│   ├── splits.csv                development and test trials
│   ├── CRITERIA_REVIEW.md        what was fixed in the rules, and why
│   └── README.md                 what the data is and its limits
├── labelling/
│   ├── practice_sheet.csv        pairs 0 and 2 — practice only
│   ├── my_label_sheet.csv        your 20 pairs, 446 rule answers to label
│   └── my_pairs.csv              the list of your 20 pairs
├── code/                         ready-made, tested starter code
│   ├── selftest.py               run first
│   ├── criteria.py               rules, inclusion/exclusion logic, "what could change the decision"
│   ├── llm_client.py             safe calls to a local model (caching, retries, no cut text)
│   ├── plain_ai.py               the plain-AI system you check (and the forced-guess variant)
│   ├── evaluate.py               every score you report, including the checking simulation
│   ├── stats_tools.py            rarity re-weighting, trial-by-trial sign test, Holm correction
│   └── requirements.txt
├── templates/                    formats your output files must follow
└── outputs/                      your results go here
```

**What is already done for you:** the reviewed rules, the development/test split, your labelling
sheet, the plain-AI system you check, the local-model client, all scoring (including the simulation
of a person checking answers), and the statistics helpers.
**What you build:** the evidence checker, the priority ranking, the rejection-risk list, the fixer and
the trap set (guide Sections 8–12).

## Five rules that matter most

1. **Build on development trials; run the test trials once**, after freezing your code and labels.
2. **Never split the rule text yourself.** Use `criteria.csv`.
3. **Your checking strategies never read the answer key** — only the scoring does.
4. **Local models only.** No patient note goes to an online service.
5. **Always state the unit** (rule answer or pair) and give counts next to rates.

The SIGIR pack for Phase 2 comes from your supervisor after the mid-term.
