# The lung-cancer set (NSCLC-100)

## Files

| file | contents |
|---|---|
| `nsclc100.csv` | 100 rows, one row = one patient–trial pair |
| `criteria.csv` | **the 223 hand-reviewed rules of the 10 trials — use this for every rule-level step** |
| `splits.csv` | which trials are for development (dev) and which for the single test run (test) |
| `CRITERIA_REVIEW.md` | what was wrong with automatic splitting, what was fixed, and two points your supervisor confirms |

## What it is

- **10 real US non-small-cell lung cancer drug trials** × **10 patients each**.
- Exactly **5 Eligible and 5 Not Eligible per trial** (balanced by design).
- Patient profiles were **written by epidemiologists from case presentations in peer-reviewed
  journals**, not taken from a hospital record system. One profile appears twice (patients 0011 and
  0032, both Not Eligible), so there are 99 distinct patients.
- **De-identified, no protected health information.**
- Eligibility labels were assigned by clinicians and epidemiologists and checked by an epidemiologist.
  They were **not** labelled twice independently, and no agreement figure exists, so some may be wrong.

## `nsclc100.csv` columns

| column | meaning |
|---|---|
| `pair_idx` | 0-based row number — **the key every other file uses** |
| `trial_id` | `T01`–`T10` |
| `patient_id` | patient identifier from the source file |
| `target` | `Eligible` / `Not Eligible` — the label for the whole pair |
| `patient_orig` | the patient profile (the "note") |
| `inc_orig`, `exc_orig` | the trial's raw inclusion / exclusion text — **do not split it yourself; use `criteria.csv`** |

## `criteria.csv` columns

| column | meaning |
|---|---|
| `trial_id`, `crit_idx` | a rule's identity; `crit_idx` runs 0…n−1 per trial, inclusion rules first |
| `kind` | `inclusion` or `exclusion` |
| `criterion_text` | the source text, never rewritten |
| `source_lines` | which raw lines it came from, so you can check it |
| `note` | how to read it, when that is not obvious — **labellers and systems both follow it** |

## Facts you must know

1. **Labels are for the whole pair only.** A Not Eligible label says the patient failed *something*,
   never *which* rule. Rule-level answers are what you label yourself.
2. **Notes are short** (at most 2,038 characters) and have almost **no dates**.
3. **8 to 35 rules per trial**; 2,230 rule answers over the 100 pairs.
4. **Split by trial, never by row.** The ten patients of a trial share identical rules.
5. **Several rules are ambiguous in the registry itself** — see `CRITERIA_REVIEW.md` (for example T10:
   "Karnofsky Performance Status of 60" with no ≥).

## Provenance

`nsclc100.csv` is derived from the lab's authoritative NSCLC-100 file (sha256 prefix
`1a142cb5241c8d52`, the version after the 24 August encoding repair) by adding `pair_idx` and
`trial_id` and keeping only the columns above; row order is unchanged. A rewritten variant of the
text and a column of old model output were removed, so model output can never be mistaken for a label.

**Lab use only. Do not share outside the lab without your supervisor's permission.**
