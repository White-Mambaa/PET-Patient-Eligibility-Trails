# How `criteria.csv` was made, and why you must not re-split the criteria yourself

`nsclc100.csv` stores each trial's criteria as raw text (`inc_orig`, `exc_orig`). To work
criterion by criterion, that text has to be split into individual criteria. **An automatic splitter
got this wrong for 6 of the 20 criteria lists**, and the mistakes were not cosmetic: some reversed
the trial's meaning. So every trial's list was reviewed by hand, and the result is `criteria.csv`.

**Use `criteria.csv` for everything:** annotation, prompts, decision records, evaluation. Every
`crit_idx` in every file refers to it.

---

## What went wrong with automatic splitting

| trial | list | automatic | reviewed | what the automatic split did | consequence |
|---|---|---|---|---|---|
| T01 | exclusion | 5 | **13** | The exception sub-list was numbered 1–5 and the trial's own list continued at 6, so criteria 6–13 were swallowed into the "autoimmune disorders" criterion | 8 real exclusions (pregnancy, recent major surgery, active infection, QTc, …) disappeared into one giant criterion |
| T02 | exclusion | 17 | **18** | Dropped the criterion "Pregnancy" (it removed anything 10 characters or shorter) | A real exclusion was lost |
| T04 | inclusion | 16 | **14** | Two sentences defining post-menopausal status became separate inclusion criteria | A male patient failed them, so he was **excluded** |
| T04 | exclusion | 31 | **21** | Deleted the "autoimmune disorders" exclusion itself (its line ends with "exceptions to this criterion:") but kept its exceptions (vitiligo, stable hypothyroidism, celiac disease, …) as standalone exclusions; also split off the exceptions to "history of another malignancy" and the qualifying notes under "unresolved toxicity" | **Reversed meaning**: patients with lupus were not excluded, patients with vitiligo were |
| T06 | exclusion | 18 | **17** | Kept the heading "Any of the following cardiac criteria:" as a criterion | A meaningless criterion that can only produce `unknown` |
| T08 | inclusion | 11 | **9** | Kept the heading "For Phase 1B Extension Only:" as a criterion, and split off a permission sentence | A meaningless criterion, plus a permission treated as a requirement |

All 10 trials were checked line by line. The other 14 lists were split correctly; some of them received notes (below).
**Total: 223 reviewed criteria** (the automatic split gave 229).

## Rules used in the review

1. **The source text is never rewritten.** A criterion made of several source lines is those lines joined, in order.
2. **Exceptions stay with the criterion they belong to.** "Autoimmune disorders … The following are exceptions: vitiligo; hypothyroidism on replacement; …" is **one** exclusion criterion.
3. **Definitions and qualifying notes stay with their criterion** (T04 post-menopausal definitions, T04 neuropathy note).
4. **Pure headings are removed** ("Subjects should not enter the study if any of the following exclusion criteria are fulfilled:"). When a heading changes the meaning of the lines below it, it is kept as a prefix on each of them (T08 "For Phase 1B Extension Only:").
5. **Lists whose items each stand alone stay split** — "adequate organ function as defined below: haemoglobin ≥ 9 g/dL; platelets ≥ 100 …" becomes one inclusion criterion per lab value, because every one is required anyway.
6. **Interpretation goes in the `note` column, never into the text.**

## The `note` column — follow it when you annotate

| where | note says |
|---|---|
| T01 #12, T01 #20, T04 #15, T04 #19 | Listed exceptions are **not** excluded |
| T04 #11 | Applies to female patients only; the post-menopausal sentences are definitions. Male patient: not applicable |
| T04 #17 | The neuropathy and irreversible-toxicity sentences qualify the criterion; they are not separate exclusions |
| T07 #1 | Conditional: if brain metastases are present they must be controlled. No brain metastases: not applicable |
| T09 #1 | Conditional: applies only to tumours adjacent to a vertebral body. Otherwise not applicable |
| T10 #9, T10 #10 | Apply only to women of / not of child-bearing potential. Otherwise not applicable |
| T07 #2, #6, #7 · T08 #1, #2, #4 · T10 #14 | Phase-specific: judge the condition as written, ignoring the phase prefix |
| **T10 #3, T10 #8** | **The registry text itself has no comparator** — see below |

## Two things the supervisor must confirm before annotation starts

1. **T10 (ClinicalTrials.gov NCT01108666)** writes "Patients must have a Karnofsky Performance Status
   **of 60**" and "Patients must have bilirubin **1.5** mg/dl" — no ≥ or ≤, in the registry itself,
   not just in our copy. Read literally, a patient with Karnofsky 90 fails. The notes say to interpret
   them as **Karnofsky ≥ 60** and **bilirubin ≤ 1.5 mg/dl** (the standard convention).
2. **Phase-specific criteria** (T07, T08, T10): patient notes never say which phase a patient would
   enter. The notes say to judge each condition as written, ignoring the phase prefix. This is a
   consistent rule, not a certainty about how the original labels were assigned.

## How to check any row yourself

`source_lines` lists the raw line numbers the criterion came from: split the trial's `inc_orig` or
`exc_orig` on line breaks, drop empty lines, and count from 0. `inc12,inc13,inc14` means inclusion
lines 12, 13 and 14 joined.
