Your results go here: decision records, cases, checks, logs, and evaluate.py JSON files.
The plain-AI script writes its cache to outputs/cache/.
