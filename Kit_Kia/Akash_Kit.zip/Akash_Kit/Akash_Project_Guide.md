# Check What Can Change the Outcome — Project Guide for Akash

**Targeted checking of AI screening decisions for clinical trials**

Version 1 · 17 September 2026 · Your supervisor owns this document; ask before changing the plan.

---

## 0. How to use this guide

This guide tells you exactly what to build, in what order, how to test it, and what to show at the
mid-term and final presentations. It is long on purpose so you never have to guess — but you do not
need to read it in one go.

| when | read |
|---|---|
| Day 1 | Sections 1–4 (the project, background, words, setup) |
| Week 1 | Sections 5–6 (data and labelling) |
| Week 2 | Section 7 (the systems you check) |
| Weeks 2–4 | Section 8 (the evidence checker) |
| Weeks 4–5 | Sections 9 and 12 (priority ranking, traps) |
| Phase 2 | Sections 10, 11, 13–15 |
| Always | Section 16 (rules) and Section 17 (common mistakes) |

**Your project is independent.** Aman works on a different question with his own kit. You never need
his files or his results, and he never needs yours.

Copy prompts and commands from `Akash_Project_Guide.md` (the same text as this Word file), not from
Word — Word can change quote marks and break code.

---

## 1. Your project on one page

### The problem

An AI screens a patient for a clinical trial one rule at a time ("ECOG 0 or 1?", "Any active brain
metastases?"), gives an answer with a quote from the note, and the answers are combined into one
decision. A trial has **8 to 35 rules**, and a **single** rule answered "not met" turns the patient
away. The AI's answers can be wrong in quiet ways: the quote is not really in the note, a "no" was
missed, the illness belongs to the patient's mother, the lab value is two years old.

Nobody can check every answer: a trial with 30 rules and 100 patients gives 3,000 answers. But
**most wrong answers do not matter.** If a patient already fails three rules, one more mistake changes
nothing. The dangerous mistake is the one that is the **only** reason an eligible patient was turned
away.

### Your question

> **With limited checking time, which AI answers should a person check first to catch the most
> wrongly turned-away patients — and do automatic fixes help or harm?**

### What you build

| part | what it does |
|---|---|
| **A. Evidence checker** | Six checks on every answer: is the quote real, does it support the answer, was it misread, is the logic right, does another sentence contradict it, did an "unknown" ignore evidence? |
| **B. Priority ranking** | Orders all answers for a human checker, using what could change the decision and what the checker flagged |
| **C. Rejection-risk list** | Ranks the patients the system turned away by how likely the rejection is wrong — without knowing the answers |
| **D. Fixer** | Repairs a flagged answer (asks the AI again with the problem pointed out) or sends it to a person — and counts the fixes that break a right answer |
| **E. Trap set** | Notes altered on purpose (an added "no", a relative's illness, an old value…) where the right answer is known in advance |

### What you show

- **Mid-term (lung-cancer set only):** the systems you check, the first checks, how many rejections
  rest on a single rule, your first trap types, and a first "which checks catch harmful mistakes"
  comparison.
- **Final (lung-cancer set + SIGIR set):** the full comparison of checking strategies, the checker's
  quality, trap results, what the fixer fixes and breaks, and whether checking matters more when notes
  state their facts.

### Where this came from

Your team's AAPEMS proposal asked for agents that analyse false negatives and false positives and a
refinement agent. Those agents needed the true answers, which a real screening system never has.
Parts A–D are the same ideas **redesigned to work without the answers**: the checker and the risk list
look for *signs* of a wrong answer, and the fixer is tested for the damage it does as well as the good.

---

## 2. Background you need

### 2.1 How a screening decision works

A trial has **inclusion rules** (the patient must have these) and **exclusion rules** (the patient
must not have these). For every rule the system answers one question: **is the condition written in
the rule true for this patient?** The answer is `yes`, `no` or `unknown`.

Code then turns that answer into the rule's outcome:

| rule kind | answer `yes` | answer `no` | answer `unknown` |
|---|---|---|---|
| inclusion ("ECOG 0 or 1") | met | not met | not stated |
| exclusion ("active brain metastases") | **not met** | met | not stated |

And the pair's decision:

- any rule **not met** → `NOT_ELIGIBLE`
- every rule **met** → `ELIGIBLE`
- otherwise → `REVIEW` (a person must look)

### 2.2 How answers go wrong

| kind of error | example |
|---|---|
| **invented quote** | the answer quotes "stage IV adenocarcinoma", which is not in the note |
| **unsupported** | the quote is real but does not show the answer |
| **misread context** | "no brain metastases" read as brain metastases; "her mother had lung cancer" read as the patient's |
| **logic error** | the note says "ECOG 2" and the answer says the rule "ECOG 0 or 1" holds |
| **contradicted** | another sentence in the note says the opposite |
| **missed evidence** | the answer is "unknown" although a sentence decides it |

### 2.3 Why most errors do not matter — and which ones do

The tool `criteria.what_could_change` (in your `code/` folder) tells you, for every answer, whether
changing that one answer would change the pair's decision.

- **Pair 0 (trial T01)** fails two rules: stage IVa (rule 1) and prior treatment (rule 3). Even if one
  of those answers were wrong, the patient would still be excluded by the other. **Neither is a sole
  reason.**
- **Pair 2 (trial T01)** is labelled Eligible. If a system wrongly answered "no" to rule 6 (ECOG 0 or 1)
  and nothing else failed, that one answer would be the **sole reason** for turning her away. Checking
  that single answer rescues her.

Your project tests whether aiming human checks at answers like that rescues more eligible patients per
check than the usual approach (checking where the AI is least sure).

### 2.4 What other groups have done

Read the abstracts of these before Week 3. Open every link yourself before citing it.

| work | what it does | how you differ |
|---|---|---|
| TrialGPT (Jin et al., *Nature Communications* 2024) | An AI judges each rule with an explanation and the note sentences it relied on | You check answers automatically and decide which to show a person |
| VERDICT (Zhou et al., arXiv 2609.03366, September 2026) | Lists "pivotal conditions" — what would change a decision — and tests itself by changing them | Uses them for explanations and self-tests; you use them to **direct human checking** and measure patients rescued per check |
| αNeSy-CTM (Qu et al., arXiv 2606.20895, June 2026) | An AI plus logical verification for trial matching | Verifies the logic, not the quotes |
| Judge, Retrieve, or Abstain (Badshah et al., arXiv 2608.17994, 2026) | An AI judge that answers, looks things up, or abstains, with an error guarantee | Does not direct human review toward decision-changing answers |
| NLI4CT (SemEval-2024 Task 2) | Statements about trial reports, with deliberately altered versions | Trial reports, not patient notes |
| Kim et al., arXiv 2506.07962 (2025) | Different AI models tend to make the same mistakes | A reason not to rely on a second AI as the only check |
| medspaCy ConText | Rule-based detection of negated, hypothetical, family and historical mentions | A tool you use in check 3 |

Earlier work in this lab also suggested that answers quoting a real sentence were **not** much more
likely to be right. It was measured on an older version of the pipeline, so treat it as a hint to test
(hypothesis K2), not as a fact.

### 2.5 What is new in your project

1. **Checking aimed at decisions,** not at individual answers: answers are ranked by whether they
   could change a patient's decision, combined with warning signs.
2. **Patients rescued per check** as the measure, compared across strategies at the same budget.
3. **Fixes counted both ways:** answers repaired *and* right answers broken.

"As far as we found" means our searches found nothing — it is not proof. Say it that way in your
thesis.

---

## 3. Words used in this guide

| word | meaning |
|---|---|
| **pair** | one patient + one trial. The unit of patient-level results |
| **rule** | one eligibility criterion of a trial (one row of `criteria.csv`) |
| **rule answer** | one rule for one pair. The unit of rule-level results |
| `truth` | `yes` / `no` / `unknown` — is the rule's condition true for this patient? |
| `verdict` | `met` / `not_met` / `not_stated` — computed in code from truth + rule kind |
| `decision` | `ELIGIBLE` / `NOT_ELIGIBLE` / `REVIEW` — for the whole pair |
| **wrongly excluded** | a pair labelled Eligible that a system decides `NOT_ELIGIBLE`. **Your main harm measure** |
| **wrongly included** | a pair labelled Not Eligible that a system decides `ELIGIBLE` |
| **rescued** | a wrongly excluded pair that is no longer excluded after checks |
| **sole reason** | the only failing rule of a NOT_ELIGIBLE decision |
| **could change the decision** | changing this one answer would change the decision |
| **flagged** | the checker found a problem (label other than VERIFIED) |
| **check budget** | how many answers a person has time to check (5, 10, 20, 50, 100) |
| **development (dev) trials** | T01, T02, T03, T05, T09 — build and tune here |
| **test trials** | T04, T06, T07, T08, T10 — run **once**, after freezing |
| **freeze** | commit your code and settings to git, write down the commit hash, change nothing afterwards |

---

## 4. Setup (Day 1)

1. Install **Python 3.10 or newer**.
2. Unzip your kit. Open a terminal in the `code/` folder.
3. Install the basics:

```bash
pip install -r requirements.txt
```

4. Run the self-test. **Do not continue until it passes.**

```bash
python selftest.py
```

The last line must be `36 passed, 0 failed`.

5. Install **Ollama** (https://github.com/ollama/ollama) and pull two local models:

```bash
ollama pull qwen2.5:7b
ollama pull qwen2.5:3b
```

   - `qwen2.5:7b` (or `llama3.1:8b`) is your **main model**. Every reported result uses it.
   - `qwen2.5:3b` is for **fast debugging only**. Never report its numbers as your main results.
   - For the checker's AI judge you may use the **other** 7–8B model (for example `llama3.1:8b`), so
     the model that is checked is not also the only judge.

6. Check the plain-AI script without calling a model:

```bash
python plain_ai.py --model qwen2.5:7b --split dev --dry-run
```

7. When you reach check 1 and check 3, install:

```bash
pip install rapidfuzz medspacy
```

8. Make a private git repository for your work. Commit the kit as it is.

**Speed.** On a laptop, one model call takes a few seconds (the 3B model took about 7 seconds per
question on the lab test machine). The 950 development rule answers can take one to three hours. Every
answer is cached, so an interrupted run continues where it stopped — just rerun the command.

**No data leaves your computer.** Use local models only. Do not upload notes to online chat tools or
cloud services. If you ever want a larger online model, ask your supervisor first.

---

## 5. The data

### 5.1 The lung-cancer set (`datasets/nsclc100/nsclc100.csv`)

- **100 pairs**: 10 real US non-small-cell lung cancer trials × 10 patients each.
- Exactly **5 Eligible and 5 Not Eligible per trial** (balanced by design).
- Patient notes were written by epidemiologists from case reports in peer-reviewed journals. No real
  hospital records and no personal health information. One profile is used twice (patients 0011 and
  0032), so there are 99 distinct patients.
- Labels (`target`) are for the **whole pair** only. They were assigned by clinicians and
  epidemiologists and checked by an epidemiologist, but never labelled twice independently, so some
  may be wrong. That is why you run a label check (Section 6.6).
- Notes are **short** (at most 2,038 characters) and have almost **no dates**.

| column | meaning |
|---|---|
| `pair_idx` | 0–99, the key every file uses |
| `trial_id` | T01–T10 |
| `patient_id` | patient identifier |
| `target` | Eligible / Not Eligible |
| `patient_orig` | the patient note |
| `inc_orig`, `exc_orig` | the raw rule text — **never split this yourself** |

### 5.2 The reviewed rules (`datasets/nsclc100/criteria.csv`)

**223 rules** for the 10 trials, so **2,230 rule answers** over the 100 pairs. An automatic splitter
got **6 of the 20 rule lists wrong** — in one trial it turned "vitiligo is an *exception*" into
"vitiligo is *excluded*". Every list was reviewed by hand; read `CRITERIA_REVIEW.md` once. **Always use
`criteria.csv`.**

| column | meaning |
|---|---|
| `trial_id`, `crit_idx` | the rule's identity; `crit_idx` runs 0…n−1 per trial, inclusion rules first |
| `kind` | inclusion / exclusion |
| `criterion_text` | the source text, never rewritten |
| `source_lines` | which raw lines it came from |
| `note` | how to read the rule when that is not obvious. **You, your labels and your systems all follow it.** |

### 5.3 Development and test trials (`datasets/nsclc100/splits.csv`)

| split | trials | pairs | eligible pairs | rule answers |
|---|---|---|---|---|
| dev | T01, T02, T03, T05, T09 | 50 | 25 | 950 |
| test | T04, T06, T07, T08, T10 | 50 | 25 | 1,280 |

The split is **by trial** because the ten patients of a trial share the same rules.

### 5.4 The SIGIR set (Phase 2)

Before Phase 2 your supervisor gives you a **SIGIR pack**:

- **204 pairs** from a public clinical-trials test collection: **14 patients**, each compared with
  about 15 different trials (**204 trials**), **100 Eligible**;
- reviewed rules for about **20 pairs** that you will label;
- a split **by patient** (each patient appears in about 15 pairs);
- a short data card.

SIGIR case descriptions are short and often leave facts unstated. That makes it a useful contrast:
there, many answers are `unknown`, and fewer errors are misreadings of stated facts.

### 5.5 Data rules

- The lung-cancer set is for **lab use only**. Do not share it outside the lab.
- Keep all data **out of public repositories**.
- Local tools only (Section 4).

---

## 6. Your answer key (labelling)

You label **20 pairs** yourself: **2 per trial, 10 Eligible and 10 Not Eligible, 446 rule answers**.
These labels are your answer key for judging which system answers are right.

**They are student labels:** made by you, not by a clinician, and not checked by an expert. That is fine for this project, but it decides how you describe and report them (Section 14, rules 9 and 10).

### 6.1 Files (`labelling/`)

| file | what |
|---|---|
| `practice_sheet.csv` | pairs 0 and 2 (trial T01), 42 rows — practice only, never scored |
| `my_label_sheet.csv` | your 20 pairs, 446 rows |
| `my_pairs.csv` | the list of your 20 pairs and their split |

Open the CSV files in Excel or LibreOffice and turn on text wrapping for `criterion_text`,
`criterion_note` and `patient_note`. **Save as CSV (UTF-8).**

The sheet deliberately does **not** show whether the pair is Eligible. Label each rule from the note
alone, and do not look up the pair's label while labelling.

### 6.2 Columns you fill

| column | allowed values | rule |
|---|---|---|
| `truth` | `yes` `no` `unknown` | required for every row |
| `evidence_span` | text | **copy-paste** the exact words from `patient_note` that decide it. Empty only when truth is `unknown`. Several spans: separate them with ` \|\| ` |
| `basis` | `stated` `inferred` `absent` | stated: written directly · inferred: a standard clinical implication · absent: nothing in the note |
| `not_applicable` | `Y` or empty | the rule only applies to a group the patient is not in (rule 5 below) |
| `compound` | `Y` or empty | the rule bundles several conditions (rule 4 below) |
| `comment` | text | anything unusual — **always** comment when you hesitate. Not sure your answer is right? Start the comment with `UNSURE:` (rule 2 below) |

### 6.3 Labelling rules

0. **If `criterion_note` is filled, follow it.** Notes explain exceptions, conditional rules,
   phase-specific rules and two defects in the source text.
1. **Judge the condition as written, from the note only.** No outside knowledge of what is "probably"
   true. If you would need to guess, the answer is `unknown`.
2. **`unknown` means the note does not contain enough information** — not "I am unsure how to apply
   the rule". If you are unsure about a rule or a medical term, first look up what the term means (a
   medical dictionary is fine; that is not outside knowledge about the patient). Still unsure? Give your
   best label and start the comment with `UNSURE:` and the reason, for example
   `UNSURE: not sure what "measurable disease" means here`. Never hide a doubt behind `unknown`.
3. **Inferred only for standard implications,** marked `basis = inferred`:
   - "stage IVA" → "metastatic disease" is `yes`
   - "squamous cell carcinoma of the lung" → "documented NSCLC" is `yes`
   - "ECOG 1" → "ECOG 0 or 1" is `yes` (this one is `stated`)
   - "adequate organ function" is **not** implied by the absence of abnormal labs → `unknown`
4. **Compound rules** ("A and B", or a rule with a sub-list): `yes` only if every part is `yes`; `no`
   if any part is `no`; otherwise `unknown`; mark `compound = Y`. For "A **or** B": `yes` if any part
   is `yes`, `no` only if all parts are `no`.
   **Exceptions reverse the condition:** "autoimmune disorders; exceptions: vitiligo", for a patient
   whose only condition is vitiligo → `no`.
5. **Not applicable** (the rule targets a group the patient is not in — a pregnancy rule for a male
   patient; a rule about treated brain metastases for a patient without brain metastases): set
   `not_applicable = Y` and choose the truth that makes the rule **not affect** eligibility —
   inclusion → `yes`, exclusion → `no`.
6. **Negated statements are evidence.** "No brain metastases" makes "brain metastases" `no`
   (`stated`), with that phrase as the evidence.
7. **Thresholds are thresholds.** Note "FEV1 ≥ 50%", rule "FEV1 ≥ 50%" → `yes`. Note "FEV1 ≥ 50%",
   rule "FEV1 ≥ 60%" → `unknown` (≥ 50 does not tell you ≥ 60).
8. **Equivalent scales:** Zubrod and WHO performance status = ECOG.
9. **"Prior therapy" rules:** a newly diagnosed patient with no treatment mentioned → `unknown`,
   unless the note says treatment-naive or "no prior therapy". A biopsy or bronchoscopy is not therapy.

### 6.4 Worked examples (trial T01, practice pairs)

**Pair 2** — note: *"A 19-year-old white, never-smoker woman experienced chest pain; a chest X-ray and
a computed tomography (CT)-scan showed early-stage lung adenocarcinoma. ECOG was 0. FEV1 ≥ 50% and
DLCO ≥ 50%."*

| rule | kind | truth | evidence_span | basis | why |
|---|---|---|---|---|---|
| 4 · FEV1 ≥ 50 percent | inclusion | yes | `FEV1 ≥ 50%` | stated | same threshold (rule 7) |
| 6 · ECOG 0 or 1 | inclusion | yes | `ECOG was 0` | stated | 0 is inside 0–1 |
| 7 · Adequate organ function | inclusion | unknown | | absent | lung function alone does not show organ function (rule 3) |
| 13 · Pregnant or breast-feeding female | exclusion | unknown | | absent | applies to her, but the note is silent |

**Pair 0** — note: *"A 69-year-old man was diagnosed with stage IVa squamous cell carcinoma of the
lung. He had a programmed cell death-ligand 1 (PD-L1) tumor proportion score ≥50%. He achieved partial
response after four cycles of sintilimab as first-line treatment."*

| rule | kind | truth | evidence_span | basis | why |
|---|---|---|---|---|---|
| 0 · Documented NSCLC | inclusion | yes | `stage IVa squamous cell carcinoma of the lung` | inferred | rule 3 |
| 1 · Stage I (> 2 cm) to IIIA | inclusion | no | `stage IVa` | stated | IVa is outside I–IIIA |
| 3 · Have not received any other therapy | inclusion | no | `four cycles of sintilimab as first-line treatment` | stated | he was treated |
| 13 · Pregnant or breast-feeding female | exclusion | no, `not_applicable = Y` | `A 69-year-old man` | stated | rule 5 |

**A hard case (write your own answer):** pair 0, rule 10 lists "PD-L1, PD-L1, or CTLA-4 inhibitors" —
PD-L1 appears twice, and sintilimab acts on PD-1. When a rule's text looks wrong, give your best label,
write a clear comment, and raise it with your supervisor.

### 6.5 The labelling procedure

1. **Week 1:** label the practice sheet on your own. Ask your supervisor to look at about ten of your
   rows. Practice is never scored.
2. **Week 1:** label the **10 development pairs** (190 rows) in `my_label_sheet.csv`.
3. **Week 4, before any system runs on a test trial:** label the **10 test pairs** (256 rows).
4. Save the finished sheet as **`labelling/my_labels_final.csv`** (same columns) and commit it. Write
   the commit hash in your notes. **From now on the labels are frozen.**
5. A few of your pairs are also labelled by another person, so your supervisor can measure how much two
   careful people agree. **Do not discuss specific rows with anyone until your supervisor says the
   comparison is done.**

**Never change a frozen label to make a system look better.** If you find a real mistake, record it in
`labelling/corrections.csv` (pair, rule, old, new, reason, date) and tell your supervisor. Report the
number of corrections in your thesis.

### 6.6 The label check

```bash
python evaluate.py labelcheck --gold ../labelling/my_labels_final.csv --out ../labelling/labelcheck.csv
```

It lists every labelled pair whose rule answers contradict its Eligible / Not Eligible label. **Send
the list to your supervisor.** Never change your labels or the pair label yourself to remove a
conflict. Your supervisor decides, and the decision goes in the `supervisor_decision` column.

**Never skip this check.** It is the only automatic comparison of your labels with the dataset's own
Eligible / Not Eligible labels (lung-cancer set: assigned by clinicians and epidemiologists; SIGIR: the collection's assessors). Run it on your lung-cancer labels, and again
on your SIGIR labels (your SIGIR pack gives the command). In your thesis, report how many pairs it flagged
and what your supervisor decided.

---

## 7. The systems you check (Week 2)

You check answers produced by systems you run yourself, with your main model.

### 7.1 Plain AI (`code/plain_ai.py`) — your main subject

One question per rule: the whole note plus one rule; the model answers yes / no / unknown, quotes the
note and gives a confidence. The prompt is printed by `--dry-run`.

```bash
python plain_ai.py --model qwen2.5:7b --split dev
python evaluate.py pairs --pred ../outputs/plain_ai_qwen2.5-7b_dev.jsonl --split dev
python evaluate.py criterion --gold ../labelling/my_labels_final.csv --pred ../outputs/plain_ai_qwen2.5-7b_dev.jsonl --split dev
python evaluate.py evidence --pred ../outputs/plain_ai_qwen2.5-7b_dev.jsonl --gold ../labelling/my_labels_final.csv --split dev
```

### 7.2 Forced guess (`--no-unknown`) — a second subject with more errors

The model **must** answer yes or no. It produces more wrong "not met" answers, which gives your
checker more harmful errors to find.

```bash
python plain_ai.py --model qwen2.5:7b --split dev --no-unknown
```

### 7.3 Your team's existing search-then-answer pipeline (optional third subject)

If you adapt it, it must use the **reviewed rules**, answer **rule by rule** with the same JSON as the
plain AI (truth, evidence, basis, rationale, confidence), apply `criteria.map_truth` in code, use
**local** search only, and write decision records (`templates/decision_record.schema.json`). Keep the
retrieval simple (the top 3 sentences); do not tune it.

### 7.4 What to record

For each system on the development trials: rule-level accuracy on your labelled pairs, wrongly
excluded (out of 25), **how many of those rest on a single failing rule** (printed by
`evaluate.py pairs`), wrongly included, sent to review, share of quotes found verbatim, and unreadable
answers. This is **Table 1 (dev)** for the mid-term.

---

## 8. Part A — the evidence checker (Weeks 2–5)

Run **all six checks on every answer** and store every result. Then give each answer **one label**
(Section 8.8). Output: one line per answer following `templates/checker_result.schema.json`, in
`outputs/checks/<system>_<split>.jsonl`.

Use `code/llm_client.py` for every model call (temperature 0, JSON only, full prompts, caching, no
failed call ever becomes an answer).

### 8.1 Rule statements (made once, then frozen — Week 3)

Checks 2, 3, 5 and 6 need each rule as a plain statement about the patient, plus key words. One model
call per rule:

```
SYSTEM:
Rewrite the eligibility condition as ONE short sentence stating that the patient has it,
keeping every medical detail, and list 1 to 3 key terms that must appear in a note for it to be
decided. If GUIDANCE is given, follow it.
Return JSON only: {"statement": "...", "key_terms": ["...", "..."]}
USER:
CONDITION: {criterion_text}
GUIDANCE: {note}          <- leave this line out when the note is empty
```

Example: "Active or untreated brain metastases" →
`{"statement": "The patient has active or untreated brain metastases.", "key_terms": ["brain metastases", "brain metastasis"]}`

Save `outputs/rule_statements.jsonl` (`trial_id, crit_idx, kind, criterion, statement, key_terms`).
**Check the 95 development rows by hand**, fix mistakes, and freeze. Generate the 128 test rows at the
start of Phase 2 and **never edit them**.

### 8.2 Check 1 — Is the quote real? (citation)

For each quoted span:

1. Normalise whitespace in the span and the note.
2. The span is inside the note → **FOUND**.
3. Otherwise compute `rapidfuzz.fuzz.partial_ratio(span, note)` (0–100):
   - `≥ θ` → **PARAPHRASED** (store the best-matching note text)
   - `< θ` → **NOT_FOUND**
4. Truth `yes` or `no` with no quote at all → **NO_EVIDENCE_CITED**.

```python
from rapidfuzz import fuzz
score = fuzz.partial_ratio(span_normalised, note_normalised)   # 0..100
```

**Choosing θ (Week 2):** take the non-verbatim quotes from the plain-AI answers on development pairs.
Hand-label up to 60 of them as `real paraphrase` or `invented`. Pick θ from {70, 75, 80, 85, 90, 95}
with the best agreement with your hand labels. Freeze θ and report the table.

**Example from a real test run:** for pair 2 the model quoted `ECOG 0`, while the note says
`ECOG was 0` — a paraphrase, not an invention.

### 8.3 Check 2 — Does the quote support the answer? (support)

- **Statement:** the frozen statement for this rule.
- **Evidence:** the found or matched note text. No usable evidence → skip (`nli_label = null`).
- **Option A — a sentence-support model:** `cross-encoder/nli-deberta-v3-base` (Apache-2.0). Its three
  output scores are in the order **contradiction, entailment, neutral**; apply softmax. Score each
  evidence sentence separately; take the highest entailment and the highest contradiction probability.
- **Option B — an AI judge** (prompt below), preferably a different model from the one being checked.
- Choose A or B on development answers by flag quality. Report both.

```
SYSTEM:
Does the EVIDENCE show that the STATEMENT is true, false, or not determinable for this patient?
Use only the evidence. Return JSON only: {"label": "entailment|contradiction|neutral"}
USER:
STATEMENT: {statement}
EVIDENCE: {evidence sentences, one per line}
```

| system answer | support label | consistent? |
|---|---|---|
| yes | entailment | yes |
| no | contradiction | yes |
| yes | neutral or contradiction | **no** → UNSUPPORTED candidate |
| no | neutral or entailment | **no** → UNSUPPORTED candidate |
| unknown | — | not checked here (see check 6) |

For option A, "entailment" means entailment probability ≥ τ and contradiction probability < τ;
"contradiction" the reverse; otherwise neutral. Pick τ from {0.5, 0.6, 0.7, 0.8, 0.9} on development
answers. Freeze.

### 8.4 Check 3 — Was it misread? (context)

Use **medspaCy ConText** (MIT licence). The target terms are the rule's frozen `key_terms`.

```python
import medspacy
from medspacy.ner import TargetRule

nlp = medspacy.load()
matcher = nlp.get_pipe("medspacy_target_matcher")
matcher.add([TargetRule(term, "CONCEPT") for term in key_terms])

doc = nlp(evidence_sentence)            # the full note sentence that contains the quote
for ent in doc.ents:
    flags = {"negated": ent._.is_negated, "uncertain": ent._.is_uncertain,
             "hypothetical": ent._.is_hypothetical, "family": ent._.is_family,
             "historical": ent._.is_historical}
```

The loading call, import path and pipe name come from the medspaCy README. **Confirm the five
`ent._.is_*` attribute names on your installed version** (print `dir(ent._)`) before building on them.

**Misread rule** (→ CONTEXT_ERROR candidate):

- the answer is `yes` and the matched term in the evidence is **negated**, **hypothetical**,
  **uncertain** or about **family**;
- the answer is `yes`, the term is **historical**, and the rule says "active", "current", "ongoing" or
  "within".

Log every flag even when it is not an error. A historical mention for a "history of…" rule is correct.

### 8.5 Check 4 — Is the logic right? (logic)

**(a) Inclusion/exclusion consistency — every answer:** `verdict == map_truth(truth, kind)`. A mismatch
is a **LOGIC_ERROR** (it means a bug in how a file was written).

**(b) Numbers — when both the rule and the evidence contain numbers:**

1. Extract (measure, comparator, value, unit) from the rule with regular expressions. Measures:
   ECOG / Zubrod / WHO, Karnofsky, FEV1, DLCO, age, creatinine, hemoglobin, platelets, bilirubin, ALT,
   AST, neutrophils. Patterns: `≥ 50`, `>= 50`, `> 2 cm`, `≤ 1.5`, `0 or 1`, `0-1`,
   `between 3.5 and 5.0`.
2. Extract the same from the evidence ("ECOG=1", "FEV1 ≥ 50%", "creatinine 2.9 mg/dL").
3. Same measure and unit → work out the expected answer with ranges: evidence `≥ 50` against rule
   `≥ 50` → yes; against `≥ 60` → cannot tell; `ECOG 2` against `0–1` → no.
4. An expected answer that differs from the system's answer → **LOGIC_ERROR**. "Cannot tell" → no
   verdict from numbers.

**(c) AI judge — only for `basis = inferred` answers without a number check:**

```
SYSTEM:
A system decided a clinical-trial condition for a patient. Judge only whether its conclusion
follows logically from the evidence it quoted. Do not use outside facts about the patient.
Return JSON only: {"valid": true, "reason": "one sentence"}
USER:
CONDITION: {criterion}
EVIDENCE QUOTED: {evidence}
REASONING: {rationale}
CONCLUSION: the condition is {truth}
```

`valid = false` → LOGIC_ERROR candidate.

### 8.6 Check 5 — Does another sentence contradict it? (contradiction)

Split the note into sentences (on ". ", "; " and line breaks). Score every sentence **not already
quoted** against the rule statement with your chosen support method:

- answer `yes` and a sentence **contradicts** the statement → **CONTRADICTED**
- answer `no` and a sentence **supports** the statement → **CONTRADICTED**

Store the sentence. The notes are short, so this is cheap.

### 8.7 Check 6 — Was evidence ignored? (missed evidence, answer `unknown` only)

Score every sentence against the statement. If any sentence supports **or** contradicts it (same τ),
the note actually decides the rule → **MISSED_EVIDENCE**. Store the sentence.

### 8.8 One label per answer (fixed order)

Run all checks, store every result in `checks`, then assign the **first** label that applies:

| order | label | condition |
|---|---|---|
| 1 | `HALLUCINATED_EVIDENCE` | check 1: any quote NOT_FOUND |
| 2 | `CONTEXT_ERROR` | check 3 misread rule fired |
| 3 | `LOGIC_ERROR` | check 4: consistency or number mismatch, or AI judge says invalid |
| 4 | `CONTRADICTED` | check 5 found a contradicting sentence |
| 5 | `UNSUPPORTED` | check 2 inconsistent, or NO_EVIDENCE_CITED with answer yes/no |
| 6 | `MISSED_EVIDENCE` | check 6 found a deciding sentence for an `unknown` |
| 7 | `VERIFIED` | none of the above |

Write a one-sentence `reason` a person can act on, for example *"The quote 'no brain metastases' is
negated, but the answer treated brain metastases as present."*

Score the checker:

```bash
python evaluate.py verification --gold ../labelling/my_labels_final.csv \
    --pred ../outputs/plain_ai_qwen2.5-7b_dev.jsonl \
    --verif ../outputs/checks/plain_ai_qwen2.5-7b_dev.jsonl --split dev
```

### 8.9 Unit tests (write them first)

Tests 1–4, 7, 8, 10 and 12–15 are **deterministic** and must pass exactly. Tests 5 and 6 depend on
medspaCy's default rules. Tests 9 and 11 depend on the support method you choose: if one fails, find
out why and write it down — **never** tune θ or τ on test data to make a test pass.

| # | input | expected |
|---|---|---|
| 1 | quote "ECOG=1", note contains "ECOG=1" | check 1 FOUND |
| 2 | quote "ECOG equals one", note contains "ECOG=1" | check 1 not FOUND |
| 3 | quote "stage IV adenocarcinoma", not in the note | NOT_FOUND → HALLUCINATED_EVIDENCE |
| 4 | answer yes, no quote | NO_EVIDENCE_CITED → UNSUPPORTED |
| 5 | answer yes for "brain metastases", sentence "No evidence of brain metastases." | negated → CONTEXT_ERROR |
| 6 | answer yes for "lung cancer", sentence "Her mother had lung cancer." | family → CONTEXT_ERROR |
| 7 | answer yes for "ECOG 0 or 1", evidence "ECOG 2" | numbers → LOGIC_ERROR |
| 8 | answer yes, kind exclusion, verdict "met" | consistency → LOGIC_ERROR |
| 9 | answer yes for "ECOG 0 or 1", evidence "ECOG=1", nothing else in the note | VERIFIED |
| 10 | quote NOT_FOUND **and** negated | HALLUCINATED_EVIDENCE (order) |
| 11 | answer unknown for "ECOG 0 or 1", note contains "ECOG=1" | MISSED_EVIDENCE |
| 12 | answer yes for "FEV1 ≥ 60%", evidence "FEV1 ≥ 50%" | numbers cannot tell → no LOGIC_ERROR from numbers |
| 13 | answers [met, not_met, met] | the not_met answer is the sole reason (priority tier 1) |
| 14 | answers [not_met, not_met, met] | no sole reason; both failing answers are in tier 2 (Section 9.2) |
| 15 | a fix turns a right answer wrong | counted as **broken**, not as fixed |

---

## 9. Part B — the priority ranking (Weeks 4–5, then Phase 2)

### 9.1 What a person does

A coordinator has time to check **k** answers (k = 5, 10, 20, 50, 100). For each checked answer they
read the note and correct the answer if it is wrong. Your ranking decides **which** k answers they see.

### 9.2 The strategies (none of them may use the answer key)

For every answer of a system on a split, compute: its verdict, `could_change` and `sole_reason`
(`criteria.what_could_change` over the pair's answers), the number of failing rules of its pair, the
checker label, and the AI's confidence.

| strategy | order |
|---|---|
| `random` | random, seed 7 — the floor |
| `least_confident` | lowest AI confidence first (missing confidence counts as 0.5) |
| `flagged_first` | flagged answers first, by label order (Section 8.8), then the rest at random |
| `fewest_reasons` | **tier 1:** sole reasons; **tier 2:** failing answers of pairs with 2 failing rules, then 3, …; **then** all other answers at random |
| `combined` | failing answers that are also flagged, fewest reasons first; then the other failing answers, fewest reasons first; then flagged non-failing answers; then the rest |
| `learned` (Phase 2, optional) | a simple model trained on development answers (Section 18) |

Write each ordering as a CSV with columns `pair_idx, crit_idx` (best first), for example
`outputs/orders/fewest_reasons_plain_ai_dev.csv`.

### 9.3 Scoring a strategy

```bash
python evaluate.py targeting --pred ../outputs/plain_ai_qwen2.5-7b_dev.jsonl \
    --order ../outputs/orders/fewest_reasons_plain_ai_dev.csv \
    --budgets 5,10,20,50,100 --split dev --gold ../labelling/my_labels_final.csv
```

For each budget it reports the wrongly excluded pairs that remain, the pairs rescued, the answers
changed, the wrongly included pairs, and the pairs sent to review.

**How a check is simulated** (read this carefully — it is part of your method):

1. If you labelled that answer, the checked answer becomes **your label**.
2. Otherwise, if the pair is labelled Eligible and the answer is "not met", the checked answer becomes
   **unknown** — the person removes a rejection reason the note does not support. This assumes the
   pair's Eligible label is right, which is why the label check matters.
3. Otherwise nothing changes, and the check is counted as having an **unknown effect**.

Report rescued pairs **per 10 checks**, and draw a curve: x = checks (0–100), y = wrongly excluded
pairs remaining, one line per strategy.

---

## 10. Part C — the rejection-risk list (Phase 2)

This is the fixed version of your proposal's "false negative analyser": it works **without** the
answers.

For every pair a system decided NOT_ELIGIBLE, compute a risk score from what is visible:

```
risk = (number of failing answers that were flagged) / (number of failing answers)
ties: fewer failing answers first, then lower average confidence of the failing answers first
```

Rank the rejected pairs by risk. Then measure, with the pair labels:

- **precision at k** — of the k highest-risk rejected pairs, how many are truly Eligible (wrongly
  excluded);
- **recall at k** — of all wrongly excluded pairs, how many are in the top k.

Report k = 3, 5 and 10, with counts. Compare with a random order of the rejected pairs.

---

## 11. Part D — the fixer (Phase 2)

Each policy produces a **new decision-records file**, scored with the usual `evaluate.py` modes.

| policy | what happens to a flagged answer |
|---|---|
| **keep** | nothing (the starting point) |
| **flag** | its truth becomes `unknown`, so the pair goes to review instead of being decided by that answer |
| **re-ask** | ask the same model once more with the feedback below, check the new answer; if VERIFIED keep it, otherwise apply **flag** |

Build the re-ask prompt with the plain-AI system prompt and `plain_ai.build_user(...)`, then add one line at the end of the user message: `FEEDBACK: {sentence}`. The feedback sentences are:

| label | feedback |
|---|---|
| HALLUCINATED_EVIDENCE | "Your quote '{span}' does not appear in the note. Quote only exact text from the note." |
| CONTEXT_ERROR | "The text '{span}' is {negated / hypothetical / about a family member / historical}; it does not show the patient currently has the condition." |
| LOGIC_ERROR | "The note states '{evidence}', which does not give your answer for '{criterion}'. Re-check the values." |
| CONTRADICTED | "Another sentence in the note says: '{sentence}'. Re-check your answer." |
| UNSUPPORTED | "Your quoted evidence does not establish your answer. Answer 'unknown' if the note does not decide the condition." |
| MISSED_EVIDENCE | "The note contains: '{sentence}'. Check whether it decides the condition." |

**Count both directions** on your labelled answers:

- **fixed** — wrong before, right after;
- **broken** — right before, wrong after;
- **unchanged**.

A policy that fixes 30 answers and breaks 25 is not a success. Also report, on all pairs, wrongly
excluded and wrongly included before → after, and how many more pairs go to review.

Combine with Part B: apply **re-ask** only to the first k answers of your best ordering, and compare
with a person checking those same k answers.

---

## 12. Part E — the trap set (Weeks 4–5 and Phase 2)

Test cases where **you know the right answer in advance** and what a careless system would get wrong.
Build them **only from your development pairs** (trials T01, T02, T03, T05, T09).

### 12.1 Seven trap types

| type | pick an answer whose label is | change the note | expected answer | the trap |
|---|---|---|---|---|
| **NEGATION** | `unknown` (not mentioned) | add "No evidence of {key term}." | `no` | answering `yes` because the word appears |
| **FAMILY_HISTORY** | `unknown` | add "{Her/His} mother had {key term}." | `unknown` | reading a relative's illness as the patient's |
| **HYPOTHETICAL** | `unknown` | add "Rule out {key term}." | `unknown` | treating a suspicion as a diagnosis |
| **OLD_VALUE** | decided by a stated value (e.g. "ECOG was 0" → `yes`) | add "Two years ago, before treatment, {measure} was {an old value that would flip the answer}." | unchanged | using the old value |
| **CONTRADICTION** | decided by a stated value | add "{measure} {opposite value}." (no time cue) | `unknown` | ignoring the conflict |
| **EVIDENCE_REMOVED** | decided by a single sentence | remove that sentence | `unknown` | still answering, or quoting the removed sentence |
| **THRESHOLD_SHIFT** | decided by a stated number | change the number so it crosses the rule's limit (e.g. "FEV1 ≥ 50%" → "FEV1 40%") | flipped | answering from habit instead of the new number |

### 12.2 How to build them

- Up to **20 cases per type** (at most 140). With 10 development pairs you may reuse a pair with a
  different rule. If fewer than 20 suitable cases exist, use all of them and report the number.
  **Never** use a test-trial pair.
- Write each changed sentence by hand, using the rule's key terms. Keep it short and unambiguous.
- **Re-read every altered note** and confirm the expected answer; set `checked_by_hand = true`.
- Save one case per line in `outputs/traps/traps.jsonl` following `templates/trap_record.schema.json`
  (`case_idx` 0…N−1).
- Write the answer key `outputs/traps/traps_key.csv` with columns
  `split, pair_idx, trial_id, crit_idx, kind, criterion_text, truth, evidence_span`, where `split` is
  `trap`, `pair_idx` is the case number and `truth` is the expected answer.

### 12.3 Run and measure

```bash
python plain_ai.py --model qwen2.5:7b --cases ../outputs/traps/traps.jsonl --dataset trap_set \
    --out ../outputs/traps/plain_ai_traps.jsonl
```

Run your checker on those answers, reading each note from `traps.jsonl` (the altered note), **not**
from `nsclc100.csv`. Then, for each trap type:

- **trap rate** — share of cases where the system answered wrongly (did the trap work?);
- **detection rate** — among those wrong answers, the share your checker flagged;
- **right-label rate** — among the detected, the share with the expected label:

| type | expected label |
|---|---|
| NEGATION, FAMILY_HISTORY, HYPOTHETICAL | CONTEXT_ERROR |
| OLD_VALUE | CONTEXT_ERROR (historical) or CONTRADICTED |
| CONTRADICTION | CONTRADICTED |
| EVIDENCE_REMOVED | HALLUCINATED_EVIDENCE or UNSUPPORTED |
| THRESHOLD_SHIFT | LOGIC_ERROR |

```bash
python evaluate.py verification --gold ../outputs/traps/traps_key.csv \
    --pred ../outputs/traps/plain_ai_traps.jsonl --verif ../outputs/traps/checks_traps.jsonl
python evaluate.py evidence --pred ../outputs/traps/plain_ai_traps.jsonl --cases ../outputs/traps/traps.jsonl
```

---

## 13. Experiments and what to report

Always use your **main model** for reported numbers. Development trials while building; test trials
**once**.

| id | question | data | table |
|---|---|---|---|
| **K1** | Which checking strategy rescues the most wrongly excluded eligible pairs per check? | all pairs of a split | Table 2 + curve |
| **K2** | How good is the checker, and which checks actually predict wrong answers? | your labelled answers | Tables 3 and 4 |
| **K3** | Do fixes help or harm? | labelled answers + all pairs | Table 5 |
| **K4** | Which traps fool the system, and which does the checker catch? | trap set | Table 6 |
| **K5** | Can the rejection-risk list find wrongly excluded patients without the answers? | all rejected pairs | Table 7 |
| **K6** | Does checking help more on the lung-cancer set than on SIGIR? | both datasets | Table 8 |

### Hypotheses (write them in your mid-term slides before you have test results)

- **K1.** `fewest_reasons` and `combined` rescue more wrongly excluded eligible pairs per 10 checks than
  `random` and `least_confident`.
- **K2.** "The quote is real" alone predicts wrong answers poorly; the misread, logic and contradiction
  checks do most of the work.
- **K3.** Re-asking fixes some answers but breaks some right ones; flagging never breaks an answer but
  sends more pairs to review.
- **K4.** Negation and family-history traps are caught more often than old-value and contradiction
  traps.
- **K5.** Among rejected pairs, those whose failing answers were flagged are wrongly excluded more
  often than a randomly chosen rejected pair (precision at 5 above the random order).
- **K6 (Phase 2).** Checking rescues more pairs per check on the lung-cancer set, where facts are stated
  and misreadings are possible, than on SIGIR, where most facts are simply missing.

A hypothesis that turns out false is a result. Report it plainly.

### Table 1 — the systems you check (unit: pair, except the first two columns)

| system | rule accuracy on your labels (n) | quotes found verbatim | wrongly excluded / eligible | of which by a single failing rule | wrongly included | sent to review |
|---|---|---|---|---|---|---|

### Table 2 — checking strategies (unit: pair; one block per system)

| strategy | rescued at 5 | at 10 | at 20 | at 50 | at 100 | rescued per 10 checks (at 50) | checks with unknown effect (at 50) |
|---|---|---|---|---|---|---|---|

### Table 3 — checker quality (unit: labelled rule answer)

| system | n | wrong answers | flagged | precision | recall | accuracy of VERIFIED answers (share) | accuracy of flagged answers |
|---|---|---|---|---|---|---|---|

### Table 4 — which checks matter (unit: labelled rule answer)

Remove one check at a time and re-score. Report the change in precision and recall, and the number of
wrong answers only that check catches.

| check removed | precision | recall | wrong answers caught only by this check |
|---|---|---|---|

### Table 5 — fixes (labelled answers; pair columns on all pairs of the split)

| system | policy | fixed | broken | unchanged | wrongly excluded before → after | wrongly included before → after | sent to review before → after |
|---|---|---|---|---|---|---|---|

### Table 6 — traps (unit: trap case)

| type | cases | trap rate | detection rate | right-label rate |
|---|---|---|---|---|

### Table 7 — rejection-risk list (unit: rejected pair)

| system | rejected pairs | wrongly excluded among them | precision at 3 / 5 / 10 | recall at 3 / 5 / 10 | random order at 5 |
|---|---|---|---|---|---|

### Table 8 — the dataset question (Phase 2)

| dataset | answers flagged | wrongly excluded before checks | rescued per 10 checks (best strategy) | share of wrong answers that are misreadings vs missed facts |
|---|---|---|---|---|

Also report your pair-level results re-weighted to realistic rarity (most screened patients do not qualify):
`evaluate.py pairs ... --target-rate 0.10 --target-rate 0.05`.

---

## 14. How to report numbers honestly

The data is small: 10 trials, 100 pairs, 25 eligible pairs per split. Pairs from the same trial are not
independent — the real sample size is closer to **10 trials** than to 100 pairs.

1. **Always give counts next to rates:** "rescued 4 of 7 wrongly excluded pairs", never just "57%".
2. **Report per trial** (`evaluate.py pairs` prints it).
3. **Compare strategies trial by trial** with `stats_tools.trial_sign_test` (lung-cancer set: unit =
   trial; SIGIR: unit = patient).
4. **Several comparisons at once?** Correct the p-values with `stats_tools.holm` and say so.
5. **A checker can look good by flagging everything.** Always report precision **and** recall, and how
   many pairs end up in review.
6. **Verified is not the same as correct.** A quote can be real and still misleading. The accuracy of
   VERIFIED answers is the number a clinician cares about.
7. **Trials with more rules exclude more patients for arithmetic reasons.** Check that gains are not
   concentrated in the longest rule lists. On SIGIR, also report a **count-the-rules baseline**
   (predict Not Eligible when a trial has more rules than the median on development patients).
8. **Call results exploratory.** Write "rescued d more pairs in k of n trials", never "significantly
   better" on this data.
9. **Call your labels "student labels"** in slides and in the thesis, never "gold", "ground truth" or
   "answer key". **Lead with the pair-level results** (wrongly excluded, rescued, wrongly included, sent
   to review): they are judged against the dataset's own Eligible / Not Eligible labels
   (lung-cancer set: assigned by clinicians and epidemiologists; SIGIR: the collection's assessors). Results on your labels (the first column of Table 1, and Tables 3–5) come
   second, with this caveat.
10. **Report rule-level results twice:** on all your labelled rows, and without the rows whose comment
    starts with `UNSURE:` (Section 6.3, rule 2). Say how many rows were UNSURE. Give rule accuracy
    (Table 1) and checker quality (Table 3) both ways; for Tables 4 and 5, check that the conclusion
    stays the same without those rows and say so in one sentence. To make the second labels file:

    ```python
    import pandas as pd
    d = pd.read_csv("../labelling/my_labels_final.csv", encoding="utf-8-sig")
    unsure = d["comment"].fillna("").astype(str).str.strip().str.upper().str.startswith("UNSURE")
    d[~unsure].to_csv("../labelling/my_labels_without_unsure.csv", index=False, encoding="utf-8-sig")
    print(int(unsure.sum()), "UNSURE rows left out")
    ```

    Then run the same `evaluate.py criterion` and `evaluate.py verification` commands with
    `--gold ../labelling/my_labels_without_unsure.csv`. Do the same for your SIGIR labels.

---

## 15. Timeline

The mid-term is in about five weeks. If yours is sooner, keep the order and move the week-5 items to
Phase 2 — the **minimum mid-term** is marked ★.

### Phase 1 — to the mid-term (lung-cancer set only)

| week | tasks | done when |
|---|---|---|
| 1 | ★ Setup; self-test passes; read Sections 1–6; practice labelling; ★ label the 10 development pairs (190 rows) | `36 passed`; development rows have no empty `truth` |
| 2 | ★ Plain AI and forced guess on the development trials (main model); score them; ★ check 1 and θ | Table 1 (dev) |
| 3 | Rule statements for the 95 development rules, hand-checked; checks 2, 3 and 4 with unit tests | tests 1–12 written, deterministic ones pass |
| 4 | Checks 5 and 6; labels; ★ checker on the development answers; ★ label the 10 test pairs and freeze all labels; label check sent; ★ strategies `random`, `least_confident`, `fewest_reasons` | Table 3 (dev); first order files |
| 5 | ★ First K1 comparison (Table 2, dev); first traps (3 types, about 10 cases each); ★ mid-term slides | first Tables 2 and 6 (dev) |

**Mid-term must-show list** (★ items):

- the problem and your question (Section 1)
- your checker diagram (checks → label → priority ranking → person / fixer)
- your labels: counts, and the label-check result
- Table 1 on the development trials, **including how many wrongful exclusions rest on a single rule**
- first checker results (Table 3, dev)
- the first strategy comparison or at least the order files and the method (Section 9.3)
- your hypotheses K1–K6 and the plan to the final

### Phase 2 — to the final (both datasets)

| week | tasks | done when |
|---|---|---|
| 6–7 | `flagged_first` and `combined`; remove-one-check analysis; full trap set; fixer on development answers | development Tables 2–6 |
| 8 | **Freeze** (commit, record hash). Rule statements for test rules (no edits). **Run the test trials once:** systems, checker, strategies, fixer | test Tables 1–5 |
| 9 | Rejection-risk list (dev, then test); receive the SIGIR pack; label your SIGIR pairs and freeze | Table 7; SIGIR labels frozen |
| 10–11 | SIGIR: systems, checker, strategies on development patients; then **test patients once** | Table 8 |
| 12 | Your own checker-style labels on 100 answers (Section 18) and the agreement with the checker; rarity re-weighting | agreement table |
| 13 | Optional extras (Section 18), only if everything above is done | — |
| 14–16 | 20 worked examples; write-up; final slides | thesis draft; final talk |

### Final presentation outline (15–18 slides)

1. The problem: 3,000 answers, one wrong "not met" is enough
2. Your question: which answers should a person check?
3. What others do (Section 2.4) and what is new
4. Data: two datasets, your labels, agreement, label check
5. The checker: six checks, one label (with an example)
6. Table 1: how often a single answer decides a rejection
7. Strategy curve (Table 2) — the headline
8. Checker quality and which checks matter (Tables 3–4)
9. Traps (Table 6)
10. Fixes: what they fix and what they break (Table 5)
11. The rejection-risk list (Table 7)
12. Lung-cancer vs SIGIR (Table 8)
13. Limits: small data, simulated checks, labels by one person, label-implied rescues
14. What a coordinator would see: "check these two answers first"
15. Conclusions and next steps

---

## 16. Rules you must follow

1. **Build on development data; test once.** Freeze (commit + hash) before any test run. Change nothing
   after seeing test results.
2. **Use `criteria.csv`.** Never split the raw rule text yourself.
3. **Inclusion/exclusion logic lives in code** (`map_truth`), never in a prompt.
4. **A failed model call is not an answer.** Retry; if it still fails the run is INCOMPLETE and is not
   evaluated. Never write a failed call as `unknown`. (`llm_client.py` and `plain_ai.py` do this.)
5. **Never cut the note or the rule** to fit a prompt. Raise the context size instead.
6. **Cache on the full prompt** (`llm_client.py` does this).
7. **Give every system the rule's `note`** when it is not empty, as the GUIDANCE line.
8. **Never drop a difficult, failed or unreadable row.** Keep it, flag it, count it.
9. **Model output is never an answer key.** Nothing a system produced goes into your labels.
10. **Your strategies never read the answer key.** Only the scoring does.
11. **Traps only from development pairs.**
12. **Fixes change system answers, never your labels.**
13. **Report datasets separately.** Lung-cancer: unit = trial for comparisons. SIGIR: unit = patient.
14. **Local tools only** for lab data; no credentials in code, notebooks, logs or git.
15. **A negative result is a result.** Never change the test set, the measure or a strategy to make
    your method win.

---

## 17. Common mistakes

1. **Flagging everything** and calling it high recall.
2. **Treating every `unknown` as an error.** The notes are short; `unknown` is often right.
3. **Counting only the fixes** of the fixer and forgetting the breaks.
4. **Letting a strategy peek at the labels** (for example ordering by "is this answer wrong?").
5. **Checking the altered trap note against `nsclc100.csv`** instead of the note in `traps.jsonl`.
6. **Using the same model as the only judge of its own answers.** Prefer a different model for the AI
   judge.
7. **A historical mention is not always an error** — "history of…" rules need it.
8. **Forgetting the label-implied rule** in the targeting simulation when you explain your numbers:
   rescues on unlabelled pairs assume the Eligible label is right.
9. **Reporting the 3B debugging model** as a main result.

---

## 18. Optional extras (only after everything else)

- **Your own checker-style labels.** Before looking at the checker's output on them, label 100 plain-AI
  answers from your labelled pairs (all wrong answers plus a random sample of right ones, seed 7) with
  the seven labels of Section 8.8. Save `labelling/support_labels.csv`
  (`pair_idx, crit_idx, support_label, reason`) and pass it to
  `evaluate.py verification --support ...` to report how often you and the checker agree.
- **A learned priority score.** Train a logistic regression (scikit-learn, class-weighted) on
  development answers to predict "this answer is a wrong 'not met' on an eligible pair", using the
  check results, `sole_reason`, the number of failing rules, and the confidence. Use it as the
  `learned` strategy on test trials.
- **Learning from mistakes.** Improve the plain-AI prompt from errors on some development trials and
  test on the others. Always compare with simply making the system more lenient — otherwise fewer
  wrongful exclusions may just mean more wrongful inclusions.

---

## 19. Suggested code layout

```
akash/
  statements.py          # rule statements + key terms (frozen)
  check_quote.py         # check 1: exact + rapidfuzz, theta from configs/checker.yaml
  check_support.py       # check 2: option A cross-encoder / option B AI judge
  check_context.py       # check 3: medspaCy ConText
  check_logic.py         # check 4: consistency, numbers, AI judge
  check_contradiction.py # check 5
  check_missed.py        # check 6
  label.py               # fixed order -> checker_result
  priority.py            # Part B strategies -> order CSVs
  risk_list.py           # Part C
  fixer.py               # Part D: keep / flag / re-ask
  traps/build_traps.py   # Part E
  run_checker.py         # --system ... --split dev|test
  tests/test_checker.py  # the 15 cases in Section 8.9
configs/
  checker.yaml           # theta, tau, support option, prompt ids - frozen before the test run
  prompts/
outputs/                 # decision records, checks, orders, traps, results
```

---

## 20. References (open each one before citing it)

- Jin Q. et al. Matching patients to clinical trials with large language models (TrialGPT). *Nature
  Communications* 15, 9074 (2024). https://github.com/ncbi-nlp/TrialGPT
- Zhou Z. et al. Accountable AI with Grounded, Faithful, Consistent, Actionable Rationales: A Case Study
  in Clinical Trial Matching with VERDICT. arXiv:2609.03366 (2026).
- Qu B., Ranaldi L., Wang X., Valentino M. Neurosymbolic Clinical Trial Matching via LLM-Driven
  Abduction and Logical Verification. arXiv:2606.20895 (2026).
- Badshah S., Emami A., Sajjad H. Judge, Retrieve, or Abstain: Uncertainty-Guarded LLM Judging with
  Provable Risk Guarantees. arXiv:2608.17994 (2026).
- Kim et al. arXiv:2506.07962 (2025) — correlated errors across language models.
- NLI4CT: SemEval-2024 Task 2. https://github.com/ai-systems/Task-2-SemEval-2024 · arXiv:2404.04963.
- medspaCy: https://github.com/medspacy/medspacy (MIT) · RapidFuzz: https://github.com/rapidfuzz/RapidFuzz (MIT)
- `cross-encoder/nli-deberta-v3-base`: https://huggingface.co/cross-encoder/nli-deberta-v3-base (Apache-2.0)
- Leon Tramontini D., Ghosh S., Eickhoff C. Investigating RAG-based Approaches in Clinical Trial and
  Patient Matching. ML4H, PMLR 297:76–87.
- PhysioNet. Use of MIMIC Data with Large Language Models and Online Services (24 September 2025).
  https://physionet.org/news/post/llm-responsible-use/
- Tools: Ollama (https://github.com/ollama/ollama), scikit-learn.
